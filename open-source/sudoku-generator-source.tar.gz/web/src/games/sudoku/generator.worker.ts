import { generate, logic, type Difficulty, type Mode } from './generator.ts'
import type { SumClue } from '../../vendor/qqwing/qqwing.js'

type Request =
  | { mode: Mode; difficulty: Difficulty; hint?: undefined }
  | { hint: true; entries: number[]; clues: SumClue[]; difficulty: Difficulty }

self.onmessage = (e: MessageEvent<Request>) => {
  try {
    const req = e.data
    if (req.hint) {
      self.postMessage({ type: 'hint', steps: logic(req.entries, req.clues, req.difficulty).steps })
      return
    }
    const puzzle = generate(req.mode, req.difficulty, (attempt) => {
      if (attempt % 5 === 0) self.postMessage({ type: 'progress', attempt })
    })
    self.postMessage({ type: 'ready', puzzle })
  } catch {
    self.postMessage({ type: 'error' })
  }
}
