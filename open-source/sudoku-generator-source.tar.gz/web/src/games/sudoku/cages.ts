/** Orthogonally connected groups; ordinary Sudoku rules determine repeated digits. */
export function neighbors(cell: number): number[] {
  return [cell % 9 > 0 ? cell - 1 : -1, cell % 9 < 8 ? cell + 1 : -1, cell >= 9 ? cell - 9 : -1, cell < 72 ? cell + 9 : -1].filter((p) => p >= 0)
}
export function connected(cells: number[]): boolean {
  const reached = new Set([cells[0]!])
  for (const cell of reached) for (const next of neighbors(cell)) if (cells.includes(next)) reached.add(next)
  return reached.size === cells.length
}
export function bent(cells: number[]): boolean {
  return new Set(cells.map((p) => Math.floor(p / 9))).size > 1 && new Set(cells.map((p) => p % 9)).size > 1
}
