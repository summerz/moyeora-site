// UI 와 생성 Worker 가 함께 쓰는 값. QQWing 을 가져오지 않는다 (화면 코드는 generator.ts 를 값으로 가져오지 말 것).
export type Mode = 'classic' | 'sum'
export type Difficulty = 1 | 2 | 3
export const DIFFICULTIES = [{ value: 1, label: '하' }, { value: 2, label: '중' }, { value: 3, label: '상' }] as const
export const MODES = [{ value: 'classic', label: '기본' }, { value: 'sum', label: '플러스' }] as const
export const MIN_SUM_CLUES = 9
export const MAX_SUM_CLUES = 12
