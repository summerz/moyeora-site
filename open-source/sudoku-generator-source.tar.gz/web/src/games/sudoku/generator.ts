import QQWing, { type LogicResult, type SumClue } from '../../vendor/qqwing/qqwing.js'
import { bent, neighbors } from './cages.ts'
import { MAX_SUM_CLUES, MIN_SUM_CLUES, type Difficulty, type Mode } from './levels.ts'

export type { Difficulty, Mode }

export type Puzzle = {
  id: string; mode: Mode; difficulty: Difficulty; givens: number[]; solution: number[]; clues: SumClue[]
}
const shapes: number[][] = []
let previous = Array.from({ length: 81 }, (_, cell) => [cell])
for (let size = 2; size <= 4; size++) {
  const next = new Map<string, number[]>()
  for (const cells of previous) for (const cell of cells) for (const neighbor of neighbors(cell)) {
    if (cells.includes(neighbor)) continue
    const shape = [...cells, neighbor].sort((a, b) => a - b)
    next.set(shape.join(','), shape)
  }
  previous = [...next.values()]
  shapes.push(...previous)
}
function shuffle<T>(items: T[]): T[] {
  const result = [...items]
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[result[i], result[j]] = [result[j]!, result[i]!]
  }
  return result
}
const parse = (s: string) => [...s.trim()].map((c) => c === '.' ? 0 : Number(c))
export function solver(grid: number[]) {
  const q = new QQWing()
  q.setPrintStyle(QQWing.PrintStyle.ONE_LINE)
  q.setPuzzle(grid)
  return q
}
export function logic(grid: number[], clues: SumClue[], tier: Difficulty): LogicResult {
  return solver(grid).solveLogically(clues, tier)
}
export function rate(givens: number[], clues: SumClue[]): Difficulty | null {
  for (const tier of [1, 2, 3] as const) if (logic(givens, clues, tier).solved) return tier
  return null
}
const score = (s: LogicResult) => s.filled * 1000 - s.candidateCount

/** Unlock logical progress, then add a varied, disjoint set of helpful groups. */
export function addSumClues(givens: number[], solution: number[], tier: Difficulty): SumClue[] | null {
  const clues: SumClue[] = []
  const q = solver(givens)
  let state = q.solveLogically(clues, tier)
  const eligible = shapes.filter((cells) => cells.every((p) => !givens[p]))
  const makeClue = (cells: number[]): SumClue => ({ cells, sum: cells.reduce((n, p) => n + solution[p]!, 0) })
  while (!state.solved && clues.length < MIN_SUM_CLUES) {
    const used = new Set(clues.flatMap((h) => h.cells))
    let best: { clue: SumClue; state: LogicResult } | null = null
    const candidates = shuffle(eligible.filter((cells) => cells.every((p) => !state.grid[p] && !used.has(p)))).slice(0, 100)
    for (const cells of candidates) {
      const clue = makeClue(cells)
      const trial = q.solveLogically([...clues, clue], tier)
      if (trial.valid && score(trial) > score(state) && (!best || score(trial) > score(best.state))) best = { clue, state: trial }
    }
    if (!best) return null
    clues.push(best.clue)
    state = best.state
  }
  if (!state.solved || state.grid.some((v, i) => v !== solution[i])) return null
  const target = Math.min(MAX_SUM_CLUES, Math.max(MIN_SUM_CLUES, 14 - tier * 2) + Math.floor(Math.random() * 2))
  const used = new Set(clues.flatMap((h) => h.cells))
  // Prioritize missing sizes and bent groups before filling remaining space.
  while (clues.length < target) {
    const sizes = new Set(clues.map((h) => h.cells.length))
    const hasBend = clues.some((h) => bent(h.cells))
    const choices = shuffle(eligible.filter((cells) => cells.every((p) => !used.has(p))))
      .sort((a, b) => Number(!sizes.has(b.length) || (!hasBend && bent(b))) - Number(!sizes.has(a.length) || (!hasBend && bent(a))))
    if (!choices.length) break
    const cells = choices[0]!
    clues.push(makeClue(cells))
    cells.forEach((p) => used.add(p))
  }
  if (clues.length < MIN_SUM_CLUES || new Set(clues.map((h) => h.cells.length)).size !== 3 || !clues.some((h) => bent(h.cells))) return null
  return clues
}

/** Runs inside a terminable worker. Unique puzzles stay within their logical technique ceiling. */
export function generate(mode: Mode, difficulty: Difficulty, progress?: (attempt: number) => void): Puzzle {
  for (let attempt = 1; attempt <= 350; attempt++) {
    progress?.(attempt)
    const q = solver(Array(81).fill(0))
    if (!q.generatePuzzle()) continue
    const givens = parse(q.getPuzzleString())
    q.setRecordHistory(true)
    if (!q.solve()) continue
    if (q.getDifficulty() !== (mode === 'sum' ? 4 : difficulty)) continue
    const solution = parse(q.getSolutionString())
    const clues = mode === 'sum' ? addSumClues(givens, solution, difficulty) : []
    if (!clues || (mode === 'classic' ? rate(givens, clues) !== difficulty : !logic(givens, clues, difficulty).solved) || solver(givens).countSolutions() !== 1) continue
    return { id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, mode, difficulty, givens, solution, clues }
  }
  throw new Error('난이도에 맞는 문제를 만들지 못했어요')
}
