/** 순서 셔플 → 자리 잡기 → 선공 알림까지의 공통 시작 연출 시간. */
export const ORDER_INTRO_MS = 3500
