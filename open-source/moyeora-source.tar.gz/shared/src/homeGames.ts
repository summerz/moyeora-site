import cfg from './home-games.json' with { type: 'json' }

/** 홈 목록·게임 켜고 끄기 설정 (shared/src/home-games.json). 서버와 웹이 같은 파일을 읽는다. */
export const HOME_CONFIG: { order: readonly string[]; hidden: readonly string[]; off: readonly string[] } = cfg

/** off = 일시 중단: 홈에서 빠지고 서버가 방 만들기·참가를 막는다 */
export const isOff = (id: string, c = HOME_CONFIG) => c.off.includes(id)
/** 홈에 보이는가 (hidden·off 는 안 보임. hidden 은 주소로 들어가면 동작) */
export const isListed = (id: string, c = HOME_CONFIG) => !c.hidden.includes(id) && !c.off.includes(id)
