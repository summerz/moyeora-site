import type { ClientMessage } from './messages.ts'

const validName = (v: unknown) => typeof v === 'string' && v.length >= 1 && v.length <= 20
const validAvatar = (v: unknown) => typeof v === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(v)
const validCode = (v: unknown) => typeof v === 'string' && /^[0-9]{6}$/.test(v)

export function isClientMessage(x: unknown): x is ClientMessage {
  if (typeof x !== 'object' || x === null) return false
  const m = x as Record<string, unknown>
  switch (m.type) {
    case 'create':
      return Number.isInteger(m.v) && (m.game === 'sus-jar' || m.game === 'who-picked' || m.game === 'ladder' || m.game === 'liar' || m.game === 'nunchi' || m.game === 'stopwatch' || m.game === 'pirate' || m.game === 'juice' || m.game === 'gobble' || m.game === 'othello' || m.game === 'burger' || m.game === 'plate' || m.game === 'marbles') && validName(m.name) && validAvatar(m.avatar)
    case 'join':
      return Number.isInteger(m.v) && validCode(m.code) && validName(m.name) && validAvatar(m.avatar)
    case 'resume':
      return Number.isInteger(m.v) && validCode(m.code) && typeof m.token === 'string' && m.token.length >= 1 && m.token.length <= 64
    case 'start':
    case 'leave':
    case 'lobby':
    case 'addBot':
      return true
    case 'submit':
      return typeof m.choice === 'string'
    case 'kick':
      return typeof m.playerId === 'string' && m.playerId.length >= 1 && m.playerId.length <= 64
    case 'config':
      return typeof m.config === 'object' && m.config !== null
    case 'aim':
      return typeof m.angle === 'number' && Number.isFinite(m.angle) && Math.abs(m.angle) <= 1e6
    default:
      return false
  }
}
