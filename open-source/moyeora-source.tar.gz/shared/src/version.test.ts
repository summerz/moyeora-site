import { test } from 'node:test'
import assert from 'node:assert/strict'
import { MIN_PROTOCOL, PROTOCOL, compareVersions, helloFor, protocolError, skewOf } from './version.ts'

test('protocolError: 현재·허용 범위는 통과', () => {
  assert.equal(protocolError({ type: 'create', v: PROTOCOL }), null)
  assert.equal(protocolError({ type: 'join', v: MIN_PROTOCOL }), null)
  assert.equal(protocolError({ type: 'start' }), null)
  assert.equal(protocolError({ type: 'resume', v: PROTOCOL }), null)
  assert.equal(protocolError({ type: 'resume' }), 'update required')
  assert.equal(protocolError('x'), null)
})

test('protocolError: 너무 낡았거나 v 가 없으면 update required', () => {
  assert.equal(protocolError({ type: 'create', v: 0 }), 'update required')
  assert.equal(protocolError({ type: 'join' }), 'update required')
  assert.equal(protocolError({ type: 'create', v: '1' }), 'update required')
  assert.equal(protocolError({ type: 'create', v: 1.5 }), 'update required')
})

test('protocolError: 클라이언트가 더 새로우면 server old', () => {
  assert.equal(protocolError({ type: 'create', v: PROTOCOL + 1 }), 'server old')
})

test('skewOf: 어느 쪽이 낡았나', () => {
  assert.equal(skewOf(2, { protocol: 2, min: 1 }), 'ok')
  assert.equal(skewOf(1, { protocol: 3, min: 2 }), 'client-old')
  assert.equal(skewOf(3, { protocol: 2, min: 1 }), 'server-old')
})

test('helloFor', () => {
  assert.deepEqual(helloFor('0.7.0'), { type: 'hello', protocol: PROTOCOL, min: MIN_PROTOCOL, version: '0.7.0' })
})

test('compareVersions', () => {
  assert.equal(compareVersions('0.7.0', '0.7.0'), 0)
  assert.ok(compareVersions('0.7.1', '0.7.0')! > 0)
  assert.ok(compareVersions('0.7.9', '0.10.0')! < 0)
  assert.ok(compareVersions('1.0.0', '0.99.99')! > 0)
  assert.equal(compareVersions('x', '0.7.0'), null)
})
