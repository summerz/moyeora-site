/** Shared fixed-step Rapier simulation. Only this subpath loads WASM; other games stay light. */
import RAPIER from '@dimforge/rapier3d-compat'
import {
  MARBLES,
  STICK_COLORS,
  type MarbleBoard,
  type MarblePose,
  type MarbleStick,
} from './marbles.ts'
const ready = RAPIER.init()
export const initMarblePhysics = () => ready
export type MarbleFrame = { ms: number; balls: MarblePose[] }
export type MarbleMotion = {
  board: MarbleBoard
  fallen: number[]
  frames: MarbleFrame[]
  hits: number[]
}
const step = 1 / 60
function worldFor(board: MarbleBoard) {
  const world = new RAPIER.World({ x: 0, y: -9.81, z: 0 })
  world.timestep = step
  world.numSolverIterations = 8
  // Open-bottom tube, convex wall segments rather than a solid cylinder.
  for (let i = 0; i < 40; i++) {
    const a = (i * Math.PI * 2) / 40
    const b = world.createRigidBody(
      RAPIER.RigidBodyDesc.fixed()
        .setTranslation(Math.cos(a) * 1.21, 1.9, Math.sin(a) * 1.21)
        .setRotation({ x: 0, y: Math.sin(-a / 2), z: 0, w: Math.cos(-a / 2) }),
    )
    world.createCollider(RAPIER.ColliderDesc.cuboid(0.065, 2.2, 0.105).setFriction(0.25), b)
  }
  const sticks = new Map<number, RAPIER.RigidBody>()
  for (const s of board.sticks) {
    const b = world.createRigidBody(
      RAPIER.RigidBodyDesc.kinematicPositionBased()
        .setTranslation(s.x, s.y, s.z)
        .setRotation({ x: s.dz / Math.SQRT2, y: 0, z: -s.dx / Math.SQRT2, w: Math.SQRT1_2 }),
    )
    world.createCollider(RAPIER.ColliderDesc.capsule(s.half, 0.055).setFriction(0.42), b)
    sticks.set(s.id, b)
  }
  const balls = new Map<number, RAPIER.RigidBody>()
  for (const p of board.balls) {
    const b = world.createRigidBody(
      RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(p.x, p.y, p.z)
        .setRotation({ x: p.qx, y: p.qy, z: p.qz, w: p.qw })
        .setCcdEnabled(true)
        .setLinearDamping(0.24)
        .setAngularDamping(0.5),
    )
    world.createCollider(
      RAPIER.ColliderDesc.ball(MARBLES.radius)
        .setRestitution(0.13)
        .setFriction(0.32)
        .setActiveEvents(RAPIER.ActiveEvents.COLLISION_EVENTS),
      b,
    )
    balls.set(p.id, b)
  }
  return { world, sticks, balls }
}
function poses(board: MarbleBoard, bodies: Map<number, RAPIER.RigidBody>): MarblePose[] {
  return board.balls.map((p) => {
    const b = bodies.get(p.id)!,
      t = b.translation(),
      q = b.rotation()
    return { ...p, x: t.x, y: t.y, z: t.z, qx: q.x, qy: q.y, qz: q.z, qw: q.w }
  })
}
export function makeMarbleBoard(rng: () => number): MarbleBoard {
  const sticks: MarbleStick[] = []
  const start = rng() * Math.PI
  for (let layer = 0; layer < 4; layer++) {
    for (let j = 0; j < 6; j++) {
      const a = start + (layer * Math.PI) / 2 + (layer < 2 ? 0 : (rng() - 0.5) * 1.4)
      const dx = Math.cos(a),
        dz = Math.sin(a)
      const off = (j - 2.5) * 0.35
      sticks.push({
        id: sticks.length,
        color: (j + layer * 2) % STICK_COLORS.length,
        y: 0.28 + layer * 0.23 + (layer < 2 ? 0 : rng() * 0.12),
        x: -dz * off,
        z: dx * off,
        dx,
        dz,
        half: Math.sqrt(MARBLES.tubeRadius ** 2 - off ** 2) + 0.78,
      })
    }
  }
  const balls: MarblePose[] = []
  // Eight per layer, no initial intersections. Server sends these settled values to clients.
  for (let i = 0; i < MARBLES.balls; i++) {
    const a = ((i % 8) * Math.PI) / 4 + ((Math.floor(i / 8) % 2) * Math.PI) / 8
    balls.push({
      id: i,
      color: Math.floor(rng() * 6),
      x: Math.cos(a) * 0.65,
      z: Math.sin(a) * 0.65,
      y: 1.65 + Math.floor(i / 8) * 0.43,
      qx: 0,
      qy: 0,
      qz: 0,
      qw: 1,
    })
  }
  const board = { sticks, balls }
  const { world, balls: bodies } = worldFor(board)
  try {
    for (let i = 0; i < 240; i++) world.step()
    return { sticks, balls: poses(board, bodies) }
  } finally {
    world.free()
  }
}
export function simulateMarblePull(
  board: MarbleBoard,
  stickId: number,
  record = true,
): MarbleMotion {
  const rod = board.sticks.find((s) => s.id === stickId)
  if (!rod) throw new Error('bad choice')
  const { world, sticks, balls } = worldFor(board)
  const queue = new RAPIER.EventQueue(true)
  const pulled = sticks.get(stickId)!
  const fallen = new Set<number>(),
    frames: MarbleFrame[] = [],
    hits: number[] = []
  let removed = false,
    lastHit = -200
  try {
    if (record) frames.push({ ms: 0, balls: poses(board, balls) })
    for (let i = 1; i <= MARBLES.motionMs / 1000 / step; i++) {
      const ms = i * step * 1000
      if (!removed) {
        const u = Math.min(1, ms / MARBLES.pullMs)
        const distance = u * 3.4
        pulled.setNextKinematicTranslation({
          x: rod.x + rod.dx * distance,
          y: rod.y,
          z: rod.z + rod.dz * distance,
        })
        if (u === 1) {
          world.removeRigidBody(pulled)
          removed = true
        }
      }
      world.step(queue)
      queue.drainCollisionEvents((_a, _b, started) => {
        if (record && started && ms > 100 && ms - lastHit > 170 && hits.length < 16) {
          hits.push(ms)
          lastHit = ms
        }
      })
      for (const [id, b] of balls) if (b.translation().y < MARBLES.fallY) fallen.add(id)
      if (record && i % 2 === 0) frames.push({ ms, balls: poses(board, balls) })
    }
    return {
      board: {
        sticks: board.sticks.filter((s) => s.id !== stickId),
        balls: poses(board, balls).filter((p) => !fallen.has(p.id)),
      },
      fallen: [...fallen].sort((a, b) => a - b),
      frames,
      hits,
    }
  } finally {
    queue.free()
    world.free()
  }
}
