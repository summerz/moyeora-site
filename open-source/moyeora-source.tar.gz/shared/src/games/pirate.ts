/** 꽂아! 펑! 해적!: 시간·구멍 수는 서버와 화면이 같이 쓴다. */
export const PIRATE = { chooseMs: 10_000, settleMs: 350, maxRounds: 40 } as const

/** 안 터진 칼이 꽂힌 뒤 다음 사람 차례가 시작되기까지 잠깐 쉬는 시간(ms). 이 동안 차례 표시는 방금 꽂은 사람에게 남는다 */
export const TURN_GAP_MS = 1000

/** 함정을 꽂은 뒤 연출 시간(ms). 모든 폰이 'pop(done) 갱신이 도착한 때'부터 같은 순서로 보여 준다: 쇼케이스(통 돌리기+칼 꽂힘) → 가만히 1초(holdMs, 해적은 반응 없이 얼굴만 정면으로) → 부들부들 → 잠깐 멈춤 → 펑!(발사)
 *  펑! 시점 = showMs + holdMs + shiverMs + freezeMs. 결과 모달은 펑! 뒤 발사 연출이 끝나야 뜬다. 서버는 done 뒤 아무것도 자동으로 하지 않으므로(deadline=null) 서버 쪽 대기는 필요 없다 */
export const POP_TIMING = { showMs: 750, holdMs: 1000, shiverMs: 1200, freezeMs: 120, reducedBoomMs: 400 } as const
export const popBoomAtMs = (reduced: boolean): number => (reduced ? POP_TIMING.reducedBoomMs : POP_TIMING.showMs + POP_TIMING.holdMs + POP_TIMING.shiverMs + POP_TIMING.freezeMs)

/** 인원별 구멍 수: 2–3명 12, 4–5명 16, 6–8명 20 */
export const holesFor = (players: number): number => (players <= 3 ? 12 : players <= 5 ? 16 : 20)

/** auto: 시간 초과로 서버가 대신 꽂은 칼 */
export type PirateUsed = { hole: number; by: string; auto?: boolean }

/** trap 은 해적이 튀어나온 뒤(popped)에만 채워진다. 그 전에는 누구에게도 null. */
export type PirateView = {
  holes: number
  used: PirateUsed[]
  /** 차례 순서(플레이어 id) */
  order: string[]
  /** 마지막으로 꽂은 사람. 다음 차례 = turnOf(order, last, 방에 있는 사람) */
  last: string | null
  /** 방금 꽂은 칼이 자리 잡는 중 (꽂은 직후 ~ 다음 차례 시작 전). 이때는 못 누르고 차례 표시는 last(방금 꽂은 사람)에 남는다 */
  settling: boolean
  popped: boolean
  trap: number | null
  loser: string | null
}
export type PirateReveal = { hole: number; by: string; pop: boolean; trap: number | null; loser: string | null }

/** 지금 꽂을 차례: last 다음부터 order 를 돌며 방에 남아 있는 첫 사람. 없으면 null. */
export const turnOf = (order: readonly string[], last: string | null, present: readonly string[]): string | null => {
  const start = last === null ? 0 : order.indexOf(last) + 1
  for (let i = 0; i < order.length; i++) {
    const id = order[(start + i) % order.length]!
    if (present.includes(id)) return id
  }
  return null
}

/** 통 구멍 배치: 행마다 구멍 수. 행이 홀수 번째면 반 칸 어긋난다. 3D 통과 서버가 같은 표를 쓴다 */
export const PIRATE_ROWS: Record<number, number[]> = { 12: [4, 4, 4], 16: [5, 6, 5], 20: [7, 6, 7] }

/** hole 번 구멍의 둘레 각(phi). phi=0 이 정면 */
export const holePhi = (hole: number, total: number): number => {
  let h = hole
  const rows = PIRATE_ROWS[total] ?? PIRATE_ROWS[12]!
  for (let r = 0; r < rows.length; r++) {
    const n = rows[r]!
    if (h < n) return (2 * Math.PI * (h + (r % 2 ? 0.5 : 0))) / n
    h -= n
  }
  return 0
}

/** 통 각도를 [0, 2π) 로 맞춘다 (서버가 받은 aim 을 정규화) */
export const normAngle = (a: number): number => ((a % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)

/** 남은 구멍 안내 한 줄 (왼쪽 N개 / 전체 total). 화면 맨 위 차례 카드 아래에 그대로 쓴다 */
export const holesComment = (left: number, total: number): string => {
  if (left <= 0) return '구멍이 다 찼어요'
  if (left === 1) return '마지막 1개… 펑 확정!'
  if (left === 2) return '남은 구멍 2개! 반반이에요!'
  if (left === 3) return '남은 구멍 3개! 여기서 피한다고요?!'
  if (left <= 5) return `남은 구멍 ${left}개. 손에 땀이…`
  if (left > total * 0.6) return `남은 구멍 ${left}개. 아직 널널하죠.`
  return `남은 구멍 ${left}개. 슬슬 긴장되죠?`
}

/** hole 번 구멍이 정면을 보는 통 각도 (three.js spin.rotation.y: 구멍의 화면 각 = phi + 통 각도). 서버·3D 화면이 같이 쓴다 */
export const frontAngleFor = (hole: number, total: number): number => normAngle(-holePhi(hole, total))
