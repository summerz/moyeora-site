import { test } from 'node:test'
import assert from 'node:assert/strict'
import { frontAngleFor, holePhi, holesComment, holesFor, POP_TIMING, popBoomAtMs, turnOf } from './pirate.ts'

test('holesFor: 2–3명 12, 4–5명 16, 6–8명 20', () => {
  assert.deepEqual([2, 3, 4, 5, 6, 7, 8].map(holesFor), [12, 12, 16, 16, 20, 20, 20])
})

test('turnOf: last 다음 사람, 나간 사람은 건너뜀, 아무도 없으면 null', () => {
  const o = ['a', 'b', 'c']
  assert.equal(turnOf(o, null, o), 'a')
  assert.equal(turnOf(o, 'a', o), 'b')
  assert.equal(turnOf(o, 'c', o), 'a')
  assert.equal(turnOf(o, 'a', ['a', 'c']), 'c')
  assert.equal(turnOf(o, 'b', ['a', 'b']), 'a')
  assert.equal(turnOf(o, 'a', []), null)
})

test('holesComment: 남은 수에 따라 한 줄', () => {
  assert.equal(holesComment(10, 12), '남은 구멍 10개. 아직 널널하죠.')
  assert.equal(holesComment(7, 12), '남은 구멍 7개. 슬슬 긴장되죠?')
  assert.equal(holesComment(5, 12), '남은 구멍 5개. 손에 땀이…')
  assert.equal(holesComment(3, 12), '남은 구멍 3개! 여기서 피한다고요?!')
  assert.equal(holesComment(2, 12), '남은 구멍 2개! 반반이에요!')
  assert.equal(holesComment(1, 12), '마지막 1개… 펑 확정!')
  assert.match(holesComment(20, 20), /널널/)
  assert.match(holesComment(12, 20), /긴장/)
})

const TAU = 2 * Math.PI

test('holePhi: 행마다 반 칸 어긋나고, 0번은 정면', () => {
  assert.equal(holePhi(0, 12), 0)
  assert.ok(Math.abs(holePhi(4, 12) - TAU / 8) < 1e-9) // 둘째 행 첫 구멍 = 반 칸(4개 행)
  assert.ok(Math.abs(holePhi(5, 16) - TAU / 12) < 1e-9) // 16: [5,6,5], 둘째 행(6칸) 첫 구멍은 반 칸
  assert.ok(Math.abs(holePhi(7, 20) - TAU / 12) < 1e-9) // 20: [7,6,7]
})

test('frontAngleFor: 3D 통 규칙(구멍의 화면 각 = phi + 통 각도)으로 정면이 된다', () => {
  for (const n of [2, 4, 6, 8]) {
    const total = holesFor(n)
    for (let h = 0; h < total; h++) {
      const a = frontAngleFor(h, total)
      assert.ok(a >= 0 && a < TAU)
      assert.ok(Math.abs(Math.sin(holePhi(h, total) + a)) < 1e-9)
      assert.ok(Math.cos(holePhi(h, total) + a) > 0.999999)
    }
  }
})

test('POP_TIMING: 펑! 시점 = 쇼케이스 + 가만히 + 부들부들 + 멈춤, 모션 줄이기는 짧게', () => {
  assert.equal(popBoomAtMs(false), POP_TIMING.showMs + POP_TIMING.holdMs + POP_TIMING.shiverMs + POP_TIMING.freezeMs)
  assert.ok(popBoomAtMs(true) < popBoomAtMs(false))
  assert.equal(POP_TIMING.holdMs, 1000)
})
