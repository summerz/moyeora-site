import assert from 'node:assert/strict'
import { test } from 'node:test'
import { emptyPlate, isPlatePosition, parsePlatePosition, pickPlateSnack, PLATE, PLATE_FRAME_MS, plateSlot, simulatePlate, SNACK_KINDS, SNACKS, type SnackKind } from './plate.ts'

test('무게는 음식마다 고정되고, 각 무게에 5종씩 남은 음식이 모두 추첨된다', () => {
  assert.equal(SNACK_KINDS.length, 20)
  for (const weight of [1, 2, 3, 4]) assert.equal(SNACK_KINDS.filter((kind) => SNACKS[kind].weight === weight).length, 5)
  for (let turn = 1; turn <= PLATE.maxTurns; turn++) {
    const minimum = Math.min(4, 1 + Math.floor((turn - 1) / 8))
    const seen = new Set<SnackKind>()
    for (let weightDraw = 0; weightDraw < 1000; weightDraw++) for (let kindDraw = 0; kindDraw < 5; kindDraw++) {
      let call = 0
      const kind = pickPlateSnack(turn, () => call++ === 0 ? weightDraw / 1000 : kindDraw / 5)
      assert.ok(SNACKS[kind].weight >= minimum, `${turn}/${kind}`)
      seen.add(kind)
    }
    assert.deepEqual([...seen].sort(), SNACK_KINDS.filter((kind) => SNACKS[kind].weight >= minimum).sort())
  }
})
test('가장 가벼운 무게의 확률은 8차례에 걸쳐 서서히 줄어든다', () => {
  const count = (turn: number, weight: number) => {
    let n = 0
    for (let draw = 0; draw < 1000; draw++) {
      let call = 0
      const kind = pickPlateSnack(turn, () => call++ === 0 ? draw / 1000 : 0)
      if (SNACKS[kind].weight === weight) n++
    }
    return n
  }
  for (const weight of [1, 2, 3]) {
    const first = 1 + (weight - 1) * 8
    assert.ok(count(first, weight) > count(first + 3, weight))
    assert.ok(count(first + 3, weight) > count(first + 7, weight))
    assert.equal(count(first + 8, weight), 0)
  }
})

test('첫 간식은 종류와 위치에 관계없이 안전하다', () => {
  for (const kind of SNACK_KINDS) for (let slot = 0; slot < 8; slot++) {
    const before = emptyPlate()
    const motion = simulatePlate(before, kind, plateSlot(slot), 1)
    assert.equal(motion.spilled, false, `${kind}/${slot}`)
    assert.deepEqual(before, emptyPlate(), '입력 상태를 바꾸지 않는다')
    assert.equal(motion.frames.length, 1 + Math.round(PLATE.motionMs / PLATE_FRAME_MS))
    assert.ok(motion.frames[0]!.items[0]!.y > 2)
    assert.equal(motion.board.items[0]!.y, 0)
  }
})
test('양쪽으로 나누면 한쪽에 몰아놓는 것보다 오래 버틴다', () => {
  const countUntilSpill = (opposite: boolean) => {
    let board = emptyPlate()
    for (let id = 1; id <= 32; id++) {
      const motion = simulatePlate(board, 'donut', plateSlot(opposite ? (id % 2) * 4 : 0), id, false)
      if (motion.spilled) return id
      board = motion.board
    }
    return 33
  }
  assert.ok(countUntilSpill(true) > countUntilSpill(false) + 3)
})
test('서버의 결과 계산과 브라우저의 궤적은 동일하고, 다시 계산해도 동일하다', () => {
  const before = simulatePlate(emptyPlate(), 'melon', plateSlot(1), 1).board
  const browser = simulatePlate(before, 'pudding', plateSlot(2), 2)
  const server = simulatePlate(before, 'pudding', plateSlot(2), 2, false)
  assert.deepEqual(browser.board, server.board)
  assert.equal(browser.spilled, server.spilled)
  assert.deepEqual(browser, simulatePlate(before, 'pudding', plateSlot(2), 2))
  assert.equal(server.frames.length, 0)
})
test('새 간식이 착지하기 전에는 기존 간식과 접시가 움직이지 않는다', () => {
  let before = emptyPlate()
  for (let id = 1; id <= 6; id++) before = simulatePlate(before, 'cookie', plateSlot(id % 8), id, false).board
  const motion = simulatePlate(before, 'sandwich', plateSlot(1), 7)
  for (let index = 0; index * PLATE_FRAME_MS < PLATE.dropMs; index++) {
    const frame = motion.frames[index]!
    assert.deepEqual(frame.items.slice(0, -1), before.items)
    assert.equal(frame.tiltX, before.tiltX)
    assert.equal(frame.tiltZ, before.tiltZ)
    assert.equal(frame.velocityX, before.velocityX)
    assert.equal(frame.velocityZ, before.velocityZ)
  }
  assert.notEqual(motion.frames[Math.ceil(PLATE.dropMs / PLATE_FRAME_MS)]!.velocityX, before.velocityX)
})
test('겹친 간식은 순간이동하지 않고 속도를 얻어 밀리다가 멈춘다', () => {
  const point = plateSlot(0)
  const before = simulatePlate(emptyPlate(), 'cookie', point, 1).board
  const motion = simulatePlate(before, 'cookie', point, 2)
  assert.equal(motion.spilled, false)
  const landed = motion.frames[Math.ceil(PLATE.dropMs / PLATE_FRAME_MS)]!.items[0]!
  assert.ok(Math.hypot(landed.vx, landed.vz) > 0.1)
  for (let index = 1; index < motion.frames.length; index++) {
    const old = motion.frames[index - 1]!.items[0]!, next = motion.frames[index]!.items[0]!
    assert.ok(Math.hypot(next.x - old.x, next.z - old.z) < 0.06)
  }
  assert.ok(Math.hypot(motion.board.items[0]!.vx, motion.board.items[0]!.vz) < 0.025)
  assert.ok(Math.hypot(motion.board.items[0]!.x - point.x, motion.board.items[0]!.z - point.z) > 0.2)
})
test('같은 위치의 충돌·가득 찬 접시·추락에도 유한한 좌표를 유지한다', () => {
  let board = emptyPlate()
  let spilled = false
  for (let id = 1; id <= 32; id++) {
    const motion = simulatePlate(board, SNACK_KINDS[id % SNACK_KINDS.length]!, plateSlot(0), id, false)
    for (const i of motion.board.items) for (const value of [i.x,i.y,i.z,i.vx,i.vz]) assert.ok(Number.isFinite(value))
    board = motion.board
    if (motion.spilled) { spilled = true; assert.ok(motion.spillAtMs! > PLATE.dropMs); break }
  }
  assert.equal(spilled, true)
})
test('반대 번호는 정확히 반대 위치이고, 무거운 쪽으로 접시가 기운다', () => {
  for (let i = 0; i < 4; i++) {
    const a = plateSlot(i), b = plateSlot(i + 4)
    assert.ok(Math.hypot(a.x + b.x, a.z + b.z) < 1e-12)
  }
  const b = simulatePlate(emptyPlate(), 'cookie', plateSlot(0), 1).board
  assert.ok(b.tiltX < 0 && b.tiltZ > 0)
})

test('자유 좌표도 같은 물리 판정을 쓰고, 허용 띠의 첫 간식은 안전하다', () => {
  for (const kind of SNACK_KINDS) for (const radius of [PLATE.placementInner, PLATE.slotRadius, PLATE.placementOuter]) for (let step = 0; step < 48; step++) {
    const angle = step * Math.PI / 24
    const point = { x: Math.sin(angle) * radius, z: Math.cos(angle) * radius }
    const motion = simulatePlate(emptyPlate(), kind, point, 1, false)
    assert.equal(motion.spilled, false, `${kind}/${radius}/${step}`)
    assert.ok(Math.hypot(motion.board.items[0]!.x - point.x, motion.board.items[0]!.z - point.z) < 0.02)
  }
})
test('좌표 입력은 유한한 숫자와 허용 띠를 검사한다', () => {
  for (const p of [{x: 0, z: 0}, {x: 2.5, z: 0}, {x: Infinity, z: 1.5}, {x: NaN, z: 1.5}, {x: '1.5', z: 0}, null]) assert.equal(isPlatePosition(p), false)
  for (const c of ['0', 'null', '{}', '{"x":1.5}', '{"x":1.5,"z":"0"}', '{"x":1e309,"z":0}', 'not json', ' '.repeat(101)]) assert.equal(parsePlatePosition(c), null)
  assert.deepEqual(parsePlatePosition('{"x":1.413,"z":0.619}'), {x: 1.413, z: 0.619})
})
