export const WHO_PICKED_OPTIONS = ['a', 'b', 'c', 'd'] as const
export type WhoPickedOption = (typeof WHO_PICKED_OPTIONS)[number]
export const WHO_PICKED_PACKS = ['all', 'family', 'friends'] as const
export type WhoPickedPack = (typeof WHO_PICKED_PACKS)[number]
export type WhoPickedConfig = { pack: WhoPickedPack }
export type WhoPickedStep = 'pick' | 'guess'
export type WhoPickedView = {
  pack: WhoPickedPack
  /** 1..questions, 로비 0 */
  question: number
  questions: number
  step: WhoPickedStep | null
  text: string | null
  /** 4개 또는 [] */
  options: string[]
  /** guess 단계(및 그 뒤 reveal)에서 pickers>=3 일 때만, 길이 4 */
  counts: number[] | null
  /** guess 단계부터 내 pick */
  myPick: WhoPickedOption | null
  /** pick 한 플레이어 id, players 순서. pick 단계에서는 [] */
  pickers: string[]
}
export type WhoPickedAnswer = { id: string; pick: WhoPickedOption | null; delta: number; score: number; guessedBy: string[]; hidden: boolean }
export type WhoPickedReveal =
  | { step: 'pick'; counts: number[] | null; pickers: string[] }
  | { step: 'guess'; answers: WhoPickedAnswer[] }
