export const LADDER_ROWS = 12
export const LADDER_ROUNDS = 3
export type Slot = { g: number; r: number } // g = gap index 0..n-2 (between column g and g+1), r = row 0..11 top→bottom
export type Rung = Slot & { o: number } // o = owner seat index (0..n-1), -1 = system
export type Collision = { seats: number[]; slots: Slot[] } // one explosion group
export type RoundResult = { placed: Rung[]; collisions: Collision[] }
export type LadderItem = { name: string; count: number }
export type LadderRecord = {
  v: 1
  at: string // ISO time
  players: { name: string; avatar: string; bot: boolean }[] // index = seat = start column
  items: string[] // bottom label per column
  system: Slot[]
  rounds: RoundResult[]
}

export function blocked(rungs: Slot[], s: Slot): boolean {
  return rungs.some((x) => x.r === s.r && Math.abs(x.g - s.g) <= 1)
}

export function validSlot(n: number, rungs: Slot[], s: Slot): boolean {
  return (
    Number.isInteger(s.g) && Number.isInteger(s.r) &&
    s.g >= 0 && s.g <= n - 2 && s.r >= 0 && s.r < LADDER_ROWS &&
    !blocked(rungs, s)
  )
}

const bySlot = (a: Slot, b: Slot) => a.r - b.r || a.g - b.g

export function resolveRound(picks: { seat: number; slot: Slot }[]): RoundResult {
  const parent = picks.map((_, i) => i)
  const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])))
  for (let i = 0; i < picks.length; i++)
    for (let j = i + 1; j < picks.length; j++) {
      const a = picks[i].slot, b = picks[j].slot
      if (a.r === b.r && Math.abs(a.g - b.g) <= 1) parent[find(i)] = find(j)
    }
  const groups = new Map<number, number[]>()
  picks.forEach((_, i) => {
    const k = find(i)
    groups.set(k, [...(groups.get(k) ?? []), i])
  })
  const placed: Rung[] = []
  const collisions: Collision[] = []
  for (const idx of groups.values()) {
    if (idx.length === 1) {
      const p = picks[idx[0]]
      placed.push({ g: p.slot.g, r: p.slot.r, o: p.seat })
    } else {
      collisions.push({
        seats: idx.map((i) => picks[i].seat).sort((a, b) => a - b),
        slots: idx.map((i) => ({ g: picks[i].slot.g, r: picks[i].slot.r })).sort(bySlot),
      })
    }
  }
  placed.sort(bySlot)
  collisions.sort((a, b) => bySlot(a.slots[0], b.slots[0]))
  return { placed, collisions }
}

// path = [(start,-1), then for each crossing (from col,r),(to col,r), then (end,LADDER_ROWS)]
export function walk(n: number, rungs: Slot[], start: number): { end: number; path: { col: number; r: number }[] } {
  const path = [{ col: start, r: -1 }]
  let c = start
  for (let r = 0; r < LADDER_ROWS; r++) {
    let to = c
    if (rungs.some((x) => x.r === r && x.g === c - 1)) to = c - 1
    else if (rungs.some((x) => x.r === r && x.g === c)) to = c + 1
    if (to !== c && to >= 0 && to < n) {
      path.push({ col: c, r }, { col: to, r })
      c = to
    }
  }
  path.push({ col: c, r: LADDER_ROWS })
  return { end: c, path }
}

export function allRungs(rec: LadderRecord): Slot[] {
  return [...rec.system, ...rec.rounds.flatMap((x) => x.placed.map(({ g, r }) => ({ g, r })))]
}

export function finalEnds(rec: LadderRecord): number[] {
  const n = rec.players.length
  const rungs = allRungs(rec)
  return rec.players.map((_, i) => walk(n, rungs, i).end)
}

const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
export function ladderId(sig: Uint8Array): string {
  let bits = 0n
  for (let i = 0; i < 5; i++) bits = (bits << 8n) | BigInt(sig[i])
  let s = ''
  for (let i = 7; i >= 0; i--) s += CROCKFORD[Number((bits >> BigInt(i * 5)) & 31n)]
  return `${s.slice(0, 4)}-${s.slice(4)}`
}

export function b64url(bytes: Uint8Array): string {
  let bin = ''
  for (const b of bytes) bin += String.fromCharCode(b)
  return btoa(bin).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '')
}

export function fromB64url(s: string): Uint8Array {
  if (!/^[A-Za-z0-9_-]*$/.test(s) || s.length % 4 === 1) throw new Error('bad base64url')
  const bin = atob(s.replaceAll('-', '+').replaceAll('_', '/'))
  return Uint8Array.from(bin, (ch) => ch.charCodeAt(0))
}

export function encodeRecord(rec: LadderRecord): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(rec))
}

const isInt = (x: unknown, lo: number, hi: number): x is number =>
  typeof x === 'number' && Number.isInteger(x) && x >= lo && x <= hi

function shapeOk(rec: any): rec is LadderRecord {
  if (!rec || typeof rec !== 'object' || rec.v !== 1 || typeof rec.at !== 'string') return false
  if (!Array.isArray(rec.players) || !Array.isArray(rec.items) || !Array.isArray(rec.system) || !Array.isArray(rec.rounds)) return false
  const n = rec.players.length
  if (n < 2 || n > 8 || rec.items.length !== n || rec.rounds.length > LADDER_ROUNDS) return false
  const slotOk = (s: any) => !!s && isInt(s.g, 0, n - 2) && isInt(s.r, 0, LADDER_ROWS - 1)
  // 서버가 허용하는 길이까지만 (이름 20자, 항목 12자). 진짜 기록이 거부되지 않게 서버 검증보다 엄격하게 하지 않는다
  const text = (s: unknown, max: number) => typeof s === 'string' && s.length >= 1 && s.length <= max
  if (rec.at.length > 40) return false
  if (!rec.players.every((p: any) => p && text(p.name, 20) && typeof p.avatar === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(p.avatar) && typeof p.bot === 'boolean')) return false
  if (!rec.items.every((x: unknown) => text(x, 12))) return false
  if (!rec.system.every(slotOk)) return false
  return rec.rounds.every(
    (rd: any) =>
      rd && Array.isArray(rd.placed) && Array.isArray(rd.collisions) &&
      rd.placed.every((p: any) => slotOk(p) && isInt(p.o, -1, n - 1)) &&
      rd.collisions.every(
        (c: any) => c && Array.isArray(c.seats) && Array.isArray(c.slots) &&
          c.seats.every((s: unknown) => isInt(s, 0, n - 1)) && c.slots.every(slotOk),
      ),
  )
}

export function parseLink(hash: string): { bytes: Uint8Array; sig: Uint8Array; record: LadderRecord } | null {
  try {
    const parts = hash.replace(/^#/, '').split('.')
    if (parts.length !== 2) return null
    const bytes = fromB64url(parts[0])
    const sig = fromB64url(parts[1])
    if (sig.length !== 64) return null
    const record = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes))
    return shapeOk(record) ? { bytes, sig, record } : null
  } catch {
    return null
  }
}

export const LADDER_PASS = 'pass'
export type LadderConfig = { items: LadderItem[] }
export type LadderSeat = { id: string; name: string; avatar: string; bot: boolean }
export type LadderBoard = { n: number; seats: LadderSeat[]; items: string[]; system: Slot[]; rounds: RoundResult[] } // seat index = start column; rounds = revealed so far
export type LadderView = { config: LadderConfig | null; total: number; board: LadderBoard | null; mySeat: number | null; link: string | null; id: string | null }
export type LadderReveal = { round: number; result: RoundResult; link: string | null; id: string | null } // link/id only on the last round
export const slotKey = (s: Slot) => `${s.g}-${s.r}` // choice string sent by clients
export function parseSlotKey(v: string): Slot | null {
  const m = /^(\d)-(\d{1,2})$/.exec(v)
  return m ? { g: Number(m[1]), r: Number(m[2]) } : null
}
