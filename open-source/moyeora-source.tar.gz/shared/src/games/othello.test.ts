import { test } from 'node:test'
import assert from 'node:assert/strict'
import { othelloCount, othelloFlips, othelloInitialBoard, othelloTargets, type OthelloBoard } from './othello.ts'

test('중앙 네 돌과 흑·백의 첫 선택지', () => {
  const b = othelloInitialBoard(['A', 'B'])
  assert.equal(b.length, 64)
  assert.equal(othelloCount(b, 'A'), 2)
  assert.equal(othelloCount(b, 'B'), 2)
  assert.deepEqual(othelloTargets(b, 'A'), [19, 26, 37, 44])
  assert.deepEqual(othelloTargets(b, 'B'), [20, 29, 34, 43])
  assert.deepEqual(othelloFlips(b, 'A', 19), [27])
})

test('가로·세로·대각선의 모든 끼인 돌을 한 번에 뒤집는다', () => {
  const b: OthelloBoard = Array(64).fill(null)
  const adjacent = [18, 19, 20, 26, 28, 34, 35, 36]
  for (const i of adjacent) b[i] = 'B'
  for (const i of [9, 11, 13, 25, 29, 41, 43, 45]) b[i] = 'A'
  assert.deepEqual(othelloFlips(b, 'A', 27).sort((a, c) => a - c), adjacent)
})

test('빈칸·내 돌을 건너뛰거나 행의 끝에서 다음 행으로 넘어가지 않는다', () => {
  const b: OthelloBoard = Array(64).fill(null)
  b[8] = 'B'; b[9] = 'A'
  assert.deepEqual(othelloFlips(b, 'A', 7), [])
  b[1] = 'A'; b[2] = 'B'; b[3] = 'A'
  assert.deepEqual(othelloFlips(b, 'A', 0), [])
  b[1] = 'B'; b[2] = null
  assert.deepEqual(othelloFlips(b, 'A', 0), [])
  for (const to of [-1, 64, 1.5, NaN, 1]) assert.deepEqual(othelloFlips(b, 'A', to), [])
})
