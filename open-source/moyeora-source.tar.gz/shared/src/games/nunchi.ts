/** 눈치 게임: 타이밍 상수는 서버와 화면이 같이 쓴다. */
export const NUNCHI = { rounds: 10, readyMs: 3000, tapMs: 10000, collideMs: 350, graceMs: 1200, revealMs: 3000 } as const

/** 방장이 대기실에서 고르는 라운드 수. 기본은 NUNCHI.rounds */
export const NUNCHI_ROUNDS = [5, 10] as const
export type NunchiConfig = { rounds: (typeof NUNCHI_ROUNDS)[number] }

/** 실제 눈치 게임처럼 고유어로 부른다(최대 8명). 카운트다운 3·2·1만 숫자 */
export const NUNCHI_CALLS = ['하나', '둘', '셋', '넷', '다섯', '여섯', '일곱', '여덟'] as const
export const callOf = (n: number): string => NUNCHI_CALLS[n - 1] ?? String(n)

export type NunchiResult = 'first' | 'safe' | 'collide' | 'last' | 'foul'
/** n = 묶음 번호(1부터). 같은 묶음이면 겹침 */
export type NunchiTap = { id: string; n: number; collided: boolean }
export type NunchiView = { taps: NunchiTap[]; fouls: string[] }
export type NunchiReveal = { rows: { id: string; n: number | null; result: NunchiResult; delta: number; score: number }[] }
