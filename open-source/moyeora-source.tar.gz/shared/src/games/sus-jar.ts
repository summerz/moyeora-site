export const SUS_JAR_CHOICES = ['drink', 'pass', 'antidote'] as const
export type SusJarChoice = (typeof SUS_JAR_CHOICES)[number]
export type SusJarContent = 'juice' | 'poison'
export type SusJarTag = 'gold' | 'nocure'
export type SusJarPayouts = {
  drink: { juice: number; poison: number; saved: number }
  antidote: { poison: number; juice: number }
  pass: number
  noChoice: number
}
export type SusJarReveal = {
  content: SusJarContent
  tag: SusJarTag | null
  double: boolean
  antidoteIn: boolean
  players: { id: string; choice: SusJarChoice | null; delta: number; score: number }[]
}
export type SusJarView = { odds: number | null; tag: SusJarTag | null; double: boolean; payouts: SusJarPayouts | null; choices: string[] }
