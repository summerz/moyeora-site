import { ORDER_INTRO_MS } from '../orderIntro.ts'

export const GOBBLE = { introMs: ORDER_INTRO_MS, chooseMs: 90_000, settleMs: 500, gapMs: 650, resultMs: 5500, maxMoves: 80 } as const
export type GobbleConfig = { bestOf: 1 | 3 | 5 }
export const gobbleWinsNeeded = (bestOf: GobbleConfig['bestOf']) => (bestOf + 1) / 2
export type GobbleSize = 1 | 2 | 3
export type GobblePiece = { id: string; owner: string; size: GobbleSize }
export type GobbleMove = { piece: string; to: number }
export type GobbleLast = GobbleMove & { by: string; from: number | null; covered: boolean; auto: boolean }
export type GobbleView = {
  board: (GobblePiece | null)[]; reserve: GobblePiece[]; order: string[]; turn: string | null
  ply: number; last: GobbleLast | null; settling: boolean; winner: string | null
  line: number[]; draw: boolean; bestOf: GobbleConfig['bestOf']; gameNo: number
}
export type GobbleReveal = { last: GobbleLast | null; winner: string | null; draw: boolean }
export const GOBBLE_LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]] as const
export const gobbleLine = (board: (GobblePiece | null)[], owner: string): number[] => {
  const line = GOBBLE_LINES.find((l) => l.every((i) => board[i]?.owner === owner))
  return line ? [...line] : []
}
export const gobbleTargets = (board: (GobblePiece | null)[], piece: GobblePiece): number[] =>
  board.flatMap((top, i) => top?.id !== piece.id && (!top || top.size < piece.size) ? [i] : [])
export const gobblePieces = (order: string[]): GobblePiece[] => order.flatMap((owner, side) =>
  ([1, 2, 3] as const).flatMap((size) => [0, 1].map((copy) => ({ id: `${side}-${size}-${copy}`, owner, size }))))
