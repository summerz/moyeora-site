import { test } from 'node:test'
import assert from 'node:assert/strict'
import { decoyTicks, digitOpacity, mulberry32 } from './stopwatch.ts'

test('digitOpacity: T>=3초면 1초까지 선명, 1→2초 선형, 이후 0', () => {
  for (const T of [3000, 5000, 10000]) {
    assert.equal(digitOpacity(0, T), 1)
    assert.equal(digitOpacity(999, T), 1)
    assert.ok(Math.abs(digitOpacity(1500, T) - 0.5) < 1e-9)
    assert.equal(digitOpacity(2000, T), 0)
    assert.equal(digitOpacity(9000, T), 0)
  }
})

test('digitOpacity: 짧은 목표는 T/3, 2T/3 (1초 → 0.33~0.67초)', () => {
  assert.equal(digitOpacity(333, 1000), 1)
  assert.ok(Math.abs(digitOpacity(500, 1000) - 0.5) < 1e-9)
  assert.equal(digitOpacity(667, 1000), 0)
})

test('mulberry32/decoyTicks: 같은 시드는 같은 박자, 틱은 단조 증가, 박자 ±8%', () => {
  const a = mulberry32(7), b = mulberry32(7)
  assert.deepEqual([a(), a(), a()], [b(), b(), b()])
  let prev = 0
  for (let t = 0; t <= 20000; t += 100) {
    const k = decoyTicks(t, 1000, 42)
    assert.ok(k >= prev)
    prev = k
  }
  assert.ok(decoyTicks(10000, 1000, 42) >= 9 && decoyTicks(10000, 1000, 42) <= 10 + 1)
  assert.equal(decoyTicks(900, 1000, 42), 0)
  assert.equal(decoyTicks(1100, 1000, 42), 1)
})
