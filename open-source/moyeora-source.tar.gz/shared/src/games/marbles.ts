export const MARBLES = {
  chooseMs: 20_000,
  motionMs: 6000,
  gapMs: 700,
  pullMs: 650,
  rods: 24,
  balls: 32,
  radius: 0.18,
  tubeRadius: 1.16,
  fallY: -0.65,
} as const
export const STICK_COLORS = ['#8f241b', '#95650f', '#203841'] as const
export const GLASS_COLORS = [
  '#52bfff',
  '#ffab58',
  '#e97cff',
  '#59d2a3',
  '#ff718b',
  '#b8b1ff',
] as const
export type MarblePose = {
  id: number
  color: number
  x: number
  y: number
  z: number
  qx: number
  qy: number
  qz: number
  qw: number
}
export type MarbleStick = {
  id: number
  color: number
  y: number
  x: number
  z: number
  dx: number
  dz: number
  half: number
}
export type MarbleBoard = { sticks: MarbleStick[]; balls: MarblePose[] }
export type MarblePull = {
  id: number
  by: string
  stick: number
  before: MarbleBoard
  startedAt: number
  auto: boolean
  fallen: number[]
}
export type MarblesView = {
  board: MarbleBoard
  order: string[]
  last: string | null
  event: MarblePull | null
  elapsedMs: number
  settling: boolean
}
export type MarblesReveal = { game: 'marbles'; by: string; fallen: number; auto: boolean }
export const emptyMarbles = (): MarbleBoard => ({ sticks: [], balls: [] })
export const parseStick = (s: string): number | null =>
  /^(0|[1-9][0-9]?)$/.test(s) && Number(s) < MARBLES.rods ? Number(s) : null
