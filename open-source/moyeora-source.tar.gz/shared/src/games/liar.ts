export const LIAR_HANDS = 3
export type LiarStep = 'talk' | 'vote' | 'guess'
/** 단계별 선택 시간(ms). talk 는 한 사람당(상한 = 이 값 × 인원, liarChooseMs). */
export const LIAR_CHOOSE_MS: Record<LiarStep, number> = { talk: 60_000, vote: 30_000, guess: 20_000 }
/** 단계의 전체 선택 시간. talk 는 인원수만큼 곱한다. 서버와 웹 타이머가 같이 쓴다. */
export const liarChooseMs = (step: LiarStep, players: number): number => LIAR_CHOOSE_MS[step] * (step === 'talk' ? players : 1)
/** 지금 말할 차례: order 에서 아직 말 안 했고 방에 남아 있는 첫 사람. 모두 끝났으면 null. */
export const currentSpeaker = (order: readonly string[], spoke: readonly string[], present: readonly string[]): string | null =>
  order.find((id) => !spoke.includes(id) && present.includes(id)) ?? null
export const LIAR_OPTION_COUNT = 8

export type LiarView = {
  /** 1..hands, 로비 0 */
  hand: number
  hands: number
  step: LiarStep | null
  category: string | null
  /** 라이어가 아닌 사람에게만(맞히기 공개 뒤엔 모두에게). 라이어는 공개 전까지 null */
  word: string | null
  /** 내가 이번 판 라이어인가 (본인에게만 true) */
  isLiar: boolean
  /** 투표 공개 뒤부터 모두에게. 그 전엔 null */
  liar: string | null
  /** 말하는 순서(플레이어 id) */
  order: string[]
  /** 시작 사람(라이어 아님) */
  starter: string | null
  /** 이번 판 talk 에서 발언을 끝낸 사람(id). 지금 차례는 currentSpeaker(order, spoke, 방에 있는 사람) */
  spoke: string[]
  /** 맞히기 단계의 라이어에게만, 8개 */
  options: string[] | null
}
export type LiarVote = { id: string; by: string[] }
export type LiarPlayerDelta = { id: string; delta: number; score: number }
export type LiarReveal =
  | { step: 'talk' }
  | { step: 'vote'; liar: string; caught: boolean; votes: LiarVote[]; deltas: number[] }
  | { step: 'guess'; liar: string; word: string; guess: string | null; correct: boolean; players: LiarPlayerDelta[] }
