import assert from 'node:assert/strict'
import { test } from 'node:test'
import { MARBLES, parseStick } from './marbles.ts'
import { initMarblePhysics, makeMarbleBoard, simulateMarblePull } from './marblePhysics.ts'
await initMarblePhysics()
const random = (seed: number) => () => {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0
  return seed / 2 ** 32
}
test('막대 번호는 실제 정수 범위만 허용한다', () => {
  for (let id = 0; id < MARBLES.rods; id++) assert.equal(parseStick(String(id)), id)
  for (const value of ['24', '-1', '01', '1e1', '0.0', '', 'NaN', ' 1', '1 '])
    assert.equal(parseStick(value), null)
})
test('다양한 배치에서 시작 구슬 32개가 모두 통 안의 막대에 지지된다', () => {
  for (let seed = 1; seed <= 40; seed++) {
    const board = makeMarbleBoard(random(seed))
    assert.equal(board.sticks.length, 24)
    assert.equal(board.balls.length, 32)
    assert.ok(
      board.balls.every(
        (p) => Number.isFinite(p.y) && p.y > 0.3 && Math.hypot(p.x, p.z) < MARBLES.tubeRadius,
      ),
    )
    assert.deepEqual(board, makeMarbleBoard(random(seed)))
  }
})
test('서버 결과와 재접속·브라우저 재생 결과가 같고 입력 상태를 바꾸지 않는다', () => {
  const board = makeMarbleBoard(random(7)),
    saved = structuredClone(board)
  const client = simulateMarblePull(board, 20),
    server = simulateMarblePull(board, 20, false)
  assert.deepEqual(client.board, server.board)
  assert.deepEqual(client.fallen, server.fallen)
  assert.deepEqual(client, simulateMarblePull(board, 20))
  assert.deepEqual(board, saved)
  assert.equal(server.frames.length, 0)
  assert.equal(client.frames[0]!.ms, 0)
  assert.equal(client.frames.at(-1)!.ms, MARBLES.motionMs)
  assert.throws(() => simulateMarblePull(client.board, 20), /bad choice/)
})
test('모든 막대를 제거하면 구슬 32개가 중복 없이 떨어지며 보존된다', () => {
  for (const seed of [1, 3, 9]) {
    let board = makeMarbleBoard(random(seed))
    const fallen = new Set<number>()
    const order = [...board.sticks]
      .sort((a, b) => ((a.id * 7) % 24) - ((b.id * 7) % 24))
      .map((s) => s.id)
    for (const id of order) {
      const before = board.balls.length,
        motion = simulateMarblePull(board, id, false)
      for (const ball of motion.fallen) {
        assert.equal(fallen.has(ball), false)
        fallen.add(ball)
      }
      board = motion.board
      assert.equal(board.balls.length + motion.fallen.length, before)
      assert.ok(board.balls.every((p) => p.y >= -0.65))
    }
    assert.equal(board.balls.length, 0)
    assert.equal(fallen.size, 32)
  }
})
