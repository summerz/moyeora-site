/** 접시는 한 번 놓을 때만 고정 간격으로 계산한다. 렌더링 FPS·네트워크 속도는 결과에 영향을 주지 않는다. */
export const PLATE = { radius: 2.5, slotRadius: 1.55, placementInner: 1.2, placementOuter: 1.85, openingMs: 4000, chooseMs: 20_000, dropMs: 360, motionMs: 3000, gapMs: 450, maxTurns: 32 } as const
export const SNACKS = {
  cookie: { name: '쿠키', weight: 1, radius: 0.32, color: '#dba267' },
  donut: { name: '도넛', weight: 2, radius: 0.38, color: '#f4a5b8' },
  pudding: { name: '푸딩', weight: 3, radius: 0.34, color: '#ffe295' },
  melon: { name: '수박', weight: 4, radius: 0.4, color: '#ef786f' },
  macaron: { name: '마카롱', weight: 1, radius: 0.3, color: '#ad97e2' },
  strawberry: { name: '딸기', weight: 1, radius: 0.32, color: '#e96a72' },
  cake: { name: '케이크', weight: 3, radius: 0.38, color: '#fff1d5' },
  sandwich: { name: '샌드위치', weight: 4, radius: 0.4, color: '#e4b77e' },
  chocolate: { name: '초콜릿', weight: 1, radius: 0.33, color: '#805644' },
  pretzel: { name: '프레첼', weight: 1, radius: 0.34, color: '#dba267' },
  waffle: { name: '와플', weight: 2, radius: 0.37, color: '#edbe64' },
  croissant: { name: '크루아상', weight: 2, radius: 0.34, color: '#edbe64' },
  bungeoppang: { name: '붕어빵', weight: 2, radius: 0.45, color: '#dba267' },
  orange: { name: '귤', weight: 2, radius: 0.32, color: '#f5a147' },
  rollcake: { name: '롤케이크', weight: 3, radius: 0.39, color: '#edbe64' },
  cupcake: { name: '컵케이크', weight: 3, radius: 0.32, color: '#f4a5b8' },
  icecream: { name: '아이스크림', weight: 3, radius: 0.46, color: '#a4d2b1' },
  pizza: { name: '피자', weight: 4, radius: 0.42, color: '#ffe295' },
  hotdog: { name: '핫도그', weight: 4, radius: 0.39, color: '#d86b60' },
  onigiri: { name: '삼각김밥', weight: 4, radius: 0.36, color: '#fff7df' },
} as const
export type SnackKind = keyof typeof SNACKS
export const SNACK_KINDS = Object.keys(SNACKS) as SnackKind[]
const SNACK_WEIGHTS = [1, 2, 3, 4] as const
const snacksByWeight = SNACK_WEIGHTS.map((weight) => SNACK_KINDS.filter((kind) => SNACKS[kind].weight === weight))
/** 8차례에 걸쳐 가장 가벼운 무게의 확률을 줄인다. 9/17/25번째부터 무게 1/2/3은 나오지 않는다. */
export function pickPlateSnack(turn: number, rng: () => number): SnackKind {
  const chances = SNACK_WEIGHTS.map((weight) => weight === 4 ? 1 : Math.max(0, 1 - Math.max(0, turn - 1 - (weight - 1) * 8) / 8))
  let draw = rng() * chances.reduce((sum, chance) => sum + chance, 0)
  let tier = chances.length - 1
  for (let i = 0; i < chances.length; i++) {
    draw -= chances[i]!
    if (draw < 0) { tier = i; break }
  }
  const kinds = snacksByWeight[tier]!
  return kinds[Math.floor(rng() * kinds.length)]!
}
export type PlateItem = { id: number; kind: SnackKind; x: number; z: number; y: number; vx: number; vz: number; fall: number | null }
export type PlateBoard = { items: PlateItem[]; tiltX: number; tiltZ: number; velocityX: number; velocityZ: number }
export type PlatePosition = { x: number; z: number }
export type PlateDrop = { id: number; by: string; kind: SnackKind; position: PlatePosition; before: PlateBoard; startedAt: number; auto: boolean }
export type PlateView = { board: PlateBoard; order: string[]; last: string | null; snack: SnackKind; event: PlateDrop | null; elapsedMs: number; openingMs: number; settling: boolean; loser: string | null; saved: boolean }
export type PlateReveal = { game: 'plate'; by: string; spilled: boolean; auto: boolean }
export const emptyPlate = (): PlateBoard => ({ items: [], tiltX: 0, tiltZ: 0, velocityX: 0, velocityZ: 0 })
/** NPC·자동 놓기의 8개 후보. 카메라 정면은 +z, 첫 후보는 왼쪽 위. */
export function plateSlot(slot: number) {
  const angle = -3 * Math.PI / 4 - slot * Math.PI / 4
  return { x: Math.sin(angle) * PLATE.slotRadius, z: Math.cos(angle) * PLATE.slotRadius }
}
export function isPlatePosition(value: unknown): value is PlatePosition {
  if (!value || typeof value !== 'object') return false
  const p = value as Partial<PlatePosition>
  if (typeof p.x !== 'number' || typeof p.z !== 'number' || !Number.isFinite(p.x) || !Number.isFinite(p.z)) return false
  const radius = Math.hypot(p.x, p.z)
  return radius >= PLATE.placementInner && radius <= PLATE.placementOuter
}
/** 소켓의 공용 문자열 제출 안에 접시 좌표 한 쌍만 담는다. */
export function parsePlatePosition(choice: string): PlatePosition | null {
  if (choice.length > 100) return null
  try {
    const p: unknown = JSON.parse(choice)
    return isPlatePosition(p) ? { x: p.x, z: p.z } : null
  } catch { return null }
}
const copy = (b: PlateBoard): PlateBoard => ({ ...b, items: b.items.map((x) => ({ ...x })) })
const clamp = (x: number, limit: number) => Math.max(-limit, Math.min(limit, x))
export type PlateMotion = { frames: PlateBoard[]; board: PlateBoard; spilled: boolean; spillAtMs: number | null }
export const PLATE_FRAME_MS = 1000 / 60

/** 질량에 의한 토크 + 감쇠 스프링 + 마찰 + 원 충돌. 모두 접시 좌표로 계산한다. */
export function simulatePlate(before: PlateBoard, kind: SnackKind, position: PlatePosition, id: number, captureFrames = true): PlateMotion {
  const b = copy(before)
  const fresh: PlateItem = { id, kind, ...position, y: 2.3, vx: 0, vz: 0, fall: null }
  b.items.push(fresh)
  const frames: PlateBoard[] = captureFrames ? [copy(b)] : []
  const dt = 1 / 60
  let spillAtMs: number | null = null
  let landed = false
  // 탄성 단계는 새 간식이 닿는 순간에만 올라간다. 선택 중에는 물리를 계산하지 않는다.
  let bounce = Math.min(Math.max(0, before.items.length - 1) / (PLATE.maxTurns - 1), 1)
  for (let step = 1; step <= PLATE.motionMs / PLATE_FRAME_MS; step++) {
    const ms = step * PLATE_FRAME_MS
    if (!landed && ms >= PLATE.dropMs) {
      landed = true
      fresh.y = 0
      bounce = Math.min((b.items.length - 1) / (PLATE.maxTurns - 1), 1)
      const impact = 0.11 + bounce * 0.025
      b.velocityX += position.z * SNACKS[kind].weight * impact
      b.velocityZ -= position.x * SNACKS[kind].weight * impact
    } else if (!landed) {
      fresh.y = 2.3 * (1 - (ms / PLATE.dropMs) ** 2)
      // 기존 접시는 착지 전까지 직전의 정지 상태를 유지한다. 탄성 변화로 먼저 움직이지 않는다.
      if (captureFrames) frames.push(copy(b))
      continue
    }
    const onPlate = b.items.filter((x) => x.fall === null && (x !== fresh || landed))
    let momentX = 0, momentZ = 0, mass = 0
    for (const item of onPlate) {
      const w = SNACKS[item.kind].weight
      momentX += w * item.z
      momentZ -= w * item.x
      mass += w
    }
    const inertia = 1.8 + mass * 0.09
    const damping = 8 - bounce * 1.8
    b.velocityX += (momentX - 30 * b.tiltX - damping * b.velocityX) / inertia * dt
    b.velocityZ += (momentZ - 30 * b.tiltZ - damping * b.velocityZ) / inertia * dt
    b.tiltX = clamp(b.tiltX + b.velocityX * dt, 0.72)
    b.tiltZ = clamp(b.tiltZ + b.velocityZ * dt, 0.72)
    // 양의 X 회전은 +z 쪽을 내리고, 양의 Z 회전은 +x 쪽을 올린다.
    const gx = -9.8 * Math.sin(b.tiltZ), gz = 9.8 * Math.sin(b.tiltX)
    const slope = Math.hypot(gx, gz)
    for (const item of onPlate) {
      const speed = Math.hypot(item.vx, item.vz)
      if (speed < 0.025 && slope < 3.1) { item.vx = 0; item.vz = 0; continue }
      item.vx += gx * dt; item.vz += gz * dt
      const nextSpeed = Math.hypot(item.vx, item.vz)
      const friction = Math.max(0, 1 - 2.8 * dt / Math.max(nextSpeed, 0.00001))
      item.vx *= friction; item.vz *= friction
      item.x += item.vx * dt; item.z += item.vz * dt
    }
    for (let i = 0; i < onPlate.length; i++) for (let j = i + 1; j < onPlate.length; j++) {
      const a = onPlate[i]!, c = onPlate[j]!
      let dx = c.x - a.x, dz = c.z - a.z
      let d = Math.hypot(dx, dz)
      const radius = SNACKS[a.kind].radius + SNACKS[c.kind].radius
      if (d >= radius) continue
      if (d < 0.00001) { dx = Math.sin((a.id + c.id) * 2.4); dz = Math.cos((a.id + c.id) * 2.4); d = 1 }
      const nx = dx / d, nz = dz / d
      const wa = SNACKS[a.kind].weight, wc = SNACKS[c.kind].weight
      const overlap = radius - Math.hypot(c.x - a.x, c.z - a.z)
      // 겹침을 한 프레임에 전부 풀면 순간이동처럼 보인다. 조금씩 밀며 속도로 이어간다.
      const correction = Math.min(0.04, Math.max(0, overlap - 0.002) * 0.15)
      a.x -= nx * correction * wc / (wa + wc); a.z -= nz * correction * wc / (wa + wc)
      c.x += nx * correction * wa / (wa + wc); c.z += nz * correction * wa / (wa + wc)
      const relative = (c.vx - a.vx) * nx + (c.vz - a.vz) * nz
      const separationSpeed = Math.min(0.65, overlap * 4)
      if (relative < separationSpeed) {
        const impulse = (separationSpeed - relative) * 0.7 / (1 / wa + 1 / wc)
        a.vx -= impulse * nx / wa; a.vz -= impulse * nz / wa
        c.vx += impulse * nx / wc; c.vz += impulse * nz / wc
      }
    }
    for (const item of b.items) {
      if (item === fresh && !landed) continue
      if (item.fall === null && Math.hypot(item.x, item.z) > PLATE.radius - SNACKS[item.kind].radius * 0.25) {
        item.fall = 0
        spillAtMs ??= ms
      }
      if (item.fall !== null) {
        item.fall += dt
        item.x += item.vx * dt; item.z += item.vz * dt
        item.y = -4.9 * item.fall ** 2
      }
    }
    if (captureFrames) frames.push(copy(b))
  }
  return { frames, board: copy(b), spilled: spillAtMs !== null, spillAtMs }
}
