/** 주스만 골라!: 카드 등장 간격과 판단 시간은 각각 빨라진다. */
export const JUICE = { rounds: 5, labelRounds: 3, readyMs: 3000, revealMs: 4500, maxSteps: 24, familiarSteps: 3, graceMs: 150, enterMs: 120, feedbackMs: 200, exitMs: 150 } as const
/** juice·poison은 기존 오렌지 컵·해골 병의 id다. 판정은 그림 id 대신 kind를 쓴다. */
export const JUICE_CARDS = {
  juice: { kind: 'juice', name: '오렌지 주스' },
  apple: { kind: 'juice', name: '사과 주스' },
  grape: { kind: 'juice', name: '포도 주스' },
  strawberry: { kind: 'juice', name: '딸기 주스' },
  lemon: { kind: 'juice', name: '레몬 주스' },
  poison: { kind: 'poison', name: '해골 물약' },
  spider: { kind: 'poison', name: '거미 진액' },
  frog: { kind: 'poison', name: '개구리 독' },
  mushroom: { kind: 'poison', name: '독버섯 즙' },
  bat: { kind: 'poison', name: '박쥐 독' },
} as const
export type JuiceCard = keyof typeof JUICE_CARDS
export type JuiceKind = typeof JUICE_CARDS[JuiceCard]['kind']
export const JUICE_TYPES = ['juice', 'apple', 'grape', 'strawberry', 'lemon'] as const satisfies readonly JuiceCard[]
export const POISON_TYPES = ['poison', 'spider', 'frog', 'mushroom', 'bat'] as const satisfies readonly JuiceCard[]
export const juiceCardKind = (card: JuiceCard): JuiceKind => JUICE_CARDS[card].kind
export type JuiceReason = 'poison' | 'timeout' | 'early'
export type JuiceRunner = { id: string; survived: number; outAt: number | null; reason: JuiceReason | null }
export type JuiceView = {
  step: number
  mode: 'ready' | 'enter' | 'card' | 'gap' | 'end'
  cards: [JuiceCard, JuiceCard] | null
  windowMs: number
  /** 서버가 보낸 시점의 남은 시간. 화면은 수신 후 performance.now()로 잰다. */
  remainingMs: number
  runners: JuiceRunner[]
}
export type JuiceRow = JuiceRunner & { rank: number; delta: number; score: number }
export type JuiceReveal = { rows: JuiceRow[] }
export const juiceWindowMs = (step: number) => Math.max(400, 1200 - (step - 1) * 40)
export const juiceShowsLabel = (round: number) => round <= JUICE.labelRounds
export const juicePaceMs = (step: number) => Math.max(600, 1700 - (step - 1) * 80, juiceWindowMs(step) + JUICE.graceMs + JUICE.feedbackMs + JUICE.exitMs)
