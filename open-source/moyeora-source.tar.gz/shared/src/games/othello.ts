import { ORDER_INTRO_MS } from '../orderIntro.ts'

export const OTHELLO = { size: 8, introMs: ORDER_INTRO_MS, chooseMs: 30_000, settleMs: 850, gapMs: 250, passMs: 3000, resultMs: 5500 } as const
export type OthelloConfig = { bestOf: 1 | 3 | 5 }
export const othelloWinsNeeded = (bestOf: OthelloConfig['bestOf']) => (bestOf + 1) / 2
export type OthelloBoard = (string | null)[]
export type OthelloLast = { to: number; by: string; flipped: number[]; auto: boolean }
export type OthelloView = {
  board: OthelloBoard; order: string[]; turn: string | null; targets: number[]
  ply: number; last: OthelloLast | null; settling: boolean; passed: string | null
  winner: string | null; draw: boolean; bestOf: OthelloConfig['bestOf']; gameNo: number
}
export type OthelloReveal = { last: OthelloLast | null; winner: string | null; draw: boolean }

export function othelloInitialBoard(order: readonly string[]): OthelloBoard {
  const board: OthelloBoard = Array(64).fill(null)
  board[27] = board[36] = order[1]!
  board[28] = board[35] = order[0]!
  return board
}

/** 행·열 경계를 따로 확인해 말판 끝을 넘어 상대 돌을 끼우지 않는다. */
export function othelloFlips(board: OthelloBoard, owner: string, to: number): number[] {
  if (!Number.isInteger(to) || to < 0 || to >= 64 || board[to] !== null) return []
  const flips: number[] = []
  const row = Math.floor(to / 8), col = to % 8
  for (const dr of [-1, 0, 1]) for (const dc of [-1, 0, 1]) {
    if (dr === 0 && dc === 0) continue
    const ray: number[] = []
    let r = row + dr, c = col + dc
    while (r >= 0 && r < 8 && c >= 0 && c < 8) {
      const i = r * 8 + c, disc = board[i]
      if (disc === null) break
      if (disc === owner) { if (ray.length) flips.push(...ray); break }
      ray.push(i); r += dr; c += dc
    }
  }
  return flips
}
export const othelloTargets = (board: OthelloBoard, owner: string): number[] =>
  board.flatMap((disc, to) => disc === null && othelloFlips(board, owner, to).length ? [to] : [])
export const othelloCount = (board: OthelloBoard, owner: string) => board.filter((disc) => disc === owner).length
