/** 주문과 입력은 바닥 → 뚜껑 순서. */
export const INGREDIENTS = ['bottom', 'top', 'middle', 'lettuce', 'tomato', 'onion', 'patty', 'cheese'] as const
export type Ingredient = (typeof INGREDIENTS)[number]
export const INGREDIENT_NAMES: Record<Ingredient, string> = { bottom: '바닥 번', top: '뚜껑 번', middle: '중간 번', lettuce: '양상추', tomato: '토마토', onion: '양파', patty: '패티', cheese: '치즈' }
export const BURGER = { readyMs: 3000, chooseMs: 20000, allInMs: 1200, revealMs: 4500, maxLayers: 12 } as const
export const BURGER_ROUNDS = [3, 5] as const
export type BurgerConfig = { rounds: (typeof BURGER_ROUNDS)[number] }
export type BurgerSubmission = { id: string; rank: number | null }
export type BurgerView = { recipe: Ingredient[]; buttons: Ingredient[]; submissions: BurgerSubmission[]; readyMs: number; total: number; yourBurger: Ingredient[] | null }
export type BurgerRow = BurgerSubmission & { delta: number; score: number; reason: 'success' | 'wrong' | 'timeout' }
export type BurgerReveal = { rows: BurgerRow[] }
