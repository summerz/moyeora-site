/** 딱 맞춰!: 타이밍 상수는 서버와 화면이 같이 쓴다. */
export const STOPWATCH = { readyMs: 3000, allInMs: 1000, revealMs: 5000, rounds: 5, seconds: 3, maxSeconds: 10 } as const

/** 방장이 대기실에서 고르는 값. 목표 초(1~10 정수)와 라운드 수 */
export const STOPWATCH_ROUNDS = [5, 10] as const
export type StopwatchConfig = { seconds: number; rounds: (typeof STOPWATCH_ROUNDS)[number] }

/** 목표 초에서 허용하는 가장 늦은 누름(ms). 이보다 늦으면 서버가 거절한다 */
export const capMs = (seconds: number): number => seconds * 2000 + 2000
/** 카운트다운 뒤 누를 수 있는 시간(ms) */
export const pressMs = (seconds: number): number => seconds * 2000 + 2000

/** 오차(절댓값 ms) 기준 보너스: <5 딱!(+3), ≤20 까비!(+2), ≤50 와우!(+1) */
export const BONUS = { ttak: { ms: 5, points: 3, label: '딱!' }, kkabi: { ms: 20, points: 2, label: '까비!' }, wow: { ms: 50, points: 1, label: '와우!' } } as const
export type StopwatchBonus = keyof typeof BONUS

/** 숫자 선명도(0~1): min(1초, T/3) 까지 선명 → min(2초, 2T/3) 까지 선형으로 흐려짐 → 이후 안 보임. 목표가 길어도 2초 안에 사라진다 */
export const digitOpacity = (elapsedMs: number, targetMs: number): number => {
  const from = Math.min(1000, targetMs / 3)
  const to = Math.min(2000, (targetMs * 2) / 3)
  return elapsedMs < from ? 1 : elapsedMs >= to ? 0 : 1 - (elapsedMs - from) / (to - from)
}

/** 작은 시드 난수(mulberry32). 모든 폰이 같은 가짜 시계 박자를 그리는 데 쓴다 */
export const mulberry32 = (seed: number): (() => number) => {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** 가짜 시계: 기본 박자(ms)와 틱마다 ±8% 흔들림. go 뒤 elapsedMs 까지 울린 틱 수 */
export const DECOY = { minBeatMs: 800, maxBeatMs: 1250, jitter: 0.08 } as const
export const decoyTicks = (elapsedMs: number, beatMs: number, seed: number): number => {
  const rng = mulberry32(seed)
  let at = 0
  let k = 0
  for (;;) {
    at += beatMs * (1 + (rng() * 2 - 1) * DECOY.jitter)
    if (at > elapsedMs) return k
    k++
  }
}

/** 목표 초와 가짜 시계 박자·시드는 모두에게 같게 공개(비밀 아님). 누른 시간은 공개 전엔 서버만 안다 */
export type StopwatchView = { seconds: number; beatMs: number; seed: number }
/** ms: 내가 잰 시간, err: ms − 목표(ms). 안 누른 사람은 null */
export type StopwatchRow = { id: string; ms: number | null; err: number | null; rank: number | null; bonus: StopwatchBonus | null; delta: number; score: number }
export type StopwatchReveal = { seconds: number; rows: StopwatchRow[] }
