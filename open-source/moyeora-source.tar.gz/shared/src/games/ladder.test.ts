import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  LADDER_ROWS, allRungs, b64url, blocked, finalEnds, fromB64url, ladderId, parseLink, resolveRound, validSlot, walk,
} from './ladder.ts'
import type { LadderRecord, Slot } from './ladder.ts'

const pick = (seat: number, g: number, r: number) => ({ seat, slot: { g, r } })

test('blocked: same row, same or adjacent gap only', () => {
  const rungs = [{ g: 1, r: 5 }]
  assert.equal(blocked(rungs, { g: 1, r: 5 }), true)
  assert.equal(blocked(rungs, { g: 0, r: 5 }), true)
  assert.equal(blocked(rungs, { g: 2, r: 5 }), true)
  assert.equal(blocked(rungs, { g: 3, r: 5 }), false)
  assert.equal(blocked(rungs, { g: 1, r: 4 }), false)
  assert.equal(blocked(rungs, { g: 1, r: 6 }), false)
})

test('validSlot: range and n=2 single gap', () => {
  assert.equal(validSlot(2, [], { g: 0, r: 0 }), true)
  assert.equal(validSlot(2, [], { g: 1, r: 0 }), false)
  assert.equal(validSlot(2, [], { g: -1, r: 0 }), false)
  assert.equal(validSlot(2, [], { g: 0, r: LADDER_ROWS }), false)
  assert.equal(validSlot(2, [], { g: 0, r: LADDER_ROWS - 1 }), true)
  assert.equal(validSlot(2, [], { g: 0.5, r: 1 }), false)
  assert.equal(validSlot(2, [{ g: 0, r: 3 }], { g: 0, r: 3 }), false)
  assert.equal(validSlot(3, [{ g: 0, r: 3 }], { g: 1, r: 3 }), false)
  assert.equal(validSlot(3, [{ g: 0, r: 3 }], { g: 1, r: 4 }), true)
})

test('resolveRound: no conflict', () => {
  const res = resolveRound([pick(0, 0, 2), pick(1, 2, 2), pick(2, 0, 3)])
  assert.deepEqual(res.collisions, [])
  assert.deepEqual(res.placed, [{ g: 0, r: 2, o: 0 }, { g: 2, r: 2, o: 1 }, { g: 0, r: 3, o: 2 }])
})

test('resolveRound: same slot and adjacent pair', () => {
  let res = resolveRound([pick(1, 1, 4), pick(0, 1, 4)])
  assert.deepEqual(res.placed, [])
  assert.deepEqual(res.collisions, [{ seats: [0, 1], slots: [{ g: 1, r: 4 }, { g: 1, r: 4 }] }])
  res = resolveRound([pick(0, 1, 4), pick(1, 2, 4)])
  assert.equal(res.collisions.length, 1)
})

test('resolveRound: chain of 3 is one collision', () => {
  const res = resolveRound([pick(0, 0, 1), pick(2, 2, 1), pick(1, 1, 1), pick(3, 5, 1)])
  assert.equal(res.collisions.length, 1)
  assert.deepEqual(res.collisions[0].seats, [0, 1, 2])
  assert.deepEqual(res.placed, [{ g: 5, r: 1, o: 3 }])
})

test('resolveRound: two separate collisions, deterministic order', () => {
  const a = [pick(0, 0, 8), pick(1, 1, 8), pick(2, 3, 2), pick(3, 3, 2), pick(4, 0, 5)]
  const res = resolveRound(a)
  assert.deepEqual(res.collisions.map((c) => c.seats), [[2, 3], [0, 1]])
  assert.deepEqual(res.placed, [{ g: 0, r: 5, o: 4 }])
  assert.deepEqual(resolveRound([...a].reverse()), res)
})

test('walk: known 3-column ladder', () => {
  // rung g=0 at r=2 swaps cols 0,1; rung g=1 at r=5 swaps cols 1,2
  const rungs = [{ g: 0, r: 2 }, { g: 1, r: 5 }]
  const w0 = walk(3, rungs, 0)
  assert.equal(w0.end, 2)
  assert.deepEqual(w0.path, [
    { col: 0, r: -1 }, { col: 0, r: 2 }, { col: 1, r: 2 }, { col: 1, r: 5 }, { col: 2, r: 5 }, { col: 2, r: LADDER_ROWS },
  ])
  assert.equal(walk(3, rungs, 1).end, 0)
  assert.equal(walk(3, rungs, 2).end, 1)
  assert.deepEqual(walk(3, [], 1).path, [{ col: 1, r: -1 }, { col: 1, r: LADDER_ROWS }])
})

function mulberry(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function record(n: number, system: Slot[]): LadderRecord {
  return {
    v: 1, at: '2026-10-09T00:00:00.000Z',
    players: Array.from({ length: n }, (_, i) => ({ name: `p${i}`, avatar: `a${i}`, bot: false })),
    items: Array.from({ length: n }, (_, i) => `i${i}`),
    system, rounds: [],
  }
}

test('finalEnds is a permutation on random valid ladders', () => {
  const rng = mulberry(7)
  for (let t = 0; t < 200; t++) {
    const n = 2 + Math.floor(rng() * 7)
    const rungs: Slot[] = []
    for (let k = 0; k < 60; k++) {
      const s = { g: Math.floor(rng() * (n - 1)), r: Math.floor(rng() * LADDER_ROWS) }
      if (validSlot(n, rungs, s)) rungs.push(s)
    }
    const rec = record(n, rungs)
    assert.equal(allRungs(rec).length, rungs.length)
    assert.deepEqual([...finalEnds(rec)].sort((a, b) => a - b), Array.from({ length: n }, (_, i) => i))
  }
})

test('ladderId format', () => {
  assert.equal(ladderId(new Uint8Array([0, 0, 0, 0, 0])), '0000-0000')
  assert.equal(ladderId(new Uint8Array([255, 255, 255, 255, 255, 9])), 'ZZZZ-ZZZZ')
  assert.match(ladderId(Uint8Array.from({ length: 64 }, (_, i) => i * 7)), /^[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}$/)
})

test('b64url round trip', () => {
  for (let len = 0; len < 40; len++) {
    const b = Uint8Array.from({ length: len }, (_, i) => (i * 37 + 250) & 255)
    const s = b64url(b)
    assert.match(s, /^[A-Za-z0-9_-]*$/)
    assert.deepEqual(fromB64url(s), b)
  }
})

test('parseLink', () => {
  const enc = (o: unknown) => b64url(new TextEncoder().encode(JSON.stringify(o)))
  const sig = b64url(new Uint8Array(64).fill(1))
  const rec = record(3, [{ g: 0, r: 1 }])
  const ok = parseLink(`${enc(rec)}.${sig}`)
  assert.ok(ok)
  assert.deepEqual(ok.record, rec)
  assert.equal(ok.sig.length, 64)
  assert.ok(parseLink(`#${enc(rec)}.${sig}`))
  for (const bad of ['', 'garbage', '...', 'a.b.c', '!!!.???', `${enc(rec)}`, `${enc(rec)}.${sig}.x`])
    assert.equal(parseLink(bad), null, bad)
  assert.equal(parseLink(`${enc({ ...rec, v: 2 })}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, system: [{ g: 2, r: 1 }] })}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, system: [{ g: 0, r: 12 }] })}.${sig}`), null)
  assert.equal(parseLink(`${enc(record(1, []))}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, items: ['x'] })}.${sig}`), null)
  assert.equal(parseLink(`${enc(rec)}.${sig.slice(0, -1)}`), null)
  assert.equal(parseLink(`${enc(rec)}.${sig.slice(0, -4)}`), null)

  // 기록 문자열은 서버가 허용하는 범위만 (UI 문구 흉내 방지)
  const p0 = rec.players[0]
  assert.equal(parseLink(`${enc({ ...rec, players: [{ ...p0, name: 'x'.repeat(21) }, ...rec.players.slice(1)] })}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, players: [{ ...p0, avatar: 'a b' }, ...rec.players.slice(1)] })}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, items: ['x'.repeat(13), 'i1', 'i2'] })}.${sig}`), null)
  assert.equal(parseLink(`${enc({ ...rec, items: ['', 'i1', 'i2'] })}.${sig}`), null)
})
