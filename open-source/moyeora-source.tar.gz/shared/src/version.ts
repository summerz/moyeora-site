import type { ServerHello } from './messages.ts'

/** 메시지·뷰 규약 번호. 깨지는 변경(필드 제거·뜻 변경)일 때만 올린다. 게임 추가는 올리지 않는다. */
export const PROTOCOL = 3
/** 서버가 받아 주는 가장 낮은 클라이언트 PROTOCOL. */
export const MIN_PROTOCOL = 3

/** 서버 인사 본문 (version 은 서버가 package.json 에서 읽어 넣는다). */
export const helloFor = (version: string): ServerHello => ({ type: 'hello', protocol: PROTOCOL, min: MIN_PROTOCOL, version })

export type Skew = 'ok' | 'client-old' | 'server-old'

/** 클라이언트 PROTOCOL 과 서버 인사를 견줘 어느 쪽이 낡았는지 알려 준다. */
export function skewOf(clientProtocol: number, hello: Pick<ServerHello, 'protocol' | 'min'>): Skew {
  if (clientProtocol < hello.min) return 'client-old'
  if (clientProtocol > hello.protocol) return 'server-old'
  return 'ok'
}

/** create/join/resume 의 v 를 검사한다. 통과면 null, 아니면 에러 코드 ('v' 가 없는 옛 클라이언트는 'update required'). */
export function protocolError(raw: unknown): 'update required' | 'server old' | null {
  if (typeof raw !== 'object' || raw === null) return null
  const m = raw as Record<string, unknown>
  if (m.type !== 'create' && m.type !== 'join' && m.type !== 'resume') return null
  if (typeof m.v !== 'number' || !Number.isInteger(m.v) || m.v < MIN_PROTOCOL) return 'update required'
  if (m.v > PROTOCOL) return 'server old'
  return null
}

/** 'x.y.z' 비교: 음수 a<b, 0 같음, 양수 a>b. 형식이 틀리면 null. */
export function compareVersions(a: string, b: string): number | null {
  const parse = (s: string) => (/^\d+\.\d+\.\d+$/.test(s) ? s.split('.').map(Number) : null)
  const x = parse(a)
  const y = parse(b)
  if (!x || !y) return null
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i]! - y[i]!
  return 0
}
