export const ADJECTIVES = ['졸린', '용감한', '배고픈', '반짝이는', '수상한', '느긋한', '재빠른', '엉뚱한', '씩씩한', '수줍은', '신나는', '똑똑한', '뽀송한', '통통한', '날쌘', '조용한', '달콤한', '매콤한', '웃는', '춤추는', '꿈꾸는', '깜짝', '몽글몽글', '데굴데굴', '토실토실', '당당한', '귀여운', '든든한', '반짝반짝', '커다란', '작은', '바쁜', '심심한', '노래하는', '따뜻한', '차가운', '보송보송', '멋진', '장난꾸러기']

export const NOUNS = ['고양이', '감자', '토끼', '펭귄', '문어', '고구마', '수박', '김밥', '만두', '치즈', '구름', '번개', '로봇', '공룡', '햄스터', '달팽이', '거북이', '오리', '두더지', '코알라', '판다', '여우', '다람쥐', '호랑이', '고래', '상어', '복숭아', '딸기', '바나나', '도넛', '붕어빵', '떡볶이', '양말', '우산', '베개', '이불', '자전거', '풍선', '연필', '지우개']

const pick = <T,>(a: readonly T[], rng: () => number) => a[Math.floor(rng() * a.length)]!

export function randomName(rng: () => number = Math.random): string {
  let n = ''
  for (let i = 0; i < 20; i++) {
    n = `${pick(ADJECTIVES, rng)} ${pick(NOUNS, rng)}`
    if (n.length <= 12) return n
  }
  return n.slice(0, 12)
}

// randomUUID 는 https·localhost 에서만 있다. LAN IP(http) 로 열면 없어서 getRandomValues 를 쓴다.
export const randomSeed = () => Array.from(globalThis.crypto.getRandomValues(new Uint8Array(6)), (b) => b.toString(16).padStart(2, '0')).join('')
