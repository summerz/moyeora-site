import assert from 'node:assert/strict'
import { test } from 'node:test'
import { HOME_CONFIG, isListed, isOff } from './homeGames.ts'
import { isClientMessage } from './guards.ts'

const isGameId = (id: string) => isClientMessage({ type: 'create', v: 1, game: id, name: 'a', avatar: 'a' })

test('JSON 의 모든 id 는 유효한 GameId', () => {
  for (const id of [...HOME_CONFIG.order, ...HOME_CONFIG.hidden, ...HOME_CONFIG.off]) assert.ok(isGameId(id), id)
})

test('hidden 과 off 는 겹치지 않는다', () => {
  assert.deepEqual(HOME_CONFIG.hidden.filter((id) => HOME_CONFIG.off.includes(id)), [])
})

test('isOff / isListed', () => {
  const c = { order: [], hidden: ['h'], off: ['o'] }
  assert.equal(isOff('o', c), true)
  assert.equal(isOff('h', c), false)
  assert.equal(isListed('h', c), false)
  assert.equal(isListed('o', c), false)
  assert.equal(isListed('x', c), true)
})
