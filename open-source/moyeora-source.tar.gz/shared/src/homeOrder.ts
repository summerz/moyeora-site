export type HomeConfig = { order: readonly string[]; hidden: readonly string[]; off?: readonly string[] }
export type HomeSort = 'default' | 'popular'

/**
 * 홈에 보일 게임 순서. cfg.order 순서대로, hidden·off 는 뺀다.
 * order 에 없는 게임(새로 추가됨)은 meta 순서대로 맨 뒤에 붙는다 — 조용히 사라지지 않게.
 * popular 모드는 counts(최근 7일 시작 횟수) 내림차순, 같거나 0 이면 위의 기본 순서를 유지한다.
 */
export function homeGames<T extends { id: string }>(
  meta: readonly T[],
  cfg: HomeConfig,
  counts: Readonly<Record<string, number>> | null | undefined,
  mode: HomeSort,
): T[] {
  const byId = new Map(meta.map((g) => [g.id, g]))
  const ordered = [
    ...cfg.order.flatMap((id) => byId.get(id) ?? []),
    ...meta.filter((g) => !cfg.order.includes(g.id)),
  ].filter((g) => !cfg.hidden.includes(g.id) && !cfg.off?.includes(g.id))
  if (mode !== 'popular' || !counts) return ordered
  const n = (g: T) => counts[g.id] ?? 0
  return ordered.map((g, i) => ({ g, i })).sort((a, b) => n(b.g) - n(a.g) || a.i - b.i).map((x) => x.g)
}
