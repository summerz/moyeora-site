import assert from 'node:assert/strict'
import { test } from 'node:test'
import { homeGames } from './homeOrder.ts'

const meta = ['a', 'b', 'c', 'd'].map((id) => ({ id }))
const ids = (x: { id: string }[]) => x.map((g) => g.id).join('')

test('order 순서대로, hidden 은 뺀다', () => {
  assert.equal(ids(homeGames(meta, { order: ['c', 'a', 'b', 'd'], hidden: ['b'] }, null, 'default')), 'cad')
})

test('order 에 없는 게임은 meta 순서로 뒤에 붙고, 모르는 id 는 무시', () => {
  assert.equal(ids(homeGames(meta, { order: ['d', 'zzz', 'a'], hidden: [] }, null, 'default')), 'dabc')
})

test('인기순: 횟수 내림차순, 동률·0 은 기본 순서 유지', () => {
  const cfg = { order: ['a', 'b', 'c', 'd'], hidden: [] }
  assert.equal(ids(homeGames(meta, cfg, { c: 5, d: 5, b: 1 }, 'popular')), 'cdba')
  assert.equal(ids(homeGames(meta, cfg, {}, 'popular')), 'abcd')
  assert.equal(ids(homeGames(meta, cfg, null, 'popular')), 'abcd')
})

test('인기순에서도 hidden 은 숨김', () => {
  assert.equal(ids(homeGames(meta, { order: ['a', 'b', 'c', 'd'], hidden: ['c'] }, { c: 9, d: 2 }, 'popular')), 'dab')
})

test('off 도 홈에서 뺀다', () => {
  assert.equal(ids(homeGames(meta, { order: ['a', 'b', 'c', 'd'], hidden: [], off: ['a'] }, null, 'default')), 'bcd')
})
