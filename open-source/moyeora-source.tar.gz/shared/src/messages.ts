import type { MarblesReveal, MarblesView } from './games/marbles.ts'
import type { PlateReveal, PlateView } from './games/plate.ts'
import type { BurgerReveal, BurgerView } from './games/burger.ts'
import type { OthelloReveal, OthelloView } from './games/othello.ts'
import type { GobbleReveal, GobbleView } from './games/gobble.ts'
import type { LadderReveal, LadderView } from './games/ladder.ts'
import type { LiarReveal, LiarView } from './games/liar.ts'
import type { PirateReveal, PirateView } from './games/pirate.ts'
import type { JuiceReveal, JuiceView } from './games/juice.ts'
import type { NunchiReveal, NunchiView } from './games/nunchi.ts'
import type { StopwatchReveal, StopwatchView } from './games/stopwatch.ts'
import type { SusJarReveal, SusJarView } from './games/sus-jar.ts'
import type { WhoPickedReveal, WhoPickedView } from './games/who-picked.ts'

export type GameId = 'sus-jar' | 'who-picked' | 'ladder' | 'liar' | 'nunchi' | 'stopwatch' | 'pirate' | 'juice' | 'gobble' | 'othello' | 'burger' | 'plate' | 'marbles'
export type Player = { id: string; name: string; avatar: string; score: number; submitted: boolean; bot: boolean }
export type Phase = 'lobby' | 'intro' | 'choosing' | 'reveal' | 'done'
export type RoomBase = { code: string; phase: Phase; round: number; rounds: number; players: Player[]; you: string; host: string; remainingMs: number | null }
export type RoomView = RoomBase & ({ game: 'sus-jar'; g: SusJarView } | { game: 'who-picked'; g: WhoPickedView } | { game: 'ladder'; g: LadderView } | { game: 'liar'; g: LiarView } | { game: 'nunchi'; g: NunchiView } | { game: 'stopwatch'; g: StopwatchView } | { game: 'pirate'; g: PirateView } | { game: 'juice'; g: JuiceView } | { game: 'gobble'; g: GobbleView } | { game: 'othello'; g: OthelloView } | { game: 'burger'; g: BurgerView } | { game: 'plate'; g: PlateView } | { game: 'marbles'; g: MarblesView })
export type SusJarRoom = Extract<RoomView, { game: 'sus-jar' }>
export type WhoPickedRoom = Extract<RoomView, { game: 'who-picked' }>
export type LadderRoom = Extract<RoomView, { game: 'ladder' }>
export type LiarRoom = Extract<RoomView, { game: 'liar' }>
export type NunchiRoom = Extract<RoomView, { game: 'nunchi' }>
export type StopwatchRoom = Extract<RoomView, { game: 'stopwatch' }>
export type PirateRoom = Extract<RoomView, { game: 'pirate' }>
export type JuiceRoom = Extract<RoomView, { game: 'juice' }>
export type OthelloRoom = Extract<RoomView, { game: 'othello' }>
export type GobbleRoom = Extract<RoomView, { game: 'gobble' }>
export type MarblesRoom = Extract<RoomView, { game: 'marbles' }>
export type PlateRoom = Extract<RoomView, { game: 'plate' }>
export type BurgerRoom = Extract<RoomView, { game: 'burger' }>
export type ClientMessage =
  | { type: 'create'; v: number; game: GameId; name: string; avatar: string }
  | { type: 'join'; v: number; code: string; name: string; avatar: string }
  | { type: 'resume'; v: number; code: string; token: string }
  | { type: 'leave' }
  | { type: 'start' }
  | { type: 'submit'; choice: string }
  | { type: 'lobby' }
  | { type: 'kick'; playerId: string }
  | { type: 'addBot' }
  | { type: 'config'; config: unknown }
  /** 해적 통 각도(라디안). 지금 차례인 사람만 보내고, 서버는 방 상태에 저장하지 않고 다른 사람들에게만 전달한다 */
  | { type: 'aim'; angle: number }
export type ServerMessage =
  | { type: 'room'; room: RoomView }
  | { type: 'reveal'; round: number; result: SusJarReveal | WhoPickedReveal | LadderReveal | LiarReveal | NunchiReveal | StopwatchReveal | PirateReveal | JuiceReveal | GobbleReveal | OthelloReveal | BurgerReveal | PlateReveal | MarblesReveal }
  | { type: 'error'; message: string }
/** 서버가 연결 직후 한 번 보내는 인사. 클라이언트가 어느 쪽이 더 새것인지 알아본다. */
export type ServerHello = { type: 'hello'; protocol: number; min: number; version: string }
/** 해적 통 각도 중계(고빈도). room 메시지와 달리 상태가 아니라서 ServerMessage 에 넣지 않는다 */
export type ServerAim = { type: 'aim'; angle: number; by: string; /** 서버가 정한 시간 초과 자동 꽂기 정면 aim — 차례 본인도 반드시 따라 돈다 */ auto?: true }
/** 자리표: 소켓이 끊겨도 이 토큰으로 같은 자리에 돌아온다 (PROTOCOL 2). 게임 핸들러엔 안 넘기므로 ServerMessage 에 넣지 않는다 */
export type ServerSeat = { type: 'seat'; code: string; token: string }
