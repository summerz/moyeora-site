/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_WS_URL?: string
  readonly VITE_LADDER_PUBKEY?: string
  readonly VITE_APP_VERSION: string
  /** GA4 측정 ID (G-XXXX). 운영 빌드(site.yml)에서만 채운다 */
  readonly VITE_GA_MEASUREMENT_ID?: string
}
