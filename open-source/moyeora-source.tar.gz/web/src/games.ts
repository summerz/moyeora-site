import type { GameId } from '@moyeora/shared'

export type AppGameId = GameId | 'sudoku'
export type GameMeta = { id: AppGameId; title: string; tagline: string; path: string; players: readonly [min: number, max: number]; npc: boolean }

export const GAMES: readonly GameMeta[] = [
  { id: 'sudoku', title: '스도쿠', tagline: '숫자를 하나씩. 풀던 곳에서 이어가요.', path: 'sudoku/', players: [1, 1], npc: false },
  { id: 'marbles', title: '막대 위의 구슬', tagline: '막대는 쏙! 구슬은 떨어뜨리지 마요.', path: 'marbles/', players: [2, 6], npc: true },
  { id: 'plate', title: '와르르 간식 접시', tagline: '기우뚱! 균형 잡고, 떨어뜨리면 벌칙!', path: 'plate/', players: [2, 8], npc: true },
  { id: 'burger', title: '햄버거 알바', tagline: '주문 보고 착착! 먼저 완성하면 더 많은 점수.', path: 'burger/', players: [2, 8], npc: true },
  { id: 'sus-jar', title: '마셔? 말아?', tagline: '독일까 주스일까. 마실까 말까.', path: 'sus-jar/', players: [2, 8], npc: true },
  { id: 'who-picked', title: '누구 픽이야?', tagline: '같은 질문, 다른 답. 누가 뭘 골랐을까.', path: 'who-picked/', players: [2, 8], npc: true },
  { id: 'ladder', title: '사다리타기', tagline: '몰래 그은 한 줄이 결과를 바꿔요', path: 'ladder/', players: [2, 8], npc: true },
  { id: 'liar', title: '라이어는 누구?', tagline: '한 명만 제시어를 몰라요. 말로 찾아내요.', path: 'liar/', players: [3, 8], npc: false },
  { id: 'nunchi', title: '눈치 게임', tagline: '하나! 둘! 셋! 눈치껏 누르고, 겹치면 끝.', path: 'nunchi/', players: [2, 8], npc: true },
  { id: 'stopwatch', title: '딱 맞춰!', tagline: '감으로 딱 3초! 보지 말고 멈춰요.', path: 'stopwatch/', players: [2, 8], npc: true },
  { id: 'pirate', title: '꽂아! 펑! 해적!', tagline: '칼을 꽂다가 해적이 튀면 벌칙!', path: 'pirate/', players: [2, 8], npc: true },
  { id: 'juice', title: '주스만 골라!', tagline: '주스는 톡! 독약은 멈춰! 점점 빨라지는 승부.', path: 'juice/', players: [2, 8], npc: true },
  { id: 'othello', title: '오델로', tagline: '사이에 끼우면 뒤집혀요! 마지막에 내 돌을 더 많이.', path: 'othello/', players: [2, 2], npc: true },
  { id: 'gobble', title: '냠냠! 세 줄!', tagline: '큰 말로 냠! 내 말 세 개를 한 줄로.', path: 'gobble/', players: [2, 2], npc: true },
]

export const gameMeta = (id: GameMeta['id']) => GAMES.find((g) => g.id === id)!

export const peopleLabel = (g: GameMeta) => (g.players[0] === 1 && g.players[1] === 1 ? '혼자' : g.players[0] === g.players[1] ? `딱 ${g.players[0]}명` : `${g.players[0]}–${g.players[1]}명`)

/** 인원 필터(n, null=전체)에 안 맞으면 이유, 맞으면 null */
export const misfit = (g: GameMeta, n: number | null): string | null => {
  const [min, max] = g.players
  if (n === null) return null
  if (n === 1) return min === 1 || g.npc ? null : `${min}명부터`
  if (n < min) return `${min}명부터`
  if (n > max) return min === max ? `딱 ${min}명` : `${max}명까지`
  return null
}
