import type { CSSProperties } from 'react'

/** 게임 공통 성공/실패 도장. 카드의 흑백 처리 밖에 배치한다. */
export function FeedbackMark({ mark, className = '', style }: { mark: 'O' | '×'; className?: string; style?: CSSProperties }) {
  const shape = mark === 'O' ? <circle cx="60" cy="60" r="44" /> : <path d="M16 16 104 104 M104 16 16 104" />
  return <span className={`feedback-mark ${className}`} data-bad={mark === '×'} role="img" aria-label={mark === 'O' ? '성공' : '실패'} style={style}>
    <svg className="feedback-mark-symbol" viewBox="0 0 120 120" fill="none" strokeLinecap="round" aria-hidden="true">
      <g stroke="#fff" strokeWidth="18">{shape}</g>
      <g stroke="currentColor" strokeWidth="12">{shape}</g>
    </svg>
  </span>
}
