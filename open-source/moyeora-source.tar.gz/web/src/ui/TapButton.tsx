import './tap.css'

export type TapKind = 'ready' | 'go' | 'tapped' | 'first' | 'bad'
type Props = { kind: TapKind; label: string; disabled: boolean; onPress: () => void }

export function TapButton({ kind, label, disabled, onPress }: Props) {
  return (
    <button
      type="button"
      className="tap-btn"
      data-kind={kind}
      disabled={disabled}
      aria-label={kind === 'ready' ? `준비 중 ${label}` : label}
      onPointerDown={(e) => { if (e.pointerType !== 'mouse' || e.button === 0) onPress() }}
      onClick={(e) => { if (e.detail === 0) onPress() }}
    >
      {label}
    </button>
  )
}
