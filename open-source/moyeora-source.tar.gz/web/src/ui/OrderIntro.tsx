import { useEffect, useMemo, useRef, useState } from 'react'
import { ORDER_INTRO_MS, type Player } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { MePill } from './MePill.tsx'
import { thud } from './sound.ts'
import './orderIntro.css'

const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches

// 타임라인(ms, 공통 intro ORDER_INTRO_MS 와 맞춘다): 섞기 → 순서대로 자리 잡기 → 헤드라인
const SHUFFLES = 4
const SHUFFLE_FROM = 250
const SHUFFLE_GAP = 330
const SETTLE_AT = SHUFFLE_FROM + SHUFFLE_GAP * SHUFFLES + 150 // 1720
const HEAD_AT = SETTLE_AT + 600

/** order 문자열에서 시드를 뽑는 작은 PRNG: 모든 폰이 같은 섞임을 본다 */
const seeded = (key: string) => {
  let h = 2166136261
  for (const c of key) h = Math.imul(h ^ c.charCodeAt(0), 16777619)
  return () => {
    h = Math.imul(h ^ (h >>> 15), 2246477709) + 0x9e3779b9
    h ^= h >>> 13
    return ((h >>> 0) % 100000) / 100000
  }
}
const shuffled = (xs: string[], rng: () => number) => {
  const a = [...xs]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1))
    ;[a[i], a[j]] = [a[j]!, a[i]!]
  }
  return a
}

/** 게임 시작 직후: 순서가 정해지는 걸 모두 같은 타이밍으로 본다. 끝나면 서버가 첫 차례로 넘긴다. */
export function OrderIntro({ players, order, me, remainingMs }: { players: readonly Player[]; order: string[]; me: string; remainingMs: number | null }) {
  const rm = reduced()
  // 늦게 들어온 폰도 서버 시계에 맞춘다
  const [t0] = useState(() => performance.now() - (ORDER_INTRO_MS - (remainingMs ?? ORDER_INTRO_MS)))
  const [t, setT] = useState(() => (rm ? ORDER_INTRO_MS : performance.now() - t0))
  useEffect(() => {
    if (rm) return
    const id = setInterval(() => setT(performance.now() - t0), 60)
    return () => clearInterval(id)
  }, [rm, t0])

  const seqs = useMemo(() => {
    const rng = seeded(order.join('|'))
    const first = players.map((p) => p.id).filter((id) => order.includes(id))
    const sequences = [first]
    for (let i = 0; i < SHUFFLES; i++) {
      let next = shuffled(order, rng)
      // 2인 게임에서도 매번 섞이는 모습이 보여야 한다.
      if (next.length > 1 && next.every((id, slot) => id === sequences[i]![slot])) next = [...next.slice(1), next[0]!]
      sequences.push(next)
    }
    return [...sequences, order]
  }, [order, players])
  const step = t >= SETTLE_AT ? SHUFFLES + 1 : t < SHUFFLE_FROM ? 0 : Math.min(SHUFFLES, 1 + Math.floor((t - SHUFFLE_FROM) / SHUFFLE_GAP))
  const seq = seqs[step]!
  const settled = t >= SETTLE_AT
  const headline = t >= HEAD_AT

  const was = useRef(false)
  useEffect(() => {
    if (settled && !was.current) { was.current = true; if (!rm) thud() }
  }, [settled, rm])

  const n = order.length
  const cols = Math.max(1, Math.min(n, 4))
  const rows = Math.ceil(n / cols)
  const CELL_H = 122
  const first = players.find((p) => p.id === order[0])
  const firstMe = order[0] === me

  return (
    <div className="order-intro" role="status">
      <div className="jua order-intro__title">{settled ? '순서가 정해졌어요!' : '순서 정하는 중…'}</div>
      <div className="order-grid" style={{ height: rows * CELL_H }}>
        {order.map((id) => {
          const p = players.find((q) => q.id === id)
          const slot = Math.max(0, seq.indexOf(id))
          const mine = id === me
          return (
            <div
              key={id}
              className="order-cell"
              style={{ width: `${100 / cols}%`, height: CELL_H, transform: `translate(${(slot % cols) * 100}%, ${Math.floor(slot / cols) * CELL_H}px)`, transition: rm ? 'none' : undefined }}
            >
              <div className="order-chip" data-me={mine ? '1' : '0'} data-settled={settled ? '1' : '0'}>
                {mine && <MePill floating />}
                {settled && <span className="order-no jua" style={{ animationDelay: `${order.indexOf(id) * 70}ms` }}>{order.indexOf(id) + 1}</span>}
                <Avatar seed={p?.avatar ?? 'x'} size={46} ring={mine} />
                <span className="nick nick--sm nick--2l nick--center">{p?.name ?? '나감'}</span>
              </div>
            </div>
          )
        })}
      </div>
      <div className="order-headline jua" data-on={headline ? '1' : '0'} aria-live="polite">
        {headline && (firstMe ? <span className="order-headline__me">첫 번째는 나!</span> : <><span>첫 번째는</span> <span className="nick nick--lg">{first?.name ?? '누군가'}</span><span>!</span></>)}
      </div>
    </div>
  )
}
