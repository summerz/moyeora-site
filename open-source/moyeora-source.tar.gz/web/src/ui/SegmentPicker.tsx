type Props<T extends string | number> = {
  label: string
  /** 'sm' = 제목 옆에 두는 작은 가로형(라벨은 접근성용으로만 쓰고 안 보임) */
  size?: 'md' | 'sm'
  options: readonly { value: T; label: string }[]
  value: T
  /** 방장만 고를 수 있다. 아니면 읽기 전용 */
  host: boolean
  onPick: (value: T) => void
}

/** 대기실 설정용 알약 선택(라운드 수·질문 묶음 등). 방장만 누를 수 있고 나머지는 흐리게 보기만 */
export function SegmentPicker<T extends string | number>({ label, size = 'md', options, value, host, onPick }: Props<T>) {
  const sm = size === 'sm'
  return (
    <div role={sm ? 'group' : undefined} aria-label={sm ? label : undefined} style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center' }}>
      {!sm && <div style={{ fontSize: 13, color: 'var(--lav)' }}>{label}</div>}
      <div style={{ display: 'flex', gap: sm ? 6 : 10 }}>
        {options.map((o) => {
          const on = value === o.value
          return (
            <button key={o.value} type="button" className="chip" aria-pressed={on} disabled={!host} onClick={() => onPick(o.value)}
              style={{ background: on ? 'var(--lime)' : 'var(--cream)', cursor: host ? 'pointer' : 'default', minHeight: sm ? 32 : 40, ...(sm ? { fontSize: 14, padding: '1px 12px', boxShadow: '2px 2px 0 var(--ink)' } : null), opacity: !host && !on ? 0.6 : 1, ...(on ? { outline: '3px solid var(--lime)', outlineOffset: 2 } : null) }}>
              {o.label}
            </button>
          )
        })}
      </div>
    </div>
  )
}
