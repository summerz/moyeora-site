import type { ReactNode } from 'react'
import type { Player, RoomView } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { Icon } from './icons.tsx'
import { MePill } from './MePill.tsx'
import { NpcTag } from './NpcTag.tsx'
import { WaitBar } from './WaitBar.tsx'

type Props = { room: RoomView; onAgain: () => void; onLobby: () => void; title?: string; children?: ReactNode; draw?: boolean; showScore?: boolean; scoreUnit?: string; scoreOrder?: 'desc' | 'asc' }

const rankOf = (sorted: Player[], p: Player) => sorted.findIndex((q) => q.score === p.score) + 1

const fmt = (n: number, unit: string) => `${n < 0 ? `−${-n}` : n}${unit}`

// 시상대: 바닥을 맞추고(stretch) 2등은 24, 3등은 48 낮게 시작한다
function Card({ p, rank, me, size, first, drop, draw, showScore, scoreUnit }: { p: Player; rank: number; me: boolean; size: number; first?: boolean; drop: number; draw?: boolean; showScore: boolean; scoreUnit: string }) {
  return (
    <div className={`sticker ${me ? 'glow-box' : ''}`} style={{ position: 'relative', background: first ? 'var(--amber)' : undefined, ...(me ? { border: '4px solid var(--lime)' } : {}), flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '14px 4px 10px', marginTop: drop }}>
      {me && <MePill floating />}
      <span className="jua" style={{ fontSize: first ? 30 : 24, display: 'inline-flex', alignItems: 'center', gap: 4 }}>{first && <Icon name="crown" size={22} />}{draw ? '무승부' : rank}</span>
      <Avatar seed={p.avatar} size={size} />
      <span className="nick nick--2l nick--center" style={{ maxWidth: '100%', padding: '0 4px' }}>{p.name}{p.bot && <NpcTag />}</span>
      {showScore && <span className="jua" style={{ fontSize: 16 }}>{fmt(p.score, scoreUnit)}</span>}
    </div>
  )
}

export function Final({ room, onAgain, onLobby, title = `${room.rounds}라운드 끝!`, children, draw = false, showScore = true, scoreUnit = '점', scoreOrder = 'desc' }: Props) {
  const isHost = room.host === room.you
  const sorted = [...room.players].sort((a, b) => scoreOrder === 'asc' ? a.score - b.score : b.score - a.score)
  const top = sorted.slice(0, 3)
  const rest = sorted.slice(3)
  const order = top.length === 3 ? [1, 0, 2] : top.length === 2 ? [1, 0] : [0]
  const meP = sorted.find((p) => p.id === room.you)
  const meRank = meP ? rankOf(sorted, meP) : 0
  const meTie = meP ? sorted.filter((q) => q.score === meP.score).length > 1 : false
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div style={{ textAlign: 'center' }}>
        <span className="chip tilt-a" style={{ background: draw ? 'var(--cream)' : 'var(--amber)', display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 22 }}>{!draw && <Icon name="crown" size={20} />}{title}</span>
      </div>
      {meP && (
        <div className="sticker glow-box" style={{ background: 'var(--card)', color: 'var(--cream)', border: '4px solid var(--lime)', display: 'flex', alignItems: 'center', gap: 12, padding: '8px 14px' }}>
          <Avatar seed={meP.avatar} size={56} />
          <span className="jua" style={{ flex: 1, minWidth: 0, fontSize: 28, color: 'var(--lime)', display: 'inline-flex', alignItems: 'center', gap: 6 }}>{draw ? '무승부!' : <>{meRank === 1 && <Icon name="crown" size={26} />}{meTie ? '공동' : '나는'} {meRank}등!</>}</span>
          {showScore && <span className="jua" style={{ fontSize: 24 }}>{fmt(meP.score, scoreUnit)}</span>}
        </div>
      )}
      <div style={{ display: 'flex', gap: 8, alignItems: 'stretch' }}>
        {order.map((i) => (
          <Card key={top[i]!.id} p={top[i]!} rank={rankOf(sorted, top[i]!)} me={top[i]!.id === room.you} size={draw ? 64 : i === 0 ? 84 : i === 1 ? 64 : 56} first={!draw && i === 0} drop={draw ? 0 : i * 24} draw={draw} showScore={showScore} scoreUnit={scoreUnit} />
        ))}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {rest.map((p) => (
          <div key={p.id} className="sticker--dark" style={{ background: 'var(--card)', borderRadius: 16, ...(p.id === room.you ? { border: '3px solid var(--lime)' } : {}), padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="jua" style={{ width: 22, color: 'var(--lav)' }}>{rankOf(sorted, p)}</span>
            <Avatar seed={p.avatar} size={32} />
            <span className="nick nick--1l" style={{ flex: 1, minWidth: 0 }}>{p.name}{p.bot && <NpcTag />}</span>
            {p.id === room.you && <MePill />}
            {showScore && <span className="jua">{fmt(p.score, scoreUnit)}</span>}
          </div>
        ))}
      </div>
      {children}
      {isHost ? (
        <div style={{ display: 'flex', gap: 10 }}>
          <button type="button" className="btn-sticker" data-tone="cream" onClick={onLobby}>대기실로</button>
          <button type="button" className="btn-sticker glow-box" data-tone="lime" onClick={onAgain}>한 판 더!</button>
        </div>
      ) : (
        <WaitBar>방장을 기다리는 중</WaitBar>
      )}
    </div>
  )
}
