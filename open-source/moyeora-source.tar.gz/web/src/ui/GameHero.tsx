import { Hero as MarblesHero } from '../games/marbles/Hero.tsx'
import { Hero as PlateHero } from '../games/plate/Hero.tsx'
import { Hero as BurgerHero } from '../games/burger/Hero.tsx'
import { Hero as OthelloHero } from '../games/othello/Hero.tsx'
import { Hero as GobbleHero } from '../games/gobble/Hero.tsx'
import type { AppGameId } from '../games.ts'
import { Hero as SudokuHero } from '../games/sudoku/Hero.tsx'
import { LadderHero } from '../games/ladder/LadderHero.tsx'
import { Hero as LiarHero } from '../games/liar/Hero.tsx'
import { Hero as NunchiHero } from '../games/nunchi/Hero.tsx'
import { Hero as PirateHero } from '../games/pirate/Hero.tsx'
import { Hero as StopwatchHero } from '../games/stopwatch/Hero.tsx'
import { Hero as WhoPickedHero } from '../games/who-picked/Hero.tsx'
import { Jar } from './Jar.tsx'
import { Hero as JuiceHero } from '../games/juice/Hero.tsx'

/** 게임 id → 그 게임의 그림. size 는 대략 가로 px. */
export function GameHero({ id, size }: { id: AppGameId; size: number }) {
  switch (id) {
    case 'sudoku': return <SudokuHero size={size} />
    case 'sus-jar': return <Jar width={size} />
    case 'who-picked': return <WhoPickedHero width={size} />
    case 'liar': return <LiarHero width={size} />
    case 'nunchi': return <NunchiHero size={size} />
    case 'stopwatch': return <StopwatchHero size={size} />
    case 'pirate': return <PirateHero size={size} />
    case 'ladder': return <LadderHero size={size} />
    case 'othello': return <OthelloHero size={size} />
    case 'gobble': return <GobbleHero size={size} />
    case 'marbles': return <MarblesHero size={size} />
    case 'plate': return <PlateHero size={size} />
    case 'burger': return <BurgerHero size={size} />
    case 'juice': return <JuiceHero size={size} />
  }
}
