import type { Player } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { MePill } from './MePill.tsx'

/** 탈락한 순서로 쌓이는 아바타. 라운드마다 부모가 새 목록을 넘긴다. */
export function EliminationStrip({ players, you, total }: { players: Player[]; you: string; total: number }) {
  return <div style={{ display: 'flex', flexDirection: 'column', gap: 10, minHeight: 82 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--lav)', fontSize: 13 }}>
      <span>탈락한 친구들</span><span>{total - players.length}명 생존</span>
    </div>
    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', paddingTop: 4 }}>
      {players.map((p) => <div className="pop" key={p.id} title={p.name} style={{ position: 'relative' }}>
        <Avatar seed={p.avatar} size={36} dim ring={p.id === you} />
        {p.id === you && <MePill floating />}
      </div>)}
      {!players.length && <span style={{ fontSize: 13, color: 'var(--lav-dim)' }}>아직 모두 살아 있어요!</span>}
    </div>
  </div>
}
