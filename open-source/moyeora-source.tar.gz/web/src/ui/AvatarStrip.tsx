import type { Player, RoomView } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'

export function AvatarStrip({ room, compact = false, dim, ring }: { room: RoomView; compact?: boolean; dim?: (p: Player) => boolean; ring?: (p: Player) => boolean }) {
  const n = room.players.filter((p) => p.submitted).length
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: compact ? 4 : 8, flexWrap: 'wrap' }}>
      <div style={{ display: 'flex', gap: compact ? 4 : 8, flexWrap: 'wrap', flex: 1 }}>
        {room.players.map((p) => (
          <Avatar key={p.id} seed={p.avatar} size={compact ? 28 : 36} ring={ring ? ring(p) : p.submitted} dim={dim ? dim(p) : !p.submitted} />
        ))}
      </div>
      {!compact && <span className="jua" style={{ color: 'var(--lav)', fontSize: 17 }}>
        <span style={{ color: 'var(--lime)' }}>{n}</span> / {room.players.length} 제출
      </span>}
    </div>
  )
}
