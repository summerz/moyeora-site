import { useState } from 'react'
import { applyUpdate } from '../appUpdate.ts'

/** 새 버전이 기다리는 중일 때 안전한 화면 위에 놓는 줄 */
export function UpdateBar() {
  const [busy, setBusy] = useState(false)
  return (
    <div className="sticker sticker--dark" role="status" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '8px 8px 8px 14px', marginBottom: 12 }}>
      <span className="jua" style={{ color: '#fff', fontSize: 16 }}>새 버전이 나왔어요</span>
      <button type="button" className="chip" disabled={busy} onClick={() => { setBusy(true); void applyUpdate() }} style={{ background: 'var(--lime)', fontSize: 15, cursor: 'pointer' }}>업데이트</button>
    </div>
  )
}
