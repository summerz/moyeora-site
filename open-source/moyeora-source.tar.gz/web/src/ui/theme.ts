import { createTheme, type MantineColorsTuple } from '@mantine/core'

const lime: MantineColorsTuple = ['#f1ffe6', '#e0ffc9', '#c9ff9f', '#b2ff75', '#9fff58', '#8cff4d', '#7be63f', '#5fb82f', '#468a22', '#2e5c16']

export const theme = createTheme({
  fontFamily: '"Noto Sans KR", system-ui, -apple-system, "Apple SD Gothic Neo", sans-serif',
  headings: { fontFamily: 'Jua, "Noto Sans KR", sans-serif' },
  primaryColor: 'lime',
  colors: { lime },
  black: '#0E0A1C',
  defaultRadius: 'lg',
})
