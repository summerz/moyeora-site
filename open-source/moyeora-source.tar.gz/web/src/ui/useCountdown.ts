import { useEffect, useMemo, useState } from 'react'

/** Remaining ms until a deadline derived from the latest `remainingMs` prop; re-renders every 250 ms. */
export function useCountdown(remainingMs: number | null): number | null {
  const deadline = useMemo(() => (remainingMs === null ? null : Date.now() + remainingMs), [remainingMs])
  const [, tick] = useState(0)
  useEffect(() => {
    if (deadline === null) return
    const t = setInterval(() => tick((n) => n + 1), 250)
    return () => clearInterval(t)
  }, [deadline])
  return deadline === null ? null : Math.max(0, deadline - Date.now())
}
