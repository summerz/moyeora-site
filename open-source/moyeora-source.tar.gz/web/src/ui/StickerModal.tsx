import { useEffect, useRef, type ReactNode } from 'react'

/** 모달 틀: 어두운 배경 + 스티커 카드. Esc·배경 터치로 닫고(onClose 가 있을 때), 열릴 때 첫 버튼에 포커스 */
type Props = {
  /** 없으면 Esc·배경 터치로 닫히지 않는다(결과창처럼 버튼으로만 넘어가는 모달) */
  onClose?: () => void
  children: ReactNode
  labelledBy?: string
  /** 'plain' = 연두 아닌 기본 카드 (연두는 '나' 전용) */
  tone?: 'lime' | 'plain'
  /** 뒤 화면이 비쳐 보이게 배경을 옅게 */
  lite?: boolean
  className?: string
}

export function StickerModal({ onClose, children, labelledBy, tone = 'lime', lite = false, className = '' }: Props) {
  const card = useRef<HTMLDivElement>(null)
  const close = useRef(onClose)
  close.current = onClose
  useEffect(() => {
    card.current?.querySelector('button')?.focus()
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') close.current?.() }
    window.addEventListener('keydown', key)
    return () => window.removeEventListener('keydown', key)
  }, [])
  return (
    <div className={`${lite ? 'modal modal--lite' : 'modal'} ${className}`} role="dialog" aria-modal="true" aria-labelledby={labelledBy} onClick={(e) => { if (e.target === e.currentTarget) onClose?.() }}>
      <div ref={card} className={tone === 'lime' ? 'sticker sticker--lime tilt-b modal__card' : 'sticker tilt-b modal__card'}>{children}</div>
    </div>
  )
}
