export type Profile = { name: string; avatar: string }

const KEY = 'moyeora:profile'

export function loadProfile(): Profile | null {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) ?? 'null')
    const name = typeof v?.name === 'string' ? v.name.trim().slice(0, 12) : ''
    if (name && typeof v.avatar === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(v.avatar)) return { name, avatar: v.avatar }
  } catch {}
  return null
}

export function saveProfile(p: Profile) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p))
  } catch {}
}
