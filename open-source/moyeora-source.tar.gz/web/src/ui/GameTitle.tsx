import { gameMeta, type AppGameId } from '../games.ts'

/** 게임 이름 + 한 줄 소개. */
export function GameTitle({ id }: { id: AppGameId }) {
  const game = gameMeta(id)
  return (
    <div style={{ textAlign: 'center' }}>
      <h1 className="jua glow" style={{ fontSize: 40, lineHeight: 1.1, margin: 0, color: '#fff', fontWeight: 400 }}>{game.title}</h1>
      <div style={{ fontSize: 14, color: 'var(--lav)', marginTop: 4 }}>{game.tagline}</div>
    </div>
  )
}
