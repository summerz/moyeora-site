import { useRef, useState, type ReactNode } from 'react'
import { StickerModal } from './StickerModal.tsx'

export type TutorialPage = { title: string; art?: ReactNode; line: ReactNode }

/** 게임 방법 모달: 쪽마다 제목 + 그림(고정 높이) + 짧은 한두 줄. 좌우로 쓸어 넘길 수 있다 */
export function Tutorial({ pages, onClose }: { pages: TutorialPage[]; onClose: () => void }) {
  const [page, setPage] = useState(0)
  const down = useRef(0)
  const last = page === pages.length - 1
  const go = (d: number) => setPage((x) => Math.min(pages.length - 1, Math.max(0, x + d)))
  const hasArt = pages.some((x) => x.art)
  return (
    <StickerModal onClose={onClose} labelledBy="tut-title" className="modal--tutorial">
      <div onPointerDown={(e) => { down.current = e.clientX }} onPointerUp={(e) => { const dx = e.clientX - down.current; if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1) }} style={{ touchAction: 'pan-y' }}>
        {/* 모든 쪽을 한 칸에 겹쳐 두고 지금 쪽만 보인다 → 모달 높이 = 가장 긴 쪽, 넘겨도 안 출렁인다 */}
        <div className="tut__stack">
          {pages.map((x, i) => (
            <div key={i} className="tut__page" aria-hidden={i !== page} data-on={i === page ? '1' : '0'}>
              <div id={i === page ? 'tut-title' : undefined} className="jua modal__title">{x.title}</div>
              {hasArt && <div className="tut__art">{x.art}</div>}
              <div className="tut__line" style={hasArt ? undefined : { textAlign: 'left', fontSize: 15 }}>{x.line}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="tut__dots" aria-hidden="true">
        {pages.map((_, i) => <span key={i} className="tut__dot" data-on={i === page ? '1' : '0'} />)}
      </div>
      <div className="tut__btns">
        {page > 0 && <button type="button" className="btn-sticker" data-tone="cream" onClick={() => go(-1)}>이전</button>}
        <button type="button" className="btn-sticker" data-tone="lime" onClick={() => (last ? onClose() : go(1))}>{last ? '알겠어요!' : '다음'}</button>
      </div>
    </StickerModal>
  )
}
