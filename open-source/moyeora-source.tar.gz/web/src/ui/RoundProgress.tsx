type Props = { round: number; rounds: number; done?: boolean; compact?: boolean }

export function RoundProgress({ round, rounds, done = false, compact = false }: Props) {
  return (
    <span className="chip tilt-a" style={{ background: 'var(--cream)', fontSize: 15, display: 'inline-flex', alignItems: 'center', gap: 8, padding: '3px 12px' }}>
      <span style={{ whiteSpace: 'nowrap' }}>{round} / {rounds}</span>
      {!compact && <span style={{ display: 'inline-flex', gap: 4 }} aria-hidden="true">
        {Array.from({ length: rounds }, (_, i) => {
          const n = i + 1
          const current = n === round
          const color = n < round || (current && done) ? 'var(--lime)' : current ? 'var(--amber)' : 'var(--cream)'
          return <span key={n} style={{ width: 10, height: 10, borderRadius: 3, border: '2px solid var(--ink)', boxSizing: 'border-box', background: color, ...(current && !done ? { animation: 'pip-pulse 1.2s infinite' } : null) }} />
        })}
      </span>}
    </span>
  )
}
