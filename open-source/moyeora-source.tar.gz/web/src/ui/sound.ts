import { useEffect } from 'react'
import tickUrl from './sfx/tick.wav'

const KEY = 'moyeora:sound'
const VOLUME = 0.6
type Cancel = () => void
const NOOP: Cancel = () => {}

let ctx: AudioContext | null = null
let master: GainNode | null = null
const sampleBuffers = new Map<string, Promise<AudioBuffer | null>>()
let muted = (() => {
  try { return localStorage.getItem(KEY) === 'off' } catch { return false }
})()

const getCtx = (): AudioContext | null => {
  if (ctx) return ctx
  const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
  if (!AC) return null
  ctx = new AC()
  master = ctx.createGain()
  master.gain.value = VOLUME
  master.connect(ctx.destination)
  return ctx
}

/** 사용자 제스처 안에서 호출: 컨텍스트를 만들고 재개 */
export function unlockAudio() {
  const c = getCtx()
  if (c && c.state !== 'running') void c.resume().catch(() => {})
}

/** 첫 터치/키 입력에 한 번 잠금 해제 (Shell 에서 호출). 해제 함수 반환 */
export function installUnlock(): Cancel {
  const off = () => {
    window.removeEventListener('pointerdown', on, true)
    window.removeEventListener('keydown', on, true)
  }
  const on = () => {
    unlockAudio()
    if (ctx?.state === 'running') off()
  }
  window.addEventListener('pointerdown', on, true)
  window.addEventListener('keydown', on, true)
  return off
}

export const isMuted = () => muted
export function setMuted(b: boolean) {
  muted = b
  try { localStorage.setItem(KEY, b ? 'off' : 'on') } catch { /* ignore */ }
}

/** performance.now() ms → AudioContext 시각(초), 과거면 지금 */
const toCtxTime = (c: AudioContext, when: number) => Math.max(c.currentTime, c.currentTime + (when - performance.now()) / 1000)

export function beepAt(when: number, kind: 'count' | 'go'): Cancel {
  const c = muted ? null : getCtx()
  if (!c || !master) return NOOP
  const t = toCtxTime(c, when)
  const go = kind === 'go'
  const dur = go ? 0.3 : 0.11
  const peak = go ? 0.9 : 0.7
  const osc = c.createOscillator()
  const g = c.createGain()
  osc.type = go ? 'triangle' : 'sine'
  osc.frequency.value = go ? 1320 : 880
  g.gain.setValueAtTime(0.0001, t)
  g.gain.linearRampToValueAtTime(peak, t + 0.008)
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
  osc.connect(g).connect(master)
  osc.start(t)
  osc.stop(t + dur + 0.02)
  return () => {
    try { osc.stop(); osc.disconnect(); g.disconnect() } catch { /* already stopped */ }
  }
}

const loadSample = (c: AudioContext, url: string) => {
  let buffer = sampleBuffers.get(url)
  if (!buffer) {
    buffer = fetch(url).then((r) => {
      if (!r.ok) throw new Error('sound unavailable')
      return r.arrayBuffer()
    }).then((b) => c.decodeAudioData(b)).catch(() => {
      sampleBuffers.delete(url)
      return null
    })
    sampleBuffers.set(url, buffer)
  }
  return buffer
}

/** 준비 중 미리 읽어 첫 판정에서도 바로 소리가 나게 한다. */
export function preloadSamples(urls: readonly string[]) {
  const c = getCtx()
  if (c) urls.forEach((url) => { void loadSample(c, url) })
}

/** 공용 음소거·볼륨·잠금 해제를 사용하는 파일 효과음. */
export function sampleAt(when: number, url: string): Cancel {
  const c = muted ? null : getCtx()
  if (!c || !master) return NOOP
  let src: AudioBufferSourceNode | null = null
  let cancelled = false
  void loadSample(c, url).then((buf) => {
    if (!buf || cancelled || muted || !master) return
    src = c.createBufferSource()
    src.buffer = buf
    src.connect(master)
    src.start(toCtxTime(c, when))
  })
  return () => {
    cancelled = true
    try { src?.stop(); src?.disconnect() } catch { /* not started */ }
  }
}

export function tickAt(when: number): Cancel { return sampleAt(when, tickUrl) }

/** 사전 카운트다운 3·2·1·시작: goAt(performance.now 기준 ms)에서 역산해 예약 */
export function useCountdownBeeps(goAtPerf: number | null) {
  useEffect(() => {
    if (goAtPerf === null) return
    const now = performance.now()
    const cancels: Cancel[] = []
    for (const k of [3, 2, 1, 0]) {
      const at = goAtPerf - k * 1000
      if (at - now < -80) continue
      cancels.push(beepAt(at, k === 0 ? 'go' : 'count'))
    }
    return () => cancels.forEach((f) => f())
  }, [goAtPerf])
}

const noise = (c: AudioContext, sec: number): AudioBufferSourceNode => {
  const buf = c.createBuffer(1, Math.ceil(c.sampleRate * sec), c.sampleRate)
  const d = buf.getChannelData(0)
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
  const src = c.createBufferSource()
  src.buffer = buf
  return src
}

/** 칼이 구멍에 '툭' 박히는 소리 (바로 재생) */
export function thud() {
  const c = muted ? null : getCtx()
  if (!c || !master) return
  const t = c.currentTime
  const osc = c.createOscillator()
  const g = c.createGain()
  osc.type = 'triangle'
  osc.frequency.setValueAtTime(260, t)
  osc.frequency.exponentialRampToValueAtTime(70, t + 0.09)
  g.gain.setValueAtTime(0.0001, t)
  g.gain.linearRampToValueAtTime(0.9, t + 0.006)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14)
  osc.connect(g).connect(master)
  osc.start(t)
  osc.stop(t + 0.16)
  const n = noise(c, 0.04)
  const ng = c.createGain()
  ng.gain.setValueAtTime(0.35, t)
  ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.04)
  n.connect(ng).connect(master)
  n.start(t)
}

/** 해적이 '펑!' 튀어나오는 소리 (바로 재생) */
/** 펑! 직전 부들부들: durMs 동안 점점 빨라지고 높아지고 커지는 떨림 소리 (끝에서 조용히 끊겨 boom 으로 이어진다) */
export function rattle(durMs: number) {
  const c = muted ? null : getCtx()
  if (!c || !master) return
  const t = c.currentTime
  const d = durMs / 1000
  const osc = c.createOscillator()
  osc.type = 'sawtooth'
  osc.frequency.setValueAtTime(90, t)
  osc.frequency.exponentialRampToValueAtTime(300, t + d)
  const lfo = c.createOscillator()
  lfo.frequency.setValueAtTime(11, t)
  lfo.frequency.exponentialRampToValueAtTime(38, t + d)
  const lg = c.createGain()
  lg.gain.value = 0.5
  const g = c.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(0.5, t + d * 0.95)
  g.gain.linearRampToValueAtTime(0.0001, t + d)
  const tremolo = c.createGain()
  tremolo.gain.value = 0.5
  lfo.connect(lg).connect(tremolo.gain)
  osc.connect(tremolo).connect(g).connect(master)
  osc.start(t)
  lfo.start(t)
  osc.stop(t + d + 0.02)
  lfo.stop(t + d + 0.02)
}

export function boom() {
  const c = muted ? null : getCtx()
  if (!c || !master) return
  const t = c.currentTime
  const n = noise(c, 0.5)
  const f = c.createBiquadFilter()
  f.type = 'lowpass'
  f.frequency.setValueAtTime(3200, t)
  f.frequency.exponentialRampToValueAtTime(200, t + 0.45)
  const ng = c.createGain()
  ng.gain.setValueAtTime(0.9, t)
  ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.5)
  n.connect(f).connect(ng).connect(master)
  n.start(t)
  const osc = c.createOscillator()
  const g = c.createGain()
  osc.type = 'sine'
  osc.frequency.setValueAtTime(180, t)
  osc.frequency.exponentialRampToValueAtTime(40, t + 0.3)
  g.gain.setValueAtTime(1, t)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35)
  osc.connect(g).connect(master)
  osc.start(t)
  osc.stop(t + 0.4)
  // 튀어 오르는 '보잉'
  const s = c.createOscillator()
  const sg = c.createGain()
  s.type = 'square'
  s.frequency.setValueAtTime(300, t + 0.08)
  s.frequency.exponentialRampToValueAtTime(900, t + 0.4)
  sg.gain.setValueAtTime(0.0001, t + 0.08)
  sg.gain.linearRampToValueAtTime(0.18, t + 0.12)
  sg.gain.exponentialRampToValueAtTime(0.0001, t + 0.45)
  s.connect(sg).connect(master)
  s.start(t + 0.08)
  s.stop(t + 0.5)
}
