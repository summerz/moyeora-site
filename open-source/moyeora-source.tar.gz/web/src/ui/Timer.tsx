import { useCountdown } from './useCountdown.ts'

type Props = { remainingMs: number | null; totalMs: number; label?: string }

const R = 23
const C = 2 * Math.PI * R

export function Timer({ remainingMs, totalMs, label }: Props) {
  const left = useCountdown(remainingMs)
  if (left === null) return null
  const secs = Math.ceil(left / 1000)
  const frac = Math.min(1, left / totalMs)
  return (
    <div role="timer" aria-label={`남은 시간 ${secs}초`} style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
      <svg width={56} height={56} viewBox="0 0 56 56">
        <circle cx={28} cy={28} r={26} fill="var(--cream)" stroke="var(--ink)" strokeWidth={3} />
        <circle className="timer-ring" cx={28} cy={28} r={R} fill="none" stroke="var(--lime)" strokeWidth={5} strokeLinecap="round" strokeDasharray={`${C * frac} ${C}`} transform="rotate(-90 28 28)" />
        <text x={28} y={29} textAnchor="middle" dominantBaseline="central" fontFamily="Jua, sans-serif" fontSize={22} fill="var(--ink)">{secs}</text>
      </svg>
      {label && <span className="jua" style={{ color: 'var(--lav)' }}>{label}</span>}
    </div>
  )
}
