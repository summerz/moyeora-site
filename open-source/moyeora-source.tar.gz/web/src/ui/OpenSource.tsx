import { useEffect, useState } from 'react'
import { StickerModal } from './StickerModal.tsx'

type Notice = { name: string; version: string; license: string; source: string; licenses: string[]; modified?: string }

/** Shared home/solo-game attribution menu, with full notices and corresponding build sources. */
export function OpenSourceLink() {
  const [open, setOpen] = useState(false)
  const [notices, setNotices] = useState<Notice[] | null>(null)
  const [error, setError] = useState(false)
  useEffect(() => {
    if (!open || notices) return
    const controller = new AbortController()
    fetch(`${import.meta.env.BASE_URL}open-source/notices.json`, { signal: controller.signal })
      .then((r) => { if (!r.ok) throw new Error('notices'); return r.json() })
      .then((data: Notice[]) => { setNotices(data); setError(false) })
      .catch((e: unknown) => { if (!(e instanceof DOMException && e.name === 'AbortError')) setError(true) })
    return () => controller.abort()
  }, [open, notices])
  return <>
    <button type="button" onClick={() => setOpen(true)} style={{ border: 0, padding: 0, background: 'transparent', color: 'var(--lav)', textDecoration: 'underline', fontSize: 12, cursor: 'pointer' }}>오픈소스</button>
    {open && <StickerModal onClose={() => setOpen(false)} labelledBy="oss-title" tone="plain">
      <h2 id="oss-title" className="jua modal__title--sm">모여라의 오픈소스</h2>
      <div style={{ overflowY: 'auto', maxHeight: '55dvh', fontSize: 12, color: 'var(--ink)' }}>
        <p>모여라를 만드는 데 사용한 오픈소스입니다. 저작권과 이용 조건은 각 라이선스 전문에서 확인할 수 있어요.</p>
        {!notices && <p role="status">{error ? '목록을 불러오지 못했어요. 창을 닫고 다시 열어 주세요.' : '목록을 불러오는 중…'}</p>}
        {notices?.map((n) => <article key={`${n.name}-${n.version}`} style={{ borderTop: '1px solid #c1b7ae', padding: '10px 0' }}>
          <strong>{n.name} {n.version}</strong><div>{n.license}</div>
          {n.modified && <p style={{ margin: '5px 0' }}>{n.modified}</p>}
          <a href={n.source} target="_blank" rel="noreferrer">원본 소스</a>
          {n.licenses.map((p, i) => <a key={p} href={import.meta.env.BASE_URL + p} target="_blank" rel="noreferrer" style={{ marginLeft: 10 }}>라이선스 전문{n.licenses.length > 1 ? ` ${i + 1}` : ''}</a>)}
        </article>)}
        <p>글꼴: Jua · Noto Sans KR — SIL Open Font License 1.1. <a href="https://github.com/google/fonts" target="_blank" rel="noreferrer">원본·라이선스</a></p>
        <p>QQWing 원본을 함께 보관하고, 수정한 코드와 웹·공용 패키지의 빌드 소스를 제공합니다.</p>
        <a href={`${import.meta.env.BASE_URL}open-source/qqwing-1.3.4-original.js`} download>QQWing 원본 JS</a><br />
        <a href={`${import.meta.env.BASE_URL}open-source/moyeora-source.tar.gz`} download>모여라 웹 소스 내려받기</a>
      </div>
      <button type="button" className="btn-sticker" data-tone="lime" onClick={() => setOpen(false)}>닫기</button>
    </StickerModal>}
  </>
}
