import { Avatar } from './Avatar.tsx'
import type { Profile } from './profile.ts'

/** 내 프로필 카드 (홈·각 게임 참가 화면 공통). */
export function ProfileCard({ profile, onEdit }: { profile: Profile; onEdit: () => void }) {
  return (
    <div className="sticker tilt-b" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px' }}>
      <Avatar seed={profile.avatar} size={56} />
      <span className="nick nick--lg nick--1l" style={{ flex: 1, minWidth: 0 }}>{profile.name}</span>
      <button type="button" onClick={onEdit} style={{ background: 'none', border: 0, color: '#6b5f8a', fontSize: 14, textDecoration: 'underline', cursor: 'pointer' }}>바꾸기</button>
    </div>
  )
}
