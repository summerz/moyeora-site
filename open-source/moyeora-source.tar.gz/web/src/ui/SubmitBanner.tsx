import { useEffect, useRef, useState } from 'react'
import type { RoomBase } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { Icon } from './icons.tsx'
import { NpcTag } from './NpcTag.tsx'

type Item = { id: string; name: string; avatar: string; bot: boolean; label: string; eliminated: boolean }

/** 제출·자동 선택 등 플레이어의 행동을 알리는 공용 스티커. */
export function PlayerNotice({ name, avatar, bot, label, eliminated = false, compact = false, tone = 'lime', icon = true }: Omit<Item, 'id' | 'eliminated'> & { eliminated?: boolean; compact?: boolean; tone?: 'lime' | 'plain'; icon?: boolean }) {
  return <div role="status" className={`sticker ${eliminated ? 'sticker--red' : tone === 'lime' ? 'sticker--lime' : ''} tilt-d pop`} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: compact ? '4px 12px' : '10px 14px', background: tone === 'plain' ? 'var(--cream)' : undefined }}>
    <Avatar seed={avatar} size={compact ? 40 : 64} />
    <div style={{ flex: 1, minWidth: 0 }}>
      <div className="nick nick--sm nick--1l">{name}{bot && <NpcTag />}</div>
      <div className="jua" style={{ fontSize: compact ? 22 : 28, lineHeight: 1.1 }}>{label}</div>
    </div>
    {icon && <Icon name={eliminated ? 'skull' : 'check'} size={compact ? 24 : 32} color={eliminated ? 'var(--ink)' : 'var(--green)'} />}
  </div>
}

/** Shows a short `label` sticker for each newly submitted player, one at a time. */
export function SubmitBanner({ room, label, compact = false, eliminated = false, durationMs = 1600 }: { room: Pick<RoomBase, 'players'>; label: string | ((id: string) => string); compact?: boolean; eliminated?: boolean | ((id: string) => boolean); durationMs?: number }) {
  const seen = useRef<Set<string> | null>(null)
  const [queue, setQueue] = useState<Item[]>([])

  useEffect(() => {
    const now = new Set(room.players.filter((p) => p.submitted).map((p) => p.id))
    const prev = seen.current
    seen.current = now
    if (!prev) return
    const added = room.players.filter((p) => p.submitted && !prev.has(p.id)).map((p) => ({ id: p.id, name: p.name, avatar: p.avatar, bot: p.bot, label: typeof label === 'function' ? label(p.id) : label, eliminated: typeof eliminated === 'function' ? eliminated(p.id) : eliminated }))
    if (added.length) setQueue((q) => [...q, ...added])
  }, [room.players, label, eliminated])

  const head = queue[0]
  useEffect(() => {
    if (!head) return
    const t = setTimeout(() => setQueue((q) => q.slice(1)), durationMs)
    return () => clearTimeout(t)
  }, [head, durationMs])

  return (
    <div style={{ minHeight: compact ? 56 : 100 }}>
      {head && (
        <PlayerNotice key={head.id} {...head} compact={compact} />
      )}
    </div>
  )
}
