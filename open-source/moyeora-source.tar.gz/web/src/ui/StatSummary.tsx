import type { ReactNode } from 'react'

/** 카드·결과 화면에서 같은 크기로 표시하는 두 열 통계. */
export function StatSummary({ items, className = '' }: {
  items: { label: string; value: ReactNode }[]
  className?: string
}) {
  return <dl className={`stat-summary ${className}`}>
    {items.map(({ label, value }) => <div className="stat-summary__item" key={label}>
      <dt>{label}</dt>
      <dd className="jua">{value}</dd>
    </div>)}
  </dl>
}
