import { useState } from 'react'
import { TextInput } from '@mantine/core'
import { Avatar } from './Avatar.tsx'
import { Icon } from './icons.tsx'
import { randomName, randomSeed } from '@moyeora/shared'
import { saveProfile, type Profile as ProfileData } from './profile.ts'

type Props = { initial?: ProfileData; onDone: (p: ProfileData) => void }

export function Profile({ initial, onDone }: Props) {
  const [seed, setSeed] = useState(() => initial?.avatar ?? randomSeed())
  const [name, setName] = useState(() => initial?.name ?? randomName())
  const [recent, setRecent] = useState<string[]>([])
  const trimmed = name.trim()

  const reroll = () => {
    setRecent((r) => [seed, ...r.filter((s) => s !== seed)].slice(0, 5))
    setSeed(randomSeed())
  }
  const done = () => {
    const p = { name: trimmed, avatar: seed }
    saveProfile(p)
    onDone(p)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div>
        <h1 className="jua" style={{ fontSize: 34, margin: 0, color: 'var(--text)' }}>{initial ? '프로필 바꾸기' : '처음 왔네요!'}</h1>
        <div style={{ color: 'var(--lav)', marginTop: 4 }}>친구들에게 보일 모습을 골라요</div>
      </div>
      <div className="sticker sticker--lime tilt-a" style={{ padding: '22px 18px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
        <div style={{ position: 'relative' }}>
          <Avatar seed={seed} size={128} />
          <button type="button" aria-label="아바타 다시 뽑기" onClick={reroll} style={{ position: 'absolute', right: -8, bottom: -4, width: 48, height: 48, borderRadius: '50%', background: 'var(--lime)', border: '3px solid var(--ink)', boxShadow: '3px 3px 0 var(--ink)', display: 'grid', placeItems: 'center', color: 'var(--ink)', cursor: 'pointer', padding: 0 }}>
            <Icon name="refresh" size={24} />
          </button>
        </div>
        {recent.length > 0 && (
          <div style={{ display: 'flex', gap: 8 }}>
            {recent.map((s) => (
              <button key={s} type="button" aria-label="이전 아바타 고르기" onClick={() => setSeed(s)} style={{ background: 'none', border: 0, padding: 0, cursor: 'pointer' }}>
                <Avatar seed={s} size={44} />
              </button>
            ))}
          </div>
        )}
        <div style={{ fontSize: 13, color: '#6b5f8a' }}>누르면 다른 얼굴이 나와요</div>
      </div>
      <div>
        <div className="jua" style={{ color: 'var(--lav)', fontSize: 18, marginBottom: 6 }}>이름</div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <TextInput style={{ flex: 1 }} classNames={{ input: 'name-input' }} maxLength={12} value={name} onChange={(e) => setName(e.currentTarget.value)} aria-label="이름" />
          <button type="button" aria-label="이름 다시 뽑기" className="btn-sticker" data-tone="amber" onClick={() => setName(randomName())} style={{ width: 56, minHeight: 56, height: 56, padding: 0 }}>
            <Icon name="dice" size={28} />
          </button>
        </div>
        <div style={{ fontSize: 13, color: 'var(--lav-dim)', marginTop: 8 }}>주사위를 누르면 "용감한 감자" 같은 이름이 새로 나와요. 직접 써도 돼요.</div>
      </div>
      <button type="button" className="btn-sticker" data-tone="lime" disabled={!trimmed} onClick={done}>이걸로 할게요</button>
    </div>
  )
}
