import type { ReactNode } from 'react'
import type { Player } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { MePill } from './MePill.tsx'
import { NpcTag } from './NpcTag.tsx'
import './playerLabel.css'

/** 말판 위·아래의 플레이어 이름과 말 색/개수. */
export function PlayerLabel({ player, me, children }: { player: Player; me: boolean; children: ReactNode }) {
  return <div className="player-label">
    <Avatar seed={player.avatar} size={28} />
    <span className="nick nick--1l">{player.name}</span>
    {me && <MePill />}{player.bot && <NpcTag />}{children}
  </div>
}
