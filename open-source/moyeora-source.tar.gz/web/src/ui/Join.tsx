import { useState } from 'react'
import { PinInput } from '@mantine/core'
import { isOff, type GameId } from '@moyeora/shared'
import { GameHero } from './GameHero.tsx'
import { GameTitle } from './GameTitle.tsx'
import { ProfileCard } from './ProfileCard.tsx'
import type { Profile } from './profile.ts'

type Props = { game: GameId; profile: Profile; onEdit: () => void; onCreate: () => void; onJoin: (code: string) => void; error?: string }

export function Join({ game, profile, onEdit, onCreate, onJoin, error }: Props) {
  const [code, setCode] = useState('')
  if (isOff(game)) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <GameTitle id={game} />
        <GameHero id={game} size={100} />
        <div className="sticker sticker--dark" style={{ padding: '18px 16px', textAlign: 'center' }} role="status">
          <span className="jua" style={{ fontSize: 20, color: '#fff' }}>지금은 쉬는 중인 게임이에요</span>
        </div>
        <a className="btn-sticker" data-tone="lime" href={import.meta.env.BASE_URL} style={{ textDecoration: 'none', textAlign: 'center' }}>홈으로</a>
      </div>
    )
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <GameTitle id={game} />
      <GameHero id={game} size={100} />
      <ProfileCard profile={profile} onEdit={onEdit} />
      <button type="button" className="btn-sticker" data-tone="lime" onClick={onCreate}>방 만들기</button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'var(--lav-dim)' }}>
        <div style={{ flex: 1, height: 2, background: 'var(--card)' }} />코드로 참가<div style={{ flex: 1, height: 2, background: 'var(--card)' }} />
      </div>
      <label htmlFor="join-code" className="jua" style={{ fontSize: 16, color: 'var(--lav)', textAlign: 'center' }}>친구가 불러 준 방 코드 6자리</label>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <PinInput id="join-code" length={6} type="number" inputMode="numeric" size="lg" placeholder="" value={code} onChange={setCode} aria-label="방 코드" />
      </div>
      <button type="button" className="btn-sticker" data-tone="cream" disabled={code.length !== 6} onClick={() => onJoin(code)}>이 코드로 참가</button>
      {error && <div style={{ color: 'var(--red)', textAlign: 'center' }} role="alert">{error}</div>}
    </div>
  )
}
