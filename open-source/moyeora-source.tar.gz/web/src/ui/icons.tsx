import type { ReactNode } from 'react'

export type IconName = 'skull' | 'cup' | 'arrow-right' | 'drop' | 'crown' | 'dice' | 'refresh' | 'check' | 'cup-q' | 'half' | 'plus' | 'minus' | 'star' | 'speaker' | 'speaker-off'

const PATHS: Record<IconName, ReactNode> = {
  skull: <><path d="M12 3a8 8 0 0 0-8 8c0 2.6 1.3 4.3 3 5.3V20h10v-3.7c1.7-1 3-2.7 3-5.3a8 8 0 0 0-8-8z" /><circle cx="9" cy="11.5" r="1.6" /><circle cx="15" cy="11.5" r="1.6" /><path d="M10 20v-2.5M14 20v-2.5" /></>,
  cup: <path d="M5 4h14l-1.6 15a2 2 0 0 1-2 1.8H8.6a2 2 0 0 1-2-1.8zM6 9h12" />,
  'arrow-right': <path d="M4 12h15M13 6l6 6-6 6" />,
  drop: <path d="M12 3c3.5 4.3 6 7.4 6 10.5a6 6 0 0 1-12 0C6 10.4 8.5 7.3 12 3z" />,
  crown: <path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z" />,
  dice: <><rect x="4" y="4" width="16" height="16" rx="3.5" /><circle cx="9" cy="9" r="1" /><circle cx="15" cy="9" r="1" /><circle cx="9" cy="15" r="1" /><circle cx="15" cy="15" r="1" /></>,
  refresh: <path d="M20 11a8 8 0 0 0-14.5-4M4 4v4h4M4 13a8 8 0 0 0 14.5 4M20 20v-4h-4" />,
  'cup-q': <><path d="M5 4h14l-1.6 15a2 2 0 0 1-2 1.8H8.6a2 2 0 0 1-2-1.8zM6 9h12" /><path d="M10.6 12.6a1.5 1.5 0 1 1 2.2 1.3c-.5.3-.8.6-.8 1.2M12 17.4v.1" /></>,
  half: <><circle cx="12" cy="12" r="8.5" /><path d="M12 3.5a8.5 8.5 0 0 1 0 17z" fill="currentColor" /></>,
  star: <path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  check: <path d="M4 12.5l5 5L20 6.5" />,
  speaker: <><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" /><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" /></>,
  'speaker-off': <><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" /><path d="M16 9.5l5 5M21 9.5l-5 5" /></>,
}

export function Icon({ name, size = 22, color = 'currentColor' }: { name: IconName; size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: 0 }}>
      {PATHS[name]}
    </svg>
  )
}
