export function Jar({ width = 70 }: { width?: number }) {
  const k = width / 70
  return (
    <div aria-hidden="true" style={{ width, height: 64 * k, margin: '0 auto' }}>
      <div style={{ position: 'relative', width: 70, height: 64, transform: `scale(${k})`, transformOrigin: 'top left' }}>
        <div style={{ position: 'absolute', left: 8, right: 8, top: 0, height: 12, background: 'var(--lime)', border: '3px solid var(--ink)', borderRadius: 8, boxShadow: '0 0 18px rgba(140,255,77,.6)' }} />
        <div style={{ position: 'absolute', left: 0, right: 0, top: 10, bottom: 0, background: 'var(--card)', border: '3px solid var(--ink)', borderRadius: '16px 16px 24px 24px' }}>
          <div className="jar-eye" style={{ position: 'absolute', left: 16, top: 16, width: 8, height: 10, background: 'var(--lime)', borderRadius: '50%' }} />
          <div className="jar-eye" style={{ position: 'absolute', right: 16, top: 16, width: 8, height: 10, background: 'var(--lime)', borderRadius: '50%' }} />
          <div style={{ position: 'absolute', left: 22, right: 22, top: 32, height: 8, borderBottom: '3px solid var(--lime)', borderRadius: '0 0 12px 12px' }} />
        </div>
      </div>
    </div>
  )
}
