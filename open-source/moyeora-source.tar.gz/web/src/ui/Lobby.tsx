import { useState, type ReactNode } from 'react'
import type { RoomView } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { GameTitle } from './GameTitle.tsx'
import { Icon } from './icons.tsx'
import { MePill } from './MePill.tsx'
import { Jar } from './Jar.tsx'
import { NpcTag } from './NpcTag.tsx'
import { WaitBar } from './WaitBar.tsx'
import { ConfirmDialog } from './ConfirmDialog.tsx'

type Props = { room: RoomView; onStart: () => void; onKick: (playerId: string) => void; onAddBot: () => void; hero?: ReactNode; children?: ReactNode; canStart?: boolean; startHint?: string; allowBots?: boolean; maxPlayers?: number }

const TILTS = ['tilt-a', 'tilt-b', 'tilt-c', 'tilt-d']
const chipStyle = { padding: '8px 4px', boxShadow: '3px 3px 0 var(--ink)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, minWidth: 0 } as const
const nameStyle = { maxWidth: "100%", minHeight: 0 } as const

export function Lobby({ room, onStart, onKick, onAddBot, hero, children, canStart = room.players.length >= 2, startHint = '2명 이상 모이면 시작할 수 있어요', allowBots = true, maxPlayers = 8 }: Props) {
  const isHost = room.host === room.you
  const [kicking, setKicking] = useState<string | null>(null)
  const target = room.players.find((x) => x.id === kicking)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <GameTitle id={room.game} />
      {hero ?? <Jar width={room.players.length > 4 ? 96 : 140} />}
      <div className="sticker sticker--lime tilt-a" style={{ textAlign: 'center', padding: '10px 10px' }}>
        <div style={{ fontSize: 12, color: '#6b5f8a' }}>방 코드</div>
        <div className="jua" style={{ fontSize: room.players.length > 4 ? 50 : 56, lineHeight: 1.1 }}>{room.code.replace(/(\d{2})(?=\d)/g, '$1 ')}</div>
        <div style={{ fontSize: 13 }}>옆 사람에게 불러 주세요</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(4, maxPlayers)}, minmax(0, 1fr))`, gap: 10, paddingTop: 8 }}>
        {room.players.map((p, i) => {
          const kickable = isHost && p.id !== room.you
          const inner = (
            <>
              <div style={{ position: 'relative' }}>
                <Avatar seed={p.avatar} size={44} />
                {p.bot && <NpcTag overlay />}
                {p.id === room.host && (
                  <span style={{ position: 'absolute', right: -4, bottom: -2, width: 18, height: 18, borderRadius: '50%', background: 'var(--ink)', color: 'var(--amber)', display: 'grid', placeItems: 'center' }}>
                    <Icon name="crown" size={11} />
                  </span>
                )}
              </div>
              <span className="nick nick--sm nick--2l nick--center" style={nameStyle}>{p.name}</span>
            </>
          )
          const me = p.id === room.you
          const cls = `sticker ${TILTS[(i + 1) % 4]}${me ? ' glow-box' : ''}`
          const st = { ...chipStyle, position: 'relative', ...(me ? { border: '3px solid var(--lime)' } : {}) } as const
          return kickable ? (
            <button key={p.id} type="button" className={cls} style={{ ...st, font: 'inherit', cursor: 'pointer' }} onClick={() => setKicking(p.id)}>
              {me && <MePill floating />}{inner}
            </button>
          ) : (
            <div key={p.id} className={cls} style={st}>{me && <MePill floating />}{inner}</div>
          )
        })}
        {isHost && allowBots && room.players.length < maxPlayers && (
          <button type="button" onClick={onAddBot} aria-label="NPC 추가" style={{ ...chipStyle, border: '3px dashed var(--lav-dim)', borderRadius: 20, boxShadow: 'none', background: 'none', color: 'var(--lav)', justifyContent: 'center', cursor: 'pointer', minHeight: 80 }}>
            <Icon name="plus" size={20} />
            <span className="jua" style={{ fontSize: 14 }}>NPC</span>
          </button>
        )}
        {room.players.length < 2 && !isHost && (
          <div style={{ ...chipStyle, border: '3px dashed var(--lav-dim)', borderRadius: 20, color: 'var(--lav-dim)', justifyContent: 'center', fontSize: 11, fontWeight: 700, textAlign: 'center', minHeight: 80 }}>기다리는 중</div>
        )}
      </div>
      {children}
      {isHost ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button type="button" className="btn-sticker glow-box" data-tone="lime" disabled={!canStart} onClick={onStart}>시작!</button>
          <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>{startHint}</div>
        </div>
      ) : (
        <WaitBar>방장이 시작하기를 기다리는 중</WaitBar>
      )}
      {target && <ConfirmDialog title={<><span className="nick nick--lg">{target.name}</span> 내보낼까요?</>} confirmLabel="내보내기" onConfirm={() => { onKick(target.id); setKicking(null) }} onCancel={() => setKicking(null)} />}
    </div>
  )
}
