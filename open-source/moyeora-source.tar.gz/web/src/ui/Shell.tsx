import { useEffect, useState, type ReactNode } from 'react'
import { Container, MantineProvider } from '@mantine/core'
import '@mantine/core/styles.css'
import './sticker.css'
import { theme } from './theme.ts'
import { Icon } from './icons.tsx'
import { installUnlock, isMuted, setMuted } from './sound.ts'
import { startAnalytics } from '../analytics.ts'
import { startAppUpdate, useUpdateReady } from '../appUpdate.ts'
import { leaveRoom, useLink } from '../ws.ts'
import { LinkCard } from './LinkCard.tsx'
import { UpdateBar } from './UpdateBar.tsx'
import { ConfirmDialog } from './ConfirmDialog.tsx'

type Props = { right?: ReactNode; confirmHome?: boolean; onHelp?: () => void; home?: boolean; safe?: boolean; fit?: boolean; solo?: boolean; onLobby?: () => void; children: ReactNode }

export function Shell({ right, confirmHome, onHelp, home = false, safe = true, fit = false, solo = false, onLobby, children }: Props) {
  const [muted, setMute] = useState(isMuted)
  useEffect(() => installUnlock(), [])
  useEffect(() => { startAppUpdate() }, [])
  useEffect(() => { startAnalytics() }, [])
  const [askHome, setAskHome] = useState(false)
  const connectionLink = useLink()
  const link = solo ? 'ok' : connectionLink
  // 라운드 도중엔 업데이트를 권하지 않는다: 게임 페이지는 safe(참가·대기실·최종일 때만 true)를 넘긴다
  const showUpdate = useUpdateReady() && safe && link === 'ok'
  return (
    <MantineProvider theme={theme} forceColorScheme="dark">
      <div className="standalone-safe-top" aria-hidden="true" />
      <Container size="xs" className={fit ? 'shell shell--fit' : 'shell'}>
        {showUpdate && <UpdateBar />}
        {link === 'retry' && <div className="chip" role="status" style={{ background: 'var(--cream)', margin: '0 auto 8px', display: 'block', width: 'fit-content' }}>다시 연결하는 중…</div>}
        {!home && <header className="shell-header">
          {(
            <a
              className="chip tilt-c"
              href={import.meta.env.BASE_URL}
              onClick={(e) => { if (confirmHome) { e.preventDefault(); setAskHome(true) } else leaveRoom() }}
              style={{ background: 'var(--cream)', fontSize: 15, textDecoration: 'none', boxShadow: '3px 3px 0 var(--ink)' }}
            >
              ← 모여라
            </a>
          )}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>{right}
            <button
              type="button"
              className="chip"
              aria-label={muted ? '소리 켜기' : '소리 끄기'}
              onClick={() => { setMuted(!muted); setMute(!muted) }}
              style={{ background: 'var(--cream)', width: 36, height: 36, padding: 0, display: 'grid', placeItems: 'center', cursor: 'pointer', boxShadow: '3px 3px 0 var(--ink)' }}
            >
              <Icon name={muted ? 'speaker-off' : 'speaker'} size={20} color="var(--ink)" />
            </button>
            {onHelp && (
              <button
                type="button"
                className="chip jua"
                aria-label="게임 방법"
                onClick={onHelp}
                style={{ background: 'var(--cream)', width: 36, height: 36, padding: 0, fontSize: 18, lineHeight: 1, cursor: 'pointer', boxShadow: '3px 3px 0 var(--ink)' }}
              >
                ?
              </button>
            )}
          </div>
        </header>}
        {askHome && <ConfirmDialog title={onLobby ? "게임을 그만할까요?" : "게임에서 나갈까요?"} message={onLobby ? "대기실로 가면 모두 함께 대기실로 돌아가요" : "지금 방에서 나가게 돼요"} confirmLabel={onLobby ? "나만 나가기" : "나가기"} altLabel={onLobby ? "대기실로" : undefined} onAlt={onLobby ? () => { setAskHome(false); onLobby() } : undefined} onConfirm={() => { leaveRoom(); window.location.href = import.meta.env.BASE_URL }} onCancel={() => setAskHome(false)} />}
        <div style={fit ? { flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' } : undefined}>{link === 'ok' || link === 'retry' ? children : <LinkCard link={link} />}</div>
      </Container>
    </MantineProvider>
  )
}
