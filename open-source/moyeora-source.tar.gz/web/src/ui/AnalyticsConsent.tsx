import { useState } from 'react'
import { Modal } from '@mantine/core'
import { analyticsAvailable, setConsent, useConsent } from '../analytics.ts'

/** 이용 분석 동의 안내 바 (아직 안 정했을 때만, 홈 화면 아래에 고정) + 자세히 창 */
export function AnalyticsNotice() {
  const consent = useConsent()
  const [open, setOpen] = useState(false)
  if (!analyticsAvailable) return null
  return (
    <>
      {consent === null && (
        <>
          <div className="consent-spacer" aria-hidden />
          <div className="consent-bar" role="region" aria-label="선택적 이용 분석">
            <span className="consent-bar__text">
              이용 분석에 참여할까요?{' '}
              <button type="button" className="link-btn" onClick={() => setOpen(true)}>자세히</button>
            </span>
            <button type="button" className="btn-sticker btn-sticker--sm" onClick={() => setConsent(false)}>안 함</button>
            <button type="button" className="btn-sticker btn-sticker--sm" data-tone="lime" onClick={() => setConsent(true)}>참여</button>
          </div>
        </>
      )}
      <AnalyticsDialog opened={open} onClose={() => setOpen(false)} />
    </>
  )
}

/** 홈 맨 아래의 작은 "이용 분석 설정" 글자 링크 */
export function AnalyticsSettingsLink() {
  const [open, setOpen] = useState(false)
  if (!analyticsAvailable) return null
  return (
    <>
      <button type="button" className="link-btn" onClick={() => setOpen(true)}>이용 분석 설정</button>
      <AnalyticsDialog opened={open} onClose={() => setOpen(false)} />
    </>
  )
}

function AnalyticsDialog({ opened, onClose }: { opened: boolean; onClose: () => void }) {
  const consent = useConsent()
  const choose = (v: boolean) => { setConsent(v); onClose() }
  return (
    <Modal opened={opened} onClose={onClose} title="이용 분석" centered
      styles={{ content: { background: 'var(--card)', color: 'var(--text)', border: '3px solid var(--ink)', borderRadius: 20 }, header: { background: 'var(--card)', color: '#fff', fontFamily: 'Jua, sans-serif' } }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 14, lineHeight: 1.5 }}>
        <p style={{ margin: 0 }}>모여라를 낫게 만들려고 Google Analytics 로 방문한 게임 화면, 게임 시작·끝, 게임 종류와 인원 수를 살펴봐요.</p>
        <p style={{ margin: 0 }}>이름·아바타·방 코드·답은 보내지 않아요. 광고 개인화와 Google Signals 도 쓰지 않아요.</p>
        <p style={{ margin: 0 }}>참여하기 전에는 아무것도 보내지 않고, 거절해도 모든 기능을 쓸 수 있어요. 언제든 홈 맨 아래에서 바꿀 수 있어요.</p>
        <p style={{ margin: 0, color: 'var(--lav)' }}>{consent === true ? '현재: 참여 중' : consent === false ? '현재: 참여 안 함' : '현재: 아직 고르지 않음'}</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <button type="button" className="btn-sticker" style={{ flex: 1, fontSize: 16 }} onClick={() => choose(false)}>참여 안 함</button>
          <button type="button" className="btn-sticker" data-tone="lime" style={{ flex: 1, fontSize: 16 }} onClick={() => choose(true)}>참여하기</button>
        </div>
      </div>
    </Modal>
  )
}
