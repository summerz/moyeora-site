import type { ReactNode } from 'react'
import type { Player } from '@moyeora/shared'
import { Avatar } from './Avatar.tsx'
import { NpcTag } from './NpcTag.tsx'

/** 라운드 결과표 한 줄: [lead] 아바타 이름 …children. 내 줄은 연두 테두리 */
export function ResultRow({ p, me, lead, children }: { p: Player; me: boolean; lead?: ReactNode; children?: ReactNode }) {
  return (
    <div style={{ background: 'var(--card)', borderRadius: 16, padding: '6px 10px', display: 'flex', alignItems: 'center', gap: 8, minHeight: 46, boxSizing: 'border-box', border: `3px solid ${me ? 'var(--lime)' : 'transparent'}` }}>
      {lead}
      <Avatar seed={p.avatar} size={32} />
      <span className="nick nick--sm nick--1l" style={{ flex: 1, minWidth: 0 }}>{p.name}{p.bot && <NpcTag />}</span>
      {children}
    </div>
  )
}

/** 결과 도장 알약 */
export function Stamp({ text, bg }: { text: string; bg: string }) {
  return <span className="chip" style={{ background: bg, fontSize: 14, padding: '1px 9px', borderWidth: 2, boxShadow: '2px 2px 0 var(--ink)', whiteSpace: 'nowrap', transform: 'rotate(-2deg)' }}>{text}</span>
}
