import type { ReactNode } from 'react'
import './shortcut-badge.css'

/** 마우스와 키보드를 사용하는 화면에서만 보여 주는 단축키 배지. */
export function ShortcutBadge({ children }: { children: ReactNode }) {
  return <kbd className="shortcut-badge" aria-hidden="true">{children}</kbd>
}
