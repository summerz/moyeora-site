import type { ReactNode } from 'react'
import { StickerModal } from './StickerModal.tsx'

/** 확인창: 취소(연두, 안전한 기본)가 먼저 포커스를 받는다 */
export function ConfirmDialog({ title, message, confirmLabel, cancelLabel = '계속할래요', altLabel, onAlt, onConfirm, onCancel }: {
  title: ReactNode; message?: string; confirmLabel: string; cancelLabel?: string; altLabel?: string; onAlt?: () => void; onConfirm: () => void; onCancel: () => void
}) {
  return (
    <StickerModal onClose={onCancel} labelledBy="confirm-title">
      <div id="confirm-title" className="jua modal__title--sm">{title}</div>
      {message && <div className="modal__msg">{message}</div>}
      <div className="modal__btns">
        <button type="button" className="btn-sticker" data-tone="lime" onClick={onCancel}>{cancelLabel}</button>
        {altLabel && onAlt && <button type="button" className="btn-sticker" data-tone="cream" onClick={onAlt}>{altLabel}</button>}
        <button type="button" className="btn-sticker" data-tone="cream" onClick={onConfirm}>{confirmLabel}</button>
      </div>
    </StickerModal>
  )
}
