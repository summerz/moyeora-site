import { useMemo } from 'react'
import { createAvatar } from '@dicebear/core'
import * as avataaars from '@dicebear/avataaars'
import type { Options } from '@dicebear/avataaars'

type Props = { seed: string; size?: number; ring?: boolean; dim?: boolean }

// 같은 값을 여러 번 넣으면 그만큼 자주 나온다. 밝은 표정·귀여운 꾸밈 쪽으로 기울이고 피부색은 균등.
// 바꾸면 기존 seed 의 얼굴도 바뀐다 (프로필은 기기 안에만 있으니 괜찮다).
const LOOK: Partial<Options> & { backgroundColor: string[]; backgroundType: 'solid'[]; radius: number } = {
  backgroundColor: ['ffb347', '4da3ff', 'c77dff', 'ff5e5b', 'ffd23f', '8cff4d'],
  backgroundType: ['solid'],
  radius: 50,
  eyes: ['happy', 'happy', 'happy', 'default', 'default', 'default', 'wink', 'wink', 'hearts', 'squint', 'side', 'surprised', 'closed'],
  mouth: ['smile', 'smile', 'smile', 'smile', 'twinkle', 'twinkle', 'twinkle', 'default', 'default', 'tongue', 'eating', 'serious'],
  eyebrows: ['default', 'default', 'default', 'defaultNatural', 'defaultNatural', 'raisedExcited', 'raisedExcited', 'raisedExcitedNatural', 'upDown', 'upDownNatural', 'flatNatural'],
  top: ['shortRound', 'shortRound', 'shortFlat', 'shortFlat', 'shortWaved', 'shortCurly', 'bob', 'bob', 'bun', 'curly', 'curvy', 'fro', 'froBand', 'longButNotTooLong', 'longButNotTooLong', 'straight01', 'straight02', 'straightAndStrand', 'bigHair', 'shaggy', 'theCaesar', 'sides', 'dreads01', 'hijab', 'winterHat02', 'hat'],
  accessories: ['round', 'round', 'prescription02', 'wayfarers', 'sunglasses', 'kurt'],
  accessoriesProbability: 25,
  facialHairProbability: 5,
  clothing: ['hoodie', 'hoodie', 'shirtCrewNeck', 'shirtCrewNeck', 'overall', 'overall', 'graphicShirt', 'shirtScoopNeck', 'shirtVNeck', 'collarAndSweater'],
  clothesColor: ['ff5e5b', 'ffb347', 'ffd23f', '8cff4d', '4da3ff', 'c77dff', '25557c', 'ffffff', '3c4f5c'],
}

const cache = new Map<string, string>()
/** data URI of the avatar (also usable as an SVG <image href>). */
export function avatarUri(seed: string, size = 64): string {
  const key = `${size}:${seed}`
  let uri = cache.get(key)
  if (!uri) {
    uri = createAvatar(avataaars, { seed, size, ...LOOK }).toDataUri()
    cache.set(key, uri)
  }
  return uri
}

export function Avatar({ seed, size = 40, ring = false, dim = false }: Props) {
  const uri = useMemo(() => avatarUri(seed, size), [seed, size])
  return (
    <img
      src={uri}
      width={size}
      height={size}
      alt=""
      style={{
        borderRadius: '50%',
        border: '3px solid var(--ink)',
        boxSizing: 'border-box',
        flexShrink: 0,
        ...(dim ? { opacity: 0.45, outline: '3px dashed var(--lav-dim)' } : ring ? { boxShadow: '0 0 0 3px var(--lime)' } : null),
      }}
    />
  )
}
