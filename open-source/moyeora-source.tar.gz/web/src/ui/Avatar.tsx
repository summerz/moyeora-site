import { useMemo } from 'react'
import { Avatar as DiceAvatar, Style, type StyleOptions } from '@dicebear/core'
import thumbs from '@dicebear/styles/thumbs.json' with { type: 'json' }

type Props = { seed: string; size?: number; ring?: boolean; dim?: boolean }

// 배경은 DiceBear 'Bold Pop' 프리셋에서 초록(#00e676)을 뺀 5색 — '나' 연두 테두리와 붙으면 구분이 안 된다.
// 바꾸면 기존 seed 의 얼굴도 바뀐다 (프로필은 기기 안에만 있으니 괜찮다).
const LOOK: StyleOptions<typeof thumbs> = {
  borderRadius: 50,
  backgroundColor: ['ff2e63', '00c2a8', 'ffb300', '3d5afe', '8e24aa'],
}

const style = new Style(thumbs)
const cache = new Map<string, string>()
/** data URI of the avatar (also usable as an SVG <image href>). */
export function avatarUri(seed: string, size = 64): string {
  const key = `${size}:${seed}`
  let uri = cache.get(key)
  if (!uri) {
    uri = new DiceAvatar(style, { seed, size, ...LOOK }).toDataUri()
    cache.set(key, uri)
  }
  return uri
}

export function Avatar({ seed, size = 40, ring = false, dim = false }: Props) {
  const uri = useMemo(() => avatarUri(seed, size), [seed, size])
  return (
    <img
      src={uri}
      width={size}
      height={size}
      alt=""
      style={{
        borderRadius: '50%',
        border: '3px solid var(--ink)',
        boxSizing: 'border-box',
        flexShrink: 0,
        ...(dim ? { opacity: 0.45, outline: '3px dashed var(--lav-dim)' } : ring ? { boxShadow: '0 0 0 3px var(--lime)' } : null),
      }}
    />
  )
}
