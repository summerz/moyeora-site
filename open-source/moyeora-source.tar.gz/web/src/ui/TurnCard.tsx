import type { ReactNode } from 'react'
import { Avatar } from './Avatar.tsx'

type Props = {
  name: string | null
  avatar?: string
  me: boolean
  /** 내 차례일 때 아래 안내 */
  meHint: string
  /** 내 차례일 때 큰 글자 (기본 '내 차례!') */
  meTitle?: string
  /** 남의 차례: 이름 뒤에 붙는 말 (기본 '님 차례') */
  other?: string
  /** name 이 null 일 때(모두 끝) */
  none?: string
  /** 카드 오른쪽 끝(타이머 등) */
  right?: ReactNode
  /** 높이 고정 (내 차례·남의 차례 카드가 같은 크기여야 하는 화면) */
  fixed?: boolean
  /** 내 차례 안내를 한 줄로(줄바꿈 없이). 짧은 문구에만 */
  hintOneLine?: boolean
}

/** '지금 차례' 카드. 나면 연두 테두리 + 안내, 아니면 누구 차례인지. */
export function TurnCard({ name, avatar, me, meHint, meTitle = '내 차례!', other = '님 차례', none = '모두 끝났어요', right, fixed = false, hintOneLine = false }: Props) {
  return (
    <div className={`sticker turn-card${me ? ' turn-card--me' : ''}${fixed ? ' turn-card--fixed' : ''}`} style={{ background: me ? 'var(--lime)' : undefined }}>
      {avatar && <Avatar seed={avatar} size={56} ring={me} />}
      <div style={{ minWidth: 0, flex: 1, display: 'flex', flexDirection: 'column', gap: 2, justifyContent: fixed ? 'center' : undefined }}>
        {name === null ? (
          <span className="jua" style={{ fontSize: 20, lineHeight: 1.25 }}>{none}</span>
        ) : me ? (
          <>
            <span className="jua turn-card-title" style={{ lineHeight: 1.2 }}>{meTitle}</span>
            {meHint && <span style={{ fontSize: 13, fontWeight: 700, wordBreak: 'keep-all', ...(hintOneLine ? { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } : {}) }}>{meHint}</span>}
          </>
        ) : (
          <span style={{ display: 'flex', alignItems: 'baseline', gap: 4, minWidth: 0 }}>
            <span className="nick nick--1l" style={{ flexShrink: 1 }}>{name}</span>
            <span className="jua" style={{ fontSize: 18, whiteSpace: 'nowrap' }}>{other}</span>
          </span>
        )}
      </div>
      {right}
    </div>
  )
}
