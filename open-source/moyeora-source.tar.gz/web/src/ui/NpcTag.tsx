const base = { background: 'var(--ink)', color: 'var(--lav)', borderRadius: 999, fontSize: 9, fontWeight: 700, lineHeight: 1, padding: '2px 5px', letterSpacing: 0.3 } as const

/** NPC 표시 알약. overlay 면 아바타 왼쪽 아래에 겹친다 (부모는 position: relative). */
export function NpcTag({ overlay }: { overlay?: boolean }) {
  const pos = overlay ? ({ position: 'absolute', left: -4, bottom: -2 } as const) : { marginLeft: 4, verticalAlign: 'middle' }
  return <span style={{ ...base, ...pos, display: 'inline-block', whiteSpace: 'nowrap' }}>NPC</span>
}
