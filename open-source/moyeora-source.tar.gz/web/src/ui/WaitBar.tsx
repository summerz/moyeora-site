import type { ReactNode } from 'react'

// 버튼 자리에 놓는 대기 상태 막대 — 누를 수 없는 상태 표시 (점선 테두리, 그림자 없음)
export function WaitBar({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`wait-bar ${className}`} role="status">
      {children}
      <span className="wait-dots" aria-hidden="true"><i>.</i><i>.</i><i>.</i></span>
    </div>
  )
}
