import type { CSSProperties } from 'react'

const FLOAT: CSSProperties = { position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', padding: '1px 10px', border: '2px solid var(--ink)', whiteSpace: 'nowrap', zIndex: 1 }

/** 연두 '나' 딱지. floating = 부모(position:relative) 윗변에 걸쳐 놓기. */
export const MePill = ({ floating, style }: { floating?: boolean; style?: CSSProperties }) => (
  <span style={{ background: 'var(--lime)', color: 'var(--ink)', borderRadius: 999, padding: '0 8px', fontSize: 12, fontWeight: 700, ...(floating ? FLOAT : {}), ...style }}>나</span>
)
