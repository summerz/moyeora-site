import { useState } from 'react'
import { applyUpdate } from '../appUpdate.ts'
import { dismissLink, type Link } from '../ws.ts'

/** 서버와의 관계가 정상이 아닐 때 화면 대신 보여 주는 카드 (서버 재시작·버전 어긋남) */
export function LinkCard({ link }: { link: Exclude<Link, 'ok' | 'retry'> }) {
  const [busy, setBusy] = useState(false)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18, paddingTop: 24 }}>
      <div className="sticker sticker--dark" style={{ padding: '22px 16px', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 8 }} role="status">
        {link === 'lost' && <>
          <span className="jua" style={{ fontSize: 20, color: '#fff' }}>서버가 새로 시작됐어요</span>
          <span style={{ color: 'var(--lav)' }}>방을 다시 만들어 주세요</span>
          <span style={{ color: 'var(--lav-dim)', fontSize: 13 }}>연결이 끊기면 방에서 나가게 돼요</span>
        </>}
        {link === 'client-old' && <>
          <span className="jua" style={{ fontSize: 20, color: '#fff' }}>새 버전이 나왔어요</span>
          <span style={{ color: 'var(--lav)' }}>업데이트하면 바로 할 수 있어요</span>
        </>}
        {link === 'server-old' && <>
          <span className="jua" style={{ fontSize: 20, color: '#fff' }}>서버를 업데이트하는 중이에요</span>
          <span style={{ color: 'var(--lav)' }}>잠시 후 다시 해 주세요. 자동으로 다시 연결해요</span>
        </>}
      </div>
      {link === 'lost' && <button type="button" className="btn-sticker" data-tone="lime" onClick={dismissLink}>참가 화면으로</button>}
      {link === 'client-old' && <button type="button" className="btn-sticker" data-tone="lime" disabled={busy} onClick={() => { setBusy(true); void applyUpdate() }}>업데이트</button>}
    </div>
  )
}
