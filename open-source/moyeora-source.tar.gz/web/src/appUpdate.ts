import { useSyncExternalStore } from 'react'

/**
 * 앱 업데이트(서비스 워커). 새 워커는 설치만 하고 기다린다.
 * 화면은 안전한 때(홈·참가·대기실·최종)에만 '업데이트' 를 보여 주고, 누른 탭만 새로 고친다.
 */
const BASE = import.meta.env.BASE_URL
const CHECK_MS = 15 * 60 * 1000

let ready = false
let reg: ServiceWorkerRegistration | undefined
let applying = false
let started = false
const listeners = new Set<() => void>()
const setReady = (v: boolean) => {
  if (ready === v) return
  ready = v
  listeners.forEach((l) => l())
}

/** 새 버전이 기다리고 있나 (다른 탭이 이미 적용해 이 탭이 낡은 경우도 포함) */
export const useUpdateReady = () =>
  useSyncExternalStore((l) => { listeners.add(l); return () => { listeners.delete(l) } }, () => ready)

export function checkForUpdate() {
  void reg?.update().catch(() => {})
}

const watch = (r: ServiceWorkerRegistration) => {
  const refresh = () => setReady(!!r.waiting && !!navigator.serviceWorker.controller)
  refresh()
  r.addEventListener('updatefound', () => {
    const w = r.installing
    w?.addEventListener('statechange', refresh)
  })
}

export function startAppUpdate() {
  if (started || !('serviceWorker' in navigator)) return
  started = true
  const sw = navigator.serviceWorker
  // 다른 탭이 적용해 컨트롤러가 바뀌면 이 탭은 낡은 화면: 알리기만 하고, 새로 고치는 건 적용한 탭뿐
  sw.addEventListener('controllerchange', () => { if (!applying) setReady(true) })
  if (import.meta.env.DEV) {
    // 개발에는 워커를 두지 않는다: 남아 있는 운영 워커는 dev 서버의 자가 해제 sw.js 로 스스로 사라진다
    void sw.getRegistrations().then((rs) => rs.forEach((r) => void r.update().catch(() => {})))
    return
  }
  void sw.register(`${BASE}sw.js`, { scope: BASE, updateViaCache: 'none' }).then((r) => {
    reg = r
    watch(r)
    // 설치된 앱은 새로 열리지 않고 이어서 켜지므로, 돌아올 때마다 확인한다
    setInterval(checkForUpdate, CHECK_MS)
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') checkForUpdate() })
  }).catch(() => {})
}

/** 기다리는 워커를 켜고 이 탭만 새로 고친다. 기다리는 게 없으면 그냥 새로 고친다. */
export async function applyUpdate() {
  const waiting = reg?.waiting
  if (!waiting) return location.reload()
  applying = true
  const done = new Promise<void>((ok) => {
    navigator.serviceWorker.addEventListener('controllerchange', () => ok(), { once: true })
    setTimeout(ok, 5000)
  })
  waiting.postMessage({ type: 'APPLY_UPDATE' })
  await done
  location.reload()
}
