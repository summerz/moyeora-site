import { useSyncExternalStore } from 'react'

/**
 * Google Analytics 4 — 동의 후에만. 자세한 결정은 DECISIONS.md "이용 분석".
 * - 측정 ID(VITE_GA_MEASUREMENT_ID)는 운영(site.yml) 빌드에만 들어간다. 없거나 형식이 틀리면 전부 꺼지고 동의 UI 도 안 보인다.
 * - 동의('granted') 전에는 gtag.js 를 불러오지도, 아무것도 보내지도 않는다.
 */
export const GA_ID_RE = /^G-[A-Z0-9]+$/
const ID = (import.meta.env.VITE_GA_MEASUREMENT_ID ?? '').trim()
export const analyticsAvailable = GA_ID_RE.test(ID)

const KEY = 'moyeora:analytics'
export type Consent = boolean | null // true=참여, false=거절, null=아직 안 정함
const read = (): Consent => {
  try { const v = localStorage.getItem(KEY); return v === 'granted' ? true : v === 'denied' ? false : null } catch { return null }
}
let consent: Consent = read()
const listeners = new Set<() => void>()
const emit = () => listeners.forEach((l) => l())
export const useConsent = () => useSyncExternalStore((l) => { listeners.add(l); return () => { listeners.delete(l) } }, () => consent)

type W = Window & { dataLayer?: unknown[]; gtag?: (...a: unknown[]) => void }
const w = window as W
let loaded = false
let failed = false
const disable = (v: boolean) => { Reflect.set(window, `ga-disable-${ID}`, v) }

const clearCookies = () => {
  for (const c of document.cookie.split(';')) {
    const name = c.trim().split('=')[0] ?? ''
    if (name !== '_ga' && !name.startsWith('_ga_')) continue
    for (const d of ['', location.hostname, '.' + location.hostname]) document.cookie = `${name}=; Max-Age=0; Path=/;${d ? ` Domain=${d};` : ''} SameSite=Lax`
  }
}

const load = () => {
  if (loaded) return
  loaded = true
  disable(false)
  w.dataLayer ??= []
  w.gtag ??= function () { w.dataLayer!.push(arguments) }
  const g = w.gtag
  g('consent', 'default', { analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied' })
  g('js', new Date())
  g('config', ID, { send_page_view: false, anonymize_ip: true, allow_google_signals: false, allow_ad_personalization_signals: false, cookie_flags: 'SameSite=Lax;Secure' })
  const s = document.createElement('script')
  s.async = true
  s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(ID)}`
  s.onerror = () => { failed = true; disable(true) }
  document.head.append(s)
}

/** 쿼리·해시(방 코드가 들어갈 수 있다)를 뺀 주소 */
export const cleanLocation = (href: string) => { const u = new URL(href); return u.origin + u.pathname }

/** 지금 페이지의 게임 id ('home' 또는 주소 첫 마디) */
const pageGame = () => {
  const base = import.meta.env.BASE_URL
  const rest = location.pathname.startsWith(base) ? location.pathname.slice(base.length) : location.pathname.replace(/^\//, '')
  return rest.split('/')[0] || 'home'
}

export function track(event: string, params: Record<string, string | number | boolean> = {}) {
  if (!analyticsAvailable || consent !== true || failed) return
  try {
    load()
    const standalone = matchMedia('(display-mode: standalone)').matches || !!(navigator as Navigator & { standalone?: boolean }).standalone
    w.gtag!('event', event, { game: pageGame(), app_version: import.meta.env.VITE_APP_VERSION, app_mode: standalone ? 'standalone' : 'browser', ...params, send_to: ID })
  } catch { /* 측정이 게임을 막으면 안 된다 */ }
}

let viewed = false
const pageView = () => {
  if (viewed || consent !== true) return
  viewed = true
  track('page_view', { page_title: document.title, page_location: cleanLocation(location.href) })
}
let started = false
/** 페이지가 뜰 때 한 번 (Shell). 동의돼 있으면 page_view, 나중에 동의하면 그때 */
export function startAnalytics() {
  if (!analyticsAvailable || started) return
  started = true
  pageView()
  // 다른 탭에서 바꾼 선택도 따른다
  window.addEventListener('storage', (e) => { if (e.key === KEY || e.key === null) apply(read()) })
}

function apply(next: Consent) {
  if (next === consent) return
  consent = next
  if (loaded) {
    try {
      disable(next !== true || failed)
      w.gtag!('consent', 'update', { analytics_storage: next === true ? 'granted' : 'denied' })
    } catch { /* ignore */ }
    if (next !== true) clearCookies()
  }
  pageView()
  emit()
}
export function setConsent(allowed: boolean) {
  try { localStorage.setItem(KEY, allowed ? 'granted' : 'denied') } catch { /* 이번 방문에만 적용 */ }
  apply(allowed)
}

/**
 * 방 상태가 올 때마다 호출 (ws.ts useSocket 한 곳): 단계 전환을 감지해 game_start / game_end.
 * 방장 클라이언트만 보낸다 — 방 하나가 인원수만큼 중복 집계되지 않게.
 */
export function trackRoom(prev: string | undefined, room: { game: string; phase: string; you: string; host: string; players: { bot: boolean }[] }) {
  if (prev === undefined || prev === room.phase || room.you !== room.host) return
  const params = { game: room.game, players: room.players.filter((p) => !p.bot).length }
  if (prev === 'lobby') track('game_start', params)
  else if (room.phase === 'done') track('game_end', params)
}
