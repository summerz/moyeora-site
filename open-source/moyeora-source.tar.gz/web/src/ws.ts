import { useCallback, useEffect, useRef, useSyncExternalStore } from 'react'
import { PROTOCOL, skewOf, type ClientMessage, type ServerHello, type ServerAim, type ServerMessage, type ServerSeat } from '@moyeora/shared'
import { trackRoom } from './analytics.ts'
import { checkForUpdate } from './appUpdate.ts'

export const WS_URL: string = import.meta.env.VITE_WS_URL ?? `ws://${location.hostname}:8787`

/** 서버와의 관계. 'retry'(자리 유지 중 재연결)는 화면을 두고 줄만 띄우고, 그 밖에 'ok' 가 아니면 Shell 이 화면 대신 안내 카드를 보여 준다. */
export type Link = 'ok' | 'retry' | 'lost' | 'client-old' | 'server-old'
let link: Link = 'ok'
const listeners = new Set<() => void>()
const setLink = (v: Link) => {
  if (link === v) return
  link = v
  listeners.forEach((l) => l())
}
export const useLink = () => useSyncExternalStore((l) => { listeners.add(l); return () => { listeners.delete(l) } }, () => link)
/** 'lost' 카드를 닫는다 (방은 이미 사라졌으니 참가 화면으로 돌아간다) */
export const dismissLink = () => { if (link === 'lost') setLink('ok') }

// 자리표: 탭 단위(sessionStorage)라 새로 고침엔 살고 탭을 닫으면 사라진다
const SEAT_KEY = 'moyeora:seat:' + location.pathname
type Seat = { code: string; token: string }
const readSeat = (): Seat | null => {
  try {
    const s = JSON.parse(sessionStorage.getItem(SEAT_KEY) ?? 'null')
    return s && typeof s.code === 'string' && typeof s.token === 'string' ? s : null
  } catch { return null }
}
const saveSeat = (s: Seat) => { try { sessionStorage.setItem(SEAT_KEY, JSON.stringify(s)) } catch {} }
const clearSeat = () => { try { sessionStorage.removeItem(SEAT_KEY) } catch {} }
let current: WebSocket | null = null
/** 일부러 방을 나간다: 자리표를 지우고 서버에 바로 빼 달라고 알린다 */
export const leaveRoom = () => {
  clearSeat()
  if (current?.readyState === WebSocket.OPEN) current.send(JSON.stringify({ type: 'leave' }))
}
const RETRY_MS = 60_000

type Outgoing<T> = T extends { v: number } ? Omit<T, 'v'> : T
const BACKOFF = [2000, 4000, 8000, 16000, 30000]

export function useSocket(onMessage: (m: ServerMessage) => void, onClose?: () => void, onAim?: (m: ServerAim) => void) {
  const socket = useRef<WebSocket | null>(null)
  const handler = useRef(onMessage)
  handler.current = onMessage
  const closeHandler = useRef(onClose)
  closeHandler.current = onClose
  const aimHandler = useRef(onAim)
  aimHandler.current = onAim

  useEffect(() => {
    let closed = false
    let timer: ReturnType<typeof setTimeout>
    let retries = 0
    let retryFrom = 0 // 재연결을 처음 시작한 시각 (0 = 해당 없음)
    let wasJoined = false // 직전 연결이 방 안이었다 (끊긴 뒤 복귀 시도 중)
    const connect = () => {
      const ws = new WebSocket(WS_URL)
      socket.current = ws
      current = ws
      let joined = false
      let resuming = false
      const afterDrop = wasJoined
      let greeted = false
      let phase: string | undefined
      ws.onmessage = (e) => {
        let m: ServerMessage | ServerHello | ServerAim | ServerSeat
        try { m = JSON.parse(e.data) } catch { return }
        if (m.type === 'aim') { aimHandler.current?.(m); return }
        if (m.type === 'hello') {
          greeted = true
          const skew = skewOf(PROTOCOL, m)
          if (skew === 'ok') {
            retries = 0
            if (link === 'server-old') setLink('ok')
            const seat = readSeat()
            if (seat && !joined) {
              resuming = true
              ws.send(JSON.stringify({ type: 'resume', v: PROTOCOL, code: seat.code, token: seat.token }))
            }
          }
          else setLink(skew)
          // 서버가 더 낡았으면 새로 뜰 때까지 간격을 늘리며 다시 연결한다
          if (skew === 'server-old') ws.close()
          return
        }
        if (m.type === 'seat') { saveSeat(m); return }
        if (m.type === 'room') {
          joined = true
          resuming = false
          wasJoined = true
          retryFrom = 0
          if (link === 'retry') setLink('ok')
          trackRoom(phase, m.room)
          phase = m.room.phase
        }
        else if (m.type === 'error' && resuming) {
          // 자리가 없다(만료·서버 재시작). 새로 고침 직후면 참가 화면 그대로, 끊긴 뒤면 안내 카드
          resuming = false
          clearSeat()
          if (afterDrop) { wasJoined = false; setLink('lost'); closeHandler.current?.() }
          return
        }
        else if (m.type === 'error') {
          if (m.message === 'update required') setLink('client-old')
          // 인사가 없는 서버 = 이 클라이언트를 모르는 옛 서버
          else if (m.message === 'server old' || (m.message === 'bad message' && !greeted)) setLink('server-old')
        }
        try { handler.current(m) } catch {}
      }
      ws.onclose = (e) => {
        if (closed) return
        socket.current = null
        if (current === ws) current = null
        if (e.code === 4000) { clearSeat(); wasJoined = false }
        // 강퇴(4000)·시도 초과(4001)는 서버가 닫은 것: 재시작 안내 대상이 아니다
        const dropped = (joined || (wasJoined && link === 'retry')) && e.code !== 4000 && e.code !== 4001
        if (dropped && readSeat()) {
          // 자리를 서버가 잠시 지켜 준다: 화면은 두고 다시 연결해 resume 한다
          wasJoined = true
          if (!retryFrom) retryFrom = Date.now()
          if (Date.now() - retryFrom < RETRY_MS) setLink('retry')
          else { clearSeat(); wasJoined = false; retryFrom = 0; setLink('lost'); closeHandler.current?.() }
        } else {
          if (link === 'retry') setLink('ok')
          wasJoined = false
          closeHandler.current?.()
          if (dropped) {
            setLink('lost')
            checkForUpdate() // 서버를 배포했다면 사이트도 새것일 수 있다
          }
        }
        const wait = link === 'server-old' ? BACKOFF[Math.min(retries++, BACKOFF.length - 1)]! : 1000
        timer = setTimeout(connect, wait)
      }
    }
    connect()
    return () => {
      closed = true
      clearTimeout(timer)
      socket.current?.close()
      current = null
    }
  }, [])

  return useCallback((m: Outgoing<ClientMessage>) => {
    const ws = socket.current
    if (ws?.readyState !== WebSocket.OPEN) return
    ws.send(JSON.stringify(m.type === 'create' || m.type === 'join' || m.type === 'resume' ? { ...m, v: PROTOCOL } : m))
  }, [])
}
