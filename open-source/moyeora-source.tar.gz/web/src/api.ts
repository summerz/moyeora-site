import { WS_URL } from './ws.ts'

/** WS 주소에서 API 주소를 만든다: ws→http, wss→https, 끝의 /ws 경로 제거 */
export const popularUrl = (wsUrl: string = WS_URL) =>
  wsUrl.replace(/^ws/, 'http').replace(/\/ws\/?$/, '').replace(/\/$/, '') + '/api/popular'

/** 최근 7일 게임별 시작 횟수. 2초 안에 못 받으면 null (호출부는 기본 순서로) */
export async function fetchPopular(): Promise<Record<string, number> | null> {
  try {
    const r = await fetch(popularUrl(), { signal: AbortSignal.timeout(2000) })
    if (!r.ok) return null
    const j = await r.json()
    return j && typeof j.counts === 'object' && j.counts ? j.counts : null
  } catch {
    return null
  }
}
