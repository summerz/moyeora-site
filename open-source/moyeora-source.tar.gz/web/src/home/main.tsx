import { useEffect, useState } from 'react'
import { flushSync } from 'react-dom'
import { createRoot } from 'react-dom/client'
import { HOME_CONFIG, homeGames, type HomeSort } from '@moyeora/shared'
import { fetchPopular } from '../api.ts'
import { GAMES, misfit, peopleLabel } from '../games.ts'
import { AnalyticsNotice, AnalyticsSettingsLink } from '../ui/AnalyticsConsent.tsx'
import { SegmentPicker } from '../ui/SegmentPicker.tsx'
import { GameHero } from '../ui/GameHero.tsx'
import { Icon } from '../ui/icons.tsx'
import { Logo } from '../ui/Logo.tsx'
import { ProfileCard } from '../ui/ProfileCard.tsx'
import { Profile } from '../ui/Profile.tsx'
import { loadProfile } from '../ui/profile.ts'
import { Shell } from '../ui/Shell.tsx'
import { OpenSourceLink } from '../ui/OpenSource.tsx'

const SORT_KEY = 'moyeora:home-sort'
const loadSort = (): HomeSort => {
  try { return localStorage.getItem(SORT_KEY) === 'popular' ? 'popular' : 'default' } catch { return 'default' }
}
const SORTS = [{ value: 'default', label: '기본순' }, { value: 'popular', label: '인기순' }] as const

type People = 'all' | '1' | '2' | '3'
const PEOPLE_KEY = 'moyeora:home-people'
const loadPeople = (): People => {
  try { const v = localStorage.getItem(PEOPLE_KEY); return v === '1' || v === '2' || v === '3' ? v : 'all' } catch { return 'all' }
}
const PEOPLE = [{ value: 'all', label: '전체' }, { value: '1', label: '혼자' }, { value: '2', label: '2명' }, { value: '3', label: '3명+' }] as const

/** 순서가 바뀌는 상태 갱신을 뷰 트랜지션으로 감싼다 (미지원·동작 줄이기면 그냥 실행) */
const withTransition = (fn: () => void) => {
  if ('startViewTransition' in document && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    (document as unknown as { startViewTransition: (cb: () => void) => unknown }).startViewTransition(() => flushSync(fn))
  } else fn()
}

function App() {
  const [sort, setSort] = useState(loadSort)
  const [counts, setCounts] = useState<Record<string, number> | null>(null)
  useEffect(() => {
    if (sort === 'popular' && !counts) void fetchPopular().then(setCounts)
  }, [sort, counts])
  const pick = (v: HomeSort) => {
    withTransition(() => setSort(v))
    try { localStorage.setItem(SORT_KEY, v) } catch {}
  }
  const [people, setPeople] = useState(loadPeople)
  const pickPeople = (v: People) => {
    withTransition(() => setPeople(v))
    try { localStorage.setItem(PEOPLE_KEY, v) } catch {}
  }
  const n = people === 'all' ? null : Number(people)

  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else {
    screen = (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div style={{ textAlign: 'center', padding: '18px 0 6px' }}>
          <Logo />
          <div style={{ color: 'var(--lav)', marginTop: 10, fontSize: 15 }}>옆에 있는 사람들과 폰으로 하는 작은 게임</div>
        </div>
        <ProfileCard profile={profile} onEdit={() => setEditing(true)} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div className="jua" style={{ color: 'var(--lav)', fontSize: 18 }}>게임</div>
          <SegmentPicker size="sm" label="게임 정렬" options={SORTS} value={sort} host onPick={pick} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: -8 }}>
          <div className="jua" style={{ color: 'var(--lav)', fontSize: 15 }}>몇 명?</div>
          <SegmentPicker size="sm" label="인원" options={PEOPLE} value={people} host onPick={pickPeople} />
        </div>
        {[...homeGames(GAMES, HOME_CONFIG, counts, sort)].sort((a, b) => Number(misfit(a, n) !== null) - Number(misfit(b, n) !== null)).map((g, i) => {
          const why = misfit(g, n)
          return (
          <a key={g.id} href={import.meta.env.BASE_URL + g.path} data-misfit={why ? '1' : undefined} className={`sticker sticker--dark sticker--lime ${i % 2 ? 'tilt-b' : 'tilt-a'}`} style={{ viewTransitionName: 'game-' + g.id, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 6, padding: '12px 14px', minHeight: 136, boxSizing: 'border-box', position: 'relative', marginTop: 10, textDecoration: 'none' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <span style={{ width: 88, flexShrink: 0, display: 'flex', justifyContent: 'center' }}><GameHero id={g.id} size={88} /></span>
              <span style={{ display: 'flex', flexDirection: 'column', gap: 6, minWidth: 0, flex: 1, paddingRight: 60 }}>
                <span className="jua glow" style={{ fontSize: 22, color: '#fff', wordBreak: 'keep-all' }}>{g.title}</span>
                <span style={{ fontSize: 13, color: 'var(--lav)', wordBreak: 'keep-all' }}>{g.tagline}</span>
              </span>
            </span>
            <span style={{ position: 'absolute', top: -13, right: 16, display: 'flex', gap: 6 }}>
              {g.npc && <span className="info-pill" title="NPC와도 할 수 있어요" aria-label="NPC와도 할 수 있어요" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 3 }}><Icon name="check" size={12} />NPC</span>}
              <span className="info-pill">{peopleLabel(g)}</span>
            </span>
            {why
              ? <span style={{ position: 'absolute', top: '50%', right: 12, transform: 'translateY(-50%)', fontSize: 13, color: 'var(--lav)' }}>{why}</span>
              : <span style={{ position: 'absolute', top: '50%', right: 12, transform: 'translateY(-50%)', width: 50, height: 50, borderRadius: '50%', background: 'var(--lime)', color: 'var(--ink)', border: '2.5px solid var(--ink)', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="arrow-right" size={25} /></span>}
          </a>
          )
        })}
        <div style={{ textAlign: 'center', color: 'var(--lav-dim)', fontSize: 12, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10 }}>
          <span>v{import.meta.env.VITE_APP_VERSION}</span>
          <AnalyticsSettingsLink />
          <OpenSourceLink />
        </div>
        <AnalyticsNotice />
      </div>
    )
  }
  return <Shell home>{screen}</Shell>
}

createRoot(document.getElementById('root')!).render(<App />)
