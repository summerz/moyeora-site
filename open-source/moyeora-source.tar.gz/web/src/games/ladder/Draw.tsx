import { useMemo } from 'react'
import { LADDER_ROWS, parseSlotKey, validSlot, type LadderBoard, type Player, type Slot } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { Board } from './Board.tsx'
import { seatColor } from './colors.ts'
import { Stage } from './Frame.tsx'
import { allSlots } from './paths.ts'
import { PendingRung } from './PendingRung.tsx'

type Props = {
  round: number
  board: LadderBoard
  players: Player[]
  mySeat: number | null
  choice: string | null
  onSlot: (s: Slot) => void
  onPass: () => void
}

export function Draw({ round, board, players, mySeat, choice, onSlot, onPass }: Props) {
  const rungs = useMemo(() => allSlots(board.system, board.rounds), [board])
  const hints = useMemo(() => {
    const out: Slot[] = []
    for (let g = 0; g < board.n - 1; g++) for (let r = 0; r < LADDER_ROWS; r++) if (validSlot(board.n, rungs, { g, r })) out.push({ g, r })
    return out
  }, [board.n, rungs])
  const pending = choice && choice !== 'pass' ? parseSlotKey(choice) : null
  const passed = choice === 'pass'
  const done = players.filter((p) => p.submitted).length
  return (
    <Stage
      title={`${round}라운드 · 한 줄 긋기`}
      sub={passed ? '이번 라운드는 안 그어요' : pending ? '공개 전까지 옮길 수 있어요' : '빈칸을 탭하거나 ‘이번엔 안 긋기’를 골라요'}
      board={
        <Board board={board} rounds={board.rounds} mySeat={mySeat} hints={hints} onTapSlot={onSlot}>
          {pending && mySeat !== null && <PendingRung slot={pending} seed={board.seats[mySeat]!.avatar} color={seatColor(mySeat)} />}
        </Board>
      }
      bottom={
        <>
          <button type="button" className="btn-sticker ld-bar" data-tone={passed ? 'lime' : 'cream'} aria-pressed={passed} onClick={onPass}>
            {passed ? '안 긋기 ✓' : '이번엔 안 긋기'}
          </button>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 6 }}>
            {players.map((p) => <Avatar key={p.id} seed={p.avatar} size={30} ring={p.submitted} dim={!p.submitted} />)}
            <span style={{ fontSize: 13, color: 'var(--lav-dim)', marginLeft: 4, fontVariantNumeric: 'tabular-nums' }}>{done} / {players.length}</span>
          </div>
          {/* 판·하단 칸은 overflow:hidden — 기울기 1.4°·pop 튐(~1.07배)·그림자 5px 가 잘리지 않게 양옆을 띄운다 */}
          <div style={{ position: 'absolute', left: 18, right: 18, bottom: 0, pointerEvents: 'none', zIndex: 3 }}>
            <SubmitBanner room={{ players }} label="그었다!" compact />
          </div>
        </>
      }
    />
  )
}
