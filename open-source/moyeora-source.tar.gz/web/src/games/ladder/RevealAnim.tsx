import { useEffect, useState } from 'react'
import type { LadderSeat, RoundResult } from '@moyeora/shared'
import { INK, seatColor } from './colors.ts'
import { H, polygon, spiky, W } from './geo.ts'
import { prefersReducedMotion } from './paths.ts'
import { DimRect, PopIn, RungLine, SvgAvatar, useGeo } from './svg.tsx'

type Props = { result: RoundResult; seats: LadderSeat[]; onCaption?: (text: string) => void; onDone?: () => void }
type Shard = { key: string; x1: number; x2: number; y: number }

const nm = (seats: LadderSeat[], i: number) => seats[i]?.name ?? '?'
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))

export function summary(result: RoundResult): string {
  const c = result.collisions
  if (c.length) return `충돌 ${c.length}건 · 선 ${c.reduce((a, x) => a + x.slots.length, 0)}개 사라짐`
  return result.placed.length ? '충돌 없이 모두 그어졌어요' : '이번 라운드엔 아무도 긋지 않았어요'
}

/** Reveal sequence for one round: placed rungs one by one (0.4 s each), then each collision group (1.5 s). */
export function RevealAnim({ result, seats, onCaption, onDone }: Props) {
  const geo = useGeo()
  const reduced = prefersReducedMotion()
  const [shown, setShown] = useState(reduced ? result.placed.length : 0)
  const [group, setGroup] = useState<number | null>(null)
  const [shards, setShards] = useState<Shard[]>([])

  useEffect(() => {
    let dead = false
    const wait = (ms: number) => new Promise<void>((res) => setTimeout(res, ms))
    const timers: ReturnType<typeof setTimeout>[] = []
    ;(async () => {
      if (reduced) {
        onCaption?.(summary(result))
        onDone?.()
        return
      }
      if (result.placed.length) onCaption?.('선이 나타나는 중…')
      await wait(500)
      for (let i = 0; i < result.placed.length && !dead; i++) {
        setShown(i + 1)
        await wait(400)
      }
      if (dead) return
      await wait(500)
      for (let gi = 0; gi < result.collisions.length && !dead; gi++) {
        const c = result.collisions[gi]!
        setGroup(gi)
        onCaption?.(c.seats.map((s) => nm(seats, s)).join(' 💥 '))
        await wait(1100)
        if (dead) return
        setGroup(null)
        const batch = c.slots.flatMap((s, k) => Array.from({ length: 5 }, (_, j) => ({ key: `${gi}-${k}-${j}`, x1: geo.X(s.g) + ((geo.X(s.g + 1) - geo.X(s.g)) * (j + 0.5)) / 5, x2: 0, y: geo.Y(s.r) })))
        setShards((a) => [...a, ...batch])
        timers.push(setTimeout(() => setShards((a) => a.filter((x) => !batch.includes(x))), 700))
        onCaption?.('선이 모두 사라졌어요')
        await wait(400)
      }
      if (dead) return
      onCaption?.(summary(result))
      await wait(300)
      if (!dead) onDone?.()
    })()
    return () => { dead = true; timers.forEach(clearTimeout) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const seeds = seats.map((s) => s.avatar)
  const g = group === null ? null : result.collisions[group]
  let cx = 0, cy = 0, R = 0
  if (g) {
    cx = g.slots.reduce((a, s) => a + geo.SX(s.g), 0) / g.slots.length
    cy = geo.Y(g.slots[0]!.r)
    R = g.seats.length === 2 ? 64 : 72
  }
  const pcx = clamp(cx, R + 26, W - R - 26)
  const pcy = clamp(cy, R + 24, H - R - 50)
  return (
    <g>
      {result.placed.slice(0, shown).map((p) => <RungLine key={`${p.g}-${p.r}`} rung={p} seeds={seeds} draw />)}
      <DimRect on={g !== null} />
      {shards.map((s) => (
        <rect key={s.key} className="ld-shard" x={s.x1 - 4} y={s.y - 2.5} width={8} height={5} rx={2} fill="#fff8e7" stroke={INK} strokeWidth={1} style={{ ['--dx' as string]: `${(Number(s.key.slice(-1)) - 2) * 14}px`, ['--dy' as string]: `${(Number(s.key.slice(-1)) * 9) % 40 - 14}px` }} />
      ))}
      {g && (
        <g key={group}>
          {g.slots.map((s, i) => {
            // 같은 칸 충돌이면 칸이 겹쳐 index 를 키로
            const y = geo.Y(s.r)
            return <line key={i} x1={geo.X(s.g)} x2={geo.X(s.g + 1)} y1={y} y2={y} stroke="#fff8e7" strokeWidth={4} strokeLinecap="round" strokeDasharray="6 5" />
          })}
          <g transform={`translate(${pcx} ${pcy})`}>
            <PopIn kind="burst">
              <polygon points={spiky(46, 26)} fill="#ffb347" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
              <polygon points={spiky(28, 15, 10)} fill="#ff8a87" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
            </PopIn>
          </g>
          {polygon(g.seats.length, pcx, pcy, R).map((pt, k) => {
            const seat = g.seats[k]!
            const ty = pt.sin < -0.3 ? pt.y - 28 : pt.y + 34
            return (
              <g key={seat}>
                <g transform={`translate(${pt.x} ${pt.y})`}>
                  <PopIn><SvgAvatar seed={seats[seat]!.avatar} color={seatColor(seat)} size={40} x={0} y={0} /></PopIn>
                </g>
                <text x={pt.x} y={ty} textAnchor="middle" fontSize={14} fontWeight={700} fill="#fff8e7" stroke={INK} strokeWidth={4} paintOrder="stroke" strokeLinejoin="round">{nm(seats, seat)}</text>
              </g>
            )
          })}
        </g>
      )}
    </g>
  )
}
