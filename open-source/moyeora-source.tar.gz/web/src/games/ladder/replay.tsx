import { useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { ladderId, parseLink, type LadderBoard, type LadderRecord } from '@moyeora/shared'
import { Shell } from '../../ui/Shell.tsx'
import { useTween } from './anim.ts'
import { Board } from './Board.tsx'
import { Descent } from './Descent.tsx'
import { BOTTOM_H } from './Frame.tsx'
import { allSlots, endsOf } from './paths.ts'
import { RevealAnim, summary } from './RevealAnim.tsx'
import { ResultList } from './ResultList.tsx'
import { verifyRecord, type Verdict } from './verify.ts'

type View = number // -1 = start board, 0.. = round index, 99 = result (descent)
const RESULT = 99

function Banner({ verdict }: { verdict: Verdict | null }) {
  if (verdict === 'bad') return <div role="alert" className="sticker" style={{ background: 'var(--red)', padding: '12px 14px', fontFamily: 'Jua, sans-serif', fontSize: 20, lineHeight: 1.3, textAlign: 'center' }}>확인할 수 없는 기록이에요 — 내용이 바뀌었을 수 있어요</div>
  if (verdict === 'unsupported') return <div role="status" className="sticker" style={{ background: 'var(--amber)', padding: '10px 14px', fontWeight: 700, textAlign: 'center' }}>이 브라우저에서는 서명을 확인할 수 없어요</div>
  return null
}

function Player({ record, id, verdict }: { record: LadderRecord; id: string; verdict: Verdict | null }) {
  const n = record.players.length
  const board: LadderBoard = useMemo(() => ({ n, seats: record.players.map((p, i) => ({ id: String(i), ...p })), items: record.items, system: record.system, rounds: record.rounds }), [record, n])
  const rungs = useMemo(() => allSlots(record.system, record.rounds), [record])
  const ends = useMemo(() => endsOf(n, rungs), [n, rungs])
  const [view, setView] = useState<View>(-1)
  const [animDone, setAnimDone] = useState(true)
  const [playKey, setPlayKey] = useState(0)
  const [auto, setAuto] = useState(false)
  const [focus, setFocus] = useState<number | null>(null)
  const [tip, setTip] = useState<number | null>(null)
  const [caption, setCaption] = useState('')
  const tween = useTween(0)
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(timer.current), [])

  const nextOf = (v: View): View | null => (v === -1 ? (record.rounds.length ? 0 : RESULT) : v === RESULT ? null : v + 1 < record.rounds.length ? v + 1 : RESULT)
  const go = (v: View, isAuto: boolean) => {
    clearTimeout(timer.current)
    tween.stop()
    setView(v); setAuto(isAuto); setTip(null); setCaption(''); setPlayKey((k) => k + 1)
    if (v === -1) { setAnimDone(true); tween.set(0); return }
    setAnimDone(false)
    if (v === RESULT) { tween.run(4000, () => { setAnimDone(true); }) } else tween.set(0)
  }
  const afterDone = useRef(() => {})
  afterDone.current = () => {
    setAnimDone(true)
    const nx = nextOf(view)
    if (auto && nx !== null) timer.current = setTimeout(() => go(nx, true), 700)
  }
  const playAll = () => {
    go(-1, true)
    timer.current = setTimeout(() => go(nextOf(-1)!, true), 700)
  }

  const inResult = view === RESULT
  const shownRounds = view === -1 ? [] : inResult ? record.rounds : record.rounds.slice(0, animDone ? view + 1 : view)
  const pickAvatar = (s: number) => { setFocus(s); setTip(s) }
  const labels: { v: View; text: string }[] = [{ v: -1, text: '시작 판' }, ...record.rounds.map((_, i) => ({ v: i, text: String(i + 1) })), { v: RESULT, text: '결과' }]
  const round = view >= 0 && view !== RESULT ? record.rounds[view] : null

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--lav)' }}>사다리 ID</div>
          <div className="jua" style={{ fontSize: 30, letterSpacing: '.04em', lineHeight: 1.1 }}>{id}</div>
        </div>
        {verdict === 'ok' && <span className="chip" style={{ fontSize: 15 }}>서명 확인됨</span>}
        {verdict === null && <span style={{ color: 'var(--lav-dim)', fontSize: 13 }}>서명 확인 중…</span>}
      </div>
      <Banner verdict={verdict} />
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
        {labels.map((l) => (
          <button key={l.v} type="button" aria-pressed={view === l.v} onClick={() => go(l.v, false)} style={{ minHeight: 40, minWidth: 40, padding: '0 12px', borderRadius: 999, border: '3px solid var(--ink)', background: view === l.v ? 'var(--lime)' : 'var(--card)', color: view === l.v ? 'var(--ink)' : 'var(--text)', fontWeight: 700, fontSize: 14, cursor: 'pointer', boxShadow: '3px 3px 0 var(--ink)' }}>{l.text}</button>
        ))}
        <button type="button" className="btn-sticker" data-tone="lime" style={{ width: 'auto', minHeight: 40, fontSize: 16, padding: '0 14px' }} onClick={playAll}>▶ 전체 재생</button>
      </div>
      <div style={{ height: 'calc(100dvh - 360px)', minHeight: 340 }}>
        <Board board={board} rounds={shownRounds} mySeat={null} topAvatars={!inResult} tipSeat={tip} onAvatar={pickAvatar} hitCol={inResult && animDone && focus !== null ? ends[focus] : null}>
          {round && !animDone && <RevealAnim key={playKey} result={round} seats={board.seats} onCaption={setCaption} onDone={() => afterDone.current()} />}
          {inResult && <Descent rungs={rungs} seats={board.seats} p={tween.p} focus={focus} onAvatar={pickAvatar} />}
        </Board>
      </div>
      <div style={{ height: BOTTOM_H, flex: 'none', overflowY: 'auto', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8, boxSizing: 'border-box' }}>
        {view === -1 && <div style={{ textAlign: 'center', color: 'var(--lav)', fontSize: 14 }}>시작 판이에요. 아바타를 눌러 누군지 확인해요</div>}
        {round && <div className="sticker" style={{ padding: '10px 14px', textAlign: 'center', fontFamily: 'Jua, sans-serif', fontSize: 22, minHeight: 64, display: 'grid', placeItems: 'center', boxSizing: 'border-box' }}>{animDone ? summary(round) : caption || '…'}</div>}
        {inResult && !animDone && <div style={{ textAlign: 'center', color: 'var(--lav)', fontSize: 14 }}>모두 내려가는 중…</div>}
        {inResult && animDone && (
          <div className="sticker" style={{ padding: 12 }}>
            <ResultList seats={board.seats} items={board.items} ends={ends} mySeat={null} focus={focus} onPick={pickAvatar} />
          </div>
        )}
      </div>
      <div style={{ fontSize: 12, color: 'var(--lav-dim)', textAlign: 'center' }}>{new Date(record.at).toLocaleString('ko-KR')} · {n}명</div>
    </div>
  )
}

function App() {
  const [hash, setHash] = useState(location.hash.slice(1))
  useEffect(() => {
    const f = () => setHash(location.hash.slice(1))
    addEventListener('hashchange', f)
    return () => removeEventListener('hashchange', f)
  }, [])
  const parsed = useMemo(() => parseLink(hash), [hash])
  const [verdict, setVerdict] = useState<Verdict | null>(null)
  useEffect(() => {
    setVerdict(null)
    if (!parsed) return
    let live = true
    verifyRecord(parsed.bytes, parsed.sig).then((v) => live && setVerdict(v))
    return () => { live = false }
  }, [parsed])

  return (
    <Shell>
      {parsed ? (
        // 서명이 맞을 때만 내용과 ID 를 그린다. 위조 링크에 진짜 서명을 붙이면 ID 가 진짜와 같아지므로 검증 전 ID 는 보여 주지 않는다.
        verdict === 'ok' || verdict === 'unsupported' ? (
          <Player key={hash} record={parsed.record} id={verdict === 'ok' ? ladderId(parsed.sig) : '확인 불가'} verdict={verdict} />
        ) : verdict === 'bad' ? (
          <Banner verdict="bad" />
        ) : (
          <div style={{ textAlign: 'center', color: 'var(--lav-dim)' }}>서명 확인 중…</div>
        )
      ) : (
        <div className="sticker" style={{ padding: 20, textAlign: 'center' }}>
          <div className="jua" style={{ fontSize: 24 }}>링크가 올바르지 않아요</div>
          <p style={{ margin: '8px 0 0' }}>결과 링크를 처음부터 끝까지 복사했는지 확인해 주세요.</p>
        </div>
      )}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
