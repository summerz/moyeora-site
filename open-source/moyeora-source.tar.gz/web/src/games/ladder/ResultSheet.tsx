import { useState } from 'react'
import { Modal } from '@mantine/core'
import type { LadderSeat } from '@moyeora/shared'
import { ResultList } from './ResultList.tsx'

type Props = {
  up: boolean
  seats: LadderSeat[]
  items: string[]
  ends: number[]
  mySeat: number | null
  id: string | null
  link: string | null
  isHost: boolean
  mismatch: { old: number; now: number } | null
  onReview: () => void
  onAgain: () => void
  onLobby: () => void
}

const replayUrl = (link: string) => `${location.origin}${import.meta.env.BASE_URL}ladder/replay/#${link}`
const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function'
const small = { fontSize: 16 } as const

/** Bottom sheet shown over the board when everyone has arrived. */
export function ResultSheet({ up, seats, items, ends, mySeat, id, link, isHost, mismatch, onReview, onAgain, onLobby }: Props) {
  const [toast, setToast] = useState<string | null>(null)
  const [manual, setManual] = useState<string | null>(null)
  const [modal, setModal] = useState(false)
  const url = link ? replayUrl(link) : null

  const flash = (m: string) => {
    setToast(m)
    setTimeout(() => setToast(null), 2000)
  }
  const copy = async () => {
    if (!url) return
    try {
      await navigator.clipboard.writeText(url)
      setManual(null)
      flash('복사했어요')
    } catch {
      setManual(url)
    }
  }
  const share = async () => {
    if (!url) return
    try {
      await navigator.share({ title: '사다리타기 결과', text: `사다리 ID ${id}`, url })
    } catch (e) {
      if (!(e instanceof DOMException && e.name === 'AbortError')) flash('공유하지 못했어요')
    }
  }
  const again = () => (mismatch ? setModal(true) : onAgain())

  return (
    <>
      <div className={`ld-sheet sticker${up ? ' up' : ''}`} aria-hidden={!up} inert={!up}>
        <ResultList seats={seats} items={items} ends={ends} mySeat={mySeat} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '3px dashed #b9ae8e', paddingTop: 6 }}>
          <div>
            <small style={{ fontSize: 13, fontWeight: 700, color: '#6a5d8f' }}>사다리 ID</small>
            <div className="jua" style={{ fontSize: 34, letterSpacing: '.04em', lineHeight: 1.1 }}>{id ?? '—'}</div>
          </div>
          {toast && <span role="status" className="chip" style={{ background: 'var(--lime)', fontSize: 15 }}>{toast}</span>}
        </div>
        <button type="button" className="btn-sticker" onClick={onReview}>다시 보기</button>
        <div className="ld-two">
          <button type="button" className="btn-sticker" style={small} onClick={copy} disabled={!url}>결과 링크 복사</button>
          {canShare && <button type="button" className="btn-sticker" style={small} onClick={share} disabled={!url}>공유하기</button>}
        </div>
        {manual && <input readOnly value={manual} aria-label="결과 링크" className="ld-in" style={{ flex: 'none', height: 38, fontSize: 13 }} onFocus={(e) => e.currentTarget.select()} ref={(el) => el?.select()} />}
        {isHost ? (
          <div className="ld-two">
            <button type="button" className={`btn-sticker${mismatch ? ' ld-muted' : ''}`} data-tone="lime" onClick={again}>한 판 더</button>
            <button type="button" className="btn-sticker" data-tone="cream" onClick={onLobby}>대기실로</button>
          </div>
        ) : (
          <div style={{ color: '#6a5d8f', textAlign: 'center', fontWeight: 700 }}>방장이 고르는 중…</div>
        )}
      </div>
      <Modal opened={modal && !!mismatch} onClose={() => setModal(false)} title={<span className="jua" style={{ fontSize: 24 }}>인원이 바뀌었어요</span>} centered withCloseButton={false}>
        <p style={{ margin: '0 0 16px' }}>{mismatch?.old}명 → {mismatch?.now}명. 대기실에서 항목 개수를 다시 맞춰 주세요.</p>
        <div className="ld-two">
          <button type="button" className="btn-sticker" data-tone="lime" onClick={() => { setModal(false); onLobby() }}>대기실로 가기</button>
          <button type="button" className="btn-sticker" onClick={() => setModal(false)}>닫기</button>
        </div>
      </Modal>
    </>
  )
}
