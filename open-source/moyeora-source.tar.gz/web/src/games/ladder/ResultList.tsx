import type { LadderSeat } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'

type Props = { seats: LadderSeat[]; items: string[]; ends: number[]; mySeat: number | null; focus?: number | null; onPick?: (seat: number) => void }

/** Items grouped by name with the avatars that arrived at them. */
export function ResultList({ seats, items, ends, mySeat, focus, onPick }: Props) {
  const names = [...new Set(items)]
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {names.map((name) => {
        const who = seats.map((_, s) => s).filter((s) => items[ends[s]!] === name)
        const compact = who.length > 2
        return (
          <div key={name} className="res" style={{ display: 'flex', alignItems: 'center', gap: 8, minHeight: 36, borderRadius: 10, padding: '0 6px', background: focus !== null && focus !== undefined && who.includes(focus) ? 'rgba(140,255,77,.5)' : undefined }}>
            <span className="jua" style={{ fontSize: 17, width: 84, flex: 'none' }}>{name}</span>
            <span style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 4, minWidth: 0 }}>
              {who.length === 0 && <span style={{ color: '#6b5f8a', fontSize: 13 }}>—</span>}
              {who.map((s) => {
                const me = s === mySeat
                const seat = seats[s]!
                return (
                  <span
                    key={s}
                    title={seat.name}
                    onClick={onPick && (() => onPick(s))}
                    style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontWeight: 700, fontSize: 14, borderRadius: 999, padding: me ? '1px 8px 1px 1px' : 1, background: me ? 'var(--lime)' : undefined, outline: me ? '3px solid var(--ink)' : undefined, cursor: onPick ? 'pointer' : undefined, marginRight: me ? 2 : 0 }}
                  >
                    <Avatar seed={seat.avatar} size={28} />
                    {!compact && <span>{me ? '나' : seat.name}{seat.bot && <NpcTag />}</span>}
                  </span>
                )
              })}
            </span>
          </div>
        )
      })}
    </div>
  )
}
