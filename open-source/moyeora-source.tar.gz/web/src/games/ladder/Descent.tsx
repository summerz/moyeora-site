import { useMemo } from 'react'
import { walk, type LadderSeat, type Slot } from '@moyeora/shared'
import { easeInOut } from './anim.ts'
import { seatColor } from './colors.ts'
import { pathPoints } from './geo.ts'
import { SvgAvatar, useGeo } from './svg.tsx'

type Props = { rungs: Slot[]; seats: LadderSeat[]; p: number; focus: number | null; onAvatar?: (seat: number) => void }

type Line = { pts: [number, number][]; cum: number[] }

function at(l: Line, d: number): [number, number] {
  let i = 1
  while (i < l.cum.length - 1 && l.cum[i]! < d) i++
  const f = (d - l.cum[i - 1]!) / (l.cum[i]! - l.cum[i - 1]! || 1)
  const a = l.pts[i - 1]!, b = l.pts[i]!
  return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]
}

/** All avatars descend along walk() paths at once; p is overall progress 0..1. Focus seat is bright, the rest faint. */
export function Descent({ rungs, seats, p, focus, onAvatar }: Props) {
  const geo = useGeo()
  const n = seats.length
  const lines = useMemo<Line[]>(
    () =>
      seats.map((_, s) => {
        const pts = pathPoints(geo, walk(n, rungs, s).path)
        const cum = [0]
        for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1]! + Math.hypot(pts[i]![0] - pts[i - 1]![0], pts[i]![1] - pts[i - 1]![1]))
        return { pts, cum }
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [n, rungs, seats],
  )
  const e = easeInOut(p)
  const all = focus === null
  const order = seats.map((_, i) => i).sort((a, b) => Number(a === focus) - Number(b === focus))
  return (
    <g>
      {order.map((s) => {
        const l = lines[s]!
        const total = l.cum[l.cum.length - 1]!
        const foc = s === focus
        return (
          <polyline key={`l${s}`} points={l.pts.map((q) => q.join(',')).join(' ')} fill="none" stroke={seatColor(s)} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - e} opacity={foc ? 1 : all ? 0.85 : 0.3} strokeWidth={foc ? 6 : all ? 4 : 2.5} filter={foc ? 'url(#ld-glow)' : undefined} />
        )
      })}
      {order.map((s) => {
        const l = lines[s]!
        const [x, y] = at(l, e * l.cum[l.cum.length - 1]!)
        const foc = s === focus
        return <SvgAvatar key={`a${s}`} seed={seats[s]!.avatar} color={seatColor(s)} size={28} x={x} y={y} scale={foc ? 1.25 : 1} opacity={foc || all ? 1 : 0.35} onClick={onAvatar && (() => onAvatar(s))} />
      })}
    </g>
  )
}
