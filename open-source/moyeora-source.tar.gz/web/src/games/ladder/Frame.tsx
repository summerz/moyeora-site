import type { ReactNode } from 'react'
import { W, H } from './geo.ts'

/** Fixed slot heights: the board never resizes between phases. */
export const TOP_H = 40
export const BOTTOM_H = 140

const ell = { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } as const

export const Heading = ({ title, sub }: { title: string; sub: string }) => (
  <div style={{ height: TOP_H, flex: 'none', overflow: 'hidden' }}>
    <div className="jua" style={{ fontSize: 20, lineHeight: 1.1, ...ell }}>{title}</div>
    <div style={{ fontSize: 12, lineHeight: 1.3, color: 'var(--lav)', ...ell }}>{sub}</div>
  </div>
)

type StageProps = { title: string; sub: string; board: ReactNode; bottom: ReactNode; sheet?: ReactNode }

/**
 * Every in-game phase: top slot (fixed) · board slot (rest, constant) · bottom slot (fixed).
 * `board` fills the board slot (overlays are positioned against it); `sheet` overlays board + bottom.
 */
export const Stage = ({ title, sub, board, bottom, sheet }: StageProps) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, height: 'calc(100dvh - 140px)', minHeight: 460 }}>
    <Heading title={title} sub={sub} />
    <div style={{ flex: 1, minHeight: 0, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ flex: '0 1 auto', minHeight: 0, aspectRatio: `${W} / ${H}`, position: 'relative' }}>{board}</div>
      <div style={{ height: BOTTOM_H, flex: 'none', display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', gap: 8, position: 'relative' }}>{bottom}</div>
      {sheet}
    </div>
  </div>
)

/** Bottom-slot info card (label + big value). */
export const InfoCard = ({ label, value, note }: { label: string; value: string; note?: string }) => (
  <div className="sticker" style={{ padding: '10px 14px', textAlign: 'center', boxSizing: 'border-box', minHeight: 96, display: 'grid', alignContent: 'center', gap: 2 }}>
    <div style={{ fontSize: 13, fontWeight: 700, color: '#6a5d8f' }}>{label}</div>
    <div className="jua" style={{ fontSize: 26, lineHeight: 1.15 }}>{value}</div>
    {note && <div style={{ fontSize: 12, fontWeight: 700, color: '#6a5d8f' }}>{note}</div>}
  </div>
)
