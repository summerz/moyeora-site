import type { Slot } from '@moyeora/shared'
import { INK } from './colors.ts'
import { W } from './geo.ts'
import { SvgAvatar, useGeo } from './svg.tsx'

/** My not-yet-revealed rung: dashed, my color, with a "내 선" label. */
export function PendingRung({ slot, seed, color }: { slot: Slot; seed: string; color: string }) {
  const geo = useGeo()
  const x1 = geo.X(slot.g), x2 = geo.X(slot.g + 1), y = geo.Y(slot.r)
  const lx = Math.min(W - 26, Math.max(26, (x1 + x2) / 2))
  return (
    <g>
      <g filter="url(#ld-glow)"><line x1={x1} x2={x2} y1={y} y2={y} stroke={color} strokeWidth={5} strokeDasharray="7 5" strokeLinecap="round" /></g>
      <SvgAvatar seed={seed} color={color} size={18} x={(x1 + x2) / 2} y={y} />
      <rect x={lx - 24} y={y - 30} width={48} height={20} rx={10} fill={color} stroke={INK} strokeWidth={2.5} />
      <text x={lx} y={y - 15.5} textAnchor="middle" fontSize={13} fontWeight={700} fill={INK}>내 선</text>
    </g>
  )
}
