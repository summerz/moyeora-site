import type { Slot } from '@moyeora/shared'

export const W = 354
export const H = 470
/** Item box width; the side margin keeps edge boxes inside the board. */
export const boxWidth = (n: number) => Math.min(84, W / n - 6)
export const TOPY = 36
export const Y0 = 64
export const Y1 = 412
const ROWS = 12

/** Board coordinates for n columns (n - 1 gaps). */
export type Geo = {
  n: number
  X: (col: number) => number
  SX: (gap: number) => number
  Y: (row: number) => number
  slotCenter: (s: Slot) => { x: number; y: number }
}

export function makeGeo(n: number): Geo {
  const PX = boxWidth(n) / 2 + 3
  const X = (c: number) => PX + (c * (W - 2 * PX)) / Math.max(1, n - 1)
  const Y = (r: number) => Y0 + ((r + 0.5) * (Y1 - Y0)) / ROWS
  const SX = (g: number) => (X(g) + X(g + 1)) / 2
  return { n, X, SX, Y, slotCenter: (s) => ({ x: SX(s.g), y: Y(s.r) }) }
}

/** Point list of a walk() path in board coordinates. */
export function pathPoints(geo: Geo, path: { col: number; r: number }[]): [number, number][] {
  return path.map((p) => [geo.X(p.col), p.r < 0 ? TOPY : p.r >= ROWS ? Y1 + 2 : geo.Y(p.r)])
}

/** n points on a regular polygon (2 → left/right, otherwise first point on top). */
export function polygon(n: number, cx: number, cy: number, R: number): { x: number; y: number; sin: number }[] {
  const start = n === 2 ? Math.PI : -Math.PI / 2
  return Array.from({ length: n }, (_, k) => {
    const a = start + (k * 2 * Math.PI) / n
    return { x: cx + R * Math.cos(a), y: cy + R * Math.sin(a), sin: Math.sin(a) }
  })
}

export function spiky(ro: number, ri: number, n = 12): string {
  return Array.from({ length: n * 2 }, (_, k) => {
    const a = (k * Math.PI) / n - Math.PI / 2
    const r = k % 2 ? ri : ro
    return `${(r * Math.cos(a)).toFixed(1)},${(r * Math.sin(a)).toFixed(1)}`
  }).join(' ')
}
