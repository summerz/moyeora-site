import { useRef, type ReactNode } from 'react'
import type { LadderBoard, RoundResult, Slot } from '@moyeora/shared'
import './ladder.css'
import { INK, seatColor } from './colors.ts'
import { boxWidth, H, makeGeo, TOPY, W, Y0, Y1 } from './geo.ts'
import { GeoCtx, RungLine, SvgAvatar, useGeo } from './svg.tsx'

type Props = {
  board: Pick<LadderBoard, 'n' | 'seats' | 'items' | 'system'>
  rounds: RoundResult[]
  mySeat: number | null
  showMe?: boolean
  topAvatars?: boolean
  hints?: Slot[]
  onTapSlot?: (s: Slot) => void
  hitCol?: number | null
  tipSeat?: number | null
  onAvatar?: (seat: number) => void
  children?: ReactNode
}

function wrap(s: string, cpl: number): string[] {
  const lines: string[] = []
  for (const w of s.split(/\s+/).filter(Boolean)) for (let i = 0; i < w.length; i += cpl) lines.push(w.slice(i, i + cpl))
  if (lines.length > 3) {
    lines.length = 3
    lines[2] = lines[2]!.slice(0, Math.max(1, cpl - 1)) + '…'
  }
  return lines
}

export function Board({ board, rounds, mySeat, showMe, topAvatars = true, hints, onTapSlot, hitCol, tipSeat, onAvatar, children }: Props) {
  const { n, seats, items } = board
  const geo = makeGeo(n)
  const { X, Y } = geo
  const svgRef = useRef<SVGSVGElement>(null)
  const seeds = seats.map((s) => s.avatar)
  const boxW = boxWidth(n)
  const cpl = Math.max(2, Math.floor((boxW - 4) / 12))

  const onPointerDown = (e: React.PointerEvent) => {
    const m = svgRef.current?.getScreenCTM()
    if (!onTapSlot || !hints?.length || !m) return
    const pt = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse())
    if (pt.y < Y0 - 10 || pt.y > Y1 + 8) return
    let best: Slot | null = null
    let bd = Infinity
    for (const s of hints) {
      const d = (pt.x - geo.SX(s.g)) ** 2 + ((pt.y - Y(s.r)) * 1.3) ** 2
      if (d < bd) { bd = d; best = s }
    }
    if (best) onTapSlot(best)
  }

  const myX = mySeat !== null ? X(mySeat) : 0
  return (
    <GeoCtx.Provider value={geo}>
      <svg ref={svgRef} preserveAspectRatio="xMidYMin meet" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="사다리 판" onPointerDown={onPointerDown} style={{ display: 'block', width: '100%', height: '100%', touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent', userSelect: 'none' }}>
        <defs>
          <filter id="ld-glow" filterUnits="userSpaceOnUse" x={-20} y={-20} width={W + 40} height={H + 40}>
            <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        {showMe && mySeat !== null && <rect x={myX - 20} y={19} width={40} height={Y1 - 19 + 8} rx={14} fill="rgba(140,255,77,.12)" stroke="#8cff4d" strokeWidth={2} strokeDasharray="5 4" filter="url(#ld-glow)" />}
        {Array.from({ length: n }, (_, c) => <line key={c} x1={X(c)} x2={X(c)} y1={Y0 - 8} y2={Y1 + 2} stroke="rgba(237,230,255,.3)" strokeWidth={4} strokeLinecap="round" />)}
        {hints?.map((s) => (
          <line key={`${s.g}-${s.r}`} x1={X(s.g) + 8} x2={X(s.g + 1) - 8} y1={Y(s.r)} y2={Y(s.r)} stroke="rgba(237,230,255,.28)" strokeWidth={2.5} strokeDasharray="3 5" strokeLinecap="round" />
        ))}
        {board.system.map((s) => <RungLine key={`s${s.g}-${s.r}`} rung={{ ...s, o: -1 }} seeds={seeds} />)}
        {rounds.flatMap((rd, i) => rd.placed.map((p) => <RungLine key={`r${i}-${p.g}-${p.r}`} rung={p} seeds={seeds} />))}
        {items.map((name, c) => {
          const lines = wrap(name, cpl)
          const fs = lines.length > 2 ? 11 : 13
          const lh = lines.length > 2 ? 12 : 15
          const hit = hitCol === c
          return (
            <g key={c}>
              <title>{name}</title>
              <rect x={X(c) - boxW / 2} y={Y1 + 10} width={boxW} height={46} rx={8} fill={hit ? '#8cff4d' : '#fff8e7'} stroke={INK} strokeWidth={2.5} />
              {lines.map((l, k) => (
                <text key={k} x={X(c)} y={Y1 + 33 + (k - (lines.length - 1) / 2) * lh + fs * 0.35} textAnchor="middle" fontSize={fs} fontWeight={700} fill={INK} style={{ fontFamily: 'inherit' }}>{l}</text>
              ))}
            </g>
          )
        })}
        {topAvatars && seats.map((s, i) => <SvgAvatar key={s.id} seed={s.avatar} color={seatColor(i)} size={32} x={X(i)} y={TOPY} onClick={onAvatar && (() => onAvatar(i))} />)}
        {showMe && mySeat !== null && (
          <g>
            <rect x={myX - 14} y={-1} width={28} height={19} rx={9} fill="#8cff4d" stroke={INK} strokeWidth={2.5} />
            <text x={myX} y={13.5} textAnchor="middle" fontSize={13} fontWeight={700} fill={INK}>나</text>
          </g>
        )}
        {children}
        {tipSeat !== null && tipSeat !== undefined && <Tip seat={tipSeat} name={seats[tipSeat]!.name + (tipSeat === mySeat ? ' (나)' : '')} bot={seats[tipSeat]!.bot} />}
      </svg>
    </GeoCtx.Provider>
  )
}

function Tip({ seat, name, bot }: { seat: number; name: string; bot: boolean }) {
  const { X } = useGeo()
  const x0 = X(seat)
  const tw = name.length * 14.5 + 22
  const nw = bot ? 44 : 0
  const w = tw + nw
  const cx = Math.min(W - w / 2 - 4, Math.max(w / 2 + 4, x0))
  return (
    <g className="ld-fade" pointerEvents="none">
      <polygon points={`${x0 - 8},57 ${x0},47 ${x0 + 8},57`} fill="#fff8e7" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
      <rect x={cx - w / 2} y={56} width={w} height={30} rx={10} fill="#fff8e7" stroke={INK} strokeWidth={3} />
      <line x1={x0 - 6} x2={x0 + 6} y1={56.5} y2={56.5} stroke="#fff8e7" strokeWidth={4} />
      <text x={cx - w / 2 + tw / 2} y={76.5} textAnchor="middle" fontSize={14} fontWeight={700} fill={INK}>{name}</text>
      {bot && (
        <>
          <rect x={cx - w / 2 + tw - 2} y={62} width={40} height={18} rx={6} fill="#ffb347" stroke={INK} strokeWidth={2} />
          <text x={cx - w / 2 + tw + 18} y={75.5} textAnchor="middle" fontSize={13} fontWeight={700} fill={INK}>NPC</text>
        </>
      )}
    </g>
  )
}
