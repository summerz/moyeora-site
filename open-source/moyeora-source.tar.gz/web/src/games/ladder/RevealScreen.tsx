import { useEffect, useMemo, useRef, useState } from 'react'
import type { ClientMessage, LadderReveal, RoomView } from '@moyeora/shared'
import { useTween } from './anim.ts'
import { Board } from './Board.tsx'
import { Descent } from './Descent.tsx'
import { InfoCard, Stage } from './Frame.tsx'
import { allSlots, endsOf } from './paths.ts'
import { RevealAnim, summary } from './RevealAnim.tsx'
import { ResultSheet } from './ResultSheet.tsx'
import { WaitBar } from '../../ui/WaitBar.tsx'

type Room = Extract<RoomView, { game: 'ladder' }>
type Stage = 'reveal' | 'idle' | 'descent' | 'result' | 'review'
type Props = { room: Room; reveal: LadderReveal | null; send: (m: ClientMessage) => void }

/** Reveal of one round and, after the last round, descent → result sheet → review. */
export function RevealScreen({ room, reveal, send }: Props) {
  const board = room.g.board!
  const done = room.phase === 'done'
  const [stage, setStage] = useState<Stage>(reveal ? 'reveal' : done ? 'result' : 'idle')
  const [caption, setCaption] = useState('')
  const [focus, setFocus] = useState<number | null>(room.g.mySeat)
  const [tip, setTip] = useState<number | null>(null)
  const [sheetUp, setSheetUp] = useState(!reveal && done)
  const tween = useTween(!reveal && done ? 1 : 0)
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(timer.current), [])

  const rounds = useMemo(() => (reveal && board.rounds.length < reveal.round ? [...board.rounds, reveal.result] : board.rounds), [board.rounds, reveal])
  const shown = stage === 'reveal' && reveal ? rounds.slice(0, reveal.round - 1) : rounds
  const rungs = useMemo(() => allSlots(board.system, rounds), [board.system, rounds])
  const ends = useMemo(() => endsOf(board.n, rungs), [board.n, rungs])

  const descend = (delay: number) => {
    clearTimeout(timer.current)
    setStage('descent')
    setSheetUp(false)
    setTip(null)
    timer.current = setTimeout(() => tween.run(4000, () => {
      setStage('result')
      timer.current = setTimeout(() => setSheetUp(true), 800)
    }), delay)
  }
  const revealDone = useRef(() => {})
  revealDone.current = () => {
    if (room.phase === 'done') descend(500)
    else setStage('idle')
  }
  const review = () => { clearTimeout(timer.current); tween.set(0); setStage('review'); setSheetUp(false); setFocus(room.g.mySeat); setTip(null) }
  const showResult = () => { clearTimeout(timer.current); tween.stop(); tween.set(1); setStage('result'); setSheetUp(true); setTip(null) }

  const descentOn = stage === 'descent' || stage === 'result' || stage === 'review'
  const rnd = reveal?.round ?? room.round
  const hitting = caption.includes('💥') || caption.startsWith('선이 모두')
  const [title, sub] =
    stage === 'descent' ? ['내려가는 중…', '내 길은 또렷하게, 남의 길은 흐리게']
    : stage === 'result' ? ['도착!', `사다리 ID ${room.g.id ?? reveal?.id ?? '—'}`]
    : stage === 'review' ? ['다시 보기', '아바타를 눌러 누군지 확인해요']
    : [`${rnd}라운드 공개`, hitting ? '부딪힌 선은 사라져요' : '선이 하나씩 나타나요']
  const mismatch = room.g.total !== room.players.length ? { old: board.n, now: room.players.length } : null
  const f = focus ?? room.g.mySeat

  const last = reveal?.result ?? board.rounds[board.rounds.length - 1]
  const mine = room.g.mySeat !== null ? board.items[ends[room.g.mySeat]!] : null
  const bottom =
    stage === 'review' ? (
      <div className="ld-two">
        <button type="button" className="btn-sticker ld-bar" data-tone="lime" onClick={() => descend(0)}>▶ 재생</button>
        <button type="button" className="btn-sticker ld-bar" onClick={showResult}>결과 보기</button>
      </div>
    ) : stage === 'reveal' || stage === 'idle' ? (
      <>
        {caption || reveal ? (
          <div className="sticker ld-bar">{caption || summary(reveal!.result)}</div>
        ) : (
          <WaitBar className="ld-bar">다음 라운드를 기다리는 중</WaitBar>
        )}
        {last && <div style={{ textAlign: 'center', fontSize: 14, fontWeight: 700, color: 'var(--lav)' }}>선 {last.placed.length}개 생김 · 충돌 {last.collisions.length}건</div>}
      </>
    ) : stage === 'descent' ? (
      <InfoCard label="내가 도착할 곳" value="두구두구…" />
    ) : mine !== null ? (
      <InfoCard label="내가 도착한 곳" value={`나 → ${mine}`} />
    ) : null

  return (
    <Stage
      title={title}
      sub={sub}
      board={
        <Board
          board={board}
          rounds={shown}
          mySeat={room.g.mySeat}
          topAvatars={!descentOn}
          hitCol={stage === 'result' && f !== null ? ends[f] : null}
          tipSeat={stage === 'review' ? tip : null}
        >
          {stage === 'reveal' && reveal && <RevealAnim key={reveal.round} result={reveal.result} seats={board.seats} onCaption={setCaption} onDone={() => revealDone.current()} />}
          {descentOn && (
            <Descent
              rungs={rungs}
              seats={board.seats}
              p={tween.p}
              focus={f}
              onAvatar={stage === 'review' ? (s) => { setFocus(s); setTip(s) } : undefined}
            />
          )}
        </Board>
      }
      bottom={bottom}
      sheet={
        <ResultSheet
          up={sheetUp}
          seats={board.seats}
          items={board.items}
          ends={ends}
          mySeat={room.g.mySeat}
          id={room.g.id ?? reveal?.id ?? null}
          link={room.g.link ?? reveal?.link ?? null}
          isHost={room.host === room.you}
          mismatch={mismatch}
          onReview={review}
          onAgain={() => send({ type: 'start' })}
          onLobby={() => send({ type: 'lobby' })}
        />
      }
    />
  )
}
