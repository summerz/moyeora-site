import { createContext, useContext, useLayoutEffect, useRef, type ReactNode } from 'react'
import type { Rung } from '@moyeora/shared'
import { avatarUri } from '../../ui/Avatar.tsx'
import { INK, seatColor } from './colors.ts'
import type { Geo } from './geo.ts'
import { prefersReducedMotion } from './paths.ts'

export const GeoCtx = createContext<Geo | null>(null)
export const useGeo = () => useContext(GeoCtx)!

type AvatarProps = { seed: string; color: string; size: number; x: number; y: number; scale?: number; opacity?: number; onClick?: () => void }

/** Avatar disc centered at (x, y). The transform is an SVG attribute (not CSS) so Safari scales around the right point. */
export function SvgAvatar({ seed, color, size, x, y, scale = 1, opacity, onClick }: AvatarProps) {
  const ring = size >= 28 ? 3 : 2
  const r = size / 2
  return (
    <g transform={`translate(${x} ${y})${scale === 1 ? '' : ` scale(${scale})`}`} opacity={opacity} onClick={onClick} style={onClick ? { cursor: 'pointer' } : undefined}>
      <circle r={r} fill={color} stroke={INK} strokeWidth={ring >= 3 ? 2.4 : 1.8} />
      <image href={avatarUri(seed, 64)} x={-(r - ring)} y={-(r - ring)} width={2 * (r - ring)} height={2 * (r - ring)} />
      {onClick && <circle r={r + 4} fill="transparent" />}
    </g>
  )
}

/** Scales its children in place (0.6 → 1.06 → 1) or bursts (0 → 1.25 → 1). Parent <g> must be translated to the child's center. */
export function PopIn({ kind = 'avatar', children }: { kind?: 'avatar' | 'burst'; children: ReactNode }) {
  const ref = useRef<SVGGElement>(null)
  useLayoutEffect(() => {
    const g = ref.current
    if (!g || prefersReducedMotion()) return
    const dur = kind === 'burst' ? 450 : 260
    const scaleAt = (k: number) =>
      kind === 'burst' ? (k < 0.6 ? 1.25 * (k / 0.6) : 1.25 - 0.25 * ((k - 0.6) / 0.4)) : k < 0.6 ? 0.6 + 0.46 * (k / 0.6) : 1.06 - 0.06 * ((k - 0.6) / 0.4)
    const apply = (k: number) => {
      g.setAttribute('transform', `scale(${scaleAt(k)})`)
      g.setAttribute('opacity', String(Math.min(1, k / 0.6)))
    }
    apply(0)
    const t0 = performance.now()
    let raf = 0
    const step = (now: number) => {
      const k = Math.min(1, (now - t0) / dur)
      apply(k)
      if (k < 1) raf = requestAnimationFrame(step)
      else g.removeAttribute('transform')
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [kind])
  return <g ref={ref}>{children}</g>
}

type RungProps = { rung: Rung; seeds: string[]; draw?: boolean; dash?: boolean; width?: number }

/** One rung with the owner's avatar dot on its center. */
export function RungLine({ rung, seeds, draw, dash, width = 4 }: RungProps) {
  const geo = useGeo()
  const x1 = geo.X(rung.g)
  const x2 = geo.X(rung.g + 1)
  const y = geo.Y(rung.r)
  const color = seatColor(rung.o)
  return (
    <g>
      <line className={`ld-ln${draw ? ' draw' : ''}`} x1={x1} x2={x2} y1={y} y2={y} stroke={color} strokeWidth={width} strokeLinecap="round" pathLength={1} strokeDasharray={dash ? '6 5' : undefined} />
      {rung.o >= 0 && seeds[rung.o] && (
        <g className={`ld-dot${draw ? ' draw' : ''}`}>
          <SvgAvatar seed={seeds[rung.o]!} color={color} size={18} x={(x1 + x2) / 2} y={y} />
        </g>
      )}
    </g>
  )
}

export const DimRect = ({ on }: { on: boolean }) => <rect className={`ld-dim${on ? ' on' : ''}`} x={0} y={0} width={354} height={470} />
