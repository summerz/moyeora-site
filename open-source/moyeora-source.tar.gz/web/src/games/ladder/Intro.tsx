import { useMemo } from 'react'
import type { LadderBoard } from '@moyeora/shared'
import { useCountdownBeeps } from '../../ui/sound.ts'
import { useCountdown } from '../../ui/useCountdown.ts'
import { Board } from './Board.tsx'
import { InfoCard, Stage } from './Frame.tsx'
import { allSlots, endsOf } from './paths.ts'

type Props = { board: LadderBoard; mySeat: number | null; remainingMs: number | null }

export function Intro({ board, mySeat, remainingMs }: Props) {
  const left = useCountdown(remainingMs)
  const goPerf = useMemo(() => (remainingMs === null ? null : performance.now() + remainingMs), [remainingMs])
  useCountdownBeeps(goPerf)
  const n = Math.max(1, Math.min(5, Math.ceil((left ?? 0) / 1000)))
  const mine = useMemo(() => (mySeat === null ? null : board.items[endsOf(board.n, allSlots(board.system, []))[mySeat]!]), [board, mySeat])
  return (
    <Stage
      title="곧 시작해요"
      sub="내 자리는 ‘나’ 표시로 확인해요"
      board={
        <>
          <div style={{ height: '100%', opacity: 0.45 }}>
            <Board board={board} rounds={[]} mySeat={mySeat} showMe />
          </div>
          <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}>
            <div key={n} className="sticker ld-cd" role="timer" aria-label={`${n}초 뒤 시작`}><span>{n}</span></div>
          </div>
        </>
      }
      bottom={mySeat === null ? null : <InfoCard label={`내 출발 자리 ${mySeat + 1}번 · 지금 그대로라면`} value={mine ?? '—'} note="앞으로 그어지는 선에 따라 달라져요" />}
    />
  )
}
