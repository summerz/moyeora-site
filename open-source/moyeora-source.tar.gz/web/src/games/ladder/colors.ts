export const PAL = ['#ff9d94', '#ffb24e', '#c1cf56', '#5fe1a3', '#00def0', '#76caff', '#cbb0ff', '#ff9de2'] as const
export const SYSTEM_COLOR = '#9d8fc4'
export const INK = '#0e0a1c'
/** Line color of a seat. System rungs (o < 0) are drawn in lavender. */
export const seatColor = (seat: number) => (seat < 0 ? SYSTEM_COLOR : PAL[(seat * 3) % 8]!)
