export function LadderHero({ size = 110 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 110 110" aria-hidden="true" style={{ alignSelf: 'center' }}>
      <path d="M30 8v94M80 8v94" stroke="#fff8e7" strokeWidth="9" strokeLinecap="round" />
      <path d="M30 28h50" stroke="#8cff4d" strokeWidth="9" strokeLinecap="round" />
      <path d="M30 55h50" stroke="#ffb24e" strokeWidth="9" strokeLinecap="round" />
      <path d="M30 82h50" stroke="#76caff" strokeWidth="9" strokeLinecap="round" />
      <circle className="hero-marble" r="6.5" fill="#ff5c8a" stroke="#1a1233" strokeWidth="2.5" style={{ opacity: 0 }} />
    </svg>
  )
}
