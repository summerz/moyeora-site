import { walk, type LadderBoard, type RoundResult, type Slot } from '@moyeora/shared'

/** Every rung on the finished board (system + all placed rungs). */
export const allSlots = (system: Slot[], rounds: RoundResult[]): Slot[] => [...system, ...rounds.flatMap((r) => r.placed.map(({ g, r: row }) => ({ g, r: row })))]

export const boardRungs = (b: Pick<LadderBoard, 'system'>, rounds: RoundResult[]) => allSlots(b.system, rounds)

/** Column each seat ends in. */
export const endsOf = (n: number, rungs: Slot[]): number[] => Array.from({ length: n }, (_, s) => walk(n, rungs, s).end)

export const prefersReducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
