import { useEffect, useRef, useState } from 'react'
import type { ClientMessage, LadderItem } from '@moyeora/shared'

const KEY = 'moyeora:ladder:items'
const MAX_ROWS = 8
const MAX_SUM = 8
let storedSent = false // the remembered list is pushed once per page load

type Row = LadderItem & { id: number }
let seq = 0
const toRows = (items: LadderItem[]): Row[] => items.map((it) => ({ ...it, id: ++seq }))
const sumOf = (rows: LadderItem[]) => rows.reduce((a, r) => a + r.count, 0)
const sendable = (rows: Row[]) => rows.length >= 1 && rows.length <= MAX_ROWS && rows.every((r) => r.name.trim().length >= 1 && r.name.length <= 12 && r.count >= 1 && r.count <= MAX_SUM) && sumOf(rows) <= MAX_SUM
const clean = (rows: Row[]): LadderItem[] => rows.map(({ name, count }) => ({ name: name.trim(), count }))

function loadStored(): LadderItem[] | null {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) ?? 'null')
    if (!Array.isArray(v)) return null
    const items = v.filter((x) => x && typeof x.name === 'string' && Number.isInteger(x.count)).map((x) => ({ name: String(x.name).slice(0, 12), count: x.count as number }))
    return sendable(toRows(items)) ? items : null
  } catch {
    return null
  }
}
const remember = (items: LadderItem[]) => {
  try { localStorage.setItem(KEY, JSON.stringify(items)) } catch { /* ignore */ }
}

type Props = { isHost: boolean; config: { items: LadderItem[] } | null; players: number; send: (m: ClientMessage) => void }

const badgeStyle = (ok: boolean) => ({ fontFamily: 'Jua, sans-serif', fontSize: 20, padding: '0 12px', border: '3px solid var(--ink)', borderRadius: 999, background: ok ? 'var(--lime)' : 'var(--amber)', minWidth: 68, textAlign: 'center', fontVariantNumeric: 'tabular-nums' }) as const
const trash = <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0e0a1c" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" /></svg>

export function ItemEditor({ isHost, config, players, send }: Props) {
  return isHost ? <HostEditor config={config} players={players} send={send} /> : <ReadOnly config={config} players={players} />
}

function HostEditor({ config, players, send }: { config: Props['config']; players: number; send: Props['send'] }) {
  const [initial] = useState(() => (storedSent ? null : loadStored()))
  const [rows, setRows] = useState<Row[]>(() => toRows(initial ?? config?.items ?? [{ name: '당첨', count: 1 }, { name: '꽝', count: 1 }]))
  const debounce = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(debounce.current), [])
  useEffect(() => {
    storedSent = true
    if (initial) send({ type: 'config', config: { items: initial } })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const push = (next: Row[], now: boolean) => {
    setRows(next)
    clearTimeout(debounce.current)
    if (!sendable(next)) return
    const items = clean(next)
    const go = () => { remember(items); send({ type: 'config', config: { items } }) }
    if (now) go()
    else debounce.current = setTimeout(go, 300)
  }
  const sum = sumOf(rows)
  const patch = (id: number, f: (r: Row) => Row | null, now: boolean) => push(rows.flatMap((r) => (r.id === id ? (f(r) ?? []) : [r])), now)

  return (
    <div className="sticker" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <b className="jua" style={{ fontSize: 20, fontWeight: 400 }}>아래 칸 항목</b>
        <span style={badgeStyle(sum === players)} aria-live="polite">{sum} / {players}</span>
      </div>
      {rows.map((r) => (
        <div key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <input className="ld-in" maxLength={12} value={r.name} placeholder="항목 이름" aria-label="항목 이름" onChange={(e) => patch(r.id, (x) => ({ ...x, name: e.target.value }), false)} />
          <button type="button" className={`ld-stp${r.count <= 1 ? ' del' : ''}`} aria-label={r.count <= 1 ? '항목 삭제' : '개수 줄이기'} onClick={() => patch(r.id, (x) => (x.count <= 1 ? null : { ...x, count: x.count - 1 }), true)}>
            {r.count <= 1 ? trash : '−'}
          </button>
          <output className="jua" style={{ width: 20, textAlign: 'center', fontSize: 22 }}>{r.count}</output>
          <button type="button" className="ld-stp" aria-label="개수 늘리기" disabled={sum >= MAX_SUM} onClick={() => patch(r.id, (x) => ({ ...x, count: x.count + 1 }), true)}>+</button>
        </div>
      ))}
      {rows.length < MAX_ROWS && sum < MAX_SUM && (
        <button type="button" onClick={() => push([...rows, ...toRows([{ name: '', count: 1 }])], true)} style={{ minHeight: 44, border: '3px dashed #8a7fb0', borderRadius: 12, background: 'transparent', color: '#5b4f82', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>+ 항목 추가</button>
      )}
      {rows.some((r) => !r.name.trim()) && <div style={{ fontSize: 13, color: '#6b5f8a', textAlign: 'center' }}>항목 이름을 모두 적어 주세요</div>}
    </div>
  )
}

function ReadOnly({ config, players }: { config: Props['config']; players: number }) {
  const items = config?.items ?? []
  const key = JSON.stringify(items)
  const [typing, setTyping] = useState(false)
  const first = useRef(true)
  useEffect(() => {
    if (first.current) { first.current = false; return }
    setTyping(true)
    const t = setTimeout(() => setTyping(false), 1500)
    return () => clearTimeout(t)
  }, [key])
  const sum = sumOf(items)
  return (
    <div className="sticker sticker--dark" style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 700, color: 'var(--lav)' }}>
        <span>아래 칸 항목</span>
        <span className="jua" style={{ fontSize: 16, color: sum === players ? 'var(--lime)' : 'var(--amber)' }}>{sum} / {players}</span>
      </div>
      <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {items.map((it, i) => <li key={i} style={{ background: 'var(--cream)', color: 'var(--ink)', borderRadius: 8, padding: '0 10px', fontWeight: 700, fontSize: 14, border: '2px solid var(--ink)' }}>{it.name} ×{it.count}</li>)}
      </ul>
      {typing && <span className="ld-typing">방장이 적는 중<i /><i /><i /></span>}
    </div>
  )
}
