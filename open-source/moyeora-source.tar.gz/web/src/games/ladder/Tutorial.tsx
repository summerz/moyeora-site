import type { ReactNode } from 'react'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { INK, seatColor } from './colors.ts'
import { spiky } from './geo.ts'
import { SvgAvatar } from './svg.tsx'

// 그림용 작은 사다리 (세로줄 3개). 실제 판과 같은 색·아바타·항목 상자를 쓴다.
const X = [40, 120, 200]
const TOP = 12
const BOT = 112
const xs = (g: number) => (X[g]! + X[g + 1]!) / 2
const ITEMS = ['꽝', '설거지', '커피 쏘기']

function Mini({ children, hit }: { children: ReactNode; hit?: number }) {
  return (
    <svg width={240} height={150} viewBox="0 0 240 150" aria-hidden="true" style={{ pointerEvents: 'none' }}>
      {X.map((x) => <line key={x} x1={x} x2={x} y1={TOP} y2={BOT} stroke="rgba(26,18,51,.3)" strokeWidth={4} strokeLinecap="round" />)}
      {children}
      {ITEMS.map((t, c) => (
        <g key={t}>
          <rect x={X[c]! - 32} y={116} width={64} height={28} rx={8} fill={hit === c ? '#8cff4d' : '#fff8e7'} stroke={INK} strokeWidth={2.5} />
          <text x={X[c]!} y={135} textAnchor="middle" fontSize={13} fontWeight={700} fill={INK}>{t}</text>
        </g>
      ))}
    </svg>
  )
}

const Rung = ({ g, y, seat, seed, dash }: { g: number; y: number; seat: number; seed?: string; dash?: boolean }) => (
  <g>
    <line x1={X[g]!} x2={X[g + 1]!} y1={y} y2={y} stroke={seatColor(seat)} strokeWidth={4} strokeLinecap="round" strokeDasharray={dash ? '6 5' : undefined} />
    {seed && <SvgAvatar seed={seed} color={seatColor(seat)} size={26} x={xs(g)} y={y} />}
  </g>
)

const Hint = ({ g, y }: { g: number; y: number }) => (
  <line x1={X[g]! + 8} x2={X[g + 1]! - 8} y1={y} y2={y} stroke="rgba(26,18,51,.35)" strokeWidth={2.5} strokeDasharray="3 5" strokeLinecap="round" />
)

const PAGES: TutorialPage[] = [
  {
    title: '빈칸에 몰래 한 줄',
    art: (
      <Mini>
        <Hint g={0} y={30} />
        <Hint g={1} y={52} />
        <Hint g={1} y={96} />
        <Rung g={1} y={30} seat={-1} />
        <Rung g={0} y={74} seat={0} seed="tut-a" />
      </Mini>
    ),
    line: <>라운드마다 내가 긋고 싶은 곳에 <b>한 줄 그어요</b>. 안 그어도 돼요.</>,
  },
  {
    title: '동시에 공개',
    art: (
      <Mini>
        <Rung g={0} y={34} seat={0} seed="tut-a" />
        <Rung g={1} y={62} seat={1} seed="tut-b" />
        <Rung g={0} y={90} seat={2} seed="tut-c" />
      </Mini>
    ),
    line: <>모두 그었으면 <b>선이 나타나요</b>. 누가 어디 그었는지는 비밀!</>,
  },
  {
    title: '겹치면 사라져요!',
    art: (
      <Mini>
        <Rung g={1} y={30} seat={-1} />
        <Rung g={0} y={70} seat={0} seed="tut-a" />
        <Rung g={1} y={70} seat={1} seed="tut-b" />
        <g transform={`translate(${X[1]} 70)`}>
          <polygon points={spiky(24, 15)} fill="#ffb24e" stroke={INK} strokeWidth={2.5} strokeLinejoin="round" />
          <text y={7} textAnchor="middle" fontSize={20} fontWeight={900} fill={INK}>!</text>
        </g>
      </Mini>
    ),
    line: <><b>같은 칸</b>이나 <b>옆 칸</b>에 그으면 충돌! 이 선들은 모두 무효 처리가 돼요.</>,
  },
  {
    title: '두근두근 다 같이 확인!',
    art: (
      <Mini hit={2}>
        <Rung g={0} y={40} seat={-1} />
        <Rung g={1} y={84} seat={-1} />
        <Rung g={0} y={62} seat={0} seed="tut-a" />
        <polyline points={`${X[0]},${TOP + 4} ${X[0]},40 ${X[1]},40 ${X[1]},84 ${X[2]},84 ${X[2]},${BOT + 2}`} fill="none" stroke="#8cff4d" strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />
        <SvgAvatar seed="tut-me" color="#8cff4d" size={26} x={X[0]!} y={TOP + 4} />
      </Mini>
    ),
    line: <>3라운드가 끝나면 <b>드디어 확인</b>!<br/>나는 뭐에 걸릴 것인가!</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
