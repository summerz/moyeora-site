import { useCallback, useEffect, useRef, useState } from 'react'
import { prefersReducedMotion } from './paths.ts'

/** 0..1 progress driven by requestAnimationFrame. `run` restarts; `set` jumps. */
export function useTween(initial = 0) {
  const [p, setP] = useState(initial)
  const raf = useRef(0)
  const stop = useCallback(() => cancelAnimationFrame(raf.current), [])
  useEffect(() => stop, [stop])
  const set = useCallback((v: number) => { stop(); setP(v) }, [stop])
  const run = useCallback((ms: number, onDone?: () => void) => {
    stop()
    if (prefersReducedMotion()) { setP(1); onDone?.(); return }
    const t0 = performance.now()
    setP(0)
    const step = (now: number) => {
      const k = Math.min(1, (now - t0) / ms)
      setP(k)
      if (k < 1) raf.current = requestAnimationFrame(step)
      else onDone?.()
    }
    raf.current = requestAnimationFrame(step)
  }, [stop])
  return { p, run, set, stop }
}

export const easeInOut = (k: number) => (k < 0.5 ? 2 * k * k : 1 - 2 * (1 - k) ** 2)
