import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { slotKey, type LadderReveal, type RoomView, type ServerMessage, type Slot } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { RoundProgress } from '../../ui/RoundProgress.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { useSocket } from '../../ws.ts'
import { Draw } from './Draw.tsx'
import { Intro } from './Intro.tsx'
import { ItemEditor } from './ItemEditor.tsx'
import { LadderHero } from './LadderHero.tsx'
import { RevealScreen } from './RevealScreen.tsx'
import { Tutorial } from './Tutorial.tsx'

type Room = Extract<RoomView, { game: 'ladder' }>

const TUT_KEY = 'moyeora:ladder:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<Room | null>(null)
  const [reveal, setReveal] = useState<LadderReveal | null>(null)
  const [choice, setChoice] = useState<string | null>(null)
  const [error, setError] = useState<string>()
  const roomRef = useRef<Room | null>(null)

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'ladder') return
      const prev = roomRef.current
      if (!prev || prev.round !== m.room.round || (m.room.phase === 'choosing' && prev.phase !== 'choosing') || m.room.phase === 'lobby') {
        setChoice(null)
        setReveal(null)
      }
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'reveal') {
      setReveal(m.result as LadderReveal)
    } else {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    setRoom(null)
    setReveal(null)
    setChoice(null)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)

  const submit = (c: string) => {
    if (c === choice) return
    setChoice(c)
    send({ type: 'submit', choice: c })
  }
  useEffect(() => { document.title = '사다리타기 — 모여라' }, [])

  const board = room?.g.board ?? null
  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="ladder"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'ladder', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    const players = room.players.length
    const ready = room.g.total === players && players >= 2
    screen = (
      <Lobby
        room={room}
        hero={<LadderHero />}
        canStart={ready}
        startHint={players < 2 ? '2명 이상 모이면 시작할 수 있어요' : ready ? '준비 끝! 시작할 수 있어요' : `항목 합계를 ${players}로 맞춰 주세요`}
        onStart={() => send({ type: 'start' })}
        onKick={(playerId) => send({ type: 'kick', playerId })}
        onAddBot={() => send({ type: 'addBot' })}
      >
        <ItemEditor isHost={room.host === room.you} config={room.g.config} players={players} send={send} />
        {error && <div role="alert" style={{ color: 'var(--red)', textAlign: 'center' }}>{error}</div>}
      </Lobby>
    )
  } else if (!board) {
    screen = <div style={{ color: 'var(--lav-dim)', textAlign: 'center' }}>불러오는 중…</div>
  } else if (room.phase === 'intro') {
    screen = <Intro board={board} mySeat={room.g.mySeat} remainingMs={room.remainingMs} />
  } else if (room.phase === 'choosing') {
    const onSlot = (s: Slot) => submit(slotKey(s))
    screen = <Draw round={room.round} board={board} players={room.players} mySeat={room.g.mySeat} choice={choice} onSlot={onSlot} onPass={() => submit('pass')} />
  } else {
    screen = <RevealScreen key={reveal?.round ?? 'none'} room={room} reveal={reveal} send={send} />
  }

  let right
  if (room && room.phase !== 'lobby' && room.phase !== 'intro') {
    const chip = <RoundProgress round={room.round} rounds={room.rounds} done={room.phase !== 'choosing'} />
    right = room.phase === 'choosing' ? <>{chip}<Timer remainingMs={room.remainingMs} totalMs={20000} /></> : <>{chip}<span style={{ color: 'var(--lav-dim)' }}>{room.players.length}명</span></>
  }

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={right} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
