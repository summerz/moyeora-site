import { fromB64url } from '@moyeora/shared'

export type Verdict = 'ok' | 'bad' | 'unsupported'

// Local dev server key (LADDER_DEV_KEY=1). Never trusted in a production build.
const DEV_PUBKEY = 'pNaLHFPSERLHlmlNhRLZJd-hqaMUDDeARNSVSRD60Mo'

const publicKey = (): string => import.meta.env.VITE_LADDER_PUBKEY || (import.meta.env.DEV ? DEV_PUBKEY : '')

/** Ed25519 check of the record bytes. No configured key → 'bad' (unverifiable). */
export async function verifyRecord(bytes: Uint8Array, sig: Uint8Array): Promise<Verdict> {
  const pub = publicKey()
  if (!pub) return 'bad'
  const subtle = globalThis.crypto?.subtle
  if (!subtle) return 'unsupported'
  let raw: Uint8Array
  try {
    raw = fromB64url(pub)
  } catch {
    return 'bad'
  }
  try {
    const key = await subtle.importKey('raw', raw.slice(), { name: 'Ed25519' }, false, ['verify'])
    return (await subtle.verify({ name: 'Ed25519' }, key, sig.slice(), bytes.slice())) ? 'ok' : 'bad'
  } catch (e) {
    // Browsers without Ed25519 reject importKey with NotSupportedError.
    return e instanceof DOMException && e.name === 'NotSupportedError' ? 'unsupported' : 'bad'
  }
}
