'use client'
import { useEffect, useEffectEvent, useRef, useState, type ReactNode } from 'react'
import * as THREE from 'three'
import { PLATE, PLATE_FRAME_MS, SNACKS, isPlatePosition, simulatePlate, type PlateBoard, type PlatePosition, type PlateView } from '@moyeora/shared'
import { boom, thud } from '../../ui/sound.ts'
import { snackMesh } from './snacks3D.ts'
import { PlateArt } from './art.tsx'

type Props = { view: PlateView; selected: PlatePosition | null; canPick: boolean; onSelect: (point: PlatePosition) => void; onConfirm: () => void; onInvalid: () => void; children?: ReactNode }
function keyPosition(selected: PlatePosition | null, key: string): PlatePosition {
  const p = selected ?? { x: 0, z: PLATE.slotRadius }
  let angle = Math.atan2(p.x, p.z), radius = Math.hypot(p.x, p.z)
  if (key === 'ArrowLeft') angle -= Math.PI / 16
  if (key === 'ArrowRight') angle += Math.PI / 16
  if (key === 'ArrowUp') radius -= 0.1
  if (key === 'ArrowDown') radius += 0.1
  radius = Math.max(PLATE.placementInner + 0.01, Math.min(PLATE.placementOuter - 0.01, radius))
  return { x: Math.sin(angle) * radius, z: Math.cos(angle) * radius }
}
/** 일반 레이아웃 안의 캔버스. 터치 좌표는 기울어진 접시의 상면으로 투영하고 회전은 로컬에서만 처리한다. */
export function PlateScene({ view, selected, canPick, onSelect, onConfirm, onInvalid, children }: Props) {
  const host = useRef<HTMLDivElement>(null)
  const control = useRef<{ sync: (v: PlateView, selected: PlatePosition | null, canPick: boolean) => void; key: (key: string) => void } | null>(null)
  const initialView = useEffectEvent(() => ({ view, selected, canPick }))
  const select = useEffectEvent((point: PlatePosition) => onSelect(point))
  const confirm = useEffectEvent(() => onConfirm())
  const invalid = useEffectEvent(() => onInvalid())
  const [fallback, setFallback] = useState(false)
  useEffect(() => {
    const el = host.current!
    const initial = initialView()
    let renderer: THREE.WebGLRenderer
    try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true }) } catch { setFallback(true); return }
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFShadowMap
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.domElement.setAttribute('aria-hidden', 'true')
    el.prepend(renderer.domElement)
    const scene = new THREE.Scene()
    const camera = new THREE.OrthographicCamera(-3.6, 3.6, 3.6, -3.6, 0.1, 60)
    let azimuth = 0, elevation = Math.PI * 44 / 180
    const aim = new THREE.Vector3(0, -0.25, 0)
    const positionCamera = () => {
      const radius = 10, horizontal = radius * Math.cos(elevation)
      camera.position.set(Math.sin(azimuth) * horizontal, radius * Math.sin(elevation) - 0.25, Math.cos(azimuth) * horizontal)
      camera.lookAt(aim); camera.updateMatrixWorld(true)
    }
    positionCamera()
    scene.add(new THREE.AmbientLight('#fff3db', 2.2))
    const light = new THREE.DirectionalLight('#ffffff', 3)
    light.position.set(-3, 7, 5); light.castShadow = true
    light.shadow.mapSize.set(512, 512)
    light.shadow.camera.left = light.shadow.camera.bottom = -4
    light.shadow.camera.right = light.shadow.camera.top = 4
    light.shadow.normalBias = 0.035
    scene.add(light)
    const make = (geometry: THREE.BufferGeometry, color: string, parent: THREE.Object3D = scene) => {
      const m = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color, roughness: 0.75 }))
      m.castShadow = true; m.receiveShadow = true; parent.add(m); return m
    }
    const foot = make(new THREE.CylinderGeometry(0.63, 0.8, 0.16, 32), '#6d9993')
    foot.position.y = -1.13
    const stem = make(new THREE.CylinderGeometry(0.24, 0.32, 0.82, 20), '#a7d0c5')
    stem.position.y = -0.64
    const pivot = make(new THREE.SphereGeometry(0.24, 20, 12), '#edbe64')
    pivot.position.y = -0.16
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.ShadowMaterial({ opacity: 0.16 }))
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = -1.22; shadow.receiveShadow = true; scene.add(shadow)
    const plate = new THREE.Group(); scene.add(plate)
    const plateBody = make(new THREE.CylinderGeometry(PLATE.radius, PLATE.radius - 0.12, 0.16, 64), '#fff2d5', plate)
    plateBody.position.y = -0.07
    make(new THREE.CylinderGeometry(2.2, 2.2, 0.02, 64), '#d6e9e5', plate).position.y = 0.02
    const rim = make(new THREE.TorusGeometry(2.4, 0.1, 8, 64), '#84b9af', plate)
    rim.rotation.x = Math.PI / 2; rim.position.y = 0.055
    const edge = make(new THREE.TorusGeometry(2.5, 0.025, 6, 64), '#1b1430', plate)
    edge.rotation.x = Math.PI / 2; edge.position.y = -0.015
    // 빈 원형 접시에서도 카메라가 도는 방향을 알아볼 수 있는 작은 테두리 무늬.
    for (const x of [-0.18, 0, 0.18]) {
      const dot = make(new THREE.CylinderGeometry(0.045, 0.045, 0.012, 12), '#d69e36', plate)
      dot.position.set(x, 0.039, Math.sqrt(2.12 ** 2 - x ** 2))
    }
    const bandMaterial = new THREE.MeshBasicMaterial({ color: '#edbe64', transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false })
    const band = new THREE.Mesh(new THREE.RingGeometry(PLATE.placementInner, PLATE.placementOuter, 96), bandMaterial)
    band.rotation.x = -Math.PI / 2; band.position.y = 0.04; plate.add(band)
    const boundaryMaterial = new THREE.MeshBasicMaterial({ color: '#d69e36', side: THREE.DoubleSide })
    for (const r of [PLATE.placementInner, PLATE.placementOuter]) {
      const line = new THREE.Mesh(new THREE.RingGeometry(r - 0.015, r + 0.015, 96), boundaryMaterial)
      line.rotation.x = -Math.PI / 2; line.position.y = 0.042; plate.add(line)
    }
    let preview: THREE.Group | null = null, previewKind = initial.view.snack
    const items = new Map<number, THREE.Group>()
    const resourceObjects: THREE.Object3D[] = [scene]
    const rm = matchMedia('(prefers-reduced-motion: reduce)')
    let eventId: number | null = null
    let frames: PlateBoard[] | null = null
    let end = initial.view.board
    let t0 = 0, soundDrop = false, soundSpill = false, spillAt: number | null = null
    let raf = 0, dead = false
    let localCanPick = initial.canPick, selectedPoint = initial.selected
    const tourEnd = initial.view.openingMs > 0 ? performance.now() + initial.view.openingMs : 0
    let toured = initial.view.openingMs <= 0, userOrbited = false, rejectUntil = 0
    const ray = new THREE.Raycaster(), pointer = new THREE.Vector2(), normal = new THREE.Vector3()
    let gesture: { id: number; x: number; y: number; lastX: number; lastY: number; dragged: boolean } | null = null
    const draw = (board: PlateBoard, next: PlateBoard = board, alpha = 0) => {
      plate.rotation.set(THREE.MathUtils.lerp(board.tiltX, next.tiltX, alpha), 0, THREE.MathUtils.lerp(board.tiltZ, next.tiltZ, alpha))
      const present = new Set(board.items.map((i) => i.id))
      for (const [id, item] of items) if (!present.has(id)) { plate.remove(item); items.delete(id) }
      for (const [index, data] of board.items.entries()) {
        let item = items.get(data.id)
        if (!item) { item = snackMesh(data.kind); items.set(data.id, item); plate.add(item); resourceObjects.push(item) }
        const after = next.items[index] ?? data
        item.position.set(THREE.MathUtils.lerp(data.x, after.x, alpha), 0.045 + THREE.MathUtils.lerp(data.y, after.y, alpha), THREE.MathUtils.lerp(data.z, after.z, alpha))
        const fall = THREE.MathUtils.lerp(data.fall ?? 0, after.fall ?? 0, alpha)
        item.rotation.set(data.fall === null ? THREE.MathUtils.lerp(data.vz, after.vz, alpha) * 0.09 : fall * 3, data.id * 2.4, data.fall === null ? -THREE.MathUtils.lerp(data.vx, after.vx, alpha) * 0.09 : fall * 2)
      }
      plate.updateMatrixWorld(true)
      renderer.render(scene, camera)
    }
    const frame = () => {
      raf = 0
      if (dead || document.hidden) return
      const now = performance.now()
      const opening = !toured && now < tourEnd
      if (opening && !userOrbited && !rm.matches) {
        const progress = Math.max(0, Math.min(1, 1 - (tourEnd - now) / PLATE.openingMs))
        azimuth = Math.PI * 2 * (progress * progress * (3 - 2 * progress))
        // 높은 시점 → 거의 측면 → 기본 시점. 드래그 가능한 범위를 첫 장면에서 보여준다.
        const stops = [44, 65, 8, 44]
        const leg = Math.min(2, Math.floor(progress * 3))
        const t = progress * 3 - leg, eased = t * t * (3 - 2 * t)
        elevation = Math.PI / 180 * (stops[leg]! + (stops[leg + 1]! - stops[leg]!) * eased)
        positionCamera()
      } else if (!toured && !opening) {
        toured = true
        if (!userOrbited) { azimuth = 0; elevation = Math.PI * 44 / 180; positionCamera() }
      }
      bandMaterial.color.set(now < rejectUntil ? '#ef786f' : '#edbe64')
      const elapsed = now - t0
      const index = Math.max(0, Math.min(frames ? frames.length - 1 : 0, Math.floor(elapsed / PLATE_FRAME_MS)))
      if (frames && !rm.matches && elapsed < PLATE.motionMs) {
        draw(frames[index]!, frames[Math.min(index + 1, frames.length - 1)]!, elapsed / PLATE_FRAME_MS - index)
        if (!soundDrop && elapsed >= PLATE.dropMs) { soundDrop = true; thud() }
        if (!soundSpill && spillAt !== null && elapsed >= spillAt) { soundSpill = true; boom() }
        raf = requestAnimationFrame(frame)
      } else draw(end)
      if ((opening || now < rejectUntil) && !raf) raf = requestAnimationFrame(frame)
    }
    const request = () => { if (!raf && !dead) raf = requestAnimationFrame(frame) }
    const sync = (v: PlateView, selection: PlatePosition | null, allowPick: boolean) => {
      localCanPick = allowPick; selectedPoint = selection
      end = v.board
      if (v.event && v.event.id !== eventId) {
        eventId = v.event.id
        const motion = simulatePlate(v.event.before, v.event.kind, v.event.position, v.event.id)
        frames = motion.frames; spillAt = motion.spillAtMs
        t0 = performance.now() - v.elapsedMs
        soundDrop = v.elapsedMs >= PLATE.dropMs; soundSpill = spillAt !== null && v.elapsedMs >= spillAt
      }
      if (!preview || previewKind !== v.snack) {
        if (preview) plate.remove(preview)
        previewKind = v.snack; preview = snackMesh(v.snack)
        preview.traverse((o) => { if (o instanceof THREE.Mesh) {
          for (const material of Array.isArray(o.material) ? o.material : [o.material]) {
            if (material instanceof THREE.MeshStandardMaterial) material.color.lerp(new THREE.Color('#7750cf'), 0.85)
          }
        } })
        plate.add(preview); resourceObjects.push(preview)
      }
      preview.visible = allowPick && selection !== null
      if (selection) preview.position.set(selection.x, 0.055, selection.z)
      request()
    }
    const fit = () => {
      const { width, height } = el.getBoundingClientRect()
      if (!width || !height) return
      renderer.setSize(width, height)
      const aspect = width / height
      const halfWidth = Math.max(3.25, 2.65 * aspect)
      camera.left = -halfWidth; camera.right = halfWidth
      camera.top = halfWidth / aspect; camera.bottom = -halfWidth / aspect
      camera.updateProjectionMatrix(); request()
    }
    const reject = () => { rejectUntil = performance.now() + 650; invalid(); request() }
    const pick = (x: number, y: number) => {
      if (!localCanPick) return
      const rect = el.getBoundingClientRect()
      pointer.set((x - rect.left) / rect.width * 2 - 1, 1 - (y - rect.top) / rect.height * 2)
      ray.setFromCamera(pointer, camera)
      normal.set(0, 1, 0).transformDirection(plate.matrixWorld)
      if (ray.ray.direction.dot(normal) >= 0) { reject(); return }
      const previewHit = preview?.visible ? ray.intersectObject(preview, true)[0] : undefined
      const hit = ray.intersectObject(band, false)[0]
      const pickedHit = previewHit ?? hit
      if (!pickedHit) { reject(); return }
      // 낮은 시점에서도 접시 옆면·테두리를 뚫고 뒤의 띠를 선택하지 않는다.
      const obstruction = ray.intersectObjects([plateBody, rim, edge], false)[0]
      if (obstruction && obstruction.distance < pickedHit.distance - 0.001) { reject(); return }
      if (previewHit) { confirm(); return }
      if (!hit) { reject(); return }
      const p = plate.worldToLocal(hit.point.clone()), radius = Math.hypot(p.x, p.z)
      // 좌표 반올림 때문에 경계 밖으로 벗어나지 않도록 작은 여유를 둔다.
      const safeRadius = Math.max(PLATE.placementInner + 0.002, Math.min(PLATE.placementOuter - 0.002, radius))
      const position = { x: Math.round(p.x / radius * safeRadius * 1000) / 1000, z: Math.round(p.z / radius * safeRadius * 1000) / 1000 }
      if (!isPlatePosition(position)) { reject(); return }
      if (selectedPoint && Math.hypot(position.x - selectedPoint.x, position.z - selectedPoint.z) <= SNACKS[previewKind].radius + 0.08) confirm()
      else select(position)
    }
    const down = (e: PointerEvent) => {
      if (dead || !e.isPrimary || e.button !== 0 || gesture) return
      gesture = { id: e.pointerId, x: e.clientX, y: e.clientY, lastX: e.clientX, lastY: e.clientY, dragged: false }
      el.setPointerCapture(e.pointerId)
    }
    const move = (e: PointerEvent) => {
      if (dead || !gesture || gesture.id !== e.pointerId) return
      if (Math.hypot(e.clientX - gesture.x, e.clientY - gesture.y) > 7) gesture.dragged = true
      if (gesture.dragged) {
        userOrbited = true
        azimuth -= (e.clientX - gesture.lastX) * 0.012
        elevation = Math.max(Math.PI * 8 / 180, Math.min(Math.PI * 65 / 180, elevation + (e.clientY - gesture.lastY) * 0.008))
        positionCamera(); request()
      }
      gesture.lastX = e.clientX; gesture.lastY = e.clientY
    }
    const up = (e: PointerEvent) => {
      if (dead || !gesture || gesture.id !== e.pointerId) return
      const tapped = !gesture.dragged
      gesture = null
      if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId)
      if (tapped) pick(e.clientX, e.clientY)
    }
    const cancel = () => { gesture = null }
    const key = (key: string) => {
      if (!localCanPick) return
      if ((key === 'Enter' || key === ' ') && selectedPoint) { confirm(); return }
      select(keyPosition(selectedPoint, key))
    }
    el.addEventListener('pointerdown', down); el.addEventListener('pointermove', move)
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', cancel)
    const observer = new ResizeObserver(fit); observer.observe(el)
    const wake = () => request()
    document.addEventListener('visibilitychange', wake)
    rm.addEventListener('change', wake)
    const lost = (e: Event) => { e.preventDefault(); dead = true; cancelAnimationFrame(raf); renderer.domElement.style.display = 'none'; setFallback(true) }
    renderer.domElement.addEventListener('webglcontextlost', lost)
    control.current = { sync, key }; fit(); sync(initial.view, initial.selected, initial.canPick)
    return () => {
      dead = true; control.current = null; cancelAnimationFrame(raf); observer.disconnect()
      document.removeEventListener('visibilitychange', wake); rm.removeEventListener('change', wake)
      el.removeEventListener('pointerdown', down); el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', cancel)
      renderer.domElement.removeEventListener('webglcontextlost', lost)
      const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>()
      for (const root of resourceObjects) root.traverse((o) => { if (o instanceof THREE.Mesh) { geometries.add(o.geometry); for (const m of Array.isArray(o.material) ? o.material : [o.material]) materials.add(m) } })
      materials.delete(bandMaterial); materials.delete(boundaryMaterial)
      bandMaterial.dispose(); boundaryMaterial.dispose()
      for (const g of geometries) g.dispose(); for (const m of materials) m.dispose()
      renderer.dispose(); renderer.domElement.remove()
    }
  }, [])
  useEffect(() => { control.current?.sync(view, selected, canPick) }, [view, selected, canPick])
  return <div className="plate-scene" ref={host} role={canPick ? 'button' : 'img'} tabIndex={canPick ? 0 : -1}
    aria-label={canPick ? '접시 위치 선택. 띠를 터치해 고르고 같은 곳을 한 번 더 눌러 놓아요. 방향키로 고르고 Enter로 놓을 수도 있어요. 드래그하면 회전합니다.' : `기울어진 접시에 간식 ${view.board.items.filter((i) => i.fall === null).length}개. 드래그하면 회전합니다.`}
    onKeyDown={(e) => { if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter', ' '].includes(e.key)) {
      e.preventDefault()
      if (fallback && canPick) {
        if ((e.key === 'Enter' || e.key === ' ') && selected) onConfirm()
        else onSelect(keyPosition(selected, e.key))
      }
      else control.current?.key(e.key)
    } }}>
    {fallback && <PlateArt board={view.board} placement selected={canPick ? selected : null} selectedKind={view.snack} fit onConfirm={onConfirm} onSelect={canPick ? onSelect : undefined} onInvalid={onInvalid} />}
    <span className="plate-orbit-hint" aria-hidden="true">{fallback ? '표시된 띠를 터치해요' : '드래그로 돌려봐요'}</span>
    {children}
  </div>
}
