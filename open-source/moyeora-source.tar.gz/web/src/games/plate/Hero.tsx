import { PlateArt } from './art.tsx'
export function Hero({ size = 180 }: { size?: number }) {
  return <div className="plate-hero" style={{ width: size, margin: '0 auto' }}><PlateArt animate /></div>
}
