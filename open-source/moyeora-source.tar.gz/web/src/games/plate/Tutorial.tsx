import { Tutorial as SharedTutorial } from '../../ui/Tutorial.tsx'
import { PlateArt } from './art.tsx'
export function Tutorial({ onClose }: { onClose: () => void }) {
  return <SharedTutorial onClose={onClose} pages={[
    { title: '고르고, 한 번 더 터치!', art: <PlateArt placement selected={{ x: 0, z: 1.55 }} selectedKind="macaron" />, line: <>드래그해서 접시를 돌려봐요.<br />띠 안에서 고르고, 간식을 다시 눌러 놓아요!</> },
    { title: '반대쪽으로 균형 잡기', art: <PlateArt mode="balance" />, line: <>한쪽이 무거우면 기우뚱!<br />반대쪽에 놓고, 꽉 찬 곳은 피하세요.</> },
    { title: '와르르! 떨어뜨리면 벌칙', art: <PlateArt mode="spill" />, line: <>간식을 떨어뜨린 사람이 져요.<br />20초 안에 안 고르면 자동으로 놓아요.</> },
  ]} />
}
