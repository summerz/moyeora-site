import { useState } from 'react'
import { createRoot } from 'react-dom/client'
import type { PlateRoom, ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { Shell } from '../../ui/Shell.tsx'
import { useSocket } from '../../ws.ts'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { Tutorial } from './Tutorial.tsx'
import './plate.css'

const TUT_KEY = 'moyeora:plate:tutorial'
const tutorialSeen = () => { try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false } }
function App() {
  const [tutorial, setTutorial] = useState(false)
  const [seen, setSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<PlateRoom | null>(null)
  const [error, setError] = useState<string>()
  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room' && m.room.game === 'plate') { setRoom(m.room); setError(undefined) }
    else if (m.type === 'error') setError(errorText(m.message))
  }
  const send = useSocket(onMessage, () => { setRoom(null); setError('연결이 끊겼어요') })
  let screen
  if (!profile || editing) screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  else if (!room) screen = <Join game="plate" profile={profile} error={error} onEdit={() => setEditing(true)} onCreate={() => send({ type: 'create', game: 'plate', ...profile })} onJoin={(code) => send({ type: 'join', code, ...profile })} />
  else if (room.phase === 'lobby') screen = <Lobby room={room} hero={<Hero size={room.players.length>4 ? 140 : 190} />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}>{error && <div role="alert">{error}</div>}</Lobby>
  else screen = <Play room={room} error={error} onPick={(position) => send({ type: 'submit', choice: JSON.stringify(position) })} onLobby={() => send({ type: 'lobby' })} />
  const closeTutorial = () => { try { localStorage.setItem(TUT_KEY, '1') } catch { /* 저장 불가 */ }; setSeen(true); setTutorial(false) }
  return <Shell fit={!!room && room.phase !== 'lobby' && room.phase !== 'intro'} safe={!room || room.phase === 'lobby' || room.phase === 'done'} confirmHome={!!room} onHelp={() => setTutorial(true)} onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined}>
    {screen}
    {(tutorial || (!!room && room.phase === 'lobby' && !seen)) && <Tutorial onClose={closeTutorial} />}
  </Shell>
}
createRoot(document.getElementById('root')!).render(<App />)
