import * as THREE from 'three'
import { SNACKS, type SnackKind } from '@moyeora/shared'

const material = (color: string) => new THREE.MeshStandardMaterial({ color, roughness: 0.8 })
/** 텍스처 없이 만드는 작은 장난감 간식. 그림과 실제 무게 표시는 같은 종류를 쓴다. */
export function snackMesh(kind: SnackKind): THREE.Group {
  const group = new THREE.Group()
  const add = (geometry: THREE.BufferGeometry, color: string, x = 0, y = 0, z = 0) => {
    const mesh = new THREE.Mesh(geometry, material(color))
    mesh.position.set(x, y, z)
    mesh.castShadow = true; mesh.receiveShadow = true
    group.add(mesh)
    return mesh
  }
  const brown = '#8b553e'
  if (kind === 'cookie') {
    add(new THREE.CylinderGeometry(0.32, 0.32, 0.15, 24), SNACKS.cookie.color, 0, 0.085)
    for (let i = 0; i < 7; i++) {
      const angle = i * 2.4, radius = i === 0 ? 0 : 0.17
      add(new THREE.SphereGeometry(0.042, 7, 5), brown, Math.sin(angle) * radius, 0.166, Math.cos(angle) * radius).scale.y = 0.4
    }
  } else if (kind === 'donut') {
    add(new THREE.TorusGeometry(0.25, 0.12, 10, 28), '#dba267', 0, 0.13).rotation.x = Math.PI / 2
    add(new THREE.TorusGeometry(0.25, 0.085, 10, 28), SNACKS.donut.color, 0, 0.21).rotation.x = Math.PI / 2
    for (let i = 0; i < 12; i++) {
      const angle = i * Math.PI / 6
      const sprinkle = add(new THREE.CapsuleGeometry(0.012, 0.046, 2, 4), i % 2 ? '#fff5d8' : '#649b96', Math.sin(angle) * 0.26, 0.292, Math.cos(angle) * 0.26)
      sprinkle.rotation.set(Math.PI / 2, 0, angle)
    }
  } else if (kind === 'pudding') {
    add(new THREE.CylinderGeometry(0.25, 0.34, 0.45, 24), SNACKS.pudding.color, 0, 0.235)
    add(new THREE.CylinderGeometry(0.255, 0.265, 0.07, 24), brown, 0, 0.48)
    add(new THREE.SphereGeometry(0.095, 12, 8), '#fff7df', 0, 0.56).scale.y = 0.65
    add(new THREE.SphereGeometry(0.045, 10, 8), '#ed786f', 0, 0.64)
  } else if (kind === 'melon') {
    const shape = new THREE.Shape().moveTo(-0.36, 0.06).lineTo(0.36, 0.06).lineTo(0, 0.62).closePath()
    const slice = add(new THREE.ExtrudeGeometry(shape, { depth: 0.22, bevelEnabled: true, bevelSize: 0.015, bevelThickness: 0.015, bevelSegments: 1, steps: 1 }), SNACKS.melon.color, 0, 0, -0.11)
    slice.receiveShadow = true
    add(new THREE.BoxGeometry(0.73, 0.075, 0.26), '#80b58e', 0, 0.04)
    for (const z of [-0.135, 0.135]) for (let i = 0; i < 3; i++) {
      const seed = add(new THREE.SphereGeometry(0.025, 8, 6), '#352a31', (i - 1) * 0.12, i === 1 ? 0.43 : 0.25, z)
      seed.scale.set(0.65, 1.3, 0.5)
    }
  } else if (kind === 'macaron') {
    add(new THREE.CylinderGeometry(0.29, 0.29, 0.07, 24), '#fff7df', 0, 0.15)
    for (const y of [0.08, 0.23]) {
      add(new THREE.SphereGeometry(0.3, 20, 12), SNACKS.macaron.color, 0, y).scale.y = 0.3
      add(new THREE.TorusGeometry(0.265, 0.025, 6, 24), '#8d77c2', 0, y + (y < 0.15 ? 0.025 : -0.025)).rotation.x = Math.PI / 2
    }
  } else if (kind === 'strawberry') {
    const outline = [new THREE.Vector2(0, 0), new THREE.Vector2(0.08, 0.04), new THREE.Vector2(0.2, 0.17), new THREE.Vector2(0.27, 0.34), new THREE.Vector2(0.24, 0.45), new THREE.Vector2(0.12, 0.49), new THREE.Vector2(0, 0.5)]
    add(new THREE.LatheGeometry(outline, 24), SNACKS.strawberry.color)
    for (let i = 0; i < 12; i++) {
      const angle = i * 2.4, y = i % 2 ? 0.2 : 0.37, radius = i % 2 ? 0.223 : 0.267
      const seed = add(new THREE.SphereGeometry(0.017, 6, 4), '#ffe295', Math.sin(angle) * radius, y, Math.cos(angle) * radius)
      seed.scale.y = 1.6
    }
    for (let i = 0; i < 5; i++) {
      const angle = i * Math.PI * 2 / 5
      const leaf = add(new THREE.SphereGeometry(0.1, 8, 6), '#649b70', Math.sin(angle) * 0.09, 0.49, Math.cos(angle) * 0.09)
      leaf.scale.set(0.5, 0.18, 1.2); leaf.rotation.y = angle
    }
  } else if (kind === 'cake') {
    for (let i = 0; i < 5; i++) add(new THREE.BoxGeometry(0.5, 0.09, 0.52), i % 2 ? '#fff7df' : '#dba267', 0, 0.055 + i * 0.09)
    add(new THREE.BoxGeometry(0.52, 0.07, 0.54), SNACKS.cake.color, 0, 0.49)
    add(new THREE.SphereGeometry(0.1, 12, 8), '#fff7df', 0, 0.56).scale.y = 0.75
    add(new THREE.SphereGeometry(0.075, 10, 8), '#e96a72', 0, 0.65)
  } else if (kind === 'sandwich') {
    const triangle = new THREE.Shape().moveTo(-0.31, -0.26).lineTo(0.31, -0.26).lineTo(0, 0.34).closePath()
    for (let i = 0; i < 5; i++) {
      const slice = add(new THREE.ExtrudeGeometry(triangle, { depth: i === 0 || i === 4 ? 0.1 : 0.04, bevelEnabled: false }), ['#e4b77e', '#80b58e', '#ef786f', '#ffe295', '#e4b77e'][i]!, 0, [0.01, 0.11, 0.15, 0.19, 0.23][i]!)
      slice.rotation.x = -Math.PI / 2
    }
  } else if (kind === 'waffle') {
    add(new THREE.BoxGeometry(0.52, 0.1, 0.52), '#ba7e50', 0, 0.06)
    for (let x = -1; x <= 1; x++) for (let z = -1; z <= 1; z++) {
      add(new THREE.BoxGeometry(0.13, 0.035, 0.13), '#edbe64', x * 0.17, 0.122, z * 0.17)
    }
    add(new THREE.BoxGeometry(0.1, 0.035, 0.09), '#fff0a7', 0.06, 0.156, -0.05).rotation.y = 0.3
  } else if (kind === 'pretzel') {
    const path = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.19, 0.12, 0.2), new THREE.Vector3(0.25, 0.12, -0.05),
      new THREE.Vector3(0.22, 0.12, -0.24), new THREE.Vector3(0.03, 0.12, -0.19),
      new THREE.Vector3(-0.25, 0.17, 0.08), new THREE.Vector3(-0.24, 0.12, -0.21),
      new THREE.Vector3(-0.06, 0.12, -0.25), new THREE.Vector3(0.2, 0.12, 0.2),
    ])
    add(new THREE.TubeGeometry(path, 32, 0.065, 7, false), '#bf7e45')
    for (const [x, z] of [[-0.19, -0.18], [0.18, -0.14], [0.04, -0.17], [-0.08, 0.05], [0.1, 0.12]]) {
      add(new THREE.BoxGeometry(0.025, 0.015, 0.025), '#fff7df', x, 0.186, z)
    }
  } else if (kind === 'croissant') {
    const arc = add(new THREE.TorusGeometry(0.21, 0.1, 10, 24, Math.PI * 1.35), '#dba267', 0, 0.13)
    arc.rotation.x = Math.PI / 2; arc.rotation.z = -Math.PI * 0.175
    for (let i = 0; i < 5; i++) {
      const angle = -Math.PI * 0.175 + (i + 0.5) * Math.PI * 1.35 / 5
      const ridge = add(new THREE.SphereGeometry(0.115, 10, 7), i % 2 ? '#edbe64' : '#e4ad68', Math.cos(angle) * 0.21, 0.13, Math.sin(angle) * 0.21)
      ridge.scale.set(0.65, 1, 1); ridge.rotation.y = -angle
    }
  } else if (kind === 'rollcake') {
    add(new THREE.CylinderGeometry(0.31, 0.31, 0.42, 24), '#edbe64', 0, 0.32).rotation.x = Math.PI / 2
    for (const z of [-0.215, 0.215]) {
      add(new THREE.CircleGeometry(0.26, 24), '#fff7df', 0, 0.32, z).rotation.y = z < 0 ? Math.PI : 0
      const points = Array.from({ length: 40 }, (_, i) => {
        const angle = i / 39 * Math.PI * 4, r = 0.02 + i / 39 * 0.19
        return new THREE.Vector3(Math.cos(angle) * r, 0.32 + Math.sin(angle) * r, z + Math.sign(z) * 0.003)
      })
      add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 40, 0.018, 5, false), '#dba267')
    }
  } else if (kind === 'cupcake') {
    add(new THREE.CylinderGeometry(0.3, 0.22, 0.3, 12), '#f4a5b8', 0, 0.16)
    for (let i = 0; i < 12; i++) {
      const angle = i * Math.PI / 6
      add(new THREE.CapsuleGeometry(0.014, 0.22, 2, 4), '#d87a99', Math.sin(angle) * 0.264, 0.16, Math.cos(angle) * 0.264)
    }
    for (let i = 0; i < 3; i++) {
      add(new THREE.SphereGeometry(0.29 - i * 0.075, 16, 10), '#fff7df', 0, 0.33 + i * 0.12).scale.y = 0.55
    }
    add(new THREE.SphereGeometry(0.055, 10, 8), '#e96a72', 0, 0.66)
  } else if (kind === 'chocolate') {
    add(new THREE.BoxGeometry(0.48, 0.055, 0.5), '#583b36', 0, 0.04)
    for (let x = -1; x <= 1; x++) for (let z = -1; z <= 1; z++) {
      add(new THREE.BoxGeometry(0.14, 0.055, 0.145), '#805644', x * 0.158, 0.09, z * 0.165)
    }
  } else if (kind === 'icecream') {
    add(new THREE.CylinderGeometry(0.2, 0.035, 0.5, 16), '#dba267', 0, 0.26)
    for (let i = 0; i < 3; i++) {
      add(new THREE.TorusGeometry(0.075 + i * 0.045, 0.013, 5, 16), '#ba7e50', 0, 0.13 + i * 0.12).rotation.x = Math.PI / 2
    }
    add(new THREE.SphereGeometry(0.27, 20, 12), '#a4d2b1', 0, 0.61)
    for (let i = 0; i < 6; i++) {
      const angle = i * Math.PI / 3
      add(new THREE.SphereGeometry(0.07, 8, 6), '#a4d2b1', Math.sin(angle) * 0.2, 0.5, Math.cos(angle) * 0.2)
    }
    for (const [x, y, z] of [[0, 0.86, 0], [0.17, 0.74, 0.14], [-0.18, 0.7, 0.16]]) {
      add(new THREE.SphereGeometry(0.025, 7, 5), '#805644', x, y, z)
    }
  } else if (kind === 'bungeoppang') {
    const fish = new THREE.Shape().moveTo(-0.23, 0.04)
      .lineTo(-0.39, 0.16).lineTo(-0.36, 0).lineTo(-0.39, -0.16).lineTo(-0.23, -0.04)
      .quadraticCurveTo(-0.13, -0.19, 0.06, -0.18)
      .quadraticCurveTo(0.25, -0.18, 0.34, -0.04).lineTo(0.32, 0).lineTo(0.34, 0.04)
      .quadraticCurveTo(0.25, 0.18, 0.06, 0.18)
      .lineTo(-0.03, 0.23).lineTo(-0.08, 0.17)
      .quadraticCurveTo(-0.18, 0.15, -0.23, 0.04).closePath()
    const bread = add(new THREE.ExtrudeGeometry(fish, { depth: 0.09, bevelEnabled: true, bevelSize: 0.015, bevelThickness: 0.015, bevelSegments: 2, steps: 1 }), SNACKS.bungeoppang.color, 0, 0.025)
    bread.rotation.x = -Math.PI / 2
    const emboss = (points: number[][]) => add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(([x, z]) => new THREE.Vector3(x, 0.134, z))), 12, 0.009, 5, false), '#a56b3e')
    add(new THREE.SphereGeometry(0.021, 10, 6), '#80503a', 0.22, 0.137, -0.05).scale.y = 0.4
    emboss([[0.13, -0.12], [0.1, 0], [0.13, 0.12]])
    emboss([[0.27, 0.05], [0.31, 0.04]])
    for (const x of [-0.14, -0.04, 0.06]) for (const z of [-0.055, 0.055]) {
      emboss([[x - 0.025, z - 0.035], [x + 0.012, z], [x - 0.025, z + 0.035]])
    }
    for (const z of [-0.085, 0.085]) emboss([[-0.25, 0], [-0.34, z]])
  } else if (kind === 'orange') {
    add(new THREE.SphereGeometry(0.31, 20, 12), '#f5a147', 0, 0.3).scale.y = 0.95
    add(new THREE.CylinderGeometry(0.025, 0.025, 0.08, 7), '#805644', 0, 0.61)
    const leaf = add(new THREE.SphereGeometry(0.13, 10, 7), '#649b70', 0.08, 0.6, 0)
    leaf.scale.set(1, 0.12, 0.45); leaf.rotation.z = -0.2
  } else if (kind === 'pizza') {
    const triangle = new THREE.Shape().moveTo(-0.32, -0.27).lineTo(0.32, -0.27).lineTo(0, 0.33).closePath()
    for (let i = 0; i < 2; i++) {
      const slice = add(new THREE.ExtrudeGeometry(triangle, { depth: i ? 0.025 : 0.07, bevelEnabled: false }), i ? '#ffe295' : '#dba267', 0, i ? 0.09 : 0.01)
      slice.rotation.x = -Math.PI / 2
    }
    add(new THREE.CapsuleGeometry(0.065, 0.54, 3, 8), '#dba267', 0, 0.1, 0.27).rotation.z = Math.PI / 2
    for (const [x, z] of [[-0.13, 0.13], [0.12, 0.1], [0, -0.12]]) {
      add(new THREE.CylinderGeometry(0.065, 0.065, 0.02, 12), '#d86b60', x, 0.126, z)
    }
  } else if (kind === 'hotdog') {
    for (const z of [-0.1, 0.1]) {
      const bun = add(new THREE.CapsuleGeometry(0.105, 0.52, 4, 12), '#e4ad68', 0, 0.12, z)
      bun.rotation.z = Math.PI / 2
    }
    add(new THREE.CapsuleGeometry(0.075, 0.59, 4, 12), '#d86b60', 0, 0.23).rotation.z = Math.PI / 2
    const mustard = Array.from({ length: 17 }, (_, i) => new THREE.Vector3(-0.26 + i / 16 * 0.52, 0.307, Math.sin(i * Math.PI / 2) * 0.035))
    add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(mustard), 24, 0.013, 5, false), '#ffe295')
  } else if (kind === 'onigiri') {
    const triangle = new THREE.Shape().moveTo(-0.3, 0.04).lineTo(0.3, 0.04).lineTo(0, 0.6).closePath()
    add(new THREE.ExtrudeGeometry(triangle, { depth: 0.22, bevelEnabled: true, bevelSize: 0.04, bevelThickness: 0.025, bevelSegments: 2, steps: 1 }), '#fff7df', 0, 0, -0.11)
    add(new THREE.BoxGeometry(0.23, 0.27, 0.275), '#42554a', 0, 0.145)
  }
  if (kind === 'icecream' || kind === 'strawberry') {
    // 바깥 그룹은 접시 위 방향·흔들림에 사용하므로 기본 자세는 안쪽 모델에 적용한다.
    group.rotation.z = kind === 'icecream' ? -Math.PI * 3 / 8 : -Math.PI * 0.3
    const bounds = new THREE.Box3().setFromObject(group)
    group.position.set(-(bounds.min.x + bounds.max.x) / 2, 0.01 - bounds.min.y, -(bounds.min.z + bounds.max.z) / 2)
    const resting = new THREE.Group()
    resting.add(group)
    return resting
  }
  return group
}
