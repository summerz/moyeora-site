import { useEffect, useId, useRef, type ReactNode } from 'react'
import { emptyPlate, isPlatePosition, PLATE, SNACKS, type PlateBoard, type PlatePosition, type SnackKind } from '@moyeora/shared'

export function SnackArt({ kind }: { kind: SnackKind }) {
  return <svg viewBox="-24 -30 48 48" width="52" height="52" aria-hidden="true" fill="none" stroke="#1b1430" strokeWidth="2" strokeLinejoin="round">
    <SnackDrawing kind={kind} />
  </svg>
}
const snackDrawings: Record<SnackKind, ReactNode> = {
  cookie: <><ellipse cy="3" rx="19" ry="12" fill="#ba7e50" /><ellipse rx="19" ry="12" fill="#dba267" />{[[-9, -3], [6, -6], [12, 2], [-3, 5]].map(([x,y],i) => <circle key={i} cx={x} cy={y} r="2.3" fill="#70503e" stroke="none" />)}</>,
  donut: <><ellipse cy="4" rx="20" ry="12" fill="#dba267" /><ellipse rx="20" ry="12" fill="#f4a5b8" /><ellipse rx="6" ry="4" fill="#dba267" /><path d="M-13 -4l3 2M8 -6l2 3M-8 5l3-1M10 4l3-1" stroke="#fff7df" strokeWidth="3" /></>,
  pudding: <><path d="M-13 -15L-18 7Q0 21 18 7L13 -15Z" fill="#ffe295" /><ellipse cy="-15" rx="13" ry="7" fill="#8b553e" /><ellipse cy="-21" rx="6" ry="4" fill="#fff7df" /><circle cy="-26" r="3" fill="#ed786f" /></>,
  melon: <><path d="M-19 8L0-24L19 8Q0 21-19 8Z" fill="#ef786f" /><path d="M-19 8Q0 21 19 8L19 14Q0 28-19 14Z" fill="#80b58e" /><path d="M-5-3l-1 3M5-3l1 3M0-12v3" strokeWidth="3" strokeLinecap="round" /></>,
  macaron: <><ellipse cy="6" rx="18" ry="10" fill="#ad97e2" /><path d="M-18-1V5Q0 15 18 5V-1Z" fill="#fff7df" /><ellipse cy="-3" rx="18" ry="10" fill="#ad97e2" /><path d="M-15 0Q0 7 15 0" stroke="#8d77c2" /></>,
  strawberry: <g transform="translate(0 -3) rotate(54) scale(.85)"><path d="M-16-9Q-19 2 0 17Q19 2 16-9Q11-20 0-15Q-11-20-16-9Z" fill="#e96a72" /><path d="M0-16L-13-21L-6-12L0-16L7-11L13-21Z" fill="#649b70" /><path d="M-9-4v2M6-5v2M0 5v2M-1-9v2" stroke="#ffe295" strokeLinecap="round" /></g>,
  cake: <><path d="M-16-11L0-17L17-9V10L0 17L-16 10Z" fill="#dba267" /><path d="M-16-3L0 4L17-3V2L0 9L-16 2Z" fill="#fff7df" /><path d="M-16-11L0-17L17-9L0-2Z" fill="#fff1d5" /><ellipse cy="-15" rx="7" ry="4" fill="#fff7df" /><circle cy="-21" r="4" fill="#e96a72" /></>,
  sandwich: <><path d="M-20 5L-2-17L20 7L-1 16Z" fill="#e4b77e" /><path d="M-19 1L-1-20L20 3L-1 12Z" fill="#80b58e" /><path d="M-19-2L-1-23L20 0L-1 9Z" fill="#ffe295" /><path d="M-20-5L-2-26L20-3L-1 6Z" fill="#fff1d5" /></>,
  waffle: <><path d="M-19-15H19V12H-19Z" fill="#ba7e50" /><path d="M-19-19H19V8H-19Z" fill="#edbe64" />{[-12,0,12].flatMap((x) => [-13,-3].map((y) => <rect key={`${x}/${y}`} x={x-4} y={y-3} width="8" height="6" rx="1" fill="#dba267" strokeWidth="1" />))}<path d="M-5-10H5V-3H-5Z" fill="#ffe295" /></>,
  pretzel: <><path d="M-7 11C-33-1-12-27 0-9C12-27 33-1 7 11L-11-11M-7 11L11-11" stroke="#805644" strokeWidth="9" strokeLinecap="round" /><path d="M-7 11C-33-1-12-27 0-9C12-27 33-1 7 11L-11-11M-7 11L11-11" stroke="#dba267" strokeWidth="5" strokeLinecap="round" /><path d="M-15-5h2M12-5h2M0-9h2M-5 5h2M6 4h2" stroke="#fff7df" /></>,
  croissant: <><path d="M-21-3Q-13-24 3-17Q19-16 21 1L13 9Q10-3 1-4Q-9-7-13 8Z" fill="#edbe64" /><path d="M-13-13L-8 1M-3-18L-1-5M7-15L4-3M15-10L10 1" stroke="#ba7e50" /></>,
  rollcake: <><path d="M-17-13L3-22Q23-24 22-4L4 9Z" fill="#edbe64" /><ellipse cx="-4" cy="-2" rx="14" ry="17" fill="#fff7df" /><path d="M-5 10C-21 8-15-17-2-13C10-9 4 5-3 4C-10 3-7-7-2-5" stroke="#dba267" strokeWidth="3" /></>,
  cupcake: <><path d="M-16-3L-11 15H11L16-3Z" fill="#f4a5b8" /><path d="M-9 0L-6 12M0 0V12M9 0L6 12" stroke="#d87a99" /><path d="M-17-4Q-21-13-10-14Q-15-22-4-23Q1-30 7-22Q17-21 12-14Q23-11 17-4Z" fill="#fff7df" /><circle cy="-25" r="3" fill="#e96a72" /></>,
  chocolate: <><path d="M-19-15H19V13H-19Z" fill="#583b36" /><path d="M-19-19H19V9H-19Z" fill="#805644" /><path d="M-6-19V9M6-19V9M-19-10H19M-19 0H19" stroke="#583b36" /></>,
  icecream: <g transform="translate(3 -5) rotate(78) scale(.85)"><path d="M-12-7L0 17L12-7Z" fill="#dba267" /><path d="M-8-4L4 8M-3-5L7 5M8-4L-4 8M3-5L-7 5" stroke="#ba7e50" strokeWidth="1" /><path d="M-15-8Q-20-20-10-24Q0-33 10-24Q20-20 15-8Q10-3 5-7Q0-2-5-7Q-10-3-15-8Z" fill="#a4d2b1" /><path d="M-8-18l2 1M5-21l2 1M3-13l2 1" stroke="#805644" /></g>,
  bungeoppang: <><path d="M-13-7L-22-15L-20-6L-22 3L-13-3Q-7 9 7 5Q16 4 20-5L18-7L20-9Q16-19 3-18L-2-22L-5-17Q-11-16-13-7Z" fill="#dba267" /><path d="M7-16Q3-7 7 3M16-4H19M-20-12L-14-6L-20 0M-10-12L-7-9L-10-6M-3-13L0-10L-3-7M-10-3L-7 0M-3-4L0-1" stroke="#a56b3e" strokeWidth="1.5" /><circle cx="13" cy="-12" r="1.7" fill="#80503a" stroke="none" /></>,
  orange: <><ellipse cy="-2" rx="18" ry="18" fill="#f5a147" /><path d="M0-20V-25" stroke="#805644" /><path d="M0-22Q5-30 14-24Q9-16 0-22Z" fill="#649b70" /><path d="M-10-8v1M8-3v1M-4 6v1" stroke="#edbe64" strokeLinecap="round" /></>,
  pizza: <><path d="M-20-17H20L0 17Z" fill="#dba267" /><path d="M-17-15H17L0 12Z" fill="#ffe295" /><path d="M-18-16H18" stroke="#dba267" strokeWidth="7" strokeLinecap="round" /><circle cx="-7" cy="-7" r="4" fill="#d86b60" /><circle cx="7" cy="-7" r="4" fill="#d86b60" /><circle cy="4" r="3" fill="#d86b60" /></>,
  hotdog: <><rect x="-21" y="-12" width="42" height="23" rx="10" fill="#e4ad68" /><rect x="-21" y="-9" width="42" height="11" rx="5" fill="#d86b60" /><path d="M-14-4L-10-7L-6-1L-2-7L2-1L6-7L10-1L14-4" stroke="#ffe295" strokeWidth="3" strokeLinecap="round" /></>,
  onigiri: <><path d="M-19 12Q-23 9-19 3L-4-23Q0-29 4-23L19 3Q23 9 19 12Z" fill="#fff7df" /><path d="M-7-1H7V13H-7Z" fill="#42554a" /><path d="M-13 3l1-2M9 0l1 2M-3-14l1-2" stroke="#e5d8bf" /></>,
}
function SnackDrawing({ kind }: { kind: SnackKind }) { return snackDrawings[kind] }
const sample: PlateBoard = { ...emptyPlate(), tiltZ: -0.05, items: [
  { id: 1, kind: 'cookie', x: -1, z: -0.9, y: 0, vx: 0, vz: 0, fall: null },
  { id: 2, kind: 'donut', x: 1.15, z: -0.45, y: 0, vx: 0, vz: 0, fall: null },
  { id: 3, kind: 'pudding', x: -0.5, z: 0.9, y: 0, vx: 0, vz: 0, fall: null },
  { id: 4, kind: 'melon', x: 1.25, z: 1.1, y: 0, vx: 0, vz: 0, fall: null },
] }
export function PlateArt({ board = sample, placement = false, selected = null, selectedKind = 'donut', onSelect, onConfirm, onInvalid, mode = 'normal', fit = false, animate = false }: { board?: PlateBoard; placement?: boolean; selected?: PlatePosition | null; selectedKind?: SnackKind; onSelect?: (point: PlatePosition) => void; onConfirm?: () => void; onInvalid?: () => void; mode?: 'normal' | 'balance' | 'spill'; fit?: boolean; animate?: boolean }) {
  const surface = useRef<SVGGElement>(null)
  const snacks = useRef<SVGGElement>(null)
  const rim = useRef<SVGGElement>(null)
  const previewTint = useId()
  useEffect(() => {
    if (!animate || !surface.current || !snacks.current) return
    const plate = surface.current
    const foodLayer = snacks.current
    const marks = rim.current
    const motion = matchMedia('(prefers-reduced-motion: reduce)')
    const items = [...board.items].filter((item) => item.y > -2).sort((a, b) => a.z - b.z)
    const drawings = items.map((item, index) => ({ item, element: foodLayer.children[index] as SVGGElement }))
    let frame = 0
    let elapsed = 0
    let previous = 0
    let visible = true
    let order = items.map((item) => item.id).join(',')
    // Rotate positions in the plate's plane; the stand and upright food drawings stay upright.
    const draw = (angle: number) => {
      const cosine = Math.cos(angle)
      const sine = Math.sin(angle)
      plate.setAttribute('transform', `rotate(${board.tiltZ * 35 + sine * 3} 130 90)`)
      marks?.setAttribute('transform', `rotate(${angle * 180 / Math.PI})`)
      const depths = drawings.map(({ item, element }) => {
        const x = item.x * cosine - item.z * sine
        const z = item.x * sine + item.z * cosine
        element.setAttribute('transform', `translate(${130 + x * 35},${88 + z * 21 - item.y * 30}) scale(.75)`)
        return { id: item.id, z, element }
      }).sort((a, b) => a.z - b.z)
      const nextOrder = depths.map((item) => item.id).join(',')
      if (order !== nextOrder) {
        depths.forEach(({ element }) => foodLayer.appendChild(element))
        order = nextOrder
      }
    }
    const tick = (now: number) => {
      if (previous) elapsed += now - previous
      previous = now
      draw(elapsed / 8000 * Math.PI * 2)
      frame = requestAnimationFrame(tick)
    }
    const update = () => {
      cancelAnimationFrame(frame)
      previous = 0
      if (motion.matches) {
        elapsed = 0
        draw(0)
      } else if (visible && !document.hidden) frame = requestAnimationFrame(tick)
    }
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting
      update()
    })
    observer.observe(plate.ownerSVGElement!)
    motion.addEventListener('change', update)
    document.addEventListener('visibilitychange', update)
    update()
    return () => {
      cancelAnimationFrame(frame)
      observer.disconnect()
      motion.removeEventListener('change', update)
      document.removeEventListener('visibilitychange', update)
      draw(0)
    }
  }, [animate, board])
  return <svg className="plate-art" style={{ width: '100%', height: fit ? '100%' : 'auto', display: 'block' }} viewBox="0 0 260 190" role="img" aria-label="받침 위에서 기우뚱하는 간식 접시" fill="none" stroke="#1b1430" strokeWidth="2.5" strokeLinejoin="round" onPointerUp={onSelect ? (e) => {
      if (e.target instanceof Element && e.target.closest('[data-preview]')) { onConfirm?.(); return }
      const matrix = surface.current?.getScreenCTM()
      if (!matrix) return
      const point = new DOMPoint(e.clientX, e.clientY).matrixTransform(matrix.inverse())
      const position = { x: (point.x - 130) / 35, z: (point.y - 88) / 21 }
      if (!isPlatePosition(position)) { onInvalid?.(); return }
      if (selected && Math.hypot(position.x - selected.x, position.z - selected.z) <= SNACKS[selectedKind].radius + 0.08) onConfirm?.()
      else onSelect(position)
    } : undefined}>
    <defs><filter id={previewTint} colorInterpolationFilters="sRGB"><feColorMatrix type="matrix" values=".15 0 0 0 .397 0 .15 0 0 .267 0 0 .15 0 .69 0 0 0 1 0" /></filter></defs>
    <ellipse cx="130" cy="173" rx="61" ry="9" fill="#1b1430" opacity=".12" stroke="none" />
    <ellipse cx="130" cy="165" rx="25" ry="9" fill="#6d9993" />
    <path d="M121 105L118 161Q130 169 142 161L139 105Z" fill="#a7d0c5" />
    <circle cx="130" cy="108" r="9" fill="#edbe64" />
    <g ref={surface} transform={`rotate(${mode === 'spill' ? 16 : board.tiltZ * 35} 130 90)`}>
      <ellipse cx="130" cy="94" rx="99" ry="58" fill="#84b9af" />
      <ellipse cx="130" cy="88" rx="99" ry="58" fill="#fff2d5" />
      <ellipse cx="130" cy="88" rx="87" ry="48" fill="#d6e9e5" stroke="#84b9af" strokeWidth="5" />
      {animate && <g transform="translate(130 88) scale(1 .58)"><g ref={rim} stroke="#84b9af" strokeWidth="3" strokeLinecap="round">
        {[0, 90, 180, 270].map((angle) => <path key={angle} transform={`rotate(${angle})`} d="M91 -12A92 92 0 0 1 91 12" />)}
      </g></g>}
      {placement && <g transform="translate(130 88) scale(35 21)" strokeWidth=".025">
        <circle r={PLATE.placementOuter} fill="#edbe64" fillOpacity=".35" stroke="#d69e36" />
        <circle r={PLATE.placementInner} fill="#d6e9e5" stroke="#d69e36" />
      </g>}
      <g ref={snacks}>{[...board.items].sort((a,b)=>a.z-b.z).filter((i)=>i.y>-2).map((i) => <g key={i.id} transform={`translate(${130+i.x*35},${88+i.z*21-i.y*30}) scale(.75)`}><SnackDrawing kind={i.kind} /></g>)}</g>
      {selected && <g data-preview="true" transform={`translate(${130+selected.x*35},${88+selected.z*21}) scale(.75)`} filter={`url(#${previewTint})`}><SnackDrawing kind={selectedKind} /></g>}
    </g>
    {mode === 'balance' && <><path d="M57 47Q106 4 173 33" stroke="#edbe64" strokeWidth="6" /><path d="M161 20L175 33L158 39" stroke="#edbe64" strokeWidth="6" /></>}
    {mode === 'spill' && <g transform="translate(225 154) rotate(30)"><SnackDrawing kind="donut" /><path d="M-5-48l5 10M10-45l-2 10" stroke="#edbe64" strokeWidth="4" /></g>}
  </svg>
}
