import { useEffect, useEffectEvent, useRef, useState } from 'react'
import { PLATE, SNACKS, turnOf, type PlatePosition, type PlateRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { MePill } from '../../ui/MePill.tsx'
import { OrderIntro } from '../../ui/OrderIntro.tsx'
import { StickerModal } from '../../ui/StickerModal.tsx'
import { PlayerNotice } from '../../ui/SubmitBanner.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { WaitBar } from '../../ui/WaitBar.tsx'
import { SnackArt } from './art.tsx'
import { PlateScene } from './PlateScene.tsx'

export function Play({ room, error, onPick, onLobby }: { room: PlateRoom; error?: string; onPick: (position: PlatePosition) => void; onLobby: () => void }) {
  const { g } = room
  const [selection, setSelection] = useState<{ round: number; position: PlatePosition | null; sent: boolean; error?: string } | null>(null)
  const submitted = useRef<{ round: number; error?: string } | null>(null)
  const selected = selection?.round === room.round ? selection.position : null
  const opening = (useCountdown(g.openingMs) ?? 0) > 0
  const roundRemaining = useCountdown(room.remainingMs)
  const autoRemaining = useCountdown(g.event?.auto ? Math.max(0, PLATE.motionMs - g.elapsedMs) : null)
  const [invalidDeadline, setInvalidDeadline] = useState<number | null>(null)
  const [invalidVisible, setInvalidVisible] = useState(false)
  useEffect(() => {
    if (invalidDeadline === null) return
    const id = setTimeout(() => setInvalidVisible(false), Math.max(0, invalidDeadline - Date.now()))
    return () => clearTimeout(id)
  }, [invalidDeadline])
  const sent = selection?.round === room.round && selection.sent && selection.error === error
  const [showResult, setShowResult] = useState(false)
  const resultDelay = useEffectEvent(() => Math.max(0, PLATE.motionMs - g.elapsedMs) + 250)
  useEffect(() => {
    if (room.phase !== 'done') return
    const id = setTimeout(() => setShowResult(true), resultDelay())
    return () => clearTimeout(id)
  }, [room.phase, g.event?.id]) // 같은 이벤트의 재방송으로 결과 타이머를 되감지 않는다.
  if (room.phase === 'intro') return <OrderIntro players={room.players} order={g.order} me={room.you} remainingMs={room.remainingMs} />
  const choosing = room.phase === 'choosing' && !g.settling && !sent && !opening
  const cur = choosing ? turnOf(g.order, g.last, room.players.map((p) => p.id)) : g.event?.by ?? g.last
  const player = room.players.find((p) => p.id === cur)
  const mine = choosing && cur === room.you
  const snack = SNACKS[g.snack]
  const confirmPosition = () => {
    if (!mine || !selected || submitted.current?.round === room.round && submitted.current.error === error) return
    submitted.current = { round: room.round, error }
    setSelection({ round: room.round, position: selected, sent: true, error })
    onPick(selected)
  }
  const selectPosition = (position: PlatePosition) => {
    if (!mine) return
    setInvalidVisible(false)
    setSelection({ round: room.round, position, sent: false, error })
  }
  const loser = room.players.find((p) => p.id === g.loser)
  const failedMe = g.loser === room.you
  const moving = !choosing && !showResult && !opening
  const autoPlayer = room.players.find((p) => p.id === g.event?.by)
  const status = error ?? (opening ? '드래그해서 접시를 돌려볼 수 있어요' : invalidVisible && mine ? '표시된 띠 안을 선택해주세요' : moving ? '간식이 멈출 때까지 기다려요' : mine ? selected ? '이 간식을 한 번 더 누르면 놓아요' : '띠 안을 터치해 고르고, 한 번 더 눌러 놓아요' : '드래그해서 접시의 기울기를 살펴봐요')
  return <div className="plate-play">
    <TurnCard name={opening ? null : player?.name ?? null} none="접시를 둘러봐요" avatar={player?.avatar} me={mine} meTitle="내 차례!" meHint="터치로 선택 · 드래그로 회전" other={moving ? '님이 놓았어요' : '님 차례'} fixed right={choosing ? <Timer key={room.round} remainingMs={roundRemaining} totalMs={PLATE.chooseMs} /> : undefined} />
    <div className="plate-snack sticker" style={{ background: 'var(--cream)' }}>
      <SnackArt kind={g.snack} />
      <div><span className="jua">{snack.name}</span><span className="plate-weight">무게 {snack.weight}<span className="plate-weight-dots" aria-hidden="true">{[1,2,3,4].map((n) => <i key={n} data-on={n<=snack.weight ? '1' : '0'} />)}</span></span></div>
      <span className="plate-count">{room.round}번째 간식</span>
    </div>
    <PlateScene view={g} selected={selected} canPick={mine} onSelect={selectPosition} onConfirm={confirmPosition} onInvalid={() => { setInvalidVisible(true); setInvalidDeadline(Date.now() + 1800) }}>
      {(autoRemaining ?? 0) > 0 && <div className="plate-timeout" key={g.event!.id}>
        <PlayerNotice name={autoPlayer?.name ?? '나간 친구'} avatar={autoPlayer?.avatar ?? 'x'} bot={autoPlayer?.bot ?? false} label="시간 초과! 자동으로 놓았어요" tone="plain" compact icon={false} />
      </div>}
    </PlateScene>
    <div className="plate-status" data-selected={mine && !!selected ? '1' : undefined} role={error ? 'alert' : 'status'}>{status}</div>
    <AvatarStrip room={room} compact dim={() => false} ring={(p) => p.id === cur} />
    {room.phase === 'done' && showResult && <StickerModal tone={failedMe ? 'lime' : 'plain'} labelledBy="plate-result-title">
      <div className="plate-result">
        <div id="plate-result-title" className="jua modal__title">{g.saved ? '끝까지 지켰어요!' : '와르르! 벌칙 당첨!'}</div>
        {!g.saved && <><div style={{ position: 'relative' }}>{failedMe && <MePill floating />}<Avatar seed={loser?.avatar ?? 'x'} size={90} ring={failedMe} /></div><span className="nick nick--lg nick--center">{loser?.name ?? '나간 친구'}</span></>}
        <p>{g.saved ? '32개의 간식을 모두 올렸어요. 모두의 승리!' : '방금 놓은 간식 때문에 접시에서 떨어졌어요.'}</p>
        {room.host === room.you ? <button type="button" className="btn-sticker" data-tone="lime" onClick={onLobby}>대기실로</button> : <WaitBar>방장이 다시 시작하기를 기다려요</WaitBar>}
      </div>
    </StickerModal>}
  </div>
}
