import { useState } from 'react'
import { OTHELLO, othelloCount, type OthelloRoom } from '@moyeora/shared'
import { PlayerLabel } from '../../ui/PlayerLabel.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { Board, Disc } from './Board.tsx'
import { PassNotice } from './PassNotice.tsx'

export function Players({ room }: { room: OthelloRoom }) {
  return <div className="othello-results">{room.g.order.map((owner) => {
    const p = room.players.find((player) => player.id === owner)!
    return <PlayerLabel key={owner} player={p} me={owner === room.you}><Disc side={room.g.order.indexOf(owner)} /><span className="othello-count jua">{othelloCount(room.g.board, owner)}<small>개</small></span></PlayerLabel>
  })}</div>
}

export function Play({ room, onMove }: { room: OthelloRoom; onMove: (to: number) => void }) {
  const [sending, setSending] = useState(false)
  const g = room.g
  const [ply, setPly] = useState(g.ply)
  if (ply !== g.ply) { setPly(g.ply); setSending(false) }
  const myTurn = room.phase === 'choosing' && !g.settling && g.turn === room.you && !sending
  const cur = room.players.find((p) => p.id === g.turn)
  const mine = room.players.find((p) => p.id === room.you)!
  const other = room.players.find((p) => p.id !== room.you)!
  const passed = room.players.find((p) => p.id === g.passed)
  const player = (p: typeof mine) => <div className={`othello-player${p.id === room.you ? ' othello-player--me' : ''}`}><PlayerLabel player={p} me={p.id === room.you}><Disc side={g.order.indexOf(p.id)} /><span className="othello-count jua">{othelloCount(g.board, p.id)}<small>개</small></span></PlayerLabel></div>
  const status = g.settling ? `${g.last?.auto ? '시간이 지나 대신 놓았어요 · ' : ''}${g.last?.flipped.length ?? 0}개를 뒤집었어요!`
    : passed ? `${passed.id === room.you ? '나는' : `${passed.name}님은`} 둘 곳이 없어 자동 패스했어요`
    : myTurn ? '점이 있는 칸을 톡! 사이의 돌이 뒤집혀요' : '상대가 어디에 놓을지 지켜봐요'
  return <><div className="othello-play">
    <TurnCard fixed hintOneLine name={cur?.name ?? null} avatar={cur?.avatar} me={g.turn === room.you} meTitle={g.settling ? '뒤집었어요!' : '내 차례!'} meHint={g.settling ? '' : '잘 생각해서 선택하세요.'} other={g.settling ? '님이 뒤집었어요' : '님 차례'} right={!g.settling && <Timer remainingMs={room.remainingMs} totalMs={OTHELLO.chooseMs} />} />
    {player(mine)}
    <div className="othello-board-space"><Board board={g.board} order={g.order} targets={myTurn ? g.targets : []} targetSide={g.order.indexOf(g.turn!)} last={g.last} moveKey={g.ply} animate onCell={(to) => { if (!myTurn || !g.targets.includes(to)) return; setSending(true); onMove(to) }} /></div>
    <p className="othello-status" role="status">{status}</p>
    {player(other)}
  </div>
    {room.phase === 'reveal' && passed && <PassNotice key={`${g.gameNo}:${g.ply}`} room={room} />}
  </>
}
