import { othelloInitialBoard, othelloTargets, type OthelloBoard } from '@moyeora/shared'
import { Tutorial as Frame } from '../../ui/Tutorial.tsx'
import { Board } from './Board.tsx'
const order = ['black', 'white']
const initial = othelloInitialBoard(order)
const flipped = [...initial]; flipped[19] = flipped[27] = 'black'
const end: OthelloBoard = Array.from({ length: 64 }, (_, i) => i < 40 ? 'black' : 'white')

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame onClose={onClose} pages={[
    { title: '흑과 백, 둘이서 대결!', art: <div className="othello-demo"><Board board={initial} order={order} /></div>, line: <>흑돌이 먼저 시작해요.<br />한 번씩 번갈아 돌을 놓아요.</> },
    { title: '사이에 끼우면 뒤집혀요!', art: <div className="othello-demo othello-demo--flip"><Board board={flipped} order={order} last={{ to: 19, by: 'black', flipped: [27], auto: false }} animate /></div>, line: <>내 돌 사이의 상대 돌을 모두 뒤집어요.<br />가로·세로·대각선 모두 가능!</> },
    { title: '점이 있는 칸을 톡!', art: <div className="othello-demo"><Board board={initial} order={order} targets={othelloTargets(initial, 'black')} /></div>, line: <>상대 돌을 뒤집을 수 있는 칸에만 놓아요.<br />둘 곳이 없으면 자동으로 차례를 넘겨요.</> },
    { title: '마지막에 돌이 많으면 승리!', art: <div className="othello-demo othello-demo--result"><Board board={end} order={order} /><div className="othello-demo-score jua">흑 40개<br />백 24개</div></div>, line: <>둘 다 놓을 수 없으면 끝! 많으면 승리!<br />혼자라면 대기실에서 NPC를 추가해요.</> },
  ]} />
}
