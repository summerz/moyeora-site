import { othelloInitialBoard } from '@moyeora/shared'
import { Board } from './Board.tsx'
import './othello.css'
const order = ['black', 'white']
const board = othelloInitialBoard(order)
board[19] = board[27] = board[26] = board[18] = order[0]!
board[20] = board[29] = board[37] = order[1]!

export function Hero({ size = 170 }: { size?: number }) {
  return <div className="othello-hero" style={{ width: size }} aria-hidden="true"><Board board={board} order={order} last={{ to: 19, by: 'black', flipped: [27], auto: false }} animate /></div>
}
