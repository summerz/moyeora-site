import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { othelloWinsNeeded, type OthelloRoom, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { OrderIntro } from '../../ui/OrderIntro.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { preloadSamples, sampleAt } from '../../ui/sound.ts'
import successUrl from '../../ui/sfx/success.wav'
import tickUrl from '../../ui/sfx/tick.wav'
import { useSocket } from '../../ws.ts'
import { Hero } from './Hero.tsx'
import { Board } from './Board.tsx'
import { Play, Players } from './Play.tsx'
import { RoundResult } from './RoundResult.tsx'
import { Tutorial } from './Tutorial.tsx'
import './othello.css'

const TUT_KEY = 'moyeora:othello:tutorial'
const tutorialSeen = () => { try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false } }
function App() {
  const [tutorial, setTutorial] = useState(false)
  const [seen, setSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<OthelloRoom | null>(null)
  const [error, setError] = useState<string>()
  const [retry, setRetry] = useState(0)
  const roomRef = useRef<OthelloRoom | null>(null)
  useEffect(() => { preloadSamples([successUrl, tickUrl]) }, [])
  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'othello') return
      const next = m.room
      const prev = roomRef.current
      if (prev && next.g.last && next.g.gameNo === prev.g.gameNo && next.g.ply > prev.g.ply) sampleAt(performance.now(), tickUrl)
      if (prev && next.g.winner && (prev.g.winner !== next.g.winner || prev.g.gameNo !== next.g.gameNo)) sampleAt(performance.now(), successUrl)
      roomRef.current = next; setRoom(next); setError(undefined)
    } else if (m.type === 'error') { setError(errorText(m.message)); setRetry((n) => n + 1) }
  }
  const send = useSocket(onMessage, () => { roomRef.current = null; setRoom(null); setError('연결이 끊겼어요') })
  let screen
  if (!profile || editing) screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  else if (!room) screen = <Join game="othello" profile={profile} error={error} onEdit={() => setEditing(true)} onCreate={() => send({ type: 'create', game: 'othello', ...profile })} onJoin={(code) => send({ type: 'join', code, ...profile })} />
  else if (room.phase === 'lobby') screen = <Lobby room={room} hero={<Hero />} maxPlayers={2} startHint="둘이 모이면 시작! 혼자라면 NPC를 추가해요" onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}><SegmentPicker label="대전 방식" size="sm" options={[{ value: 1, label: '단판' }, { value: 3, label: '3판 2승' }, { value: 5, label: '5판 3승' }]} value={room.g.bestOf} host={room.host === room.you} onPick={(bestOf) => send({ type: 'config', config: { bestOf } })} /><p className="othello-footnote">{room.g.bestOf === 1 ? '마지막에 내 돌이 더 많으면 승리!' : `먼저 ${othelloWinsNeeded(room.g.bestOf)}승 하면 승리 · 무승부는 승수 제외`}</p></Lobby>
  else if (room.phase === 'done') screen = <Final room={room} draw={room.g.draw} showScore={room.g.bestOf !== 1} scoreUnit="승" title={room.g.draw ? '비겼어요! 한 판 더?' : '오델로! 승부 끝!'} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })}><Board board={room.g.board} order={room.g.order} /><Players room={room} /></Final>
  else if (room.phase === 'intro') screen = <><OrderIntro players={room.players} order={room.g.order} me={room.you} remainingMs={room.remainingMs} /><p className="othello-footnote">첫 번째가 흑돌 · 흑돌부터 시작해요</p></>
  else if (room.phase === 'reveal' && (room.g.winner || room.g.draw)) screen = <RoundResult room={room} />
  else screen = <Play key={`${room.g.gameNo}-${retry}`} room={room} onMove={(to) => send({ type: 'submit', choice: `${room.g.gameNo}:${room.g.ply}:${to}` })} />
  return <Shell onHelp={() => setTutorial(true)} confirmHome={!!room && room.phase !== 'lobby' && room.phase !== 'done'} safe={!room || room.phase === 'lobby' || room.phase === 'done'} fit={!!room && (room.phase === 'choosing' || room.phase === 'reveal')} onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined}>
    {screen}
    {error && room && <p className="othello-error" role="alert">{error}</p>}
    {(tutorial || (!seen && room?.phase === 'lobby')) && <Tutorial onClose={() => { setTutorial(false); setSeen(true); try { localStorage.setItem(TUT_KEY, '1') } catch {} }} />}
  </Shell>
}
createRoot(document.getElementById('root')!).render(<App />)
