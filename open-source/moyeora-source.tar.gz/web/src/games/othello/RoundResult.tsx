import { OTHELLO, othelloWinsNeeded, type OthelloRoom } from '@moyeora/shared'
import { ResultRow, Stamp } from '../../ui/ResultRow.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { Board } from './Board.tsx'
import { Players } from './Play.tsx'

export function RoundResult({ room }: { room: OthelloRoom }) {
  const g = room.g
  const winner = room.players.find((p) => p.id === g.winner)
  const needed = othelloWinsNeeded(g.bestOf)
  const finished = g.bestOf === 1 || room.players.some((p) => p.score >= needed)
  return <div className="othello-round-result">
    <TurnCard fixed name={winner?.name ?? null} avatar={winner?.avatar} me={g.winner === room.you} meTitle="이번 판 승리!" meHint={finished ? '잠시 후 최종 결과를 확인해요' : '다음 판도 이어서 해요'} other="님 승리!" none="이번 판은 무승부!" />
    <div className="othello-board-space"><Board board={g.board} order={g.order} /></div>
    <Players room={room} />
    <div>{g.bestOf !== 1 && room.players.map((p) => <ResultRow key={p.id} p={p} me={p.id === room.you}><Stamp text={`${p.score}승`} bg={p.id === g.winner ? 'var(--amber)' : 'var(--cream)'} /></ResultRow>)}</div>
    <div className="othello-next"><p className="othello-footnote">{finished ? '승부 끝! 잠시 후 최종 결과를 확인해요' : <>먼저 {needed}승 하면 최종 승리!<br />다음 판은 흑·백을 바꿔요{g.draw ? ' · 무승부는 승수 제외' : ''}</>}</p><Timer remainingMs={room.remainingMs} totalMs={OTHELLO.resultMs} /></div>
  </div>
}
