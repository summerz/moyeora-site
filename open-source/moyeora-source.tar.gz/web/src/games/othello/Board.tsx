import type { CSSProperties } from 'react'
import type { OthelloBoard, OthelloLast } from '@moyeora/shared'

export function Disc({ side, flip = false, delay = 0, arrive = false }: { side: number; flip?: boolean; delay?: number; arrive?: boolean }) {
  return <span className={`othello-disc${flip ? ' othello-disc--flip' : ''}${arrive ? ' othello-disc--arrive' : ''}`} style={{ '--flip-delay': `${delay}ms` } as CSSProperties} aria-hidden="true">
    <span className={`othello-face othello-face--${side}`} />
    <span className={`othello-face othello-face--back othello-face--${1 - side}`} />
  </span>
}

export function Board({ board, order, targets = [], targetSide = 0, last, moveKey = 0, animate = false, onCell }: {
  board: OthelloBoard; order: readonly string[]; targets?: number[]; targetSide?: number; last?: OthelloLast | null
  moveKey?: number; animate?: boolean; onCell?: (to: number) => void
}) {
  return <div className="othello-board" role="group" aria-label="오델로 8×8 말판">
    {board.map((owner, to) => {
      const side = owner === null ? -1 : order.indexOf(owner)
      const legal = targets.includes(to)
      const flipped = animate && !!last?.flipped.includes(to)
      const label = `${Math.floor(to / 8) + 1}행 ${to % 8 + 1}열, ${side < 0 ? legal ? '놓을 수 있어요' : '빈칸' : side === 0 ? '흑돌' : '백돌'}`
      const cls = `othello-cell${legal ? ' othello-cell--legal' : ''}${last?.to === to ? ' othello-cell--last' : ''}`
      const content = side < 0 ? legal ? <span className={`othello-target othello-target--${targetSide}`} aria-hidden="true" /> : null : <Disc key={flipped || animate && last?.to === to ? `${to}-${moveKey}` : `${to}-still`} side={side} flip={flipped} delay={last ? Math.min(160, (Math.abs(Math.floor(to / 8) - Math.floor(last.to / 8)) + Math.abs(to % 8 - last.to % 8)) * 35) : 0} arrive={animate && last?.to === to} />
      return legal && onCell ? <button key={to} type="button" className={cls} aria-label={label} onClick={() => onCell(to)}>{content}</button>
        : <div key={to} className={cls} aria-label={label}>{content}</div>
    })}
  </div>
}
