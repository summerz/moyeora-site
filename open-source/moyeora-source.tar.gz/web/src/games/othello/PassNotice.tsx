import { useState } from 'react'
import type { OthelloRoom } from '@moyeora/shared'
import { StickerModal } from '../../ui/StickerModal.tsx'

/** 자동 패스 안내는 서버의 reveal 시간 동안만 표시한다. */
export function PassNotice({ room }: { room: OthelloRoom }) {
  const [closed, setClosed] = useState(false)
  const passed = room.players.find((p) => p.id === room.g.passed)
  const next = room.players.find((p) => p.id === room.g.turn)
  if (closed || !passed || !next) return null
  return <StickerModal tone="plain" lite onClose={() => setClosed(true)} labelledBy="othello-pass-title">
    <div id="othello-pass-title" className="jua modal__title">자동 패스!</div>
    <p className="modal__msg othello-pass-message"><span className="nick">{passed.name}</span>님은 놓을 수 있는 칸이 없어요.</p>
    <p className="modal__msg othello-pass-message">잠시 후 <span className="nick">{next.name}</span>님이 한 번 더 둬요!</p>
  </StickerModal>
}
