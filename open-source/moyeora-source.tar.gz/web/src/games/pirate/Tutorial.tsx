import { useEffect, useState, type ReactNode } from 'react'
import { Timer } from '../../ui/Timer.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { Barrel, SWORD_COLORS } from './Barrel.tsx'

const art = (node: ReactNode) => <div style={{ width: 160 }}>{node}</div>

/** 10 → 7 을 되풀이하는 타이머 그림 */
function LoopTimer() {
  const [k, setK] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setK((n) => n + 1), 3200)
    return () => clearInterval(t)
  }, [])
  return <div style={{ zoom: 1.5 }}><Timer key={k} remainingMs={10_000} totalMs={10_000} /></div>
}

const PAGES: TutorialPage[] = [
  {
    title: '내 차례에 한 칸',
    art: art(<Barrel holes={12} mark={5} stuck={[{ hole: 1, color: SWORD_COLORS[1], initial: '문' }, { hole: 10, color: SWORD_COLORS[3], initial: '고' }]} />),
    line: <>내 차례가 오면 빈 구멍 하나에<br/><b>칼을 꽂아요</b></>,
  },
  {
    title: '펑! 하면 벌칙',
    art: art(<Barrel holes={12} head="out" stuck={[{ hole: 1, color: SWORD_COLORS[1], initial: '문' }, { hole: 6, color: SWORD_COLORS[0], initial: '나' }]} trap={6} />),
    line: <>해적이 <b>튀어나오면</b><br/>꽂은 사람이 벌칙!</>,
  },
  {
    title: '시간은 10초',
    art: <LoopTimer />,
    line: <>망설이면 <b>아무 데나</b> 꽂혀요</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
