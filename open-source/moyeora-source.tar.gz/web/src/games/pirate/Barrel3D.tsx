/*
 * 이 게임만 레이아웃이 다르다 (다른 게임은 전부 일반 DOM 흐름). 오해하기 쉬운 점:
 * - 캔버스는 화면 전체(`position: fixed; inset: 0`)를 덮는 오버레이이고 pointer-events 가 none 이다.
 *   그래야 펑! 때 해적이 헤더·차례 카드 위를 지나 화면 밖까지 날아갈 수 있다 (통 칸 안에 가두면 잘린다).
 * - 통은 레이아웃 안의 투명한 '자리(slot)' div 위치로 camera.setViewOffset 투영해서 그린다.
 *   자리 위치는 resize / scroll / visualViewport 변화마다 다시 잰다(fit). 캔버스가 아니라 자리가 공간을 차지한다.
 * - 터치는 자리 div 가 받아서 직접 raycast 로 구멍·드래그를 판정한다 (캔버스는 입력을 받지 않는다).
 * - 렌더는 필요할 때만 돈다(render-on-demand: 움직임이 있을 때만 rAF). 3D 를 못 쓰면 2D `Barrel` 로 대체한다.
 * - z-index 순서: 페이지 UI < 이 캔버스(25) < 펑! 딱지(27) < 모달(30). pirate.css 참고.
 */
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import type * as THREE from 'three'
import { PIRATE_ROWS, POP_TIMING } from '@moyeora/shared'
import { Barrel, swordVar, type BarrelProps, type Mood } from './Barrel.tsx'

/** 다른 사람이 돌리는 통 각도. n 이 바뀔 때마다 새 값 */
export type Aim = { angle: number; n: number; /** 서버가 정한 시간 초과 자동 꽂기 — 차례 본인도 따라 돈다 */ auto?: boolean }
type Props = BarrelProps & {
  aim?: Aim | null
  /** 내 차례에 통을 돌리는 동안(≈12회/초) + 놓을 때 마지막 한 번 */
  onAim?: (angle: number) => void
}
type T3 = typeof THREE
type Ctl = { sync: (p: Props) => void; dispose: () => void }

const INK = '#0e0a1c'
const TAU = Math.PI * 2
const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches

// ---- 통 모양 ----
const HALF = 1.4 // 반높이
const R_END = 1.25
const R_BULGE = 0.3
const radiusAt = (y: number) => R_END + R_BULGE * (1 - (y / HALF) ** 2)
const slopeAt = (y: number) => (-2 * R_BULGE * y) / (HALF * HALF)
const ROW_Y = [0.62, 0, -0.62]

/** 구멍마다 둘레 각(phi)·높이. 행마다 반 칸씩 어긋난다. phi=0 이 정면(+z) */
export const holeLayout = (holes: number): { phi: number; y: number }[] =>
  (PIRATE_ROWS[holes] ?? PIRATE_ROWS[12]!).flatMap((n, r) => Array.from({ length: n }, (_, j) => ({ phi: (TAU * (j + (r % 2 ? 0.5 : 0))) / n, y: ROW_Y[r]! })))

// ---- 해적 (통 안에 몸이 숨어 있고, 머리·어깨만 테두리 위로) ----
const REST_Y = 0.85 // 해적 몸통 중심의 통 기준 높이
const HEAD_Y = 1.15 // 몸통 중심 → 머리 중심
const HEAD_R = 0.68
const SHOW_MS = 350
const SHOW_YAW = 0.55 // 치명적인 칼이 정면에서 살짝 옆으로 보이게
const SQUASH_S = 0.12
const SHIVER_S = POP_TIMING.shiverMs / 1000 // 부들부들 시간(초). 이 뒤로는 움직임 없이 웅크린 채 멈춘다(freeze) → Play 가 펑! 으로 넘긴다
const FLY_S = 1.5
const END_S = SQUASH_S + FLY_S + 0.5 // 날아오르기 시작~착지 후 흔들림 끝(초). Play 의 결과 모달 시점이 이걸 따른다
const APEX = 5.6 // 가장 높이 올라가는 높이(통 단위). 화면 위로 나간다
const easeOut = (u: number) => 1 - (1 - u) ** 3
const smooth = (u: number) => u * u * (3 - 2 * u)
const clamp01 = (u: number) => Math.max(0, Math.min(1, u))

export type PiratePose = { x: number; y: number; rotY: number; rotZ: number; sx: number; sy: number; armL: number; armR: number }
const REST: PiratePose = { x: 0, y: REST_Y, rotY: 0, rotZ: 0, sx: 1, sy: 1, armL: 0.7, armR: 0.7 }

/** 튀어오르는 해적: 시간(초)만의 함수. trap 번호로만 변주해서 모든 폰이 똑같이 본다 */
export const launchPose = (t: number, trap: number, rm: boolean): PiratePose => {
  const s = trap % 2 ? 1 : -1
  const land = ((trap % 3) - 1) * 0.1
  if (rm) return { ...REST, y: REST_Y + 1.1 * easeOut(clamp01(t / 0.4)), armL: 1.2, armR: 1.2 }
  if (t < SQUASH_S) {
    const u = t / SQUASH_S
    return { ...REST, sx: 1.12 - 0.12 * u, sy: 0.8 + 0.3 * u }
  }
  if (t < SQUASH_S + FLY_S) {
    const u = (t - SQUASH_S) / FLY_S
    const k = clamp01(u / 0.15)
    const flail = Math.sin(t * 20) * 0.55
    return {
      x: land * u + s * 0.5 * Math.sin(Math.PI * u),
      y: REST_Y + APEX * 4 * u * (1 - u),
      rotY: -s * TAU * u,
      rotZ: s * TAU * 2 * u,
      sx: 0.94 + 0.06 * k,
      sy: 1.16 - 0.16 * k,
      armL: 2.5 + flail,
      armR: 2.5 - flail * 0.8,
    }
  }
  // 착지: 통 안으로 쏙, 살짝 튕기고 어지러운 듯 기울어진 채 멈춘다
  const v = clamp01((t - SQUASH_S - FLY_S) / 0.5)
  return {
    x: land,
    y: REST_Y + 0.3 * 4 * v * (1 - v) * (1 - v),
    rotY: 0,
    rotZ: s * 0.18 * smooth(v),
    sx: 1 + 0.1 * Math.sin(Math.PI * Math.min(1, v * 2)) * (v < 0.5 ? 1 : 0),
    sy: 1 - 0.16 * Math.sin(Math.PI * Math.min(1, v * 2)) * (v < 0.5 ? 1 : 0),
    armL: 2.2 - 1.2 * smooth(v),
    armR: 2.2 - 1.2 * smooth(v),
  }
}
export const LAUNCH_END_S = END_S

/** 부들부들: 시간(초)만의 함수(무작위 없음 → 모든 폰이 똑같이). 점점 세지는 떨림 + 통 안으로 움츠림. 반환 amp 는 통 떨림 세기 */
export const shiverPose = (t: number): { pose: PiratePose; amp: number } => {
  const k = clamp01(t / SHIVER_S)
  const amp = t >= SHIVER_S ? 0 : 0.12 + 0.88 * k * k
  const sink = 0.28 * smooth(clamp01(t / 0.6))
  return {
    amp,
    pose: {
      x: (Math.sin(t * 71) * 0.035 + Math.sin(t * 47 + 1) * 0.02) * amp,
      y: REST_Y - sink,
      rotY: Math.sin(t * 39) * 0.06 * amp,
      rotZ: Math.sin(t * 53 + 2) * 0.07 * amp,
      sx: 1 + 0.06 * smooth(k),
      sy: 1 - 0.08 * smooth(k),
      // 팔은 몸통에 붙여 통 안에 가둔다: 떨림은 안쪽으로만(0 이상, 최대 0.1rad) → 손 끝이 통 안벽(반지름 ~1.0)을 넘지 않는다
      armL: 0.7 - 0.62 * smooth(clamp01(t / 0.3)) + (0.5 + 0.5 * Math.sin(t * 61)) * 0.05 * amp,
      armR: 0.7 - 0.62 * smooth(clamp01(t / 0.3)) + (0.5 + 0.5 * Math.sin(t * 59 + 1)) * 0.05 * amp,
    },
  }
}

// ---- 나무 통 무늬 ----
const rand = (seed: number) => () => {
  seed = (seed * 1664525 + 1013904223) >>> 0
  return seed / 4294967296
}

/** 통 옆면 텍스처(2048x640): 판자마다 살짝 다른 색 + 구분용 무늬 4개. 무늬는 구멍과 겹치지 않는 자리를 골라 둔다 */
const paintBody = (holes: number) => {
  const W = 2048
  const H = 640
  const c = document.createElement('canvas')
  c.width = W
  c.height = H
  const g = c.getContext('2d')!
  const STAVES = 14
  const sw = W / STAVES
  const rnd = rand(11)
  for (let i = 0; i < STAVES; i++) {
    const h = 31 + (rnd() - 0.5) * 9
    const s = 58 + (rnd() - 0.5) * 12
    const l = (i % 2 ? 50 : 59) + (rnd() - 0.5) * 8
    g.fillStyle = `hsl(${h} ${s}% ${l}%)`
    g.fillRect(i * sw, 0, sw + 1, H)
    g.strokeStyle = 'rgba(92,52,20,0.16)'
    g.lineWidth = 3
    for (let k = 0; k < 4; k++) {
      const x = i * sw + sw * (0.15 + 0.7 * rnd())
      g.beginPath()
      g.moveTo(x, 0)
      g.bezierCurveTo(x + 10 * (rnd() - 0.5), H * 0.3, x + 10 * (rnd() - 0.5), H * 0.7, x + 6 * (rnd() - 0.5), H)
      g.stroke()
    }
  }
  g.fillStyle = '#7c4a20'
  for (let i = 0; i < STAVES; i++) g.fillRect(i * sw - 3, 0, 6, H)

  // 무늬 자리: 목표 각도 근처에서 가장 가까운 구멍과 가장 먼 곳
  const layout = holeLayout(holes)
  const place = (deg: number) => {
    let best = { phi: (deg * Math.PI) / 180, y: 0, d: -1 }
    for (let dd = -26; dd <= 26; dd += 2) {
      const phi = ((deg + dd) * Math.PI) / 180
      for (let y = -0.85; y <= 0.85; y += 0.05) {
        const d = Math.min(...layout.map((o) => {
          let dp = Math.abs(((phi - o.phi) % TAU + TAU + Math.PI) % TAU - Math.PI)
          dp *= radiusAt(y)
          return Math.hypot(dp, y - o.y)
        }))
        if (d > best.d) best = { phi, y, d }
      }
    }
    return { x: ((best.phi % TAU + TAU) % TAU) / TAU * W, y: (1 - (best.y + HALF) / (2 * HALF)) * H }
  }
  const stroke = (w: number, col = INK) => { g.lineWidth = w; g.strokeStyle = col; g.lineJoin = 'round'; g.lineCap = 'round' }

  // 1) 짙은 옹이
  {
    const p = place(35)
    g.save(); g.translate(p.x, p.y); g.rotate(0.12)
    for (const [rx, ry, col] of [[34, 48, '#7c4a20'], [24, 36, '#5a3214'], [14, 24, '#3b2010'], [6, 12, '#24130a']] as const) {
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, TAU); g.fill()
    }
    stroke(3, 'rgba(36,19,10,0.7)')
    for (const k of [-1, 1]) { g.beginPath(); g.moveTo(k * 40, -30); g.quadraticCurveTo(k * 52, 0, k * 40, 34); g.stroke() }
    g.restore()
  }
  // 2) 덧댄 판자(못 2개)
  {
    const p = place(125)
    g.save(); g.translate(p.x, p.y); g.rotate(-0.1)
    g.fillStyle = '#e8bd7c'; g.fillRect(-48, -68, 96, 136)
    stroke(5); g.strokeRect(-48, -68, 96, 136)
    stroke(2.5, 'rgba(124,74,32,0.55)'); g.beginPath(); g.moveTo(-16, -62); g.lineTo(-16, 62); g.moveTo(18, -62); g.lineTo(18, 62); g.stroke()
    for (const [nx, ny] of [[-30, -50], [30, 50]]) {
      g.fillStyle = '#aab3c4'; g.beginPath(); g.arc(nx, ny, 9, 0, TAU); g.fill()
      stroke(3.5); g.stroke()
      g.fillStyle = '#e8edf5'; g.beginPath(); g.arc(nx - 2.5, ny - 2.5, 2.8, 0, TAU); g.fill()
    }
    g.restore()
  }
  // 3) 해골 낙인(가위 뼈)
  {
    const p = place(215)
    g.save(); g.translate(p.x, p.y)
    const burn = '#3a1f0e'
    stroke(11, burn)
    g.beginPath(); g.moveTo(-50, -34); g.lineTo(50, 52); g.moveTo(50, -34); g.lineTo(-50, 52); g.stroke()
    g.fillStyle = burn
    for (const [bx, by] of [[-54, -38], [-42, -46], [54, -38], [42, -46], [-54, 56], [-42, 62], [54, 56], [42, 62]]) { g.beginPath(); g.arc(bx, by, 8, 0, TAU); g.fill() }
    g.beginPath(); g.arc(0, -8, 30, 0, TAU); g.fill()
    g.fillRect(-18, 10, 36, 26)
    g.fillStyle = '#c8803d'
    for (const ex of [-12, 12]) { g.beginPath(); g.ellipse(ex, -10, 8, 10, 0, 0, TAU); g.fill() }
    g.beginPath(); g.moveTo(0, 6); g.lineTo(-5, 16); g.lineTo(5, 16); g.fill()
    stroke(3.5, '#c8803d'); g.beginPath(); g.moveTo(-6, 22); g.lineTo(-6, 36); g.moveTo(6, 22); g.lineTo(6, 36); g.stroke()
    g.restore()
  }
  // 4) 갈라진 금
  {
    const p = place(305)
    g.save(); g.translate(p.x, p.y)
    stroke(6, '#2a1608')
    g.beginPath(); g.moveTo(-6, -110); g.lineTo(10, -70); g.lineTo(-10, -34); g.lineTo(12, 4); g.lineTo(-4, 44); g.lineTo(8, 84); g.lineTo(-2, 112); g.stroke()
    stroke(4, '#2a1608')
    g.beginPath(); g.moveTo(-10, -34); g.lineTo(-38, -22); g.lineTo(-52, -34); g.moveTo(12, 4); g.lineTo(40, 14); g.lineTo(50, 36); g.stroke()
    stroke(2.5, 'rgba(255,240,200,0.5)')
    g.beginPath(); g.moveTo(-2, -108); g.lineTo(14, -70); g.lineTo(-6, -34); g.stroke()
    g.restore()
  }
  return c
}

// ---- 해적 얼굴 ----
const paintFace = (mood: Mood) => {
  const W = 1024
  const H = 512
  const c = document.createElement('canvas')
  c.width = W
  c.height = H
  const g = c.getContext('2d')!
  g.fillStyle = '#ffe0b0'
  g.fillRect(0, 0, W, H)
  // 빨간 두건: 머리 윗부분을 한 바퀴
  const edge = (x: number) => 196 + 16 * Math.cos(((x - 256) / W) * TAU)
  g.beginPath()
  g.moveTo(0, 0)
  g.lineTo(W, 0)
  for (let x = W; x >= 0; x -= 8) g.lineTo(x, edge(x))
  g.closePath()
  g.fillStyle = '#ff5e5b'
  g.fill()
  g.beginPath()
  for (let x = 0; x <= W; x += 8) (x ? g.lineTo(x, edge(x)) : g.moveTo(x, edge(x)))
  g.lineWidth = 11
  g.strokeStyle = INK
  g.lineJoin = 'round'
  g.stroke()
  g.fillStyle = '#fff8e7'
  for (let k = 0; k < 28; k++) {
    const x = (k * W) / 28 + (k % 2 ? 18 : 0)
    const y = 52 + (k % 3) * 42
    g.beginPath()
    g.arc(x, y, 10, 0, TAU)
    g.fill()
  }
  // 얼굴(정면 = u 0.25 → x 256, 적도 → y 256). 로고 그림과 같은 좌표(×4.6)
  g.save()
  g.translate(256, 256)
  g.scale(4.6, 4.6)
  g.lineCap = 'round'
  g.lineJoin = 'round'
  g.strokeStyle = INK
  g.fillStyle = INK
  g.lineWidth = 2.4
  g.stroke(new Path2D('M-34 -14 L-8 -4 M-8 -4 L33 -12'))
  g.beginPath()
  g.ellipse(-11, 0, 9.5, 8, 0, 0, TAU)
  g.fill()
  if (mood === 'pop') {
    g.lineWidth = 3
    g.stroke(new Path2D('M8 -6 L18 4 M18 -6 L8 4'))
  } else {
    g.beginPath()
    g.arc(13, -1, mood === 'scared' ? 4.6 : 3.2, 0, TAU)
    g.fill()
  }
  g.lineWidth = 2.4
  const must = new Path2D('M-11 12 Q-5.5 6 0 12 Q5.5 6 11 12')
  g.fill(must)
  g.stroke(must)
  g.lineWidth = 2.6
  if (mood === 'idle') g.stroke(new Path2D('M-7 19 q7 6 14 0'))
  else if (mood === 'scared') g.stroke(new Path2D('M-6 23 q6 -6 12 0'))
  else {
    g.beginPath()
    g.ellipse(0, 23, 6, 5.5, 0, 0, TAU)
    g.fill()
  }
  if (mood === 'scared') {
    g.fillStyle = '#4da3ff'
    g.lineWidth = 1.6
    const drop = new Path2D('M-30 -8 q3 5 0 9 q-3 -4 0 -9')
    g.fill(drop)
    g.stroke(drop)
  }
  g.restore()
  return c
}

function createScene(T: T3, canvas: HTMLCanvasElement, slot: HTMLElement, holes: number, io: { props: () => Props }): Ctl {
  const renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: true })
  renderer.setClearColor(0x000000, 0)
  const scene = new T.Scene()
  const camera = new T.PerspectiveCamera(36, 1 / 1.1, 0.1, 80)
  camera.position.set(0, 2.1, 7.7)
  camera.lookAt(0, 0.55, 0)
  scene.add(new T.AmbientLight(0xffffff, 2.3))
  const sun = new T.DirectionalLight(0xffffff, 2.2)
  sun.position.set(-3, 4, 5)
  scene.add(sun)

  const toon = new T.DataTexture(new Uint8Array([120, 195, 255]), 3, 1, T.RedFormat)
  toon.minFilter = toon.magFilter = T.NearestFilter
  toon.needsUpdate = true
  const mats = new Map<string, THREE.MeshToonMaterial>()
  const mat = (c: string) => {
    let m = mats.get(c)
    if (!m) mats.set(c, (m = new T.MeshToonMaterial({ color: c, gradientMap: toon })))
    return m
  }
  const inkMat = new T.MeshBasicMaterial({ color: INK, side: T.BackSide })
  const flat = (c: string, extra?: THREE.MeshBasicMaterialParameters) => new T.MeshBasicMaterial({ color: c, ...extra })
  const textures: THREE.Texture[] = []
  const canvasTex = (c: HTMLCanvasElement) => {
    const t = new T.CanvasTexture(c)
    t.colorSpace = T.SRGBColorSpace
    textures.push(t)
    return t
  }

  /** 뒤집힌 껍질(inverted hull) 윤곽선: 같은 모양을 g 만큼 키워 잉크색 뒷면으로 */
  const withInk = (geo: THREE.BufferGeometry, m: THREE.Material, g: number, parent: THREE.Object3D) => {
    geo.computeBoundingBox()
    const s = geo.boundingBox!.getSize(new T.Vector3())
    const mesh = new T.Mesh(geo, m)
    const hull = new T.Mesh(geo, inkMat)
    hull.scale.set(1 + (2 * g) / Math.max(s.x, 0.05), 1 + (2 * g) / Math.max(s.y, 0.05), 1 + (2 * g) / Math.max(s.z, 0.05))
    const holder = new T.Group()
    holder.add(hull, mesh)
    parent.add(holder)
    return { mesh, holder }
  }

  const shake = new T.Group()
  const spin = new T.Group()
  shake.add(spin)
  scene.add(shake)

  // 몸통: 판자 색 + 무늬 캔버스 텍스처
  const bodyTex = canvasTex(paintBody(holes))
  bodyTex.wrapS = T.RepeatWrapping
  bodyTex.anisotropy = 4
  const profile = Array.from({ length: 29 }, (_, i) => {
    const y = -HALF + (2 * HALF * i) / 28
    return new T.Vector2(radiusAt(y), y)
  })
  const bodyMat = new T.MeshToonMaterial({ map: bodyTex, gradientMap: toon })
  const body = withInk(new T.LatheGeometry(profile, 72), bodyMat, 0.05, spin).mesh
  // 윗면: 테두리 + 어두운 안쪽
  const rTop = radiusAt(HALF)
  const rim = new T.Mesh(new T.RingGeometry(rTop - 0.2, rTop - 0.005, 64), flat('#f0b866', { side: T.DoubleSide }))
  rim.rotation.x = -Math.PI / 2
  rim.position.y = HALF + 0.003
  const rimInk = new T.Mesh(new T.RingGeometry(rTop - 0.27, rTop - 0.2, 64), flat(INK, { side: T.DoubleSide }))
  rimInk.rotation.x = -Math.PI / 2
  rimInk.position.y = HALF + 0.004
  const inner = new T.Mesh(new T.CircleGeometry(rTop - 0.27, 48), flat('#2a1608'))
  inner.rotation.x = -Math.PI / 2
  inner.position.y = 0.2
  const innerWall = new T.Mesh(new T.CylinderGeometry(rTop - 0.22, rTop - 0.27, HALF - 0.2, 48, 1, true), flat('#3a1f0e', { side: T.BackSide }))
  innerWall.position.y = (HALF + 0.2) / 2
  spin.add(rim, rimInk, inner, innerWall)
  // 쇠테 2개
  for (const y of [1.12, -1.12]) {
    const { holder } = withInk(new T.TorusGeometry(radiusAt(y) + 0.03, 0.085, 10, 72), mat('#b8c0d0'), 0.04, spin)
    holder.rotation.x = Math.PI / 2
    holder.position.y = y
  }

  // 구멍
  const layout = holeLayout(holes)
  const ZV = new T.Vector3(0, 0, 1)
  const hole = layout.map(({ phi, y }, h) => {
    const r = radiusAt(y)
    const pos = new T.Vector3(r * Math.sin(phi), y, r * Math.cos(phi))
    const n = new T.Vector3(Math.sin(phi), -slopeAt(y), Math.cos(phi)).normalize()
    const g = new T.Group()
    g.position.copy(pos)
    g.quaternion.setFromUnitVectors(ZV, n)
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, z: number) => {
      const me = new T.Mesh(geo, m)
      me.position.z = z
      g.add(me)
      return me
    }
    add(new T.CircleGeometry(0.29, 24), flat(INK), 0.018)
    add(new T.CircleGeometry(0.22, 24), flat('#2a1608'), 0.024)
    const ring = new T.Group()
    ring.position.z = 0.03
    ring.add(new T.Mesh(new T.RingGeometry(0.29, 0.44, 28), flat(INK)))
    const lime = new T.Mesh(new T.RingGeometry(0.31, 0.39, 28), flat('#b7f34a'))
    lime.position.z = 0.003
    ring.add(lime)
    ring.visible = false
    g.add(ring)
    const hit = add(new T.CircleGeometry(0.34, 12), flat('#000', { colorWrite: false, depthWrite: false }), 0.06)
    hit.userData.hole = h
    spin.add(g)
    return { phi, y, pos, n, g, ring, hit }
  })
  const flash = new T.Mesh(new T.RingGeometry(0.3, 0.4, 28), flat('#ff5e5b', { transparent: true }))
  flash.visible = false
  spin.add(flash)

  // 칼
  const swords = new Map<number, { g: THREE.Group; t0: number }>()
  const sword = (h: number, color: string) => {
    const o = hole[h]!
    const g = new T.Group()
    const X = new T.Vector3().crossVectors(new T.Vector3(0, 1, 0), o.n).normalize()
    const Z = new T.Vector3().crossVectors(X, o.n)
    g.quaternion.setFromRotationMatrix(new T.Matrix4().makeBasis(X, o.n, Z))
    const part = (geo: THREE.BufferGeometry, m: THREE.Material, y: number) => withInk(geo, m, 0.035, g).holder.position.set(0, y, 0)
    part(new T.BoxGeometry(0.22, 0.3, 0.07), mat('#c9d3e3'), 0.15)
    // 가로대는 칼 축을 도는 각이 구멍마다 다르고, 칼도 구멍마다 살짝 기울어 있다 (swordVar: 구멍 번호만의 함수)
    const v = swordVar(h)
    withInk(new T.BoxGeometry(0.52, 0.11, 0.15), mat(color), 0.035, g).holder.position.set(0, 0.33, 0)
    g.children[g.children.length - 1]!.rotation.y = v.guard
    g.quaternion.multiply(new T.Quaternion().setFromEuler(new T.Euler(((v.tilt * Math.PI) / 180) * 0.9, 0, (((v.tilt * Math.PI) / 180) * (v.guard > 1.6 ? -1 : 1)))))
    part(new T.CylinderGeometry(0.075, 0.075, 0.22, 10), mat('#8a5a2b'), 0.5)
    part(new T.SphereGeometry(0.14, 14, 10), mat(color), 0.68)
    g.position.copy(o.pos)
    spin.add(g)
    return g
  }

  // ---- 해적: 통(spin)의 자식이라 통을 돌리면 같이 돈다 ----
  const pirate = new T.Group()
  pirate.position.set(0, REST_Y, 0)
  pirate.rotation.order = 'YXZ'
  spin.add(pirate)
  const faceTex: Record<Mood, THREE.CanvasTexture> = { idle: canvasTex(paintFace('idle')), scared: canvasTex(paintFace('scared')), pop: canvasTex(paintFace('pop')) }
  faceTex.idle.anisotropy = faceTex.scared.anisotropy = faceTex.pop.anisotropy = 4
  const headMat = new T.MeshToonMaterial({ map: faceTex.idle, gradientMap: toon, color: 0xc4c4c4 })
  const headHolder = withInk(new T.SphereGeometry(HEAD_R, 40, 28), headMat, 0.045, pirate).holder
  headHolder.position.y = HEAD_Y
  // 두건 매듭 + 꼬리(뒤통수)
  const red = mat('#ff5e5b')
  const knot = withInk(new T.SphereGeometry(0.13, 12, 10), red, 0.03, headHolder).holder
  knot.position.set(0, 0.3, -HEAD_R - 0.02)
  for (const k of [-1, 1]) {
    const tail = withInk(new T.ConeGeometry(0.15, 0.5, 4), red, 0.03, headHolder).holder
    tail.position.set(k * 0.14, 0.12, -HEAD_R - 0.1)
    tail.rotation.set(0.1, 0, k * 0.5 + Math.PI)
  }
  // 줄무늬 셔츠(빨강·하양)
  const shirt = document.createElement('canvas')
  shirt.width = 4
  shirt.height = 128
  const sg = shirt.getContext('2d')!
  for (let i = 0; i < 8; i++) {
    sg.fillStyle = i % 2 ? '#fff8e7' : '#ff5e5b'
    sg.fillRect(0, i * 16, 4, 16)
  }
  const shirtTex = canvasTex(shirt)
  shirtTex.wrapS = shirtTex.wrapT = T.RepeatWrapping
  const shirtMat = new T.MeshToonMaterial({ map: shirtTex, gradientMap: toon, color: 0xc4c4c4 })
  withInk(new T.CapsuleGeometry(0.46, 1.0, 6, 20), shirtMat, 0.04, pirate)
  const arm = (side: -1 | 1) => {
    const pivot = new T.Group()
    pivot.position.set(side * 0.58, 0.62, 0)
    pirate.add(pivot)
    withInk(new T.CapsuleGeometry(0.15, 0.5, 4, 12), shirtMat, 0.035, pivot).holder.position.y = -0.33
    withInk(new T.SphereGeometry(0.18, 14, 10), mat('#ffe0b0'), 0.035, pivot).holder.position.y = -0.8
    return pivot
  }
  const armL = arm(-1)
  const armR = arm(1)

  // ---- 상태 ----
  let ang = 0
  let target = 0
  let vel = 0
  let showT0 = -1
  let showFrom = 0
  let showTo = 0
  let launchT0 = -1
  let shiverT0 = -1
  let faceOff = 0 // 해적이 통 기준으로 더 돌아야 정면을 보는 각(rad, 최단 경로). 꽂힌 칼이 정면에 올 때의 통 각도로만 정해져 모든 폰이 같다
  let faceT0 = -1e9
  let state: BarrelProps['head'] = 'idle'
  let trapIdx = 0
  let lastAimN: number | null = null
  let lastAimAt = 0
  let locked = false
  let tween: { t0: number; from: number; to: number; dur: number } | null = null
  let disposed = false
  let raf = 0
  let lastT = 0
  let dragging = false
  let lastSend = 0
  let size = { w: 0, h: 0 }
  let rectKey = ''
  let mounted = false
  const unwrap = (a: number) => a + TAU * Math.round((ang - a) / TAU)
  const phiOf = (h: number) => hole[h]?.phi ?? 0
  /** phi 번 구멍이 정면에서 SHOW_YAW 만큼 옆으로 보이는 통 각도 */
  const showAngle = (h: number) => unwrap(-phiOf(h) + SHOW_YAW)
  const send = (final: boolean) => {
    const now = performance.now()
    if (!final && now - lastSend < 80) return
    lastSend = now
    io.props().onAim?.(ang)
  }

  const kick = () => {
    if (!raf && !disposed) raf = requestAnimationFrame(frame)
  }

  /** 통이 자리(slot) 칸 안에 정확히 보이도록 투영을 옮긴다. 캔버스는 화면 전체 */
  const fit = () => {
    const r = slot.getBoundingClientRect()
    const key = `${r.left.toFixed(1)}|${r.top.toFixed(1)}|${r.width.toFixed(1)}|${r.height.toFixed(1)}|${size.w}|${size.h}`
    if (key === rectKey || !r.width || !r.height || !size.w) return
    rectKey = key
    camera.aspect = r.width / r.height
    camera.setViewOffset(r.width, r.height, -r.left, -r.top, size.w, size.h)
    camera.updateProjectionMatrix()
  }

  const update = (now: number, dt: number): boolean => {
    const rm = reduced()
    let active = false
    // 각도
    if (showT0 >= 0 && now - showT0 < SHOW_MS && !rm) {
      ang = showFrom + (showTo - showFrom) * smooth((now - showT0) / SHOW_MS)
      active = true
    } else if (dragging) {
      active = true
    } else if (tween && !rm) {
      const k = (now - tween.t0) / tween.dur
      if (k >= 1) { ang = target = tween.to; tween = null } else ang = tween.from + (tween.to - tween.from) * smooth(k)
      active = true
    } else if (Math.abs(vel) > 0.05 && !rm) {
      ang += vel * dt
      target = ang
      vel *= Math.exp(-dt * 3.2)
      send(Math.abs(vel) <= 0.05)
      if (Math.abs(vel) <= 0.05) vel = 0
      active = true
    } else {
      const d = target - ang
      if (rm || Math.abs(d) < 0.0006) ang = target
      else {
        ang += d * (1 - Math.exp(-dt / 0.045))
        active = true
      }
    }
    spin.rotation.y = ang
    // 해적
    let pose: PiratePose = REST
    let mood: Mood = 'idle'
    if (state === 'scared') {
      pose = { ...REST, x: Math.sin(now / 28) * 0.04 }
      mood = 'scared'
      active = true
    } else if (state === 'squash') {
      // 칼이 꽂힌 직후 1초(holdMs)는 반응 없이 평소 모습 그대로(얼굴만 정면으로 돌림, 아래 facing)
      pose = REST
    } else if (state === 'shiver') {
      const t = rm ? 0 : (now - shiverT0) / 1000
      const s = shiverPose(t)
      pose = s.pose
      mood = 'scared'
      shake.position.x = Math.sin(t * 63) * 0.035 * s.amp
      shake.rotation.z = Math.sin(t * 49 + 1) * 0.012 * s.amp
      flash.visible = false
      if (t < SHIVER_S) active = true
    } else if (state === 'launch' || state === 'out') {
      const t = state === 'out' ? 99 : (now - launchT0) / 1000
      pose = launchPose(rm ? Math.min(t, 0.4) : Math.min(t, END_S), trapIdx, rm)
      mood = 'pop'
      if (t < END_S) active = true
      // 통 흔들림 + 터진 구멍 번쩍
      if (t < 0.6 && !rm) {
        const k = Math.exp(-t * 5)
        shake.position.x = Math.sin(t * 60) * 0.14 * k
        shake.rotation.z = Math.sin(t * 52 + 1) * 0.04 * k
      } else {
        shake.position.x = 0
        shake.rotation.z = 0
      }
      if (t < 1.5 && !rm) {
        const f = (t / 0.5) % 1
        flash.visible = true
        flash.scale.setScalar(0.6 + 0.9 * f)
        ;(flash.material as THREE.MeshBasicMaterial).opacity = 1 - f
      } else flash.visible = false
    } else {
      shake.position.x = 0
      shake.rotation.z = 0
      flash.visible = false
    }
    pirate.position.set(pose.x, pose.y, 0)
    const facing = state === 'squash' || state === 'shiver' || state === 'launch' || state === 'out'
    const fw = !facing ? 0 : rm ? 1 : smooth(clamp01((now - faceT0) / 300))
    if (fw < 1 && fw > 0) active = true
    pirate.rotation.set(0, pose.rotY + fw * faceOff, pose.rotZ)
    pirate.scale.set(pose.sx, pose.sy, pose.sx)
    armL.rotation.z = -pose.armL
    armR.rotation.z = pose.armR
    if (headMat.map !== faceTex[mood]) headMat.map = faceTex[mood]
    for (const [h, s] of swords) {
      const u = clamp01((now - s.t0) / 250)
      if (u < 1) active = true
      s.g.position.copy(hole[h]!.pos).addScaledVector(hole[h]!.n, (1 - smooth(u)) * 0.7)
    }
    slot.setAttribute('data-angle', ang.toFixed(3))
    return active
  }
  const frame = () => {
    raf = 0
    if (disposed) return
    const now = performance.now()
    const dt = Math.min(0.05, lastT ? (now - lastT) / 1000 : 0.016)
    lastT = now
    const active = update(now, dt)
    fit()
    renderer.render(scene, camera)
    if (active) raf = requestAnimationFrame(frame)
    else lastT = 0
  }

  // ---- 입력: 자리(slot) 칸이 포인터를 받고, 화면 전체 캔버스 좌표로 바꿔 광선을 쏜다 ----
  const ray = new T.Raycaster()
  const tap = (cx: number, cy: number) => {
    const p = io.props()
    if (!p.tappable || !p.onPick) return
    fit()
    ray.setFromCamera(new T.Vector2((cx / size.w) * 2 - 1, -((cy / size.h) * 2 - 1)), camera)
    scene.updateMatrixWorld(true)
    const free = hole.filter((_, h) => !swords.has(h)).map((o) => o.hit)
    const hits = ray.intersectObjects([body, ...free], false)
    const first = hits[0]
    if (first && first.object.userData.hole !== undefined) p.onPick(first.object.userData.hole as number)
  }
  let down: { id: number; x0: number; y0: number; lx: number; lt: number; moved: boolean } | null = null
  const K = 0.0075
  const onDown = (e: PointerEvent) => {
    if (down || e.button > 0) return
    down = { id: e.pointerId, x0: e.clientX, y0: e.clientY, lx: e.clientX, lt: performance.now(), moved: false }
    slot.setPointerCapture?.(e.pointerId)
    vel = 0
  }
  const onMove = (e: PointerEvent) => {
    if (!down || e.pointerId !== down.id) return
    if (!down.moved && Math.hypot(e.clientX - down.x0, e.clientY - down.y0) > 8) down.moved = true
    if (!down.moved || !io.props().tappable || locked) return
    const now = performance.now()
    const dx = e.clientX - down.lx
    const dt = Math.max(8, now - down.lt) / 1000
    ang += dx * K
    target = ang
    vel = vel * 0.6 + ((dx * K) / dt) * 0.4
    down.lx = e.clientX
    down.lt = now
    dragging = true
    send(false)
    kick()
  }
  const onUp = (e: PointerEvent) => {
    if (!down || e.pointerId !== down.id) return
    const d = down
    down = null
    if (!d.moved) return tap(e.clientX, e.clientY)
    if (dragging) {
      dragging = false
      if (performance.now() - d.lt > 90 || reduced()) vel = 0
      vel = Math.max(-9, Math.min(9, vel))
      if (Math.abs(vel) <= 0.05) send(true)
      kick()
    }
  }
  const onCancel = (e: PointerEvent) => {
    if (down && e.pointerId === down.id) {
      down = null
      if (dragging) { dragging = false; send(true) }
    }
  }
  slot.addEventListener('pointerdown', onDown)
  slot.addEventListener('pointermove', onMove)
  slot.addEventListener('pointerup', onUp)
  slot.addEventListener('pointercancel', onCancel)

  const resize = () => {
    const w = window.innerWidth
    const h = window.innerHeight
    if (!w || !h || (w === size.w && h === size.h)) return kick()
    size = { w, h }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    renderer.setSize(w, h, false)
    rectKey = ''
    kick()
  }
  const relayout = () => kick()
  window.addEventListener('resize', resize)
  window.addEventListener('scroll', relayout, true)
  window.visualViewport?.addEventListener('resize', resize)
  const ro = new ResizeObserver(relayout)
  ro.observe(slot)
  resize()

  const sync = (p: Props) => {
    if (disposed) return
    const first = !mounted
    // 칼 (꽂아도 통은 돌리지 않는다)
    const want = new Map(p.stuck?.map((s, i) => [s.hole, { s, i }]))
    for (const [h, v] of swords) if (!want.has(h)) { spin.remove(v.g); swords.delete(h) }
    for (const [h, { s, i }] of want) {
      if (swords.has(h) || !hole[h]) continue
      const g = sword(h, s.color)
      swords.set(h, { g, t0: i >= (p.freshFrom ?? Infinity) && !first ? performance.now() : -1e9 })
    }
    // 내 차례면 빈 구멍에 연두 링
    hole.forEach((o, h) => { o.ring.visible = !!p.tappable && !swords.has(h) })
    const showing = p.head === 'squash' || p.head === 'shiver' || p.head === 'launch' || p.head === 'out'
    // 다른 사람이 돌리는 각도
    if (p.aim && p.aim.n !== lastAimN) {
      const mine = !!p.tappable && !p.aim.auto
      if (lastAimN !== null && !mine && !showing) {
        const now = performance.now()
        const to = unwrap(p.aim.angle)
        if (p.aim.auto) { locked = true; dragging = false; down = null }
        vel = 0
        const dist = Math.abs(to - ang)
        // 사람이 끌 때처럼 잦은 작은 갱신(≤200ms 간격·작은 폭)은 120ms 로 따라가고, 띄엄띄엄 큰 이동은 거리에 비례해 부드럽게 (350~800ms)
        if (dist > 0.12 && (now - lastAimAt > 200 || p.aim.auto)) {
          tween = { t0: now, from: ang, to, dur: Math.max(350, Math.min(800, 350 + dist * 280)) }
          target = to
        } else { tween = null; target = to }
        lastAimAt = now
      }
      lastAimN = p.aim.n
    } else if (!p.aim) { lastAimN = null; locked = false }
    if (!p.tappable) locked = false
    // 해적 상태
    if (p.head !== state) {
      const now = performance.now()
      const prev = state
      state = p.head ?? 'idle'
      const t = p.trap ?? p.stuck?.[p.stuck.length - 1]?.hole ?? 0
      trapIdx = t
      if (state === 'squash' || state === 'out' || ((state === 'shiver' || state === 'launch') && showT0 < 0)) {
        const a = -showAngle(t)
        faceOff = a - TAU * Math.round(a / TAU) // (-π, π]: 가장 짧게 돌아 카메라를 본다
        faceT0 = state === 'squash' ? now : -1e9
      }
      if (state === 'squash') {
        showT0 = now
        showFrom = ang
        showTo = showAngle(t)
        target = showTo
        dragging = false
        vel = 0
        const o = hole[t]
        if (o) { flash.position.copy(o.pos).addScaledVector(o.n, 0.05); flash.quaternion.copy(o.g.quaternion) }
      } else if (state === 'shiver') {
        shiverT0 = now
        if (showT0 < 0) { showT0 = now - SHOW_MS }
      } else if (state === 'launch') {
        launchT0 = now
        if (showT0 < 0) { showT0 = now - SHOW_MS }
      } else if (state === 'out') {
        showT0 = now - SHOW_MS
        launchT0 = now - 5000
        ang = target = showAngle(t)
        const o = hole[t]
        if (o) { flash.position.copy(o.pos); flash.quaternion.copy(o.g.quaternion) }
      } else if (prev === 'squash' || prev === 'shiver' || prev === 'launch' || prev === 'out') {
        showT0 = -1
        launchT0 = -1
      }
    }
    mounted = true
    rectKey = ''
    kick()
  }

  return {
    sync,
    dispose: () => {
      disposed = true
      cancelAnimationFrame(raf)
      ro.disconnect()
      window.removeEventListener('resize', resize)
      window.removeEventListener('scroll', relayout, true)
      window.visualViewport?.removeEventListener('resize', resize)
      slot.removeEventListener('pointerdown', onDown)
      slot.removeEventListener('pointermove', onMove)
      slot.removeEventListener('pointerup', onUp)
      slot.removeEventListener('pointercancel', onCancel)
      const seen = new Set<unknown>()
      scene.traverse((o) => {
        const m = o as THREE.Mesh
        if (m.geometry && !seen.has(m.geometry)) { seen.add(m.geometry); m.geometry.dispose() }
        const ms = Array.isArray(m.material) ? m.material : m.material ? [m.material] : []
        for (const x of ms) if (!seen.has(x)) { seen.add(x); x.dispose() }
      })
      for (const m of mats.values()) m.dispose()
      toon.dispose()
      for (const t of textures) t.dispose()
      renderer.dispose()
      renderer.forceContextLoss()
    },
  }
}

export function Barrel3D(props: Props) {
  const { aim: _aim, onAim: _onAim, ...flat } = props
  const [mode, setMode] = useState<'3d' | '2d'>('3d')
  const slot = useRef<HTMLDivElement>(null)
  const canvas = useRef<HTMLCanvasElement>(null)
  const latest = useRef(props)
  latest.current = props
  const ctl = useRef<Ctl | null>(null)

  useEffect(() => {
    if (mode !== '3d') return
    let dead = false
    let made: Ctl | undefined
    ;(async () => {
      try {
        const T = await import('three')
        if (dead) return
        made = createScene(T, canvas.current!, slot.current!, props.holes, { props: () => latest.current })
        ctl.current = made
        made.sync(latest.current)
      } catch {
        if (!dead) setMode('2d')
      }
    })()
    return () => {
      dead = true
      made?.dispose()
      ctl.current = null
    }
  }, [mode, props.holes])
  useEffect(() => { ctl.current?.sync(props) })

  if (mode === '2d') return <Barrel {...flat} />
  return (
    <>
      {/* 자리: 레이아웃 안의 투명한 칸. 포인터는 여기서 받고, 그림은 화면 전체 캔버스가 이 칸 위치에 맞춰 그린다 */}
      <div ref={slot} style={{ width: 'min(100%, 400px)', aspectRatio: '1 / 1.1', margin: '0 auto', touchAction: 'pan-y' }} data-head={props.head} role="img" aria-label={props.label ?? '해적 통'} />
      {createPortal(
        <canvas ref={canvas} aria-hidden="true" style={{ position: 'fixed', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 25, display: 'block' }} />,
        document.body,
      )}
    </>
  )
}
