import { Barrel, SWORD_COLORS } from './Barrel.tsx'

/** 통에 칼이 꽂히고 통이 흔들리다 해적이 쏙 올라오는 4초 반복 그림(Barrel 의 peek). size = 대략 가로 px */
export function Hero({ size = 160 }: { size?: number }) {
  return (
    <div aria-hidden="true" className="pirate-hero" style={{ width: size }}>
      <Barrel holes={12} peek label="" stuck={[{ hole: 1, color: SWORD_COLORS[0], initial: '' }, { hole: 6, color: SWORD_COLORS[3], initial: '' }, { hole: 10, color: SWORD_COLORS[2], initial: '' }]} />
    </div>
  )
}
