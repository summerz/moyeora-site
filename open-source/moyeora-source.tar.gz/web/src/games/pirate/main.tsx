import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { type PirateRoom, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { Shell } from '../../ui/Shell.tsx'
import { useSocket } from '../../ws.ts'
import { type Aim } from './Barrel3D.tsx'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { Tutorial } from './Tutorial.tsx'

const TUT_KEY = 'moyeora:pirate:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<PirateRoom | null>(null)
  const [error, setError] = useState<string>()
  const roomRef = useRef<PirateRoom | null>(null)
  const [aim, setAim] = useState<Aim | null>(null)
  const aimN = useRef(0)

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'pirate') return
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'error') {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    setRoom(null)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose, (m) => setAim({ angle: m.angle, n: ++aimN.current, auto: m.auto }))
  useEffect(() => { document.title = '꽂아! 펑! 해적! — 모여라' }, [])

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="pirate"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'pirate', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    screen = <Lobby room={room} hero={<Hero size={room.players.length > 4 ? 150 : 190} />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })} />
  } else {
    screen = <Play room={room} onPick={(hole) => send({ type: 'submit', choice: String(hole) })} onLobby={() => send({ type: 'lobby' })} aim={aim} onAim={(angle) => send({ type: 'aim', angle })} />
  }

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {error && room && <div role="alert" style={{ color: 'var(--red)', textAlign: 'center', marginTop: 10 }}>{error}</div>}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
