import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { PIRATE, POP_TIMING, holesComment, popBoomAtMs, turnOf, type PirateRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { StickerModal } from '../../ui/StickerModal.tsx'
import { MePill } from '../../ui/MePill.tsx'
import { boom, rattle, thud } from '../../ui/sound.ts'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { WaitBar } from '../../ui/WaitBar.tsx'
import { SWORD_COLORS, type Stuck } from './Barrel.tsx'
import { Barrel3D, LAUNCH_END_S, type Aim } from './Barrel3D.tsx'
import { OrderIntro } from '../../ui/OrderIntro.tsx'

type Props = { room: PirateRoom; onPick: (hole: number) => void; onLobby: () => void; aim: Aim | null; onAim: (angle: number) => void }

const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
const initialOf = (name: string | undefined) => (name ? ([...name][0] ?? '?') : '?')

const SPIKES = Array.from({ length: 32 }, (_, i) => {
  const a = (i * Math.PI) / 16
  const r = i % 2 ? 84 : 122
  return `${(125 + Math.sin(a) * r).toFixed(1)},${(125 - Math.cos(a) * r).toFixed(1)}`
}).join(' ')

/** 펑! 딱지. 3D 캔버스(z 25)보다 위(27)여야 해적 뒤에 가려지지 않는다. 캔버스처럼 body 에 fixed 로 띄우고, 통 자리(anchor) 윗변 근처에 놓는다. 모달(30)보다는 아래 */
function Boom({ out, anchor }: { out: boolean; anchor: HTMLElement | null }) {
  const r = anchor?.getBoundingClientRect()
  const style = r ? { left: r.left + r.width / 2, top: r.top + r.height * 0.2 } : { left: '50%', top: '30%' }
  return createPortal(
    <div className={out ? 'pirate-boom pirate-boom--out' : 'pirate-boom'} style={style} aria-hidden="true">
      <svg viewBox="0 0 250 250"><polygon points={SPIKES} fill="var(--cream)" stroke="var(--ink)" strokeWidth={6} strokeLinejoin="round" /></svg>
      <span className="pirate-boom__txt" style={{ color: '#ff5e5b' }}>펑!</span>
    </div>,
    document.body,
  )
}

export function Play(props: Props) {
  // 시작 직후 순서 정하기(intro)는 통 없이 칩 연출만 (훅 순서가 갈리지 않게 컴포넌트를 나눈다)
  return props.room.phase === 'intro' ? <OrderIntro players={props.room.players} order={props.room.g.order} me={props.room.you} remainingMs={props.room.remainingMs} /> : <PlayRound {...props} />
}

function PlayRound({ room, onPick, onLobby, aim, onAim }: Props) {
  const g = room.g
  const me = room.you
  const nameOf = (id: string) => room.players.find((p) => p.id === id)
  const colorOf = (id: string) => SWORD_COLORS[Math.max(0, g.order.indexOf(id)) % SWORD_COLORS.length]!
  // 꽂은 직후 쉬는 틈(settling)에는 차례 표시가 방금 꽂은 사람에게 남고, 끝나면 다음 사람으로 넘어간다
  const curId = g.popped ? null : g.settling && g.last ? g.last : turnOf(g.order, g.last, room.players.map((p) => p.id))
  const cur = curId ? nameOf(curId) : undefined
  const myTurn = curId === me
  const live = room.phase === 'choosing' && !g.settling && !g.popped
  const stuck: Stuck[] = g.used.map((u) => ({ hole: u.hole, color: colorOf(u.by), initial: initialOf(nameOf(u.by)?.name) }))
  const free = g.holes - g.used.length

  // 이미 터진 방에 들어온 경우는 애니메이션 없이 결과부터
  const late = useRef(g.popped).current
  const mountUsed = useRef(g.used.length).current
  const [popGo, setPopGo] = useState(late)
  const [showResult, setShowResult] = useState(late)
  const [boomGone, setBoomGone] = useState(false)
  const [shiver, setShiver] = useState(false)
  useEffect(() => {
    if (!g.popped || late) return
    const rm = reduced()
    // 모든 폰이 같은 순서(pop 갱신 도착 기준): 쇼케이스(0.75초) → 가만히(1초, 반응 없음) → 부들부들(1.2초, 점점 세게) → 잠깐 멈춤 → 펑!(발사) → 결과. 시간은 shared POP_TIMING
    const boomAt = popBoomAtMs(rm)
    const shiverAt = POP_TIMING.showMs + POP_TIMING.holdMs // 칼 꽂힌 직후 1초는 반응 없이 가만히 — 부들부들·덜그럭 소리는 이때부터
    const ts: ReturnType<typeof setTimeout>[] = []
    if (!rm) ts.push(setTimeout(() => { setShiver(true); rattle(POP_TIMING.shiverMs) }, shiverAt))
    ts.push(setTimeout(() => { setPopGo(true); boom(); navigator.vibrate?.([60, 40, 120]) }, boomAt))
    ts.push(setTimeout(() => setShowResult(true), rm ? boomAt + 700 : boomAt + Math.round(LAUNCH_END_S * 1000) + 150))
    ts.push(setTimeout(() => setBoomGone(true), rm ? boomAt + 700 : boomAt + 450)) // 해적이 나는 모습을 가리지 않게 먼저 걷는다
    return () => ts.forEach(clearTimeout)
  }, [g.popped, late])

  const n = g.used.length
  const prevN = useRef(n)
  const [auto, setAuto] = useState<{ by: string; n: number } | null>(null)
  useEffect(() => {
    if (n > prevN.current) {
      thud()
      const last = g.used[n - 1]
      if (last?.auto) setAuto({ by: last.by, n })
    }
    prevN.current = n
  }, [n, g.used])
  useEffect(() => {
    if (!auto) return
    const t = setTimeout(() => setAuto((a) => (a === auto ? null : a)), 2500)
    return () => clearTimeout(t)
  }, [auto])

  const sent = useRef(-1)
  const pick = (h: number) => {
    if (!live || !myTurn || sent.current === room.round) return
    sent.current = room.round
    navigator.vibrate?.(20)
    onPick(h)
  }

  const head = g.popped ? (late ? 'out' : popGo ? 'launch' : shiver ? 'shiver' : 'squash') : free <= 2 ? 'scared' : 'idle'
  const loser = g.loser ? nameOf(g.loser) : undefined
  const meLoser = g.loser === me
  const barrelBox = useRef<HTMLDivElement>(null)
  const isHost = room.host === me
  const autoName = auto ? nameOf(auto.by)?.name ?? '누군가' : ''

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <TurnCard
        fixed
        name={g.popped ? (loser?.name ?? null) : (cur?.name ?? null)}
        avatar={g.popped ? loser?.avatar : cur?.avatar}
        me={g.popped ? false : myTurn}
        meTitle={g.settling ? '꽂았어요!' : undefined}
        meHint={g.settling ? '다음 사람 차례로 넘어가요' : '빈 구멍을 찾아 꽂아요!'}
        hintOneLine
        other={g.popped || g.settling ? '님이 꽂았어요' : '님 차례'}
        none="…"
        right={live ? <Timer remainingMs={room.remainingMs} totalMs={PIRATE.chooseMs} /> : undefined}
      />
      <div className="pirate-info" role="status" data-auto={auto ? '1' : '0'}>
        {auto ? (
          auto.by === me ? (
            <span>시간 초과! 내 칼이 아무 데나 꽂혔어요</span>
          ) : (
            <>
              <span>시간 초과!</span>
              <span className="nick nick--sm nick--1l" style={{ flexShrink: 1 }}>{autoName}</span>
              <span>님 칼이 아무 데나 꽂혔어요</span>
            </>
          )
        ) : g.popped ? (
          <span>함정이었어요!</span>
        ) : (
          <span>{holesComment(free, g.holes)}</span>
        )}
      </div>
      {/* 통 자리: 여기는 칸(공간)만 잡고 터치만 받는다. 통 그림은 화면 전체를 덮는 오버레이 캔버스가 이 칸 위치에 맞춰 그린다(Barrel3D.tsx 맨 위 설명). 다른 게임과 달리 그림이 레이아웃 밖으로 나갈 수 있다 */}
      <div ref={barrelBox} style={{ position: 'relative', marginTop: 2 }}>
        <Barrel3D
          aim={g.popped ? null : aim}
          onAim={onAim}
          holes={g.holes}
          stuck={stuck}
          tappable={live && myTurn}
          onPick={pick}
          trap={g.trap}
          head={head}
          wobble={!g.popped && free <= 3}
          shake={popGo && !late}
          freshFrom={mountUsed}
        />
        {popGo && !late && <Boom out={showResult || boomGone} anchor={barrelBox.current} />}
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px 8px', justifyContent: 'center', paddingTop: 4 }}>
        {g.order.map((id, i) => {
          const p = nameOf(id)
          const turn = id === curId
          return (
            <span key={id} className="pirate-chip" data-me={id === me ? '1' : '0'} data-turn={turn ? '1' : '0'} data-gone={p ? '0' : '1'}>
              <b className="pirate-chip__no jua">{i + 1}</b>
              <i className="pirate-chip__dot" style={{ background: colorOf(id) }}>{initialOf(p?.name)}</i>
              <span className="nick nick--sm">{p?.name ?? '나감'}</span>
            </span>
          )
        })}
      </div>
      {!myTurn || g.popped || g.settling ? (!showResult ? <WaitBar>{g.popped ? '해적이 튀어나오는 중' : g.settling && myTurn ? '다음 차례로 넘어가는 중' : '차례를 기다리는 중'}</WaitBar> : null) : null}
      {showResult && g.popped && (
        <StickerModal lite tone={meLoser ? 'lime' : 'plain'} labelledBy="pirate-result">
          {meLoser && <MePill floating />}
          <div id="pirate-result" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, maxWidth: '100%' }}>
            <Avatar seed={loser?.avatar ?? 'x'} size={76} ring={meLoser} />
            <div style={{ minWidth: 0, display: 'flex', flexDirection: 'column' }}>
              <span className="jua" style={{ fontSize: 40, lineHeight: 1.1, color: '#e0443f' }}>펑!</span>
              {/* 닉네임과 "님 벌칙!" 이 한 줄 글자(.nick--lg)로 같은 크기. 긴 이름은 이름 안에서 줄바꿈 */}
              <span className="nick nick--lg" style={{ minWidth: 0 }}>
                {meLoser ? '내가 벌칙!' : <>{loser?.name ?? '누군가'}<span style={{ whiteSpace: 'nowrap' }}>님 벌칙!</span></>}
              </span>
            </div>
          </div>
          {isHost ? <button type="button" className="btn-sticker glow-box" data-tone="lime" onClick={onLobby}>다시 하기</button> : <WaitBar>방장을 기다리는 중</WaitBar>}
        </StickerModal>
      )}
    </div>
  )
}
