import './pirate.css'

/** 플레이어 칼 색. 연두(--lime)는 '나' 전용이라 쓰지 않는다 */
export const SWORD_COLORS = ['#ff5e5b', '#4da3ff', '#c77dff', '#ffd23f', '#ff9bd2', '#4de0c8', '#ff8a3d', '#ffffff'] as const

export type Stuck = { hole: number; color: string; initial: string }
export type Mood = 'idle' | 'scared' | 'pop'

const INK = '#0e0a1c'

/** 3D 통(LatheGeometry)과 같은 실루엣: 끝 반지름 1.25, 가운데 +0.3 볼록, 반높이 1.4. 가로 ≈ 높이 × 1.1 */
const CX = 170
const TOP = 100 // 윗면 타원 중심 y
const BOT = 324 // 아랫면 타원 중심 y
const RY = 24 // 윗·아랫면 타원 세로 반지름 (위에서 내려다본 원근)
const R_END = 100
const R_MID = 125.5 // 가운데 반지름 (= R_END × (1.55/1.25) 를 살짝 줄여 시각 균형)
const CTRL = 134 // 위 R_MID 를 만드는 3차 곡선 제어점 반지름
const MIDY = (TOP + BOT) / 2
/** 높이 y 에서의 통 반지름 */
const radiusAt = (y: number) => R_END + (R_MID - R_END) * (1 - ((y - MIDY) / ((BOT - TOP) / 2)) ** 2)
/** 통 둘레 u(-1..1, 정면 0)를 따라 위→아래로 내려가는 곡선 (널빤지 선·판자 경계) */
const curve = (u: number, y0 = TOP, y1 = BOT) => `C${CX + u * CTRL} ${y0 + (y1 - y0) * 0.22} ${CX + u * CTRL} ${y0 + (y1 - y0) * 0.78} ${CX + u * R_END} ${y1}`

const LAYOUT: Record<number, { rows: number[]; step: number; base: number }> = {
  12: { rows: [4, 4, 4], step: 0.44, base: 15 },
  16: { rows: [5, 6, 5], step: 0.34, base: 12.5 },
  20: { rows: [7, 6, 7], step: 0.28, base: 10.5 },
}
const ROW_Y = [176, 228, 280]

export const holePoints = (holes: number): { x: number; y: number; sx: number; rx: number; ry: number }[] => {
  const { rows, step, base } = LAYOUT[holes] ?? LAYOUT[12]!
  return rows.flatMap((n, r) => {
    // 4·4·4 는 행마다 반 칸씩 어긋나게 (위·아래 −¼칸, 가운데 +¼칸 → 전체가 가운데로 모여 가장자리에 덜 붙는다)
    const shift = holes === 12 ? (r === 1 ? step / 4 : -step / 4) : 0
    return Array.from({ length: n }, (_, i) => {
      const u = shift + (i - (n - 1) / 2) * step
      const c = Math.sqrt(Math.max(0, 1 - u * u))
      const y = ROW_Y[r]! + 8 * c // 정면일수록 조금 아래(위에서 내려다본 곡면)
      return { x: CX + radiusAt(ROW_Y[r]!) * u, y, sx: 0.4 + 0.6 * c, rx: base * (0.4 + 0.6 * c), ry: base * 0.8 }
    })
  })
}

/** 구멍 번호만으로 정해지는 칼 모양 변주 (모든 폰이 같게 본다): 손잡이 가로대가 칼 축을 도는 각(0~π), 칼 기울기(±5~8°) */
export const swordVar = (hole: number): { guard: number; tilt: number } => {
  const h = Math.imul(hole + 1, 2654435761) >>> 0
  const g = ((h >>> 3) & 1023) / 1024
  const t = ((h >>> 14) & 255) / 255
  const sgn = (h >>> 25) & 1 ? 1 : -1
  return { guard: g * Math.PI, tilt: sgn * (5 + 3 * t) }
}

/** 3D 해적과 같은 모습: 둥근 머리 + 흰 점 빨간 두건(매듭 꼬리) + 안대 + 콧수염. 좌표는 반지름 36 기준 */
export function PirateFace({ mood = 'idle' }: { mood?: Mood }) {
  const RED = '#ee5a52'
  return (
    <g>
      <circle cx={3} cy={3} r={36} fill={INK} />
      <circle r={36} fill="#e8c999" stroke={INK} strokeWidth={2.8} />
      <clipPath id="pirate-clip"><circle r={36} /></clipPath>
      <path d="M-26 8 Q-12 24 8 20 Q28 16 34 2 Q36 18 14 30 Q-10 38 -26 8Z" fill="#d6b17c" opacity={0.5} clipPath="url(#pirate-clip)" />
      <g clipPath="url(#pirate-clip)">
        <path d="M-40 -42 H40 V-14 Q0 -2 -40 -14 Z" fill={RED} stroke={INK} strokeWidth={2.8} />
        {[[-20, -27], [-3, -24], [14, -28], [27, -20], [-30, -18]].map(([x, y]) => <circle key={x} cx={x} cy={y} r={2.6} fill="#fff8e7" />)}
      </g>
      {/* 두건 매듭 + 꼬리 */}
      <g className="pirate-tails">
        <path d="M31 -22 L47 -36 L46 -17 Z M31 -22 L50 -12 L40 -6 Z" fill={RED} stroke={INK} strokeWidth={2.4} strokeLinejoin="round" />
        <circle cx={31} cy={-22} r={4.2} fill={RED} stroke={INK} strokeWidth={2.2} />
      </g>
      {/* 안대 */}
      <path d="M-35 -13 L-9 -3 M-9 -3 L34 -11" stroke={INK} strokeWidth={2.6} fill="none" strokeLinecap="round" />
      <ellipse cx={-12} cy={1} rx={10} ry={8.5} fill={INK} />
      {/* 눈 */}
      {mood === 'pop' ? (
        <g stroke={INK} strokeWidth={3} strokeLinecap="round"><path d="M8 -6 L18 4 M18 -6 L8 4" /></g>
      ) : (
        <circle className="pirate-eye" cx={13} cy={-1} r={mood === 'scared' ? 4.6 : 3.4} fill={INK} />
      )}
      {/* 콧수염 + 입 */}
      <path d="M-14 13 Q-7 5 0 12 Q7 5 14 13 Q7 16 0 14 Q-7 16 -14 13Z" fill={INK} stroke={INK} strokeWidth={2} strokeLinejoin="round" />
      {mood === 'idle' && <path d="M-6 21 q6 5 12 0" fill="none" stroke={INK} strokeWidth={2.6} strokeLinecap="round" />}
      {mood === 'scared' && <path d="M-6 25 q6 -6 12 0" fill="none" stroke={INK} strokeWidth={2.6} strokeLinecap="round" />}
      {mood === 'pop' && <ellipse cx={0} cy={25} rx={6} ry={5.5} fill={INK} />}
      {mood === 'scared' && <path d="M-26 -8 q3 5 0 9 q-3 -4 0 -9" fill="#4da3ff" stroke={INK} strokeWidth={1.6} transform="translate(-4 0)" />}
    </g>
  )
}

/** 줄무늬 셔츠 어깨: 통 테두리 위로 어깨만 보인다 */
function Shoulders() {
  return (
    <g>
      <clipPath id="pirate-shirt"><path d="M-62 44 Q-64 6 -34 0 L34 0 Q64 6 62 44 Z" /></clipPath>
      <path d="M-62 44 Q-64 6 -34 0 L34 0 Q64 6 62 44 Z" fill="#fff8e7" />
      <g clipPath="url(#pirate-shirt)">{[2, 14, 26, 38].map((y) => <rect key={y} x={-70} y={y} width={140} height={6} fill="#ee5a52" />)}</g>
      <path d="M-62 44 Q-64 6 -34 0 L34 0 Q64 6 62 44" fill="none" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
    </g>
  )
}

/** 꽂힌 칼: 칼날은 구멍 안, 손잡이만 비스듬히 튀어나온다 */
function Sword({ s, x, y, fresh }: { s: Stuck; x: number; y: number; fresh: boolean }) {
  const v = swordVar(s.hole)
  // 가로대가 칼 축을 도는 만큼 폭이 줄어 보인다 (정면 1 → 옆면 0.3)
  const c = 0.3 + 0.7 * Math.abs(Math.cos(v.guard))
  return (
    <g transform={`translate(${x} ${y}) rotate(${v.tilt.toFixed(1)}) scale(1.2)`}>
      <g className={fresh ? 'pirate-stab' : undefined}>
        <line x1={0} y1={0} x2={5} y2={-5} stroke={INK} strokeWidth={7} strokeLinecap="round" />
        <line x1={0} y1={0} x2={5} y2={-5} stroke="#c9d3e3" strokeWidth={3} strokeLinecap="round" />
        <g transform={`translate(5.95 -5.95) rotate(45) scale(${c.toFixed(2)} 1) rotate(-45) translate(-5.95 5.95)`}>
          <line x1={9.9} y1={0} x2={0} y2={-9.9} stroke={INK} strokeWidth={9} strokeLinecap="round" transform="translate(1 -1)" />
          <line x1={9.9} y1={0} x2={0} y2={-9.9} stroke={s.color} strokeWidth={5.4} strokeLinecap="round" transform="translate(1 -1)" />
        </g>
        <line x1={6} y1={-6} x2={13} y2={-13} stroke={INK} strokeWidth={7} strokeLinecap="round" />
        <line x1={6} y1={-6} x2={13} y2={-13} stroke="#8a5a2b" strokeWidth={3.4} strokeLinecap="round" />
        <circle cx={15} cy={-15} r={8} fill={s.color} stroke={INK} strokeWidth={2.4} />
        <text x={15} y={-14.8} textAnchor="middle" dominantBaseline="central" fontFamily="Jua, sans-serif" fontSize={10.5} fill={INK}>{s.initial}</text>
      </g>
    </g>
  )
}

export type BarrelProps = {
  holes: number
  stuck?: Stuck[]
  /** 지금 누를 수 있다(빈 구멍에 연두 테두리) */
  tappable?: boolean
  onPick?: (hole: number) => void
  /** 해적이 터진 구멍 */
  trap?: number | null
  head?: 'idle' | 'scared' | 'squash' | 'shiver' | 'launch' | 'out'
  wobble?: boolean
  shake?: boolean
  /** 튜토리얼: 이 구멍을 강조 */
  mark?: number
  /** 홈 그림: 가끔 고개를 쏙 내민다 */
  peek?: boolean
  /** 이미 꽂혀 있던 칼은 애니메이션 없이 */
  freshFrom?: number
  label?: string
}

export function Barrel({ holes, stuck = [], tappable = false, onPick, trap = null, head = 'idle', wobble = false, shake = false, mark, peek = false, freshFrom = Infinity, label }: BarrelProps) {
  const pts = holePoints(holes)
  const byHole = new Map(stuck.map((s, i) => [s.hole, { s, i }]))
  const mood: Mood = head === 'launch' || head === 'out' ? 'pop' : head === 'scared' || head === 'shiver' ? 'scared' : 'idle'
  const L = CX - R_END, R = CX + R_END
  const body = `M${L} ${TOP} Q${CX} ${TOP + 2 * RY} ${R} ${TOP} ${curve(1)} Q${CX} ${BOT + 2 * RY} ${L} ${BOT} ${curve(-1, BOT, TOP)} Z`
  const bandU = [-1, -0.67, -0.33, 0, 0.33, 0.67, 1]
  const bandC = ['#f4b05a', '#e68a34', '#f8c070', '#ea9640', '#f2a850', '#d6802c']
  // 훈은 통 단면 타원의 앞쪽 절반 (윗면 테두리와 같은 원근: 세로 반지름 RY)
  const hoop = (y: number) => { const r = radiusAt(y) + 3; return `M${CX - r} ${y} A${r} ${RY} 0 0 0 ${CX + r} ${y}` }
  return (
    <svg viewBox="30 36 280 316" width="100%" role="img" aria-label={label ?? '해적 통'} style={{ display: 'block', overflow: 'visible' }}>
      <g className={shake ? 'pirate-shake' : head === 'shiver' ? 'pirate-trem' : wobble ? 'pirate-wobble' : peek ? 'pirate-hero-jiggle' : undefined}>
        {/* 윗면: 테두리 + 어두운 안쪽 */}
        <ellipse cx={CX} cy={TOP} rx={R_END} ry={RY} fill="#f0b866" stroke={INK} strokeWidth={3} />
        <ellipse cx={CX} cy={TOP} rx={R_END - 13} ry={RY - 7} fill="#3a1f0e" stroke={INK} strokeWidth={2.4} />
        <g transform={`translate(${CX} ${TOP - 2})`}>
          <g className="pirate-head" data-head={head} data-peek={peek ? '1' : '0'}>
            <g transform="translate(0 6)"><Shoulders /></g>
            <g transform="translate(0 -14)"><PirateFace mood={mood} /></g>
          </g>
        </g>
        <clipPath id="pirate-body"><path d={body} /></clipPath>
        <path d={body} fill="#e8913a" />
        <g clipPath="url(#pirate-body)">
          {/* 널빤지마다 색을 달리 한 곡선 세로 띠 */}
          {bandC.map((c, i) => (
            <path key={i} d={`M${CX + bandU[i]! * R_END} ${TOP} ${curve(bandU[i]!)} L${CX + bandU[i]! * R_END} ${BOT + 40} L${CX + bandU[i + 1]! * R_END} ${BOT + 40} L${CX + bandU[i + 1]! * R_END} ${BOT} ${curve(bandU[i + 1]!, BOT, TOP)} Z`} fill={c} />
          ))}
          <path d={`M${CX + 0.55 * R_END} ${TOP} ${curve(0.55)} L${CX + 0.55 * R_END} ${BOT + 40} L${R + 40} ${BOT + 40} L${R + 40} ${TOP} Z`} fill="#7c4a20" opacity={0.28} />
          {bandU.slice(1, -1).map((u) => <path key={u} d={`M${CX + u * R_END} ${TOP + 8} ${curve(u, TOP + 8, BOT)}`} stroke="#8a5222" strokeWidth={2.4} fill="none" opacity={0.7} />)}
          {[130, 296].map((y) => (
            <g key={y}>
              <path d={hoop(y)} fill="none" stroke={INK} strokeWidth={16} />
              <path d={hoop(y)} fill="none" stroke="#cfd6ea" strokeWidth={10} />
              <path d={hoop(y - 2)} fill="none" stroke="#f3f6fc" strokeWidth={2.6} />
            </g>
          ))}
        </g>
        <path d={body} fill="none" stroke={INK} strokeWidth={3.4} strokeLinejoin="round" />
        {pts.map((p, h) => {
          const u = byHole.get(h)
          const free = !u
          const canTap = free && tappable && !!onPick
          return (
            <g key={h}>
              <ellipse cx={p.x} cy={p.y} rx={p.rx} ry={p.ry} fill="#2a1608" stroke={INK} strokeWidth={2.6} />
              <ellipse cx={p.x - 2 * p.sx} cy={p.y + 3} rx={p.rx * 0.53} ry={p.ry * 0.42} fill="#120a04" />
              {h === trap && <circle className="pirate-flash" cx={p.x} cy={p.y} r={p.rx + 8} fill="none" stroke="#ff5e5b" strokeWidth={4} />}
              {free && (canTap || h === mark) && (
                <ellipse className={h === mark ? 'pirate-mark' : 'pirate-ring'} cx={p.x} cy={p.y} rx={p.rx + 3} ry={p.ry + 3} fill="none" stroke="var(--lime)" strokeWidth={3.4} />
              )}
              {u && <Sword s={u.s} x={p.x} y={p.y} fresh={u.i >= freshFrom} />}
              {peek && h === 5 && <g className="pirate-hero-sword"><Sword s={{ hole: h, color: SWORD_COLORS[1], initial: '' }} x={p.x} y={p.y} fresh={false} /></g>}
              {canTap && (
                <circle cx={p.x} cy={p.y} r={Math.max(18, p.rx + 6)} fill="transparent" role="button" tabIndex={0} aria-label={`${h + 1}번 구멍`} style={{ cursor: 'pointer' }}
                  onClick={() => onPick(h)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(h) } }} />
              )}
            </g>
          )
        })}
      </g>
    </svg>
  )
}
