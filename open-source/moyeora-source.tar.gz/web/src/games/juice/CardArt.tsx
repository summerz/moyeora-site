import type { CSSProperties, ReactNode } from 'react'
import { JUICE_CARDS, juiceCardKind, type JuiceCard } from '@moyeora/shared'
import { DrinkArt } from './DrinkArt.tsx'
import { FeedbackMark } from '../../ui/FeedbackMark.tsx'
import './card.css'

export function CardFace({ kind, size = 92, label = true }: { kind: JuiceCard; size?: number; label?: boolean }) {
  return <><DrinkArt kind={kind} size={size} /><span className="jua juice-card-label" data-hidden={!label || undefined}>{label ? JUICE_CARDS[kind].name : '? ? ?'}</span></>
}

/** 두 카드에 걸쳐 중앙에 결과를 표시한다. 게임과 튜토리얼이 같은 구도를 쓴다. */
export function CardPair({ children, mark, className = '' }: { children: ReactNode; mark?: 'O' | '×' | null; className?: string }) {
  return <div className={`juice-card-pair ${className}`}>
    {children}
    {mark && <FeedbackMark mark={mark} className="juice-mark" />}
  </div>
}

/** 홈과 튜토리얼에서도 실제 카드의 앞면·테두리를 공유한다. */
export function CardArt({ kind, width = 100 }: { kind: JuiceCard; width?: number }) {
  return <div className="juice-card-frame juice-card-art" data-kind={juiceCardKind(kind)} data-art={kind} aria-hidden="true" style={{ '--juice-art-width': `${width}px` } as CSSProperties}>
    <CardFace kind={kind} size={width * .6} />
  </div>
}
