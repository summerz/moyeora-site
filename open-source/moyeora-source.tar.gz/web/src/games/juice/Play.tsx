import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react'
import { JUICE, JUICE_CARDS, juiceCardKind, juiceShowsLabel, type JuiceRoom, type JuiceReveal, type JuiceView } from '@moyeora/shared'
import { EliminationStrip } from '../../ui/EliminationStrip.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { TapButton } from '../../ui/TapButton.tsx'
import { useCountdownBeeps } from '../../ui/sound.ts'
import { useCountdown } from '../../ui/useCountdown.ts'
import { CardFace, CardPair } from './CardArt.tsx'
import { Reveal } from './Reveal.tsx'
import { juiceFeedback, preloadJuiceSounds, type JuiceFeedback } from './sound.ts'

type Props = { room: JuiceRoom; reveal: JuiceReveal | null; stageEnd: number; readyEnd: number; onPick: (side: number, elapsed: number) => void }
type OnFeedback = (step: number, result: JuiceFeedback) => void

function useBeatClock(end: number, active: boolean) {
  const [now, setNow] = useState(() => performance.now())
  useEffect(() => {
    if (!active) return
    let frame = 0
    const update = () => { setNow(performance.now()); frame = requestAnimationFrame(update) }
    frame = requestAnimationFrame(update)
    return () => cancelAnimationFrame(frame)
  }, [end, active])
  return Math.max(0, end - now)
}

function feedbackMark(g: JuiceView, pick: number | null, left: number, out: boolean, failed: boolean): 'O' | '×' | null {
  if (failed) return '×'
  if (out) return null
  if (pick !== null) return g.cards?.[pick] && juiceCardKind(g.cards[pick]) === 'juice' ? 'O' : '×'
  if (g.mode !== 'card' && g.mode !== 'gap') return null
  if (left > 0 && g.mode !== 'gap') return null
  return g.cards?.every((c) => juiceCardKind(c) === 'poison') ? 'O' : '×'
}

function Cards({ g, showLabel, end, out, failed, onPick, onFeedback }: { g: JuiceView; showLabel: boolean; end: number; out: boolean; failed: boolean; onPick: Props['onPick']; onFeedback: OnFeedback }) {
  const [pick, setPick] = useState<number | null>(null)
  const locked = useRef(false)
  const left = useBeatClock(end, g.mode === 'card')
  const mark = feedbackMark(g, pick, left, out, failed)
  const press = (side: number) => {
    if (locked.current || out || g.mode !== 'card' || performance.now() >= end) return
    locked.current = true
    setPick(side)
    const elapsed = Math.max(0, Math.round(g.windowMs - (end - performance.now())))
    const correct = g.cards?.[side] && juiceCardKind(g.cards[side]) === 'juice'
    onFeedback(g.step, correct ? 'success' : 'failure')
    if (correct) navigator.vibrate?.(15)
    else navigator.vibrate?.([40, 30, 40])
    onPick(side, elapsed)
  }
  return <div className="juice-stage" data-mode={g.mode} data-spectating={out && !failed}>
    <CardPair className="juice-cards" mark={mark}>
      {[0, 1].map((side) => {
        const kind = g.cards?.[side]
        return <button type="button" key={side} className="juice-card juice-card-frame" data-kind={kind ? juiceCardKind(kind) : 'back'} data-art={kind} disabled={out || g.mode !== 'card' || pick !== null || left === 0}
          aria-label={kind ? `${side === 0 ? '왼쪽' : '오른쪽'} ${JUICE_CARDS[kind].name}` : '카드 등장 중'}
          onPointerDown={(e) => { if (e.button === 0) { e.preventDefault(); press(side) } }} onClick={(e) => { if (e.detail === 0) press(side) }}>
          {kind ? <CardFace kind={kind} label={showLabel} /> : <span className="jua juice-back">?</span>}
        </button>
      })}
    </CardPair>
    <div className="juice-time-track" aria-hidden="true"><div style={{ transform: `scaleX(${g.mode === 'card' ? Math.min(1, left / g.windowMs) : 0})` }} /></div>
  </div>
}

export function Play({ room, reveal, stageEnd, readyEnd, onPick }: Props) {
  const { g } = room
  const me = g.runners.find((p) => p.id === room.you)
  const out = me?.outAt !== null && me?.outAt !== undefined
  const played = useRef(new Set<string>())
  const onFeedback = useCallback<OnFeedback>((step, result) => {
    const key = `${step}:${result}`
    if (played.current.has(key)) return
    played.current.add(key)
    juiceFeedback(result)
  }, [])
  useEffect(preloadJuiceSounds, [])
  useEffect(() => {
    if (room.phase !== 'choosing' || g.mode !== 'card' || out) return
    const noGo = g.cards?.every((c) => juiceCardKind(c) === 'poison')
    const timer = setTimeout(() => {
      if (played.current.has(`${g.step}:success`) || played.current.has(`${g.step}:failure`)) return
      onFeedback(g.step, noGo ? 'success' : 'failure')
    }, Math.max(0, stageEnd - performance.now()))
    return () => clearTimeout(timer)
  }, [room.phase, g.mode, g.step, g.cards, out, stageEnd, onFeedback])
  // 마지막 탈락으로 바로 결과 화면이 되어도 시간 초과 실패음은 재생한다.
  useEffect(() => {
    if (me?.outAt != null) onFeedback(me.outAt, 'failure')
    else if (me?.survived === g.step && g.step > 0) onFeedback(g.step, 'success')
  }, [me?.outAt, me?.survived, g.step, onFeedback])
  const readyLeft = useBeatClock(readyEnd, g.mode === 'ready' && room.phase === 'choosing')
  const resultLeft = useCountdown(room.phase === 'reveal' ? room.remainingMs : null)
  useCountdownBeeps(g.mode === 'ready' && room.phase === 'choosing' ? readyEnd : null)
  const eliminated = [...g.runners].filter((r) => r.outAt !== null).sort((a, b) => a.outAt! - b.outAt!)
  const ids = new Set(eliminated.map((r) => r.id))
  const showLabel = juiceShowsLabel(room.round)
  const bannerRoom = { players: room.players.map((p) => ({ ...p, submitted: ids.has(p.id) })) }
  return <div className="juice-play" style={{ '--juice-enter': `${JUICE.enterMs}ms`, '--juice-feedback': `${JUICE.feedbackMs}ms`, '--juice-exit': `${JUICE.exitMs}ms` } as CSSProperties}>
    {room.phase !== 'choosing' && reveal ? <>
      <Reveal room={room} reveal={reveal} />
      <p className="juice-hint">{room.phase === 'done' ? '곧 최종 순위가 나와요' : `다음 라운드까지 ${Math.ceil((resultLeft ?? 0) / 1000)}초 · 모두 다시 도전!`}</p>
    </> : <>
      <div className="juice-status" role="status">
        <div className="jua juice-heading">{out ? '관전 중 · 친구들을 응원해요' : g.mode === 'ready' ? (showLabel ? '주스는 누르고, 독약은 참기!' : '이제 이름 없이, 그림만 보고 찾아요!') : '주스만 톡! 둘 다 독약이면 멈춰요'}</div>
        <span className="juice-hint">{g.step ? `${g.step}번째 카드 · ${(g.windowMs / 1000).toFixed(2)}초 안에 판단!` : '좌우가 바뀌니 잘 보세요'}</span>
      </div>
      {g.mode === 'ready' ? <div className="juice-ready"><TapButton kind="ready" label={String(Math.max(1, Math.ceil(readyLeft / 1000)))} disabled onPress={() => {}} />{!showLabel && <div className="jua juice-heading">이름표가 사라졌어요</div>}</div> : <Cards key={g.step} g={g} showLabel={showLabel} end={stageEnd} out={out} failed={me?.outAt === g.step} onPick={onPick} onFeedback={onFeedback} />}
      <div className="jua juice-feedback" role="status">{out ? me?.outAt !== g.step ? room.round < room.rounds ? '다음 라운드에 다시 도전해요' : '최종 결과를 기다려요' : me?.reason === 'poison' ? '독약을 골랐어요!' : '시간 초과! 주스를 놓쳤어요' : me?.survived === g.step && g.step > 0 ? 'O 잘했어요!' : g.mode === 'gap' ? '다음 카드 준비!' : '\u00a0'}</div>
    </>}
    <SubmitBanner room={bannerRoom} label="탈락!" compact eliminated durationMs={600} />
    <EliminationStrip players={eliminated.flatMap((r) => room.players.filter((p) => p.id === r.id))} you={room.you} total={room.players.length} />
  </div>
}
