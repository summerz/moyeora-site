import type { JuiceCard } from '@moyeora/shared'

/** 모든 독약(5종)은 같은 해골 병뚜껑(SkullCap)을 쓰고, 병 안에 재료를 크게 그린다. 병 목은 x42~58, 뚜껑 아래 y32에서 만난다. */
function SkullCap() {
  return <>
    <rect x="42" y="28" width="16" height="9" rx="2" fill="#302040" />
    <path d="M50 2c-9 0-17 6-17 14 0 5 3 9 7 11v3h20v-3c4-2 7-6 7-14 0-8-8-11-17-11Z" fill="#fff8ef" strokeWidth="3" />
    <circle cx="43" cy="15" r="3.8" fill="#302040" stroke="none" /><circle cx="57" cy="15" r="3.8" fill="#302040" stroke="none" />
    <path d="m48 21 2-3 2 3Z" fill="#302040" strokeWidth="1.5" />
    <path d="M45 28v-3m5 3v-3m5 3v-3" strokeWidth="1.8" />
  </>
}

function AppleJuice() {
  return <>
    <path d="M52 19 58 7h16" stroke="#e95375" strokeWidth="6" />
    <path d="M22 36h42v68H22Z" fill="#eff6d5" />
    <path d="M64 36 80 30v68l-16 6Z" fill="#cfdca6" />
    <path d="m22 36 21-16 21 16Z" fill="#f8fbe8" />
    <path d="m43 20 16-6 21 16-16 6Z" fill="#dbe6b8" />
    <rect x="28" y="48" width="30" height="46" rx="5" fill="#8bcf6d" strokeWidth="3" />
    <g transform="translate(43 71) scale(.68) translate(-47 -66)">
      <path d="M47 53c-15-9-23 5-18 20 4 12 12 14 18 9 6 5 14 3 18-9 5-15-3-29-18-20Z" fill="#ef6470" strokeWidth="3.5" />
      <path d="m47 53-2-10" strokeWidth="3.5" />
      <path d="M47 49c1-9 8-12 15-9-1 8-7 11-15 9Z" fill="#67b86b" strokeWidth="3" />
    </g>
  </>
}

function GrapeJuice() {
  return <>
    <path d="M38 17h24v23c14 6 19 17 19 34v24c0 5-4 8-9 8H28c-5 0-9-3-9-8V74c0-17 5-28 19-34Z" fill="#ead8fb" />
    <path d="M23 60h54v38c0 3-2 4-5 4H28c-3 0-5-1-5-4Z" fill="#a073cf" stroke="none" />
    <rect x="34" y="8" width="32" height="14" rx="4" fill="#9bd77f" />
    <path d="M51 60c0-7 6-11 13-9-1 7-6 10-13 9Z" fill="#79c778" strokeWidth="2" />
    <path d="m50 62-1-4" strokeWidth="2.5" />
    <g fill="#b071d5" strokeWidth="2.5">
      <circle cx="38" cy="67" r="5.5" /><circle cx="50" cy="67" r="5.5" /><circle cx="62" cy="67" r="5.5" />
      <circle cx="44" cy="78" r="5.5" /><circle cx="56" cy="78" r="5.5" /><circle cx="50" cy="89" r="5.5" />
    </g>
  </>
}

function StrawberryJuice() {
  return <>
    <path d="m58 34 12-25h17" stroke="#78bdc6" strokeWidth="7" />
    <path d="M23 34h54l-7 66a6 6 0 0 1-6 5H36a6 6 0 0 1-6-5Z" fill="#fff0f1" />
    <path d="M27 47h46l-5 53H32Z" fill="#ef849e" stroke="none" />
    <path d="M34 61c-2 13 8 30 16 36 8-6 18-23 16-36-10-6-22-6-32 0Z" fill="#f75d72" strokeWidth="3" />
    <path d="m34 57 11 2 5-9 5 9 11-2-8 10-8-5-8 5Z" fill="#81c77b" strokeWidth="2.5" />
    <path d="m43 73 0 2m14-2v2m-7 5v2m-7 2v2m13-2v2m-6 2v2" stroke="#fff7ba" strokeWidth="2.5" />
  </>
}

function LemonJuice() {
  return <>
    <path d="M38 19h24v19l14 17v43c0 5-4 8-9 8H33c-5 0-9-3-9-8V55l14-17Z" fill="#fff8d6" />
    <path d="M28 58h44v40c0 3-2 4-5 4H33c-3 0-5-1-5-4Z" fill="#f6d858" stroke="none" />
    <rect x="34" y="9" width="32" height="15" rx="4" fill="#77bdab" />
    <g transform="translate(7.5 11.5) scale(.85)">
      <path d="M35 76c-3-2-3-6 0-8 5-18 28-22 32-5 4 14-14 29-27 22-4 1-7-4-5-9Z" fill="#ffe46b" strokeWidth="3.5" />
      <path d="M41 66c2-6 7-10 12-10" stroke="#fff9c0" strokeWidth="3" />
    </g>
    <path d="M55 63c-1-7 3-11 10-11 2 7-2 11-10 11Z" fill="#84c67c" strokeWidth="2.5" />
  </>
}

/** 뼈다귀(개뼈 모양). 원점 중심, 가로 길이 약 54. */
function Bone() {
  return <path d="M-16-4H16C16-9 22-9 23-5C27-4 27 3 23 4C22 8 16 8 16 4H-16C-16 8-22 8-23 4C-27 3-27-4-23-5C-22-9-16-9-16-4Z" fill="#fff8ef" strokeWidth="3" />
}

function SpiderPoison() {
  return <>
    <path d="M42 32h16v8l22 17v41c0 5-4 8-9 8H29c-5 0-9-3-9-8V57l22-17Z" fill="#ffd4d7" />
    <path d="M22 60h56v38c0 4-3 6-7 6H29c-4 0-7-2-7-6Z" fill="#eb7d88" stroke="none" />
    <path d="M43 62 33 53l-5 2M42 70 28 66l-4 5M42 78 28 80l-3 7M44 86 34 95l-4-1M57 62l10-9 5 2M58 70l14-4 4 5M58 78l14 2 3 7M56 86l10 9 4-1" strokeWidth="3" />
    <ellipse cx="50" cy="81" rx="12" ry="14" fill="#4a2a55" strokeWidth="3" />
    <circle cx="50" cy="63" r="8" fill="#4a2a55" strokeWidth="3" />
    <path d="M44 74h12l-12 15h12Z" fill="#ef4a63" stroke="none" />
    <circle cx="46.5" cy="62" r="2.2" fill="#ff7b8e" stroke="none" /><circle cx="53.5" cy="62" r="2.2" fill="#ff7b8e" stroke="none" />
    <SkullCap />
  </>
}

function FrogPoison() {
  return <>
    <path d="M42 32h16v8l28 14v46c0 5-4 9-10 9H24c-6 0-10-4-10-9V54l28-14Z" fill="#e4f5cf" />
    <path d="M16 60h68v38c0 4-3 7-8 7H24c-5 0-8-3-8-7Z" fill="#8bcf6d" stroke="none" />
    <ellipse cx="50" cy="80" rx="31" ry="18" fill="#35c24f" strokeWidth="3" />
    <circle cx="33" cy="60" r="8" fill="#35c24f" strokeWidth="3" /><circle cx="67" cy="60" r="8" fill="#35c24f" strokeWidth="3" />
    <circle cx="33" cy="60" r="5" fill="#ffe14d" strokeWidth="2" /><circle cx="67" cy="60" r="5" fill="#ffe14d" strokeWidth="2" />
    <g fill="#302040" stroke="none"><ellipse cx="33" cy="61" rx="1.7" ry="4" /><ellipse cx="67" cy="61" rx="1.7" ry="4" />
      <circle cx="30" cy="78" r="3.2" /><circle cx="70" cy="78" r="3.2" /><circle cx="39" cy="91" r="2.8" /><circle cx="61" cy="91" r="2.8" /><circle cx="50" cy="72" r="2.4" /></g>
    <path d="m24 54 14 5m38-5-14 5" strokeWidth="3.5" />
    <path d="M36 83q14 7 28 0" strokeWidth="3" />
    <SkullCap />
  </>
}

function MushroomPoison() {
  return <>
    <path d="M42 32h16v8c22 11 32 26 32 46 0 15-12 22-40 22S10 101 10 86c0-20 8-34 32-46Z" fill="#ffe0ec" />
    <path d="M17 68h66v17c0 11-9 17-33 17S17 96 17 85Z" fill="#ef849e" stroke="none" />
    <path d="M41 74h18l3 22c-7 3-17 3-24 0Z" fill="#fff5d5" strokeWidth="3" />
    <path d="M20 76c0-18 13-29 30-29s30 11 30 29c-20 7-40 7-60 0Z" fill="#d9385f" strokeWidth="3" />
    <g fill="#fff8ef" stroke="none"><circle cx="37" cy="66" r="5" /><circle cx="54" cy="57" r="4.5" /><circle cx="66" cy="70" r="4" /><circle cx="47" cy="73" r="2.6" /></g>
    <SkullCap />
  </>
}

function BatPoison() {
  return <>
    <path d="M42 32h16v8c14 5 30 12 30 29v31c0 5-4 8-9 8H21c-5 0-9-3-9-8V69c0-17 16-24 30-29Z" fill="#fff1b5" />
    <path d="M14 64h72v35c0 5-3 7-8 7H22c-5 0-8-2-8-7Z" fill="#f6d858" stroke="none" />
    <path d="M43 68 26 59q-1 11 3 17 5-2 7 6 5-4 8 2Z" fill="#7a5a99" strokeWidth="3" />
    <path d="M57 68l17-9q1 11-3 17-5-2-7 6-5-4-8 2Z" fill="#7a5a99" strokeWidth="3" />
    <path d="m43 54-2-8 7 5ZM57 54l2-8-7 5Z" fill="#7a5a99" strokeWidth="2.5" />
    <ellipse cx="50" cy="78" rx="8" ry="13" fill="#7a5a99" strokeWidth="3" />
    <circle cx="50" cy="62" r="9" fill="#7a5a99" strokeWidth="3" />
    <circle cx="46.5" cy="60.5" r="2.2" fill="#ffe14d" stroke="none" /><circle cx="53.5" cy="60.5" r="2.2" fill="#ffe14d" stroke="none" />
    <path d="m46 66 1.5 5 1.5-5m2 0 1.5 5 1.5-5" fill="#fff8ef" strokeWidth="1.5" />
    <SkullCap />
  </>
}

const NEW_DRINK_ART = { apple: AppleJuice, grape: GrapeJuice, strawberry: StrawberryJuice, lemon: LemonJuice, spider: SpiderPoison, frog: FrogPoison, mushroom: MushroomPoison, bat: BatPoison }

/** 카드·도움말·홈에서 같은 그림을 쓴다. 색뿐 아니라 실루엣과 표식도 다르다. */
export function DrinkArt({ kind, size = 100 }: { kind: JuiceCard; size?: number }) {
  const Art = kind !== 'juice' && kind !== 'poison' ? NEW_DRINK_ART[kind] : null
  return <svg width={size} height={size * 1.15} viewBox="0 0 100 115" aria-hidden="true" fill="none" stroke="#302040" strokeWidth="4" strokeLinejoin="round" strokeLinecap="round">
    {kind === 'juice' ? <>
      <path d="M60 37 70 9h17" stroke="#e95375" strokeWidth="7" />
      <path d="M23 35h54l-7 65a6 6 0 0 1-6 5H36a6 6 0 0 1-6-5Z" fill="#fff6d5" />
      <path d="M27 55h46l-5 44H32Z" fill="#ffae36" stroke="none" />
      <path d="m36 64 2 22" stroke="#fff4c6" strokeWidth="5" />
      <circle cx="66" cy="43" r="17" fill="#ffbf4c" />
      <circle cx="66" cy="43" r="11" fill="#ffe29b" strokeWidth="2" />
      <path d="m66 32 0 22m-11-11h22m-19-8 16 16m0-16L58 51" strokeWidth="1.5" />
    </> : kind === 'poison' ? <>
      <path d="M42 32h16v12c16 9 26 22 26 43 0 13-9 19-34 19S16 100 16 87c0-21 10-34 26-43Z" fill="#d7b9ff" />
      <path d="M22 70h56v18c0 9-6 12-28 12S22 97 22 88Z" fill="#9255c7" stroke="none" />
      <g transform="translate(50 77) scale(.88)">
        <g transform="rotate(35)"><Bone /></g><g transform="rotate(-35)"><Bone /></g>
      </g>
      <SkullCap />
    </> : Art && <Art />}
  </svg>
}
