import type { JuiceReveal, JuiceRoom } from '@moyeora/shared'
import { ResultRow, Stamp } from '../../ui/ResultRow.tsx'
import { Icon } from '../../ui/icons.tsx'

export function Reveal({ room, reveal }: { room: Pick<JuiceRoom, 'players' | 'you'>; reveal: JuiceReveal }) {
  return <div className="juice-results">
    <div className="jua juice-heading">이번 판 생존 순위!</div>
    {[...reveal.rows].sort((a, b) => a.rank - b.rank).map((r) => {
      const p = room.players.find((p) => p.id === r.id)
      if (!p) return null
      return <ResultRow key={r.id} p={p} me={p.id === room.you} lead={<span className="jua juice-rank" data-first={r.rank === 1}>{r.rank === 1 ? <Icon name="crown" size={18} color="var(--amber)" /> : r.rank}</span>}>
        <span className="juice-record">{r.survived}장 성공</span>
        <Stamp text={r.outAt === null ? '생존!' : r.reason === 'poison' ? '독약!' : r.reason === 'early' ? '너무 빨라!' : '시간 초과'} bg={r.outAt === null ? 'var(--amber)' : 'var(--red)'} />
        <span className="jua juice-score">+{r.delta}</span>
      </ResultRow>
    })}
  </div>
}
