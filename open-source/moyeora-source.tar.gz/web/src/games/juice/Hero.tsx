import { CardArt } from './CardArt.tsx'
import './hero.css'

export function Hero({ size = 130 }: { size?: number }) {
  return <div className="juice-hero" style={{ height: size * .95 }}>
    <div className="juice-hero-card" data-kind="juice"><CardArt kind="juice" width={size * .54} /></div>
    <div className="juice-hero-card" data-kind="poison" style={{ marginLeft: -size * .1 }}><CardArt kind="poison" width={size * .54} /></div>
  </div>
}
