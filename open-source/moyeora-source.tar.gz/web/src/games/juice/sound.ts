import { preloadSamples, sampleAt } from '../../ui/sound.ts'
import successUrl from '../../ui/sfx/success.wav'
import failureUrl from './sfx/failure.wav'

export type JuiceFeedback = 'success' | 'failure'
const sounds = { success: successUrl, failure: failureUrl }

export const preloadJuiceSounds = () => preloadSamples(Object.values(sounds))
export const juiceFeedback = (result: JuiceFeedback) => sampleAt(performance.now(), sounds[result])
