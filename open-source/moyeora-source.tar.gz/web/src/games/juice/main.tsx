import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { JUICE, type JuiceRoom, type JuiceReveal, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { Shell } from '../../ui/Shell.tsx'
import { useSocket } from '../../ws.ts'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { Tutorial } from './Tutorial.tsx'
import './juice.css'

const TUT_KEY = 'moyeora:juice:tutorial'
const tutorialSeen = () => { try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false } }

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<JuiceRoom | null>(null)
  const [reveal, setReveal] = useState<JuiceReveal | null>(null)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const roomRef = useRef<JuiceRoom | null>(null)
  const clock = useRef({ readyEnd: 0, stageEnd: 0 })
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'juice') return
      const next = m.room
      const prev = roomRef.current
      const newRound = !prev || prev.round !== next.round || (next.phase === 'choosing' && prev.phase !== 'choosing')
      if (newRound) {
        setReveal(null); setShowFinal(false); clearTimeout(finalTimer.current)
        clock.current.readyEnd = performance.now() + next.g.remainingMs
      }
      // 다른 사람의 입력으로 재전송해도 시간이 늘어나지 않도록, 앞면이 열릴 때 한 번만 고정한다.
      if (next.g.mode === 'card' && (newRound || prev?.g.step !== next.g.step || prev.g.mode !== 'card')) clock.current.stageEnd = performance.now() + next.g.remainingMs
      roomRef.current = next
      setRoom(next); setError(undefined)
    } else if (m.type === 'reveal') {
      setReveal(m.result as JuiceReveal)
      if (roomRef.current?.phase === 'done') finalTimer.current = setTimeout(() => setShowFinal(true), JUICE.revealMs)
    } else setError(errorText(m.message))
  }
  const onClose = () => {
    roomRef.current = null; clearTimeout(finalTimer.current)
    setRoom(null); setReveal(null); setShowFinal(false); setError('연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)
  const pick = (side: number, elapsed: number) => {
    const current = roomRef.current
    if (!current || current.phase !== 'choosing' || current.g.mode !== 'card') return
    send({ type: 'submit', choice: `${current.g.step}:${side}:${elapsed}` })
  }

  let screen
  if (!profile || editing) screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  else if (!room) screen = <Join game="juice" profile={profile} error={error} onEdit={() => setEditing(true)} onCreate={() => send({ type: 'create', game: 'juice', ...profile })} onJoin={(code) => send({ type: 'join', code, ...profile })} />
  else if (room.phase === 'lobby') screen = <Lobby room={room} hero={<Hero />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}><p className="juice-hint">5라운드 · 같은 카드에서 탈락하면 공동 순위</p></Lobby>
  else if (room.phase === 'done' && showFinal) screen = <Final room={room} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })} />
  else screen = <Play key={room.round} room={room} reveal={reveal} stageEnd={clock.current.stageEnd} readyEnd={clock.current.readyEnd} onPick={pick} />

  return <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={room && room.phase !== 'lobby' ? <span className="chip chip--lav">{room.round} / {room.rounds}</span> : undefined} onHelp={() => setTutorial(true)} confirmHome={room !== null && room.phase !== 'lobby' && room.phase !== 'done'}>
    {screen}
    {(tutorial || (!tutSeen && room?.phase === 'lobby')) && <Tutorial onClose={() => { setTutorial(false); setTutSeen(true); try { localStorage.setItem(TUT_KEY, '1') } catch {} }} />}
  </Shell>
}
createRoot(document.getElementById('root')!).render(<App />)
