import { JUICE_TYPES, POISON_TYPES, type JuiceReveal, type JuiceRoom } from '@moyeora/shared'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { Stamp } from '../../ui/ResultRow.tsx'
import { CardArt, CardPair } from './CardArt.tsx'
import { Hero } from './Hero.tsx'
import { Reveal } from './Reveal.tsx'

const sampleRoom: Pick<JuiceRoom, 'players' | 'you'> = {
  you: 'me',
  players: [
    { id: 'friend', name: '주스왕', avatar: 'juice-tut-friend', score: 2, submitted: true, bot: false },
    { id: 'me', name: '나', avatar: 'juice-tut-me', score: 1, submitted: true, bot: false },
  ],
}
const sampleResult: JuiceReveal = { rows: [
  { id: 'friend', survived: 9, outAt: null, reason: null, rank: 1, delta: 2, score: 2 },
  { id: 'me', survived: 5, outAt: 6, reason: 'poison', rank: 2, delta: 1, score: 1 },
] }

const pages: TutorialPage[] = [
  { title: '주스만 골라!', art: <Hero size={140} />, line: <>카드가 펼쳐지면 <b>주스 카드를 톡!</b><br />좌우 위치는 계속 바뀌어요.</> },
  { title: '모양이 달라도, 주스만!', art: <div className="juice-tutorial-gallery">
    {[...JUICE_TYPES, ...POISON_TYPES].map((kind) => <CardArt key={kind} kind={kind} width={42} />)}
  </div>, line: <>매 라운드 첫 3번은 익숙한 그림이에요.<br /><b>4번째부터 주스·독약 각각 5종이 섞여요!</b><br />4라운드부터는 이름 없이 그림만 보고 골라요.</> },
  { title: '둘 다 독약이면?', art: <><CardArt kind="frog" /><CardArt kind="bat" /></>, line: <><b>해골 표시가 있으면 독약!</b><br />둘 다 독약이면 아무것도 누르지 마세요.</> },
  { title: '점점 더 빨라져요', art: <>
    <div className="tut__col"><CardPair className="juice-tutorial-pair" mark="O"><CardArt kind="juice" width={56} /><CardArt kind="poison" width={56} /></CardPair><Stamp text="성공!" bg="var(--amber)" /></div>
    <div className="tut__col"><CardPair className="juice-tutorial-pair" mark="×"><CardArt kind="poison" width={56} /><CardArt kind="juice" width={56} /></CardPair><Stamp text="탈락!" bg="var(--red)" /></div>
  </>, line: <>카드가 점점 빨라져요. 잘못 누르거나<br /><b>주스를 놓치면 그 라운드 탈락!</b></> },
  { title: '다섯 판의 승부!', art: <div className="juice-tutorial-results"><Reveal room={sampleRoom} reveal={sampleResult} /></div>, line: <>오래 살아남을수록 높은 점수! <br /><b>5라운드 총점</b>으로 우승자를 가려요.</> },
]
export function Tutorial({ onClose }: { onClose: () => void }) { return <Frame pages={pages} onClose={onClose} /> }
