import type { Ingredient } from '@moyeora/shared'
import { BurgerLayers, IngredientLayer } from './BurgerArt.tsx'

const ORDER: Ingredient[] = ['bottom', 'patty', 'cheese', 'tomato', 'lettuce', 'top']
const INK = '#2b160f'

function Panel({ x, label, ingredients, compact = false }: { x: number; label: string; ingredients: Ingredient[]; compact?: boolean }) {
  return <g>
    <rect x={x} y="5" width="112" height="126" rx="14" fill="#fff8e7" stroke={INK} strokeWidth="3" />
    <text x={x + 56} y="25" textAnchor="middle" fontSize="15">{label}</text>
    <g transform={`translate(${x + 18} 0) scale(.44)`}><BurgerLayers ingredients={ingredients} compact={compact} /></g>
  </g>
}

function BuildArt() {
  return <>
    <Panel x={28} label="주문서" ingredients={ORDER} />
    <Panel x={180} label="내 햄버거" ingredients={ORDER.slice(0, 3)} />
    <path d="M161 118V45m-7 8 7-8 7 8" stroke={INK} strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    {(['bottom', 'patty', 'cheese', 'tomato', 'lettuce', 'onion', 'middle', 'top'] as Ingredient[]).map((ingredient, i) => <g key={ingredient} transform={`translate(${34 + (i % 4) * 64} ${140 + Math.floor(i / 4) * 21})`}>
      <rect width="58" height="16" rx="5" fill="#fff8e7" stroke={INK} strokeWidth="2" />
      <g transform="translate(13 3) scale(.2)"><IngredientLayer ingredient={ingredient} /></g>
    </g>)}
  </>
}

function UndoArt() {
  return <>
    <Panel x={28} label="내 햄버거" ingredients={['bottom', 'patty', 'cheese', 'onion']} />
    <Panel x={180} label="하나 빠졌어요" ingredients={['bottom', 'patty', 'cheese']} />
    <path d="M146 75h25m-8-7 8 7-8 7" fill="none" stroke={INK} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="104" cy="78" r="15" fill="none" stroke="#dd7d29" strokeWidth="3" strokeDasharray="4 4" />
    <path d="M104 83v19l-6-6q-5-3-6 2l12 20q2 3 7 3h9q7 0 7-8v-13q0-4-4-4h-3v-2q0-4-4-4h-5v-7q0-7-7 0Z" fill="#fff8e7" stroke={INK} strokeWidth="2.5" strokeLinejoin="round" />
    <text x="160" y="160" textAnchor="middle" fontSize="17">햄버거를 톡! 마지막 재료 취소</text>
  </>
}

function SubmitArt() {
  return <>
    <g transform="translate(26 -30) scale(.52)"><BurgerLayers ingredients={ORDER} compact /></g>
    <rect x="23" y="126" width="104" height="38" rx="12" fill="#ffa941" stroke={INK} strokeWidth="3" />
    <text x="75" y="151" fontSize="22" textAnchor="middle">완료</text>
    <path d="M135 97h30m-8-7 8 7-8 7" fill="none" stroke={INK} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="218" cy="53" r="24" fill="none" stroke="#278351" strokeWidth="6" />
    <text x="259" y="59" fontSize="19">정답!</text>
    <path d="m200 112 34 34m0-34-34 34" stroke="#c03454" strokeWidth="6" strokeLinecap="round" />
    <text x="259" y="136" fontSize="19">실패</text>
    <g transform="translate(96 7)">
      <circle cx="17" cy="17" r="18" fill="#fff8e7" stroke={INK} strokeWidth="2.5" />
      <text x="17" y="23" textAnchor="middle" fontSize="17">20</text>
    </g>
  </>
}

function ScoreArt() {
  return <>
    {[{ x: 23, y: 77, rank: 1, score: 8 }, { x: 99, y: 103, rank: 2, score: 7 }, { x: 175, y: 125, rank: 3, score: 6 }].map(({ x, y, rank, score }) => <g key={rank}>
      <text x={x + 32} y={y - 12} textAnchor="middle" fontSize="17">{rank}등</text>
      <rect x={x} y={y} width="64" height={170 - y} rx="9" fill={rank === 1 ? '#ffa941' : '#fff8e7'} stroke={INK} strokeWidth="3" />
      <text x={x + 32} y={y + 33} textAnchor="middle" fontSize="24">{score}점</text>
    </g>)}
    <path d="m35 35 10 7 10-15 10 15 10-7-5 19H40Z" fill="#ffa941" stroke={INK} strokeWidth="2.5" strokeLinejoin="round" />
    <path d="m269 79 27 27m0-27-27 27" stroke="#c03454" strokeWidth="5" strokeLinecap="round" />
    <text x="282" y="133" textAnchor="middle" fontSize="23">−1점</text>
    <text x="282" y="156" textAnchor="middle" fontSize="13">실패</text>
    <text x="157" y="23" textAnchor="middle" fontSize="14">8명이 플레이하면</text>
  </>
}

const scenes = { build: BuildArt, undo: UndoArt, submit: SubmitArt, score: ScoreArt }
export function TutorialArt({ scene }: { scene: keyof typeof scenes }) {
  const Scene = scenes[scene]
  return <svg aria-hidden="true" className="burger-tutorial-art jua" viewBox="0 0 320 180" fill={INK}><Scene /></svg>
}
