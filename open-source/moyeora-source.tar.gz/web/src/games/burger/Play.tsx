import { useEffect, useState } from 'react'
import { BURGER, INGREDIENT_NAMES, type BurgerReveal, type BurgerRoom, type Ingredient } from '@moyeora/shared'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { preloadSamples, sampleAt, tickAt, useCountdownBeeps } from '../../ui/sound.ts'
import successUrl from '../../ui/sfx/success.wav'
import failureUrl from '../juice/sfx/failure.wav'
import { BurgerArt, IngredientArt } from './BurgerArt.tsx'
import { ResultMark, SUCCESS_MARK_MS } from './ResultMark.tsx'

type Props = { room: BurgerRoom; reveal: BurgerReveal | null; goPerf: number; ingredients: Ingredient[]; onChange: (items: Ingredient[]) => void; pending: boolean; onSubmit: () => void; error?: string }
function statusMessage(ready: number, finished: boolean, rank: number | null, points: number, timedOut: boolean, pending: boolean, error?: string) {
  if (ready > 0) return `준비! ${Math.ceil(ready / 1000)}`
  if (finished && rank !== null) return `${rank}등 완성! +${points}점`
  if (finished) return `${timedOut ? '시간 초과' : '실패'} · −1점`
  if (pending) return '제출 중…'
  return error ?? '아래부터 차례대로 쌓아요'
}
export function Play({ room, reveal, goPerf, ingredients, onChange, pending, onSubmit, error }: Props) {
  const choosing = room.phase === 'choosing'
  const ready = useCountdown(choosing ? room.g.readyMs : null) ?? 0
  const left = useCountdown(room.remainingMs)
  const submitted = room.g.submissions.find((x) => x.id === room.you)
  const row = reveal?.rows.find((x) => x.id === room.you)
  const active = choosing && ready === 0 && (left ?? 0) > 0 && !pending && !submitted
  const shown = room.g.yourBurger ?? ingredients
  const rank = submitted?.rank ?? row?.rank ?? null
  const finished = !!submitted || !choosing
  useCountdownBeeps(choosing ? goPerf : null)
  useEffect(() => preloadSamples([successUrl, failureUrl]), [])
  const outcome = finished ? rank === null ? 'failure' : 'success' : null
  const [settled, setSettled] = useState(false)
  useEffect(() => {
    if (outcome !== 'success') return
    const timer = setTimeout(() => setSettled(true), SUCCESS_MARK_MS)
    return () => clearTimeout(timer)
  }, [outcome])
  const compact = outcome === 'success' && settled
  useEffect(() => {
    if (!outcome) return
    return sampleAt(performance.now(), outcome === 'success' ? successUrl : failureUrl)
  }, [outcome])
  const isSuccess = (id: string) => room.g.submissions.some((x) => x.id === id && x.rank !== null)
  const label = (id: string) => isSuccess(id) ? '완성했다!' : '실패했다!'
  const bannerRoom = !choosing ? { players: room.players.map((p) => ({ ...p, submitted: true })) } : room
  const points = row?.delta ?? room.g.total - (rank ?? 0) + 1
  const message = statusMessage(ready, finished, rank, points, !choosing && !submitted, pending, error)
  const add = (item: Ingredient) => {
    if (!active || ingredients.length >= BURGER.maxLayers) return
    onChange([...ingredients, item]); tickAt(performance.now()); navigator.vibrate?.(10)
  }
  const undo = () => {
    if (!active || ingredients.length === 0) return
    onChange(ingredients.slice(0, -1)); tickAt(performance.now())
  }
  return <div className="burger-play">
    <div className="burger-status" role="status">
      <TurnCard fixed name={null} me={!finished && ready === 0} meHint="" none={message}
        right={choosing && ready === 0 ? <Timer remainingMs={left} totalMs={BURGER.chooseMs} /> : undefined} />
    </div>
    <div className="burger-workbench">
      <section className="sticker burger-panel" aria-label="주문서">
        <div className="burger-panel-title jua">주문서</div>
        <div className="burger-drawing">{ready > 0 ? <span className="burger-ready jua">{Math.ceil(ready / 1000)}</span> : <BurgerArt label="주문" ingredients={room.g.recipe} compact={compact} />}</div>
        <span className="burger-hint">아래부터 ↑</span>
      </section>
      <div className="burger-mine-slot">
        <button type="button" className="sticker burger-panel burger-panel--mine" data-outcome={outcome ?? undefined} aria-label="마지막 재료 빼기" disabled={!active || shown.length === 0} onClick={undo}>
          <span className="burger-panel-title jua">내 햄버거 <small>{shown.length}층</small></span>
          <span className="burger-drawing"><BurgerArt label="내 햄버거" ingredients={shown} compact={compact} layoutIngredients={room.g.recipe} /></span>
          <span className="burger-hint">{finished ? '제출 완료' : '누르면 마지막 재료 빼기'}</span>
        </button>
        <ResultMark outcome={outcome} />
      </div>
      <div className="burger-toast"><SubmitBanner room={bannerRoom} label={label} eliminated={(id) => !isSuccess(id)} compact durationMs={900} /></div>
    </div>
    <div className="burger-controls">
      <div className="burger-ingredients" aria-label="재료 선택">
        {room.g.buttons.map((item) => <button key={item} type="button" className="sticker burger-ingredient" disabled={!active || ingredients.length >= BURGER.maxLayers} onClick={() => add(item)} aria-label={INGREDIENT_NAMES[item]}>
          <IngredientArt ingredient={item} /><span className="jua">{INGREDIENT_NAMES[item]}</span>
        </button>)}
      </div>
      <button type="button" className="btn-sticker burger-submit" data-tone="amber" disabled={!active || ingredients.length === 0} onClick={onSubmit}>{finished ? '다음 주문 기다리는 중' : pending ? '제출 중…' : `완료${ingredients.length === BURGER.maxLayers ? ` · ${BURGER.maxLayers}층` : ''}`}</button>
    </div>
    <div className="burger-avatars"><AvatarStrip room={room} compact ring={(p) => isSuccess(p.id)} dim={(p) => !isSuccess(p.id)} /></div>
    <div className="burger-next" aria-hidden={choosing}>{choosing ? '' : room.phase === 'done' ? '곧 최종 순위가 나와요' : `다음 주문까지 ${Math.ceil((left ?? 0) / 1000)}초`}</div>
  </div>
}
