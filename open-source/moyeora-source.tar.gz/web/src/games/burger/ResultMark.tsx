import { FeedbackMark } from '../../ui/FeedbackMark.tsx'

export const SUCCESS_MARK_MS = 1100

export function ResultMark({ outcome }: { outcome: 'success' | 'failure' | null }) {
  if (!outcome) return null
  return <FeedbackMark key={outcome} mark={outcome === 'success' ? 'O' : '×'} className={`burger-result-mark burger-result-mark--${outcome}`} style={outcome === 'success' ? { animationDuration: `${SUCCESS_MARK_MS}ms` } : undefined} />
}
