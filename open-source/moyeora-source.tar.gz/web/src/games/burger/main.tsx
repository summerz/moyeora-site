import { useState } from 'react'
import { createRoot } from 'react-dom/client'
import { BURGER_ROUNDS } from '@moyeora/shared'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { RoundProgress } from '../../ui/RoundProgress.tsx'
import { useBurgerGame } from './useBurgerGame.ts'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { Tutorial } from './Tutorial.tsx'
import './burger.css'

const TUT_KEY = 'moyeora:burger:tutorial'
const tutorialSeen = () => { try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false } }
function App() {
  const [tutorial, setTutorial] = useState(false)
  const [seen, setSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const { room, reveal, ingredients, setIngredients, pending, error, showFinal, goPerf, send, submit } = useBurgerGame()
  const playing = !!room && room.phase !== 'lobby' && !(room.phase === 'done' && showFinal)
  let screen
  if (!profile || editing) screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  else if (!room) screen = <Join game="burger" profile={profile} error={error} onEdit={() => setEditing(true)} onCreate={() => send({ type: 'create', game: 'burger', ...profile })} onJoin={(code) => send({ type: 'join', code, ...profile })} />
  else if (room.phase === 'lobby') screen = <Lobby room={room} hero={<Hero size={130} />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}>
    <SegmentPicker label="라운드" options={BURGER_ROUNDS.map((n) => ({ value: n, label: `${n}판` }))} value={room.rounds} host={room.host === room.you} onPick={(rounds) => send({ type: 'config', config: { rounds } })} />
    {error && <div role="alert">{error}</div>}
  </Lobby>
  else if (room.phase === 'done' && showFinal) screen = <Final room={room} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })} />
  else screen = <Play key={room.round} room={room} reveal={reveal} goPerf={goPerf} ingredients={ingredients} onChange={setIngredients} pending={pending} onSubmit={submit} error={error} />
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* 저장 불가 */ }
    setSeen(true); setTutorial(false)
  }
  return <Shell fit={playing} safe={!room || room.phase === 'lobby' || room.phase === 'done'} confirmHome={!!room} onHelp={() => setTutorial(true)} right={playing && room ? <RoundProgress compact round={room.round} rounds={room.rounds} /> : undefined} onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined}>
    {screen}
    {(tutorial || (!!room && room.phase === 'lobby' && !seen)) && <Tutorial onClose={closeTutorial} />}
  </Shell>
}
createRoot(document.getElementById('root')!).render(<App />)
