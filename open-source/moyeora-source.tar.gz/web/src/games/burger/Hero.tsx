import { useEffect, useRef } from 'react'
import { BurgerLayers } from './BurgerArt.tsx'
import './hero.css'

export function Hero({ size = 130 }: { size?: number }) {
  const art = useRef<SVGSVGElement>(null)
  useEffect(() => {
    const motion = matchMedia('(prefers-reduced-motion: reduce)')
    let animations: Animation[] = []
    const update = () => {
      animations.forEach((animation) => animation.cancel())
      animations = []
      if (motion.matches) return
      const layers = art.current?.querySelectorAll<SVGGElement>('.burger-layer') ?? []
      layers.forEach((layer, index) => {
        if (index === 0) return
        const open = `translate(5px, ${layer.style.getPropertyValue('--layer-open')})`
        const closed = `translate(5px, ${layer.style.getPropertyValue('--layer-closed')})`
        const delay = (index - 1) * 65 / 5000
        animations.push(layer.animate([
          { transform: open, offset: 0 },
          { transform: open, offset: .2 + delay, easing: 'cubic-bezier(.55, 0, 1, .65)' },
          { transform: closed, offset: .244 + delay },
          { transform: closed, offset: .6, easing: 'cubic-bezier(.4, 0, .2, 1)' },
          { transform: open, offset: .78 },
          { transform: open, offset: 1 },
        ], { duration: 5000, iterations: Infinity }))
      })
    }
    update()
    motion.addEventListener('change', update)
    return () => {
      motion.removeEventListener('change', update)
      animations.forEach((animation) => animation.cancel())
    }
  }, [])
  return <div className="burger-hero" style={{ width: size * 1.08, height: size * 1.08 }}>
    <svg ref={art} className="burger-hero-art" role="img" aria-label="햄버거 알바" viewBox="0 40 170 266">
      <BurgerLayers ingredients={['bottom', 'lettuce', 'patty', 'cheese', 'tomato', 'top']} compact />
    </svg>
  </div>
}
