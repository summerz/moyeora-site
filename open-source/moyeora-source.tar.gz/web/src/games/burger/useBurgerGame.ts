import { useEffect, useRef, useState } from 'react'
import { BURGER, type BurgerReveal, type BurgerRoom, type Ingredient, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { useLink, useSocket } from '../../ws.ts'

/** 방 갱신·입력·제출·마지막 결과의 생명주기를 한 곳에서 관리한다. */
export function useBurgerGame() {
  const [room, setRoom] = useState<BurgerRoom | null>(null)
  const [reveal, setReveal] = useState<BurgerReveal | null>(null)
  const [ingredients, setIngredients] = useState<Ingredient[]>([])
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const roomRef = useRef<BurgerRoom | null>(null)
  const goPerf = useRef(0)
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  const link = useLink()
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'reveal') { setReveal(m.result as BurgerReveal); return }
    if (m.type === 'error') { setError(errorText(m.message)); setPending(false); return }
    if (m.room.game !== 'burger') return
    const next = m.room
    const prev = roomRef.current
    const newRound = !prev || prev.round !== next.round || (next.phase === 'choosing' && prev.phase !== 'choosing') || next.phase === 'lobby'
    if (newRound) {
      setIngredients(next.g.yourBurger ?? [])
      setReveal(null)
      setShowFinal(false)
      clearTimeout(finalTimer.current)
      if (next.phase === 'choosing') goPerf.current = performance.now() + next.g.readyMs
    }
    roomRef.current = next
    setRoom(next)
    setError(undefined)
    // 접수된 제출은 room에서 잠근다. 재연결에서 유실된 요청은 다시 시도할 수 있다.
    setPending(false)
    if (next.phase === 'done' && prev?.phase !== 'done') {
      finalTimer.current = setTimeout(() => setShowFinal(true), BURGER.revealMs)
    }
  }
  const onClose = () => {
    roomRef.current = null
    clearTimeout(finalTimer.current)
    setRoom(null); setReveal(null); setPending(false); setShowFinal(false)
  }
  const send = useSocket(onMessage, onClose)
  const submit = () => {
    if (pending || link !== 'ok' || roomRef.current?.g.submissions.some((p) => p.id === roomRef.current?.you)) return
    setPending(true)
    send({ type: 'submit', choice: ingredients.join(',') })
  }
  return { room, reveal, ingredients, setIngredients, pending: pending || link !== 'ok', error, showFinal, goPerf: goPerf.current, send, submit }
}
