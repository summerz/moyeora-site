import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { TutorialArt } from './TutorialArt.tsx'
const pages: TutorialPage[] = [
  { title: '주문서대로 쌓아요', art: <TutorialArt scene="build" />, line: <>왼쪽 주문서를 보고 <b>아래부터</b> 터치해요.<br />재료 위치는 매 판 바뀌어요.</> },
  { title: '실수하면 햄버거를 톡!', art: <TutorialArt scene="undo" />, line: <>내 햄버거를 누르면 <b>마지막 재료가 빠져요.</b><br />완료 전에는 얼마든지 고칠 수 있어요.</> },
  { title: '20초 안에 완료!', art: <TutorialArt scene="submit" />, line: <>다 쌓았으면 <b>완료</b>! 판정은 한 번만 해요.<br />오답·시간 초과는 실패예요.</> },
  { title: '빠르고 정확하게!', art: <TutorialArt scene="score" />, line: <>참가 인원수부터 <b>성공 순서대로</b> 점수!<br />실패하면 <b>−1점</b>이에요.</> },
]
export function Tutorial({ onClose }: { onClose: () => void }) { return <Frame pages={pages} onClose={onClose} /> }
