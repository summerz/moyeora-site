import type { CSSProperties } from 'react'
import { INGREDIENT_NAMES, type Ingredient } from '@moyeora/shared'

// 첫 시안에서 만든 투명 재료 아틀라스. 영역을 SVG로 잘라 원본 알파를 그대로 쓴다.
const SHEETS = {
  ingredients: { href: '/burger/ingredients.png', width: 1536, height: 1024 },
  buns: { href: '/burger/buns.png', width: 2172, height: 724 },
}
const SPRITES: Record<Ingredient, { region: string; height: number; sheet?: keyof typeof SHEETS }> = {
  top: { region: '74 38 621 232', height: 50 },
  bottom: { region: '101 197 910 306', height: 36, sheet: 'buns' },
  middle: { region: '1158 237 913 230', height: 22, sheet: 'buns' },
  patty: { region: '827 300 646 196', height: 30 },
  lettuce: { region: '51 555 685 158', height: 30 },
  tomato: { region: '829 522 638 200', height: 30 },
  onion: { region: '65 749 638 197', height: 30 },
  cheese: { region: '816 750 661 218', height: 32 },
}

/** 주문서·내 햄버거·버튼·튜토리얼이 같은 그림을 공유한다. */
export function IngredientLayer({ ingredient }: { ingredient: Ingredient }) {
  const sprite = SPRITES[ingredient]
  const sheet = SHEETS[sprite.sheet ?? 'ingredients']
  return <svg x="8" y="4" width="144" height={sprite.height} viewBox={sprite.region} preserveAspectRatio="none" overflow="hidden" aria-hidden="true">
    <image href={sheet.href} width={sheet.width} height={sheet.height} />
  </svg>
}
export function IngredientArt({ ingredient }: { ingredient: Ingredient }) {
  return <svg aria-hidden="true" viewBox="0 0 160 58"><IngredientLayer ingredient={ingredient} /></svg>
}
// 재료 중앙에서 위·아래 재료와 맞닿는 높이. 치즈의 늘어진 끝은 아래 재료를 덮는다.
const CONTACT: Record<Ingredient, { top: number; bottom: number }> = {
  bottom: { top: 14, bottom: 40 }, top: { top: 4, bottom: 54 },
  middle: { top: 11, bottom: 26 }, lettuce: { top: 12, bottom: 28 },
  tomato: { top: 13, bottom: 34 }, onion: { top: 14, bottom: 34 },
  patty: { top: 16, bottom: 34 }, cheese: { top: 12, bottom: 26 },
}

/** 펼친 주문 전체를 중앙에 놓고, 입력 중과 완성 후에도 같은 기준을 쓴다. */
function centeredOffset(ingredients: readonly Ingredient[], height: number) {
  if (!ingredients.length) return 0
  const bounds = ingredients.map((ingredient, i) => {
    const y = 286 - CONTACT[ingredient].bottom - i * 34
    return { top: y + 4, bottom: y + 4 + SPRITES[ingredient].height }
  })
  return height / 2 - (Math.min(...bounds.map((x) => x.top)) + Math.max(...bounds.map((x) => x.bottom))) / 2
}

export function BurgerLayers({ ingredients, compact = false, offset = 0 }: { ingredients: readonly Ingredient[]; compact?: boolean; offset?: number }) {
  let previousY = 0
  return <>{ingredients.map((ingredient, i) => {
    const contact = CONTACT[ingredient]
    const openY = 286 - contact.bottom - i * 34 + offset
    const closedY = i > 0
      ? previousY + CONTACT[ingredients[i - 1]!].top - contact.bottom + 1
      : openY
    previousY = closedY
    const style = {
      transform: `translate(5px, ${compact ? closedY : openY}px)`,
      '--layer-open': `${openY}px`, '--layer-closed': `${closedY}px`,
      '--layer-delay': `${Math.max(0, i - 1) * 65}ms`,
    } as CSSProperties
    return <g key={`${i}-${ingredient}`} className="burger-layer" style={style}><IngredientLayer ingredient={ingredient} /></g>
  })}</>
}

export function BurgerArt({ ingredients, label, compact = false, layoutIngredients = ingredients }: { ingredients: readonly Ingredient[]; label: string; compact?: boolean; layoutIngredients?: readonly Ingredient[] }) {
  const height = Math.max(300, (Math.max(layoutIngredients.length, ingredients.length) - 1) * 34 + 66)
  // 입력 중·결과 모두 같은 좌표와 바닥 높이. 영역은 고정하고 각 재료만 움직인다.
  return <svg role="img" aria-label={`${label}: ${ingredients.length ? ingredients.map((x) => INGREDIENT_NAMES[x]).join(', ') : '아직 재료 없음'}`} viewBox={`0 0 170 ${height}`} className="burger-art" data-compact={compact}>
    <BurgerLayers ingredients={ingredients} compact={compact} offset={centeredOffset(layoutIngredients, height)} />
  </svg>
}
