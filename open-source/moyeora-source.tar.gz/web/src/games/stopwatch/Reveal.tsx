import { BONUS, type StopwatchReveal, type StopwatchRoom } from '@moyeora/shared'
import { ResultRow, Stamp } from '../../ui/ResultRow.tsx'
import { diffText, secText } from './format.ts'
import { Timeline } from './Timeline.tsx'

const STAMP_BG = { ttak: '#ffd23f', kkabi: '#c77dff', wow: '#4da3ff' } as const

/** 공개: 시간선 + 순위표(순위·시간·차이·도장·점수). 안 누른 사람은 맨 아래 */
export function Reveal({ room, reveal }: { room: StopwatchRoom; reveal: StopwatchReveal }) {
  const by = new Map(room.players.map((p) => [p.id, p]))
  const rows = [...reveal.rows].sort((a, b) => (a.rank ?? 99) - (b.rank ?? 99))
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <Timeline seconds={reveal.seconds} rows={reveal.rows} players={room.players} you={room.you} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {rows.map((r) => {
          const p = by.get(r.id)
          if (!p) return null
          const lead = <span className="jua" style={{ width: 18, textAlign: 'center', fontSize: 17, flexShrink: 0, color: r.rank === 1 ? 'var(--amber)' : 'var(--lav)' }}>{r.rank ?? '–'}</span>
          return (
            <ResultRow key={r.id} p={p} me={r.id === room.you} lead={lead}>
              {r.ms === null || r.err === null ? (
                <span style={{ fontSize: 14, color: 'var(--lav-dim)', fontWeight: 700, whiteSpace: 'nowrap' }}>안 누름</span>
              ) : (
                <>
                  <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', lineHeight: 1.15, flexShrink: 0 }}>
                    <span className="jua" style={{ fontSize: 17 }}>{secText(r.ms)}초</span>
                    <span style={{ fontSize: 12, color: 'var(--lav)', fontVariantNumeric: 'tabular-nums' }}>{diffText(r.err)}</span>
                  </span>
                  {r.bonus && <Stamp text={BONUS[r.bonus].label} bg={STAMP_BG[r.bonus]} />}
                </>
              )}
              <span className="jua" style={{ minWidth: 30, textAlign: 'right', fontSize: 18, flexShrink: 0 }}>{r.delta > 0 ? `+${r.delta}` : r.delta}</span>
            </ResultRow>
          )
        })}
      </div>
    </div>
  )
}
