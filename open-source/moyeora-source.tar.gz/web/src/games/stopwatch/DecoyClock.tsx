import { decoyTicks } from '@moyeora/shared'
import { ClockFace, Needle } from './ClockFace.tsx'

/** 믿으면 안 되는 시계: 틱 단위로 움직이지만 박자가 틀렸다(모두에게 같은 박자) */
export function DecoyClock({ elapsed, beatMs, seed, opacity }: { elapsed: number; beatMs: number; seed: number; opacity: number }) {
  const ticks = decoyTicks(Math.max(0, elapsed), beatMs, seed)
  return (
    <div aria-hidden="true" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, opacity, visibility: opacity > 0 ? 'visible' : 'hidden' }}>
      <ClockFace size={120} hand={<g style={{ transform: `rotate(${ticks * 30}deg)`, transformOrigin: '50px 52px' }}><Needle /></g>} />
      <div style={{ fontSize: 14, color: 'var(--lav)', fontWeight: 700 }}>이 시계는 믿지 마세요 😏</div>
    </div>
  )
}
