import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { capMs, pressMs, STOPWATCH, STOPWATCH_ROUNDS, type StopwatchReveal, type StopwatchRoom, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { useSocket } from '../../ws.ts'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { SecondsStepper } from './SecondsStepper.tsx'
import { Tutorial } from './Tutorial.tsx'

const TUT_KEY = 'moyeora:stopwatch:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<StopwatchRoom | null>(null)
  const [reveal, setReveal] = useState<StopwatchReveal | null>(null)
  const [stopped, setStopped] = useState<number | null>(null)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const roomRef = useRef<StopwatchRoom | null>(null)
  // 라운드 첫 choosing 메시지에서 한 번만 계산한다 (roundOver 로 remainingMs 가 줄어들기 때문).
  // 카운트다운이 0 이 되는 순간의 performance.now() — 누른 시간은 여기서부터 재서 보낸다
  const goPerfRef = useRef(0)
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'stopwatch') return
      const prev = roomRef.current
      if (!prev || prev.round !== m.room.round || (m.room.phase === 'choosing' && prev.phase !== 'choosing')) {
        setStopped(null)
        setReveal(null)
        setShowFinal(false)
        clearTimeout(finalTimer.current)
        if (m.room.phase === 'choosing') goPerfRef.current = performance.now() + (m.room.remainingMs ?? 0) - pressMs(m.room.g.seconds)
      }
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'reveal') {
      setReveal(m.result as StopwatchReveal)
      if (roomRef.current?.phase === 'done') {
        clearTimeout(finalTimer.current)
        finalTimer.current = setTimeout(() => setShowFinal(true), STOPWATCH.revealMs)
      }
    } else {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    clearTimeout(finalTimer.current)
    setRoom(null)
    setReveal(null)
    setStopped(null)
    setShowFinal(false)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)

  const stop = () => {
    const seconds = roomRef.current?.g.seconds
    if (stopped !== null || seconds === undefined) return
    const elapsed = performance.now() - goPerfRef.current
    if (elapsed < 0) return // 카운트다운 중
    navigator.vibrate?.(30)
    const ms = Math.min(capMs(seconds), Math.max(1, Math.round(elapsed)))
    setStopped(ms)
    send({ type: 'submit', choice: String(ms) })
  }

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="stopwatch"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'stopwatch', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    screen = <Lobby room={room} hero={<Hero size={room.players.length > 4 ? 110 : 130} />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}>
        <>
          <SecondsStepper seconds={room.g.seconds} host={room.host === room.you} onPick={(seconds) => send({ type: 'config', config: { seconds, rounds: room.rounds } })} />
          <SegmentPicker label="라운드" options={STOPWATCH_ROUNDS.map((n) => ({ value: n, label: `${n}판` }))} value={room.rounds} host={room.host === room.you} onPick={(rounds) => send({ type: 'config', config: { seconds: room.g.seconds, rounds } })} />
        </>
      </Lobby>
  } else if (room.phase === 'done' && showFinal) {
    screen = <Final room={room} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })} />
  } else {
    screen = <Play room={room} reveal={reveal} goPerf={goPerfRef.current} stopped={stopped} onStop={stop} />
  }

  const right =
    room && room.phase !== 'lobby' && !(room.phase === 'done' && showFinal) ? (
      <span className="chip tilt-a" style={{ background: 'var(--cream)', fontSize: 15, padding: '3px 12px' }}>{room.round} / {room.rounds}</span>
    ) : undefined

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={right} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
