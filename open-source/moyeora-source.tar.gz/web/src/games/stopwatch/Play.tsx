import { useEffect, useState } from 'react'
import { tickAt, useCountdownBeeps } from '../../ui/sound.ts'
import type { StopwatchReveal, StopwatchRoom } from '@moyeora/shared'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { TapButton, type TapKind } from '../../ui/TapButton.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { Reveal } from './Reveal.tsx'
import { Stopwatch } from './Stopwatch.tsx'

type Props = {
  room: StopwatchRoom
  reveal: StopwatchReveal | null
  /** 이 라운드 시작(카운트다운 0)의 performance.now() 값 */
  goPerf: number
  /** 이번 라운드에 내가 멈춘 시간(ms). null: 아직 */
  stopped: number | null
  onStop: () => void
}

/** 시작 시각 기준 흐른 시간(ms). 매 프레임 갱신, 시작 전이면 음수 */
const useElapsed = (goPerf: number, active: boolean) => {
  const [elapsed, setElapsed] = useState(() => performance.now() - goPerf)
  useEffect(() => {
    if (!active) return
    let id = 0
    const frame = () => {
      setElapsed(performance.now() - goPerf)
      id = requestAnimationFrame(frame)
    }
    id = requestAnimationFrame(frame)
    return () => cancelAnimationFrame(id)
  }, [goPerf, active])
  return elapsed
}

export function Play({ room, reveal, goPerf, stopped, onStop }: Props) {
  const choosing = room.phase === 'choosing'
  const elapsed = useElapsed(goPerf, choosing && stopped === null)
  const left = useCountdown(choosing ? null : room.remainingMs)
  const iPressed = stopped !== null || room.players.find((p) => p.id === room.you)?.submitted === true
  useCountdownBeeps(choosing ? goPerf : null)
  const ticking = choosing && !iPressed
  useEffect(() => {
    if (!ticking) return
    const cancels = [tickAt(goPerf + 1000), tickAt(goPerf + 2000)]
    return () => cancels.forEach((f) => f())
  }, [ticking, goPerf])

  if (!choosing && reveal) {
    const sec = left !== null ? Math.ceil(left / 1000) : null
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Reveal room={room} reveal={reveal} />
        {sec !== null && (
          <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>
            {room.phase === 'done' ? '곧 결과가 나와요' : `다음 라운드까지 ${sec}초`}
          </div>
        )}
      </div>
    )
  }

  let kind: TapKind
  let label: string
  if (iPressed || !choosing) [kind, label] = ['tapped', choosing ? '멈췄어요' : '…']
  else if (elapsed < 0) [kind, label] = ['ready', String(Math.max(1, Math.ceil(-elapsed / 1000)))]
  else [kind, label] = ['go', '멈춰!']

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <Stopwatch seconds={room.g.seconds} beatMs={room.g.beatMs} seed={room.g.seed} elapsed={elapsed} stopped={stopped} />
      <TapButton kind={kind} label={label} disabled={!choosing || iPressed || elapsed < 0} onPress={onStop} />
      <AvatarStrip room={room} />
      <SubmitBanner room={room} label="멈췄다!" compact />
    </div>
  )
}
