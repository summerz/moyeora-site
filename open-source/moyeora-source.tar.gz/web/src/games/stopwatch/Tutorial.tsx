import { BONUS } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { Stamp } from '../../ui/ResultRow.tsx'
import { TapButton } from '../../ui/TapButton.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { ClockFace, Needle } from './ClockFace.tsx'
import './tutorial.css'

const STAMP_BG = { ttak: '#ffd23f', kkabi: '#c77dff', wow: '#4da3ff' } as const

/** 숫자 카드 한 장(실제 화면의 스톱워치 숫자 카드를 줄인 것) */
const digit = (text: string, o: number) => (
  <div className="sticker sw-digits swt__digit">
    <span style={{ opacity: o, filter: o < 1 ? `blur(${((1 - o) * 4).toFixed(1)}px)` : undefined }}>{text}</span>
  </div>
)

const bonus = (k: keyof typeof BONUS) => (
  <div className="swt__bonus">
    <Stamp text={BONUS[k].label} bg={STAMP_BG[k]} />
    <span className="jua">+{BONUS[k].points}</span>
  </div>
)

const PAGES: TutorialPage[] = [
  {
    title: '숫자는 처음만 도와줘요',
    art: (
      <div className="tut__col">
        <div className="chip swt__goal">목표 3.00초</div>
        <div className="swt__row">
          {digit('0.40', 1)}
          <span className="swt__arrow">›</span>
          {digit('1.35', 0.4)}
          <span className="swt__arrow">›</span>
          {digit('', 0)}
        </div>
      </div>
    ),
    line: <>1초, 2초... 처음만 보이고<br/>금방 <b>사라져요</b>. 감으로 세야 해요!</>,
  },
  {
    title: '시계는 거짓말',
    art: (
      <div className="swt__clock">
        <ClockFace size={110} hand={<g style={{ transform: 'rotate(120deg)', transformOrigin: '50px 52px' }}><Needle /></g>} />
      </div>
    ),
    line: <>박자가 틀린 <b>가짜 시계</b>가 나와요. 믿지 마세요!</>,
  },
  {
    title: '본인의 감을 믿어요!',
    art: (
      <div className="swt__stop">
        <div className="tut__btn"><TapButton kind="go" label="멈춰!" disabled onPress={() => {}} /></div>
        <div className="tut__col">
          <Avatar seed="tut-a" size={44} />
          <span className="swt__secret jua">???</span>
        </div>
      </div>
    ),
    line: <>본인의 감을 믿어요!<br/>이때다 싶을 때 <b>멈춰!</b></>,
  },
  {
    title: '가까울수록 고득점',
    art: (
      <div className="tut__col tut__col--list">
        {bonus('ttak')}
        {bonus('kkabi')}
        {bonus('wow')}
      </div>
    ),
    line: <>목표에 아주 가까우면 <b>추가 득점도</b>!<br/>안 누르면 0점</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
