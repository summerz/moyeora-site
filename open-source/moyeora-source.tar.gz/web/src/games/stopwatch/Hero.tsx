import { ClockFace, Needle } from './ClockFace.tsx'
import './stopwatch.css'

/** 스톱워치 얼굴: 가끔 휙 도는 초침. 동작 줄이기면 멈춤 */
export function Hero({ size = 130 }: { size?: number }) {
  return (
    <div aria-hidden="true" className="tilt-c" style={{ width: size, height: size, margin: '0 auto' }}>
      <ClockFace size={size} hand={<g className="sw-hand"><Needle /></g>} />
    </div>
  )
}
