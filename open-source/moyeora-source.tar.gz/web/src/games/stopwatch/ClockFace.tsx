import type { ReactNode } from 'react'

/** 스톱워치 얼굴 그림(손잡이·눈금·초록 부채꼴). 바늘은 hand 로 넣는다 (중심 50,52) */
export function ClockFace({ size, hand }: { size: number; hand: ReactNode }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{ display: 'block', overflow: 'visible' }}>
      <rect x={44} y={3} width={12} height={9} rx={2} fill="var(--cream)" stroke="var(--ink)" strokeWidth={3} />
      <rect x={40} y={0} width={20} height={5} rx={2.5} fill="var(--amber)" stroke="var(--ink)" strokeWidth={3} />
      <circle cx={55} cy={57} r={44} fill="var(--ink)" />
      <circle cx={50} cy={52} r={44} fill="var(--cream)" stroke="var(--ink)" strokeWidth={3} />
      {Array.from({ length: 12 }, (_, i) => (
        <line key={i} x1={50} y1={13} x2={50} y2={i % 3 === 0 ? 21 : 17} stroke="var(--ink)" strokeWidth={i % 3 === 0 ? 3.5 : 2} strokeLinecap="round" transform={`rotate(${i * 30} 50 52)`} />
      ))}
      {hand}
      <circle cx={50} cy={52} r={5} fill="var(--amber)" stroke="var(--ink)" strokeWidth={3} />
    </svg>
  )
}

export const Needle = () => <line x1={50} y1={60} x2={50} y2={20} stroke="var(--ink)" strokeWidth={4} strokeLinecap="round" />
