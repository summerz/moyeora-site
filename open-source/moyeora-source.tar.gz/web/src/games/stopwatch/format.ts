/** ms → "3.04" (소수 둘째 자리까지 버림, 시계처럼) */
export const clock = (ms: number): string => (Math.floor(Math.max(0, ms) / 10) / 100).toFixed(2)

/** 공개 화면 시간: 가장 가까운 0.01초 */
export const secText = (ms: number): string => (ms / 1000).toFixed(2)

/** 오차(ms) → "+0.04" / "−0.12" (U+2212). 딱!(5ms 미만)이나 반올림하면 0 이면 0.00 */
export const diffText = (err: number): string => {
  const t = (Math.abs(err) / 1000).toFixed(2)
  return Math.abs(err) < 5 || t === '0.00' ? '0.00' : `${err < 0 ? '−' : '+'}${t}`
}
