import './stopwatch.css'
import { digitOpacity } from '@moyeora/shared'
import { DecoyClock } from './DecoyClock.tsx'
import { clock } from './format.ts'

type Props = {
  seconds: number
  beatMs: number
  seed: number
  /** 지금까지 흐른 시간(ms). 카운트다운 중이면 음수 */
  elapsed: number
  /** 내가 멈춘 시간(ms). 있으면 숫자를 다시 보여준다 */
  stopped: number | null
}

/** 큰 스톱워치 숫자. 목표의 1/3 까지 선명, 2/3 까지 흐려지고 그 뒤엔 안 보인다(감으로!). */
export function Stopwatch({ seconds, beatMs, seed, elapsed, stopped }: Props) {
  const running = stopped === null && elapsed >= 0
  const o = stopped !== null ? 1 : running ? digitOpacity(elapsed, seconds * 1000) : 1
  const shown = stopped ?? Math.max(0, elapsed)
  const hidden = running && o === 0
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div className="chip" style={{ background: 'var(--cream)', fontSize: 17, padding: '2px 14px' }}>목표 {seconds.toFixed(2)}초</div>
      <div className="sticker sw-digits" role="timer" aria-label={stopped !== null ? `내 기록 ${clock(stopped)}초` : '스톱워치'}
        style={{ width: '100%', boxSizing: 'border-box', textAlign: 'center', fontSize: 76, padding: '14px 0 10px', background: stopped !== null ? 'var(--cream)' : 'var(--card)', color: stopped !== null ? 'var(--ink)' : 'var(--text)' }}>
        <span style={{ display: 'inline-block', opacity: o, filter: o < 1 ? `blur(${((1 - o) * 4).toFixed(1)}px)` : undefined }}>{clock(shown)}</span>
      </div>
      <div style={{ height: 20, fontSize: 14, color: 'var(--lav)', fontWeight: 700 }}>{hidden ? '여기서부터 감으로!' : ''}</div>
      {/* 자리는 늘 잡아 둔다(나타날 때 화면이 밀리지 않게). 내가 멈추면 시계는 사라진다 */}
      <div style={{ minHeight: 150 }}>
        {stopped === null && <DecoyClock elapsed={elapsed} beatMs={beatMs} seed={seed} opacity={running ? 1 - o : 0} />}
      </div>
    </div>
  )
}
