import { STOPWATCH } from '@moyeora/shared'

type Props = { seconds: number; host: boolean; onPick: (seconds: number) => void }

const btn = (disabled: boolean) => ({ width: 44, height: 44, padding: 0, fontSize: 26, lineHeight: 1, display: 'grid', placeItems: 'center', cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.4 : 1, background: 'var(--cream)' }) as const

/** 대기실: 목표 초 − [3초] + (방장만 바꿀 수 있고 나머지는 보기만) */
export function SecondsStepper({ seconds, host, onPick }: Props) {
  const lo = seconds <= 1
  const hi = seconds >= STOPWATCH.maxSeconds
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center' }}>
      <div style={{ fontSize: 13, color: 'var(--lav)' }}>목표 시간</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button type="button" className="chip" aria-label="1초 줄이기" disabled={!host || lo} onClick={() => onPick(seconds - 1)} style={btn(!host || lo)}>−</button>
        <span className="chip" role="status" style={{ minWidth: 72, textAlign: 'center', background: 'var(--lime)', boxSizing: 'border-box', minHeight: 44, display: 'grid', placeItems: 'center' }}>{seconds}초</span>
        <button type="button" className="chip" aria-label="1초 늘리기" disabled={!host || hi} onClick={() => onPick(seconds + 1)} style={btn(!host || hi)}>+</button>
      </div>
    </div>
  )
}
