import type { Player, StopwatchRow } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { secText } from './format.ts'

const DOT = 30
const LANE = 32

/** 가로 시간선: 목표선을 가운데에 두고 눌렀던 시간마다 아바타 점. 겹치면 위로 올린다 */
export function Timeline({ seconds, rows, players, you }: { seconds: number; rows: StopwatchRow[]; players: Player[]; you: string }) {
  const by = new Map(players.map((p) => [p.id, p]))
  const target = seconds * 1000
  const pressed = rows.filter((r) => r.err !== null).sort((a, b) => a.ms! - b.ms!)
  const span = Math.max(150, ...pressed.map((r) => Math.abs(r.err!))) * 1.25
  const pct = (ms: number) => 50 + ((ms - target) / span) * 50
  // 가로 330px 기준 점 지름만큼 떨어지면 같은 층. 아니면 위층
  const minGap = (DOT / 330) * 100
  const lanes: number[] = []
  const placed = pressed.map((r) => {
    const x = pct(r.ms!)
    let lane = lanes.findIndex((last) => x - last >= minGap)
    if (lane < 0) lane = lanes.length
    lanes[lane] = x
    return { r, x, lane }
  })
  const h = 34 + Math.max(1, lanes.length) * LANE
  return (
    <div className="sticker sticker--dark" style={{ position: 'relative', height: h + 26, padding: 0, margin: '0 2px', boxSizing: 'border-box', overflow: 'hidden' }} aria-label="누른 시간">
      <div style={{ position: 'absolute', left: '50%', top: 6, bottom: 24, borderLeft: '3px dashed var(--lime)' }} />
      <div className="jua" style={{ position: 'absolute', left: '50%', top: 4, transform: 'translateX(-50%)', background: 'var(--card)', color: 'var(--lime)', fontSize: 14, padding: '0 6px' }}>{seconds.toFixed(2)}</div>
      <div style={{ position: 'absolute', left: 12, right: 12, bottom: 26, borderTop: '3px solid var(--lav-dim)' }} />
      <div className="jua" style={{ position: 'absolute', left: 10, bottom: 3, fontSize: 12, color: 'var(--lav-dim)' }}>{secText(target - span)}</div>
      <div className="jua" style={{ position: 'absolute', right: 10, bottom: 3, fontSize: 12, color: 'var(--lav-dim)' }}>{secText(target + span)}</div>
      {placed.map(({ r, x, lane }) => {
        const p = by.get(r.id)
        if (!p) return null
        const me = r.id === you
        return (
          <div key={r.id} title={`${p.name} ${secText(r.ms!)}`} style={{ position: 'absolute', left: `calc(12px + (100% - 24px) * ${(Math.min(98, Math.max(2, x)) / 100).toFixed(4)} - ${DOT / 2}px)`, bottom: 30 + lane * LANE, width: DOT, height: DOT, borderRadius: '50%', boxShadow: me ? '0 0 0 3px var(--lime)' : '0 0 0 2px var(--ink)' }}>
            <Avatar seed={p.avatar} size={DOT} />
          </div>
        )
      })}
    </div>
  )
}
