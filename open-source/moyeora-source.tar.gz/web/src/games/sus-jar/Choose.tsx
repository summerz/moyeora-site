import { useEffect, useRef, useState, type ReactNode } from 'react'
import { SUS_JAR_CHOICES, type SusJarRoom, type SusJarChoice, type SusJarPayouts } from '@moyeora/shared'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { Icon, type IconName } from '../../ui/icons.tsx'
import { CHOICE_LABEL, fmtPts, oddsLook } from './labels.ts'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'

type Props = { room: SusJarRoom; choice: SusJarChoice | null; onChoose: (c: SusJarChoice) => void }

const META: Record<SusJarChoice, { tone: 'amber' | 'cream' | 'lime'; icon: IconName }> = {
  drink: { tone: 'amber', icon: 'cup' },
  pass: { tone: 'cream', icon: 'arrow-right' },
  antidote: { tone: 'lime', icon: 'drop' },
}

type Pill = { icon?: IconName; label: string; pts: string; bg: string; color: string }
const JUICE = { bg: '#FFE2A8', color: '#8A4B00' }
const POISON = { bg: 'var(--ink)', color: 'var(--red)' }
const GOOD = { bg: 'var(--cream)', color: '#2E8B1E' }
const GREY = { bg: '#D9D3E6', color: '#4a4166' }

function pillsFor(c: SusJarChoice, p: SusJarPayouts): Pill[] {
  if (c === 'drink') return [{ icon: 'cup', label: '주스면', pts: fmtPts(p.drink.juice), ...JUICE }, { icon: 'skull', label: '독이면', pts: fmtPts(p.drink.poison), ...POISON }]
  if (c === 'pass') return [{ label: '', pts: fmtPts(p.pass), ...GREY }]
  return [{ icon: 'skull', label: '독이면', pts: fmtPts(p.antidote.poison), ...GOOD }, { icon: 'cup', label: '주스면', pts: fmtPts(p.antidote.juice), ...POISON }]
}

function Pills({ list }: { list: Pill[] }) {
  return (
    <span style={{ marginLeft: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
      {list.map((q, i) => (
        <span key={i} className="jua" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 16, lineHeight: 1.2, padding: '2px 10px', border: '2.5px solid var(--ink)', borderRadius: 999, background: q.bg, color: q.color, whiteSpace: 'nowrap' }}>
          {q.icon && <Icon name={q.icon} size={14} />}{q.label && `${q.label} `}<span style={{ fontSize: 18 }}>{q.pts}</span>
        </span>
      ))}
    </span>
  )
}

function Banner({ kind, children, icon }: { kind: 'gold' | 'nocure' | 'double'; children: ReactNode; icon?: IconName }) {
  const st = {
    gold: { background: 'var(--amber)', border: '3px solid var(--ink)' },
    nocure: { background: 'var(--cream)', border: '3px dashed var(--ink)' },
    double: { background: 'var(--lime)', border: '3px solid var(--ink)' },
  }[kind]
  return (
    <div className={`sticker jua ${kind === 'double' ? 'glow-box' : ''}`} style={{ ...st, borderRadius: 14, boxShadow: '4px 4px 0 var(--ink)', padding: '8px 12px', fontSize: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, transform: 'rotate(-1deg)', animation: 'banner-in 350ms both' }}>
      {icon && <Icon name={icon} size={24} />}{children}
    </div>
  )
}

const LABEL: Record<SusJarChoice, string> = { drink: '마신다!', pass: CHOICE_LABEL.pass, antidote: CHOICE_LABEL.antidote }
const TONE_COLOR = { amber: '#FFB347', lav: '#C9B8FF', lime: 'var(--lime)' } as const
const GLOW = { amber: '0 0 22px rgba(255,179,71,.6)', lav: '0 0 22px rgba(201,184,255,.6)', lime: '0 0 22px rgba(140,255,77,.6)' } as const
const ODDS_ICON = { amber: 'cup-q', lav: 'half', lime: 'skull' } as const

function ChoicePop({ choice }: { choice: SusJarChoice }) {
  const m = META[choice]
  return (
    <div style={{ position: 'fixed', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none', zIndex: 20 }}>
      <div className="sticker" style={{ background: `var(--${m.tone})`, borderRadius: 24, boxShadow: '6px 6px 0 var(--ink)', padding: '22px 30px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, animation: 'choice-pop 900ms both' }}>
        <Icon name={m.icon} size={56} />
        <span className="jua" style={{ fontSize: 44, lineHeight: 1.1 }}>{LABEL[choice]}</span>
      </div>
    </div>
  )
}

export function Choose({ room, choice, onChoose }: Props) {
  const allIn = room.players.length > 0 && room.players.every((p) => p.submitted)
  const odds = Math.round((room.g.odds ?? 0) * 100)
  const look = oddsLook(room.g.odds ?? 0.5)
  const color = TONE_COLOR[look.tone]
  const [pop, setPop] = useState<{ c: SusJarChoice; n: number } | null>(null)
  const popTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(popTimer.current), [])
  const pick = (c: SusJarChoice) => {
    navigator.vibrate?.(20)
    onChoose(c)
    setPop((p) => ({ c, n: (p?.n ?? 0) + 1 }))
    clearTimeout(popTimer.current)
    popTimer.current = setTimeout(() => setPop(null), 900)
  }
  const body: ReactNode = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {(room.g.tag || room.g.double) && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {room.g.tag === 'gold' && <Banner kind="gold" icon="star">황금 통! 마시기 점수 2배</Banner>}
          {room.g.tag === 'nocure' && <Banner kind="nocure">해독제 품절!</Banner>}
          {room.g.double && <Banner kind="double" icon="star">마지막 판 · 모든 점수 2배!</Banner>}
        </div>
      )}
      {allIn && <div style={{ color: 'var(--lime)', textAlign: 'right', fontSize: 14, fontWeight: 700 }}>모두 골랐어요 · 곧 공개!</div>}
      <div className="sticker sticker--dark tilt-b" style={{ textAlign: 'center', padding: '14px 10px', boxShadow: `5px 5px 0 ${color}` }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, color }}>
          <Icon name={ODDS_ICON[look.tone]} size={36} />
          <span className="jua" style={{ fontSize: 44, textShadow: GLOW[look.tone] }}>독 {odds}%</span>
        </div>
        <div style={{ fontSize: 15, color: 'var(--lav)' }}>{look.title} · {look.hint}</div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {SUS_JAR_CHOICES.map((c) => {
          if (c === 'antidote' && !room.g.choices.includes('antidote')) {
            return <div key={c} className="jua" style={{ border: '3px dashed var(--lav-dim)', borderRadius: 18, minHeight: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--lav-dim)', fontSize: 18, textAlign: 'center', padding: '8px 12px', boxSizing: 'border-box' }}>해독제 품절 · 이번 판은 없어요</div>
          }
          const m = META[c]
          const mine = choice === c
          return (
            <button key={c} type="button" className="btn-sticker" data-tone={m.tone} aria-pressed={mine} onClick={() => pick(c)}
              style={{ minHeight: 64, justifyContent: 'flex-start', textAlign: 'left', position: 'relative', ...(choice && !mine ? { opacity: 0.5 } : null), ...(mine ? { outline: `3px solid var(--${c === 'antidote' ? 'amber' : 'lime'})`, outlineOffset: 3 } : null) }}>
              <Icon name={m.icon} size={30} />
              <span style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: 23, lineHeight: 1.1 }}>{LABEL[c]}</span>
                {c === 'antidote' && room.g.payouts && <span style={{ fontSize: 11, fontFamily: '"Noto Sans KR", sans-serif', fontWeight: 500 }}>마신 사람은 {fmtPts(room.g.payouts.drink.saved)}</span>}
              </span>
              {room.g.payouts && <Pills list={pillsFor(c, room.g.payouts)} />}
              {mine && <span className="jua" style={{ marginLeft: 8, background: 'var(--ink)', color: 'var(--cream)', fontSize: 12, padding: '3px 10px', borderRadius: 999, whiteSpace: 'nowrap' }}>내 선택</span>}
            </button>
          )
        })}
      </div>
      <div style={{ fontSize: 12, color: 'var(--lav-dim)', textAlign: 'center' }}>시간 안에 안 고르면 −1점 · 모두 고르면 3초 뒤 공개</div>
      <SubmitBanner room={room} label="선택 완료!" />
      <AvatarStrip room={room} />
      {pop && <ChoicePop key={pop.n} choice={pop.c} />}
    </div>
  )
  return body
}
