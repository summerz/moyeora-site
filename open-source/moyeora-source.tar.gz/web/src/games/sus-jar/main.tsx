import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import type { SusJarRoom, ServerMessage, SusJarChoice, SusJarReveal } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { RoundProgress } from '../../ui/RoundProgress.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { useSocket } from '../../ws.ts'
import { Choose } from './Choose.tsx'
import { Reveal } from './Reveal.tsx'
import { Tutorial } from './Tutorial.tsx'

const TUT_KEY = 'moyeora:sus-jar:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<SusJarRoom | null>(null)
  const [reveal, setReveal] = useState<SusJarReveal | null>(null)
  const [choice, setChoice] = useState<SusJarChoice | null>(null)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const roomRef = useRef<SusJarRoom | null>(null)
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'sus-jar') return
      const prev = roomRef.current
      if (!prev || prev.round !== m.room.round || (m.room.phase === 'choosing' && prev.phase !== 'choosing')) {
        setChoice(null)
        setReveal(null)
        setShowFinal(false)
        clearTimeout(finalTimer.current)
      }
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'reveal') {
      setReveal(m.result as SusJarReveal)
      if (roomRef.current?.phase === 'done') {
        clearTimeout(finalTimer.current)
        finalTimer.current = setTimeout(() => setShowFinal(true), 3000)
      }
    } else {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    clearTimeout(finalTimer.current)
    setRoom(null)
    setReveal(null)
    setChoice(null)
    setShowFinal(false)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)

  const choose = (c: SusJarChoice) => {
    setChoice(c)
    send({ type: 'submit', choice: c })
  }

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="sus-jar"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'sus-jar', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    screen = <Lobby room={room} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })} />
  } else if (room.phase === 'choosing' || !reveal) {
    screen = <Choose room={room} choice={choice} onChoose={choose} />
  } else if (room.phase === 'done' && showFinal) {
    screen = <Final room={room} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })} />
  } else {
    screen = <Reveal room={room} reveal={reveal} onResult={() => setShowFinal(true)} />
  }

  let right
  if (room && room.phase !== 'lobby') {
    const chip = <RoundProgress round={room.round} rounds={room.rounds} done={room.phase !== 'choosing' && !!reveal} />
    right =
      room.phase === 'choosing' || !reveal ? (
        <>{chip}<Timer remainingMs={room.remainingMs} totalMs={20000} /></>
      ) : room.phase === 'done' && showFinal ? undefined : (
        <>{chip}<span style={{ color: 'var(--lav-dim)' }}>{room.players.length}명</span></>
      )
  }

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={right} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
