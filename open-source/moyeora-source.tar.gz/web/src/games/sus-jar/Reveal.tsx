import type { SusJarRoom, SusJarChoice, SusJarReveal } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { Icon } from '../../ui/icons.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { CONTENT_LABEL, NO_CHOICE, STAMP_LABEL } from './labels.ts'

type Props = { room: SusJarRoom; reveal: SusJarReveal; onResult: () => void }

const deltaText = (d: number) => (d > 0 ? `+${d}점` : d < 0 ? `−${-d}점` : '0점')
const deltaColor = (d: number) => (d > 0 ? 'var(--green)' : d < 0 ? 'var(--red)' : 'var(--lav-dim)')
const TILTS = ['tilt-a', 'tilt-b', 'tilt-c', 'tilt-d']

const STAMP = {
  drink: { icon: 'cup', color: '#B8641A', border: '3px solid #FFB347' },
  pass: { icon: 'arrow-right', color: '#6b5f8a', border: '3px solid var(--ink)' },
  antidote: { icon: 'drop', color: '#2E8B1E', border: '3px solid #2E8B1E' },
} as const

function Stamp({ choice }: { choice: SusJarChoice | null }) {
  const s = choice ? STAMP[choice] : null
  return (
    <span className="jua" style={{ position: 'absolute', top: 8, right: 8, transform: 'rotate(8deg)', display: 'inline-flex', alignItems: 'center', gap: 4, padding: '5px 12px', borderRadius: 999, fontSize: 17, lineHeight: 1.2, whiteSpace: 'nowrap', background: s ? 'rgba(255,248,231,.85)' : 'rgba(42,33,71,.85)', color: s ? s.color : 'var(--lav-dim)', border: s ? s.border : '3px dashed var(--lav-dim)' }}>
      {s && choice && <Icon name={s.icon} size={20} />}
      {choice ? STAMP_LABEL[choice] : NO_CHOICE}
    </span>
  )
}

export function Reveal({ room, reveal, onResult }: Props) {
  const left = useCountdown(room.remainingMs)
  const poison = reveal.content === 'poison'
  const player = (id: string) => room.players.find((p) => p.id === id)
  const antidoters = reveal.players.filter((p) => p.choice === 'antidote').map((p) => player(p.id)?.name ?? '?')
  const names = antidoters.join(', ')
  const last = names.charCodeAt(names.length - 1)
  const ga = last >= 0xac00 && last <= 0xd7a3 && (last - 0xac00) % 28 !== 0 ? '이' : '가'
  const sub = reveal.antidoteIn
    ? `${names}${ga} 해독제를 넣어 ${poison ? '중화됐어요' : '주스를 망쳤어요'}`
    : '아무도 해독제를 넣지 않았어요'

  const chips = [reveal.tag === 'gold' ? '황금 통 ×2' : reveal.tag === 'nocure' ? '해독제 품절' : null, reveal.double ? '×2 마지막 판' : null].filter((t): t is string => !!t)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {chips.length > 0 && (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
          {chips.map((t) => <span key={t} className="chip" style={{ background: 'var(--cream)', fontSize: 13, padding: '2px 12px' }}>{t}</span>)}
        </div>
      )}
      <div className="sticker tilt-b" style={{ background: poison ? 'var(--lime)' : 'var(--amber)', textAlign: 'center', padding: '16px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          <Icon name={poison ? 'skull' : 'cup'} size={38} />
          <span className="jua" style={{ fontSize: 40 }}>{CONTENT_LABEL[reveal.content]}</span>
        </div>
        <div style={{ fontSize: 17, lineHeight: 1.35, marginTop: 4 }}>{sub}</div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 10 }}>
        {reveal.players.map((r, i) => {
          const p = player(r.id)
          const me = r.id === room.you
          const none = r.choice === null
          return (
            <div key={r.id} className={`sticker ${me ? 'sticker--lime' : ''} ${TILTS[i % 4]}`}
              style={{ position: 'relative', padding: '10px 10px', display: 'flex', flexDirection: 'column', gap: 4, boxShadow: me ? '3px 3px 0 var(--lime)' : '3px 3px 0 var(--ink)', ...(none ? { background: 'var(--card)', color: 'var(--text)', border: '3px dashed var(--lav-dim)' } : null) }}>
              <div style={{ height: 32 }} aria-hidden="true" />
              <Avatar seed={p?.avatar ?? r.id} size={44} />
              <span className="nick nick--2l">{(p?.name ?? '?') + (me ? ' · 나' : '')}{p?.bot && <NpcTag />}</span>
              <Stamp choice={r.choice} />
              <span className="jua" style={{ fontSize: 20 }}>
                <span style={{ color: deltaColor(r.delta) }}>{deltaText(r.delta)}</span> → {r.score < 0 ? `−${-r.score}` : r.score}점
              </span>
            </div>
          )
        })}
      </div>
      {room.phase === 'done' ? (
        <button type="button" className="btn-sticker" data-tone="cream" onClick={onResult}>결과 보기</button>
      ) : (
        left !== null && <div style={{ color: 'var(--lav-dim)', textAlign: 'center' }}>다음 라운드까지 {Math.ceil(left / 1000)}초</div>
      )}
    </div>
  )
}
