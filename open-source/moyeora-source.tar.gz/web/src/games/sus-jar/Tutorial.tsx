import type { ReactNode } from 'react'
import { Stamp } from '../../ui/ResultRow.tsx'
import { Icon, type IconName } from '../../ui/icons.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'

const still = { pointerEvents: 'none' as const }

/** 독 확률 카드 (Choose 와 같은 모양, 줄여서) */
const oddsCard = (
  <div aria-hidden="true" style={{ ...still, zoom: 0.62 }}>
    <div className="sticker sticker--dark tilt-b" style={{ textAlign: 'center', padding: '14px 26px', boxShadow: '5px 5px 0 var(--lime)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, color: 'var(--lime)' }}>
        <Icon name="skull" size={36} />
        <span className="jua" style={{ fontSize: 44, textShadow: '0 0 22px rgba(140,255,77,.6)' }}>독 70%</span>
      </div>
      <div style={{ fontSize: 15, color: 'var(--lav)' }}>독이 많아요 · 조심!</div>
    </div>
  </div>
)

const CH: { tone: 'amber' | 'cream' | 'lime'; icon: IconName; label: string }[] = [
  { tone: 'amber', icon: 'cup', label: '마신다!' },
  { tone: 'cream', icon: 'arrow-right', label: '패스' },
  { tone: 'lime', icon: 'drop', label: '해독제' },
]
const choices = (
  <div aria-hidden="true" style={{ ...still, display: 'flex', flexDirection: 'column', gap: 8, zoom: 0.7 }}>
    {CH.map((c) => (
      <button key={c.label} type="button" tabIndex={-1} className="btn-sticker" data-tone={c.tone} style={{ minHeight: 48, justifyContent: 'flex-start', width: 230 }}>
        <Icon name={c.icon} size={26} />
        <span style={{ fontSize: 22, lineHeight: 1.1 }}>{c.label}</span>
      </button>
    ))}
  </div>
)

const card = (bg: string, icon: IconName, title: string, who: ReactNode) => (
  <div className="sticker" style={{ ...still, background: bg, borderRadius: 18, padding: '12px 8px', width: 130, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <Icon name={icon} size={24} />
      <span className="jua" style={{ fontSize: 22 }}>{title}</span>
    </div>
    {who}
  </div>
)
const reveal = (
  <div aria-hidden="true" style={{ display: 'flex', gap: 14 }}>
    {card('var(--amber)', 'cup', '주스!', <><Stamp text="마셨다 +5" bg="var(--lime)" /><Stamp text="해독제 −3" bg="#FFD1D1" /></>)}
    {card('var(--lime)', 'skull', '독!', <><Stamp text="마셨다 −4" bg="#FFD1D1" /><Stamp text="해독제 +4" bg="var(--cream)" /></>)}
  </div>
)

const score = (
  <div className="tut__col tut__col--list" aria-hidden="true" style={still}>
    <Stamp text="황금 통 · 마시기 ×2" bg="var(--amber)" />
    <Stamp text="마지막 5라운드 · 모두 ×2" bg="var(--lime)" />
    <Stamp text="패스 0점" bg="#D9D3E6" />
    <Stamp text="못 골랐다 −1점" bg="#FFD1D1" />
  </div>
)

const PAGES: TutorialPage[] = [
  { title: '통에 독이 있을까?', art: oddsCard, line: <>독 <b>확률</b>이 보여요.<br/>그걸 보고 각자 선택하는 거예요!</> },
  { title: '세 가지 중 하나', art: choices, line: <><b>마신다</b>, <b>패스</b>, <b>해독제</b>.<br/>정해진 시간 안에 골라요</> },
  { title: '선택으로 점수가 갈려요', art: reveal, line: <>주스는 마시면 득점인데, 주스에 해독제를 타면 실점. 독을 마시면 실점인데, 해독제를 타면 득점!</> },
  { title: '많이 모으면 승리', art: score, line: <>다양한 라운드가 존재해요. <b>합산 최고점</b>이 승리!</> },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
