import type { SusJarChoice, SusJarContent } from '@moyeora/shared'

export const CHOICE_LABEL: Record<SusJarChoice, string> = { drink: '마신다', pass: '패스', antidote: '해독제 넣는다' }
export const STAMP_LABEL: Record<SusJarChoice, string> = { drink: '마셨다', pass: '패스', antidote: '해독제' }
export const fmtPts = (n: number) => (n < 0 ? `−${-n}점` : n > 0 ? `+${n}점` : '0점')
export const NO_CHOICE = '못 골랐어요'
export const CONTENT_LABEL: Record<SusJarContent, string> = { juice: '주스였다!', poison: '독이었다!' }

export const ODDS_LOOK = {
  0.3: { tone: 'amber', title: '독이 적어요', hint: '주스일 가능성이 더 커요' },
  0.5: { tone: 'lav', title: '반반', hint: '아무도 몰라요' },
  0.7: { tone: 'lime', title: '독이 많아요', hint: '조심!' },
} as const
// 서버가 끝자리를 흔들어 보내므로(28%, 51%, 76%) 값이 아니라 구간으로 고른다.
export const oddsLook = (odds: number) => (odds < 0.4 ? ODDS_LOOK[0.3] : odds < 0.6 ? ODDS_LOOK[0.5] : ODDS_LOOK[0.7])
