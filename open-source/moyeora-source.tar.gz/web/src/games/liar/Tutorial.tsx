import { Avatar } from '../../ui/Avatar.tsx'
import { Stamp } from '../../ui/ResultRow.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { PersonCard, cardBadge } from './PersonCard.tsx'
import { SecretCard } from './SecretCard.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import './tutorial.css'

const noop = () => {}
const citizen = { category: '과일', word: '사과', isLiar: false } as never
const P = (id: string, name: string) => ({ id, name, avatar: id })

const PAGES: TutorialPage[] = [
  {
    title: '한 명만 몰라요',
    art: (
      <div className="ltut ltut__pair" aria-hidden="true">
        <SecretCard g={citizen} word="사과" />
        <div className="q-card" style={{ gap: 10 }}>
          <div className="jua" style={{ fontSize: 24 }}><span style={{ color: 'var(--lav)', fontSize: 16 }}>카테고리 · </span>과일</div>
          <div className="jua" style={{ minHeight: 92, boxSizing: 'border-box', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--cream)', border: '3px solid var(--ink)', color: '#c0392b', fontSize: 28 }}>당신은 라이어!</div>
        </div>
      </div>
    ),
    line: <>참가자 중 제시어를 모르는 한 명이 <b>라이어</b>예요.</>,
  },
  {
    title: '한 마디씩 설명해요',
    art: (
      <div className="ltut ltut__sec" aria-hidden="true">
        <TurnCard name="똑똑한 문어" avatar="tut-a" me meHint="제시어를 한 마디로 설명해요" />
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10 }}>
          <Avatar seed="tut-b" size={44} dim /><Avatar seed="tut-c" size={44} dim /><Avatar seed="tut-d" size={44} dim />
        </div>
      </div>
    ),
    line: <>제시어를 <b>한 마디</b>로 설명!<br/>라이어는 아는 척할 수밖에 없겠죠.</>,
  },
  {
    title: '라이어를 찾아요',
    art: (
      <div className="ltut ltut__vote" aria-hidden="true">
        <div><PersonCard p={P('tut-b', '느긋한 곰')} id="tut-b" me={false} onClick={noop} disabled /></div>
        <div><PersonCard p={P('tut-c', '수상한 여우')} id="tut-c" me={false} onClick={noop} selected badge={cardBadge('내 표', 'ink')} /></div>
      </div>
    ),
    line: <>가장 수상한 사람에게 <b>투표</b>! 라이어는 나중에 제시어를 맞힐 기회가 있어요.</>,
  },
  {
    title: '점수는 이렇게',
    art: (
      <div className="ltut ltut__rows" aria-hidden="true">
        <div>시민이 라이어를 찍으면 <Stamp text="+1점" bg="var(--lime)" /></div>
        <div>라이어가 안 잡히면 <Stamp text="+2점" bg="var(--amber)" /></div>
        <div>잡혀도 제시어를 맞히면 <Stamp text="+1점" bg="var(--amber)" /></div>
      </div>
    ),
    line: <>3판 합계가 가장 높은 사람이 <b>승리</b>!</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
