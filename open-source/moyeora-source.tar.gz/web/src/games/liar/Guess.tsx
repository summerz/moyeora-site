import type { LiarRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { Headline } from './Headline.tsx'
import { SecretCard } from './SecretCard.tsx'

type Props = { room: LiarRoom; choice: string | null; onChoose: (idx: string) => void }

export function Guess({ room, choice, onChoose }: Props) {
  const { g } = room
  if (!g.isLiar) {
    const liar = room.players.find((p) => p.id === g.liar)
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <SecretCard g={g} />
        {liar && <div style={{ display: 'flex', justifyContent: 'center' }}><Avatar seed={liar.avatar} size={72} /></div>}
        <Headline title={liar ? '제시어를 고르는 중…' : '라이어가 나갔어요'} sub={liar && <><span className="nick">{liar.name}</span> 님이 라이어였어요</>} />
      </div>
    )
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SecretCard g={g} />
      <Headline title="당신은 라이어였죠!" sub="진짜 제시어는 뭐였을까요?" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {(g.options ?? []).map((o, i) => {
          const mine = choice === String(i)
          return (
            <button key={o} type="button" className="btn-sticker" data-tone={mine ? 'lime' : 'cream'} aria-pressed={mine}
              onClick={() => { navigator.vibrate?.(20); onChoose(String(i)) }}
              style={{ minHeight: 64, fontSize: 19, lineHeight: 1.2, wordBreak: 'keep-all', overflowWrap: 'anywhere', textAlign: 'center', ...(choice !== null && !mine ? { opacity: 0.6 } : null) }}>
              {o}
            </button>
          )
        })}
      </div>
    </div>
  )
}
