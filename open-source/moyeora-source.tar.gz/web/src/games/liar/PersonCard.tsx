import type { ReactNode } from 'react'
import { Avatar } from '../../ui/Avatar.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'

type P = { id: string; name: string; avatar: string; bot?: boolean }
type Props = {
  p: P | undefined
  /** p 가 없을 때(나간 사람) 쓰는 id — 아바타 시드 */
  id: string
  me: boolean
  /** 있으면 버튼(투표) */
  onClick?: () => void
  disabled?: boolean
  selected?: boolean
  /** 배경색(예: 라이어 = amber) */
  bg?: string
  /** 오른쪽 위 딱지 */
  badge?: ReactNode
  children?: ReactNode
}

/** Vote·VoteReveal·GuessReveal 격자의 사람 카드: 아바타 + 이름(+ 나) + 아래 내용. 같은 크기. */
export function PersonCard({ p, id, me, onClick, disabled, selected, bg, badge, children }: Props) {
  const style = { position: 'relative', padding: '10px 10px', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6, font: 'inherit', textAlign: 'left', boxSizing: 'border-box', width: '100%', boxShadow: me ? '3px 3px 0 var(--lime)' : undefined, background: selected ? 'var(--lime)' : bg } as const
  const body = (
    <>
      <Avatar seed={p?.avatar ?? id} size={56} />
      <span className="nick nick--2l" style={{ width: '100%' }}>{(p?.name ?? '?') + (me ? ' · 나' : '')}{p?.bot && <NpcTag />}</span>
      {children}
      {badge}
    </>
  )
  return onClick ? (
    <button type="button" className="sticker" disabled={disabled} aria-pressed={selected} onClick={onClick} style={{ ...style, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1 }}>{body}</button>
  ) : (
    <div className="sticker" style={{ ...style, boxShadow: me ? '3px 3px 0 var(--lime)' : '3px 3px 0 var(--ink)' }}>{body}</div>
  )
}

/** PersonCard 오른쪽 위 딱지 */
export const cardBadge = (text: string, tone: 'ink' | 'amber'): ReactNode => (
  <span className="jua" style={{ position: 'absolute', top: 8, right: 8, background: 'var(--ink)', color: tone === 'amber' ? 'var(--amber)' : 'var(--cream)', fontSize: 13, padding: '2px 10px', borderRadius: 999, whiteSpace: 'nowrap', transform: tone === 'amber' ? 'rotate(8deg)' : undefined }}>{text}</span>
)
