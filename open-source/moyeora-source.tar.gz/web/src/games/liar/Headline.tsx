import type { ReactNode } from 'react'

/** 화면 맨 위 큰 제목(Jua) + 작은 보조 줄. liar 의 투표·맞히기 화면 공통. */
export function Headline({ title, sub }: { title: ReactNode; sub?: ReactNode }) {
  return (
    <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div className="jua" style={{ fontSize: 30, lineHeight: 1.25, wordBreak: 'keep-all', overflowWrap: 'anywhere' }}>{title}</div>
      {sub && <div style={{ fontSize: 15, color: 'var(--lav)', lineHeight: 1.4, wordBreak: 'keep-all' }}>{sub}</div>}
    </div>
  )
}
