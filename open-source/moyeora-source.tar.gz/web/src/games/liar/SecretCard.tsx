import { useState } from 'react'
import type { LiarView } from '@moyeora/shared'

const AREA = { minHeight: 92, boxSizing: 'border-box', borderRadius: 14, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, textAlign: 'center', padding: '8px 12px', width: '100%' } as const

type Props = {
  g: LiarView
  /** talk 단계: 눌러서 제시어 확인(다시 누르면 가림). 처음 열 때 onOpen */
  peek?: boolean
  onOpen?: () => void
  /** 맞히기 공개 뒤: 제시어를 그대로 보여준다 */
  word?: string
}

/** 모든 liar 화면 맨 위의 같은 카드(같은 틀·크기). 카테고리 + 제시어 칸.
 *  제시어는 talk 에서만 눌러서 본다 — 그 밖의 단계에선 가려 둔다(투표 중 라이어가 옆 폰을 엿볼 수 있다). 가린 모습은 라이어·시민 똑같다. */
export function SecretCard({ g, peek = false, onOpen, word }: Props) {
  const [open, setOpen] = useState(false)
  const toggle = () => {
    if (!open) onOpen?.()
    setOpen(!open)
  }
  return (
    <div className="q-card" style={{ gap: 10 }}>
      <div className="jua" style={{ fontSize: 24, lineHeight: 1.3, wordBreak: 'keep-all' }}>
        <span style={{ color: 'var(--lav)', fontSize: 16 }}>카테고리 · </span>{g.category}
      </div>
      {peek ? (
        <button type="button" aria-pressed={open} aria-label={open ? '제시어 가리기' : '눌러서 제시어 확인'} onClick={toggle}
          style={{ ...AREA, background: 'var(--cream)', color: 'var(--ink)', border: '3px solid var(--ink)', cursor: 'pointer', font: 'inherit' }}>
          {!open ? (
            <>
              <svg width={30} height={30} viewBox="0 0 24 24" fill="none" stroke="var(--ink)" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx={12} cy={12} r={9.5} /><path d="M9.3 9.6a2.8 2.8 0 1 1 4.2 2.4c-.9.5-1.5 1-1.5 2M12 17.4v.1" />
              </svg>
              <span className="jua" style={{ fontSize: 20 }}>눌러서 제시어 확인</span>
            </>
          ) : g.isLiar ? (
            <>
              <span className="jua" style={{ fontSize: 28, lineHeight: 1.2, color: '#c0392b' }}>당신은 라이어!</span>
              <span style={{ fontSize: 13, fontWeight: 700, wordBreak: 'keep-all' }}>남의 설명을 듣고 맞혀 보세요</span>
            </>
          ) : (
            <>
              <span style={{ fontSize: 12, color: '#6b5f8a' }}>제시어 · 다시 누르면 가려요</span>
              <span className="jua" style={{ fontSize: 34, lineHeight: 1.15, wordBreak: 'keep-all', overflowWrap: 'anywhere' }}>{g.word}</span>
            </>
          )}
        </button>
      ) : word ? (
        <div style={{ ...AREA, background: 'var(--cream)', color: 'var(--ink)', border: '3px solid var(--ink)' }}>
          <span style={{ fontSize: 12, color: '#6b5f8a' }}>제시어</span>
          <span className="jua" style={{ fontSize: 34, lineHeight: 1.15, wordBreak: 'keep-all', overflowWrap: 'anywhere' }}>{word}</span>
        </div>
      ) : (
        <div className="jua" style={{ ...AREA, border: '3px dashed var(--lav-dim)', color: 'var(--lav-dim)', fontSize: 18 }}>제시어는 비밀!</div>
      )}
    </div>
  )
}
