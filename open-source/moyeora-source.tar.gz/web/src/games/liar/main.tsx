import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { liarChooseMs, type LiarReveal, type LiarRoom, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { RoundProgress } from '../../ui/RoundProgress.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { useSocket } from '../../ws.ts'
import { Guess } from './Guess.tsx'
import { GuessReveal } from './GuessReveal.tsx'
import { Hero } from './Hero.tsx'
import { Talk } from './Talk.tsx'
import { Tutorial } from './Tutorial.tsx'
import { Vote } from './Vote.tsx'
import { VoteReveal } from './VoteReveal.tsx'

const TUT_KEY = 'moyeora:liar:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<LiarRoom | null>(null)
  const [reveal, setReveal] = useState<LiarReveal | null>(null)
  const [choice, setChoice] = useState<string | null>(null)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const roomRef = useRef<LiarRoom | null>(null)
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'liar') return
      const prev = roomRef.current
      if (!prev || prev.round !== m.room.round || (m.room.phase === 'choosing' && prev.phase !== 'choosing')) {
        setChoice(null)
        setReveal(null)
        setShowFinal(false)
        clearTimeout(finalTimer.current)
      }
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'reveal') {
      setReveal(m.result as LiarReveal)
      if (roomRef.current?.phase === 'done') {
        clearTimeout(finalTimer.current)
        finalTimer.current = setTimeout(() => setShowFinal(true), 6000)
      }
    } else {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    clearTimeout(finalTimer.current)
    setRoom(null)
    setReveal(null)
    setChoice(null)
    setShowFinal(false)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)

  const choose = (c: string) => {
    setChoice(c)
    send({ type: 'submit', choice: c })
  }

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="liar"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'liar', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    screen = (
      <Lobby room={room} hero={<Hero width={room.players.length > 4 ? 110 : 150} />} allowBots={false} canStart={room.players.length >= 3} startHint="3명 이상 모이면 시작할 수 있어요"
        onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => undefined} />
    )
  } else if (room.phase === 'done' && showFinal) {
    screen = <Final room={room} title="3판 끝!" onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })} />
  } else if (room.phase !== 'choosing' && reveal?.step === 'vote' && room.g.step === 'vote') {
    screen = <VoteReveal room={room} reveal={reveal} />
  } else if (room.phase !== 'choosing' && reveal?.step === 'guess' && room.g.step === 'guess') {
    screen = <GuessReveal room={room} reveal={reveal} onResult={() => setShowFinal(true)} />
  } else if (room.g.step === 'guess') {
    screen = <Guess key={room.round} room={room} choice={choice} onChoose={choose} />
  } else if (room.g.step === 'vote') {
    screen = <Vote key={room.round} room={room} vote={choice} onVote={choose} />
  } else {
    screen = <Talk key={room.round} room={room} onDone={() => choose('done')} />
  }

  let right
  if (room && room.phase !== 'lobby' && room.g.step) {
    const revealing = room.phase !== 'choosing'
    const chip = <RoundProgress round={room.g.hand} rounds={room.g.hands} done={revealing && room.g.step === 'guess'} />
    right =
      room.phase === 'done' && showFinal ? undefined : revealing ? (
        <>{chip}<span style={{ color: 'var(--lav-dim)' }}>{room.players.length}명</span></>
      ) : (
        <>{chip}<Timer remainingMs={room.remainingMs} totalMs={liarChooseMs(room.g.step, room.players.length)} /></>
      )
  }

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={right} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
