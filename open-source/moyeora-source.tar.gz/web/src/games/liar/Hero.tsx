export function Hero({ width = 150 }: { width?: number }) {
  const big = width >= 150
  return (
    <div aria-hidden="true" className="sticker tilt-c" style={{ width, margin: '0 auto', padding: '8px 8px 12px', boxSizing: 'border-box', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div className="jua hero-look" style={{ fontSize: big ? 84 : 60, lineHeight: 1 }}>?</div>
      <span className="chip" style={{ fontSize: 14, padding: '0 12px', background: 'var(--amber)', boxShadow: '2px 2px 0 var(--ink)', borderWidth: 2, whiteSpace: 'nowrap' }}>누굴까?</span>
    </div>
  )
}
