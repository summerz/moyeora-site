import type { LiarRoom } from '@moyeora/shared'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { cardBadge, PersonCard } from './PersonCard.tsx'
import { Headline } from './Headline.tsx'
import { SecretCard } from './SecretCard.tsx'

type Props = { room: LiarRoom; vote: string | null; onVote: (id: string) => void }

/** 라이어·시민 화면이 똑같다(역할 단서 없음). 제시어도 가려 둔다. */
export function Vote({ room, vote, onVote }: Props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SecretCard g={room.g} />
      <Headline title="라이어를 잡아요!" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {room.players.map((p) => {
          const me = p.id === room.you
          const mine = vote === p.id
          return <PersonCard key={p.id} p={p} id={p.id} me={me} disabled={me} selected={mine} badge={mine ? cardBadge('내 표', 'ink') : undefined} onClick={() => { navigator.vibrate?.(20); onVote(p.id) }} />
        })}
      </div>
      <SubmitBanner room={room} label="투표했다!" />
    </div>
  )
}
