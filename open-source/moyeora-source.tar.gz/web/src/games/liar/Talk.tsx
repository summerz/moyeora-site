import { useState } from 'react'
import { currentSpeaker, type LiarRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { Icon } from '../../ui/icons.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { SecretCard } from './SecretCard.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'

type Props = { room: LiarRoom; onDone: () => void }

/** 차례대로 한 마디씩. 지금 차례인 사람만 '발언 완료'를 누른다(제시어 카드를 한 번 열어 본 뒤부터). */
export function Talk({ room, onDone }: Props) {
  const [opened, setOpened] = useState(false)
  const { g } = room
  const order = g.order.map((id) => room.players.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => !!p)
  const speakerId = currentSpeaker(g.order, g.spoke, room.players.map((p) => p.id))
  const speaker = room.players.find((p) => p.id === speakerId)
  const mine = speakerId === room.you
  const over = room.phase !== 'choosing'
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SecretCard key={room.round} g={g} peek onOpen={() => setOpened(true)} />
      <TurnCard name={speaker?.name ?? null} avatar={speaker?.avatar} me={mine} meHint="제시어를 한 마디로 설명해요" other="님이 말하는 중…" none="모두 말했어요! 곧 투표해요" />
      <div>
        <div className="jua" style={{ color: 'var(--lav)', fontSize: 15, marginBottom: 6 }}>말하는 순서</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 8 }}>
          {order.map((p, i) => {
            const done = g.spoke.includes(p.id)
            const now = p.id === speakerId
            return (
              <div key={p.id} aria-current={now ? 'step' : undefined} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, minWidth: 0, padding: '6px 2px', borderRadius: 14, background: now ? 'var(--amber)' : undefined, border: now ? '3px solid var(--ink)' : '3px solid transparent', boxSizing: 'border-box' }}>
                <span style={{ position: 'relative', display: 'inline-flex' }}>
                  <Avatar seed={p.avatar} size={44} dim={done} ring={p.id === room.you} />
                  {done && <span style={{ position: 'absolute', right: -4, bottom: -4, width: 20, height: 20, borderRadius: '50%', background: 'var(--lime)', color: 'var(--ink)', border: '2px solid var(--ink)', display: 'grid', placeItems: 'center' }}><Icon name="check" size={12} /></span>}
                </span>
                <span className="nick nick--sm nick--1l nick--center" style={{ maxWidth: '100%', color: now ? 'var(--ink)' : undefined, opacity: done ? 0.55 : 1 }}>{i + 1}. {p.name}{p.bot && <NpcTag />}</span>
              </div>
            )
          })}
        </div>
      </div>
      {mine && !over && (
        <>
          <button type="button" className="btn-sticker" data-tone="lime" disabled={!opened} onClick={() => { navigator.vibrate?.(20); onDone() }}>발언 완료</button>
          {!opened && <div style={{ fontSize: 13, color: 'var(--lav)', textAlign: 'center' }}>제시어 카드를 먼저 눌러 확인해요</div>}
        </>
      )}
    </div>
  )
}
