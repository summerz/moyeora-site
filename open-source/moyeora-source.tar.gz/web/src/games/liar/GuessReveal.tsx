import type { LiarReveal, LiarRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { PersonCard } from './PersonCard.tsx'
import { SecretCard } from './SecretCard.tsx'

type Props = { room: LiarRoom; reveal: Extract<LiarReveal, { step: 'guess' }>; onResult: () => void }

const fmt = (d: number) => (d > 0 ? `+${d}점` : '+0점')

export function GuessReveal({ room, reveal, onResult }: Props) {
  const left = useCountdown(room.remainingMs)
  const player = (id: string) => room.players.find((p) => p.id === id)
  const liar = player(reveal.liar)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SecretCard g={room.g} word={reveal.word} />
      <div className="sticker" style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12, background: reveal.guess === null ? undefined : reveal.correct ? 'var(--lime)' : '#ff8a87' }}>
        <Avatar seed={liar?.avatar ?? reveal.liar} size={44} />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="nick nick--sm nick--1l">{liar ? liar.name : '라이어'} (라이어)</div>
          <div className="jua" style={{ fontSize: 22, lineHeight: 1.2, wordBreak: 'keep-all', overflowWrap: 'anywhere' }}>
            {reveal.guess === null ? (liar ? '고르지 못했어요' : '나갔어요') : `${reveal.guess} ${reveal.correct ? '· 맞았다!' : '· 틀렸다…'}`}
          </div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {reveal.players.map((r) => {
          const me = r.id === room.you
          return (
            <PersonCard key={r.id} p={player(r.id)} id={r.id} me={me}>
              <span className="jua" style={{ fontSize: 20 }}>
                <span style={{ color: r.delta > 0 ? 'var(--green)' : '#6b5f8a' }}>{fmt(r.delta)}</span> → {r.score}점
              </span>
            </PersonCard>
          )
        })}
      </div>
      {room.phase === 'done' ? (
        <button type="button" className="btn-sticker" data-tone="cream" onClick={onResult}>결과 보기</button>
      ) : (
        left !== null && <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>다음 판까지 {Math.ceil(left / 1000)}초</div>
      )}
    </div>
  )
}
