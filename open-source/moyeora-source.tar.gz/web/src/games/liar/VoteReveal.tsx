import type { LiarReveal, LiarRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { cardBadge, PersonCard } from './PersonCard.tsx'
import { SecretCard } from './SecretCard.tsx'

type Props = { room: LiarRoom; reveal: Extract<LiarReveal, { step: 'vote' }> }

export function VoteReveal({ room, reveal }: Props) {
  const left = useCountdown(room.remainingMs)
  const player = (id: string) => room.players.find((p) => p.id === id)
  const liar = player(reveal.liar)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <SecretCard g={room.g} />
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, textAlign: 'center' }}>
        <div className="jua" style={{ fontSize: 28, lineHeight: 1.25, wordBreak: 'keep-all', overflowWrap: 'anywhere' }}>
          라이어는 <span style={{ color: 'var(--lime)' }}>{liar?.name ?? '?'}</span>!
        </div>
        <span className="jua tilt-d pop" style={{ display: 'inline-block', fontSize: 30, padding: '2px 22px', borderRadius: 14, border: '4px solid var(--ink)', boxShadow: '4px 4px 0 var(--ink)', background: reveal.caught ? 'var(--lime)' : '#ff8a87', color: 'var(--ink)' }}>
          {reveal.caught ? '잡았다!' : '놓쳤다…'}
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {reveal.votes.map((v) => {
          const p = player(v.id)
          const isLiar = v.id === reveal.liar
          const me = v.id === room.you
          const delta = reveal.deltas[room.players.findIndex((q) => q.id === v.id)] ?? 0
          return (
            <PersonCard key={v.id} p={p} id={v.id} me={me} bg={isLiar ? 'var(--amber)' : undefined} badge={isLiar ? cardBadge('라이어', 'amber') : undefined}>
              <span className="jua" style={{ fontSize: 20 }}>{v.by.length}표 <span style={{ fontSize: 14, color: delta > 0 ? 'var(--green)' : '#6b5f8a' }}>{delta > 0 ? `+${delta}점` : '0점'}</span></span>
              <div style={{ minHeight: 24, display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap' }}>
                {v.by.map((id) => <Avatar key={id} seed={player(id)?.avatar ?? id} size={22} />)}
              </div>
            </PersonCard>
          )
        })}
      </div>
      {left !== null && <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>라이어의 마지막 기회까지 {Math.ceil(left / 1000)}초</div>}
    </div>
  )
}
