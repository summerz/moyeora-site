import { useEffect, useMemo, useState } from 'react'
import { callOf, type NunchiReveal, type NunchiRoom } from '@moyeora/shared'
import { useCountdownBeeps } from '../../ui/sound.ts'
import { useCountdown } from '../../ui/useCountdown.ts'
import { Order } from './Order.tsx'
import { ResultTable } from './ResultTable.tsx'
import { TapButton, type TapKind } from '../../ui/TapButton.tsx'

type Props = {
  room: NunchiRoom
  reveal: NunchiReveal | null
  goAt: number
  /** 이번 라운드에 내가 보낸 시각이 goAt 전이었는지(null: 아직 안 보냄) */
  sent: 'foul' | 'tap' | null
  onTap: () => void
}

const useNow = (active: boolean) => {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    if (!active) return
    const t = setInterval(() => setNow(Date.now()), 80)
    return () => clearInterval(t)
  }, [active])
  return active ? Date.now() : now
}

export function Play({ room, reveal, goAt, sent, onTap }: Props) {
  const choosing = room.phase === 'choosing'
  const now = useNow(choosing)
  const goPerf = useMemo(() => (choosing ? goAt - Date.now() + performance.now() : null), [choosing, goAt])
  useCountdownBeeps(goPerf)
  const left = useCountdown(choosing ? null : room.remainingMs)
  const me = room.you
  const myTap = room.g.taps.find((t) => t.id === me)
  const fouled = room.g.fouls.includes(me)
  const myRow = !choosing && reveal ? reveal.rows.find((r) => r.id === me) : undefined

  let kind: TapKind
  let label: string
  if (myRow) {
    if (myRow.result === 'foul') [kind, label] = ['bad', '부정 출발']
    else if (myRow.result === 'collide') [kind, label] = ['bad', '겹침!']
    else if (myRow.result === 'last') [kind, label] = ['bad', '꼴찌']
    else [kind, label] = [myRow.result === 'first' ? 'first' : 'tapped', `${callOf(myRow.n ?? 0)}!`]
  } else if (fouled || sent === 'foul') {
    ;[kind, label] = ['bad', '부정 출발']
  } else if (myTap) {
    ;[kind, label] = myTap.collided ? ['bad', '겹침!'] : ['tapped', `${callOf(myTap.n)}!`]
  } else if (sent === 'tap') {
    ;[kind, label] = ['tapped', '눌렀어요']
  } else if (!choosing) {
    ;[kind, label] = reveal ? ['bad', '꼴찌'] : ['tapped', '…']
  } else if (now < goAt) {
    ;[kind, label] = ['ready', String(Math.max(1, Math.ceil((goAt - now) / 1000)))]
  } else {
    ;[kind, label] = ['go', '일어나!']
  }
  const sec = left !== null ? Math.ceil(left / 1000) : null
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <TapButton kind={kind} label={label} disabled={!choosing || sent !== null || !!myTap || fouled} onPress={onTap} />
      {reveal && !choosing ? <ResultTable room={room} reveal={reveal} /> : <Order room={room} />}
      {reveal && !choosing && sec !== null && (
        <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>
          {room.phase === 'done' ? '곧 결과가 나와요' : `다음 라운드까지 ${sec}초`}
        </div>
      )}
    </div>
  )
}
