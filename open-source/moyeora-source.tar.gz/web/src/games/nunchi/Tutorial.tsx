import type { ReactNode } from 'react'
import { Avatar } from '../../ui/Avatar.tsx'
import { Stamp } from '../../ui/ResultRow.tsx'
import { TapButton } from '../../ui/TapButton.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { stampOf } from './ResultTable.tsx'

const who = (seed: string, stamp: { text: string; bg: string }): ReactNode => (
  <div className="tut__col">
    <Avatar seed={seed} size={64} />
    <Stamp text={stamp.text} bg={stamp.bg} />
  </div>
)

const PAGES: TutorialPage[] = [
  {
    title: '버튼이 켜지면 눌러요',
    art: <div className="tut__btn"><TapButton kind="go" label="누르기!" disabled onPress={() => {}} /></div>,
    line: <>3·2·1··· 눈치를 보면서<br/><b>안 겹칠 때</b> 눌러요!</>,
  },
  {
    title: '겹치면 실패',
    art: <>{who('tut-a', stampOf('collide', -4, 1))}{who('tut-b', stampOf('collide', -4, 1))}</>,
    line: <>거의 동시에 누르면 <b>겹침</b>! 둘 다 점수를 잃어요.</>,
  },
  {
    title: '늦어도, 빨라도 실패',
    art: <>{who('tut-c', stampOf('last', -2))}{who('tut-d', stampOf('foul', -2))}</>,
    line: <>마지막이면 <b>꼴찌</b>,<br/>3·2·1 끝나기 전에 누르면 <b>부정 출발</b></>,
  },
  {
    title: '눈치가 빨라야 해!',
    art: (
      <div className="tut__col tut__col--list">
        <Stamp {...stampOf('first', 5, 1)} />
        <Stamp {...stampOf('safe', 4, 2)} />
        <Stamp {...stampOf('collide', -4, 1)} />
        <Stamp {...stampOf('last', -2)} />
      </div>
    ),
    line: <>최고점을 얻은 사람이 승리!</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
