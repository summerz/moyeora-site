import './nunchi.css'

export function Hero({ size = 130 }: { size?: number }) {
  return (
    <div aria-hidden="true" className="sticker tilt-c nunchi-hero" style={{ width: size, height: size, margin: '0 auto', borderRadius: '50%', display: 'grid', placeItems: 'center', boxSizing: 'border-box' }}>
      <span className="jua" style={{ fontSize: size * 0.34, lineHeight: 1, whiteSpace: 'nowrap' }}>하나!</span>
    </div>
  )
}
