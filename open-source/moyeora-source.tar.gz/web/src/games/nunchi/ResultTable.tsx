import { callOf, type NunchiReveal, type NunchiResult, type NunchiRoom } from '@moyeora/shared'
import { ResultRow, Stamp } from '../../ui/ResultRow.tsx'

const LABEL: Record<NunchiResult, { text: string; bg: string }> = {
  first: { text: '하나!', bg: 'var(--lime)' },
  safe: { text: '성공', bg: 'var(--amber)' },
  collide: { text: '겹침', bg: 'var(--red)' },
  last: { text: '꼴찌', bg: 'var(--red)' },
  foul: { text: '부정 출발', bg: 'var(--red)' },
}

const num = (n: number) => (n < 0 ? `−${-n}` : String(n))
const signed = (n: number) => (n > 0 ? `+${n}` : num(n))

/** 도장 문구 = 결과(성공은 부른 말 "둘!") + 이번 라운드 실제 점수. 꼴찌 0점(겹침이 있었던 판)은 빨강 대신 중립색 */
export const stampOf = (result: NunchiResult, delta: number, n: number | null = null): { text: string; bg: string } => {
  const l = LABEL[result]
  const text = (result === 'first' || result === 'safe') && n !== null ? `${callOf(n)}!` : l.text
  return { text: `${text} ${signed(delta)}`, bg: delta === 0 ? 'var(--cream)' : l.bg }
}

export function ResultTable({ room, reveal }: { room: NunchiRoom; reveal: NunchiReveal }) {
  const by = new Map(room.players.map((p) => [p.id, p]))
  const rows = [...reveal.rows].sort((a, b) => (a.n ?? 99) - (b.n ?? 99))
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {rows.map((r) => {
        const p = by.get(r.id)
        if (!p) return null
        const stamp = stampOf(r.result, r.delta, r.n)
        return (
          <ResultRow key={r.id} p={p} me={r.id === room.you}>
            <Stamp text={stamp.text} bg={stamp.bg} />
            <span className="jua" style={{ minWidth: 48, textAlign: 'right', fontSize: 18 }}>{num(r.score)}점</span>
          </ResultRow>
        )
      })}
    </div>
  )
}
