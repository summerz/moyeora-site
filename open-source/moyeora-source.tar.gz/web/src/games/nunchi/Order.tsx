import { callOf, type NunchiRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'

const rowStyle = { display: 'flex', alignItems: 'center', gap: 8, minHeight: 40, padding: '2px 6px', borderRadius: 12, boxSizing: 'border-box' } as const
const numChip = { minWidth: 30, height: 30, padding: '0 8px', borderRadius: 15, border: '3px solid var(--ink)', boxSizing: 'border-box', display: 'grid', placeItems: 'center', fontSize: 14, whiteSpace: 'nowrap', flexShrink: 0, background: 'var(--cream)' } as const
const redChip = { background: 'var(--red)', fontSize: 13, padding: '0 8px', borderWidth: 2, boxShadow: '2px 2px 0 var(--ink)', flexShrink: 0, whiteSpace: 'nowrap' } as const

/** 누른 순서 목록. 부정 출발은 맨 위, 아직 안 누른 사람은 맨 아래. */
export function Order({ room }: { room: NunchiRoom }) {
  const by = new Map(room.players.map((p) => [p.id, p]))
  const { taps, fouls } = room.g
  const groups = new Map<number, { ids: string[]; collided: boolean }>()
  for (const t of taps) {
    const g = groups.get(t.n) ?? { ids: [], collided: t.collided }
    g.ids.push(t.id)
    groups.set(t.n, g)
  }
  const pressed = new Set([...taps.map((t) => t.id), ...fouls])
  const waiting = room.players.filter((p) => !pressed.has(p.id))
  const who = (ids: string[]) => ids.flatMap((id) => (by.get(id) ? [by.get(id)!] : []))
  const line = (ids: string[]) => (
    <>
      <span style={{ display: 'flex', gap: 2, flexShrink: 0 }}>
        {who(ids).map((p) => <Avatar key={p.id} seed={p.avatar} size={32} />)}
      </span>
      <span className="nick nick--sm nick--1l" style={{ flex: 1, minWidth: 0 }}>{who(ids).map((p) => p.name).join('·')}</span>
    </>
  )
  const mine = (ids: string[]) => (ids.includes(room.you) ? { background: 'rgba(140,255,77,.35)' } : null)
  return (
    <div className="sticker" style={{ padding: 8, display: 'flex', flexDirection: 'column', gap: 2 }} aria-label="누른 순서">
      {fouls.length > 0 && (
        <div style={{ ...rowStyle, ...mine(fouls) }}>
          <span className="chip jua" style={{ ...redChip, fontSize: 14 }}>부정 출발</span>
          {line(fouls)}
        </div>
      )}
      {[...groups.entries()].map(([n, g]) => (
        <div key={n} style={{ ...rowStyle, ...mine(g.ids) }}>
          <span className="jua" style={{ ...numChip, ...(g.collided ? { background: 'var(--red)' } : null) }}>{callOf(n)}</span>
          {line(g.ids)}
          {g.collided && <span className="chip jua" style={redChip}>겹침</span>}
        </div>
      ))}
      {waiting.length > 0 && (
        <div style={{ ...rowStyle, opacity: 0.55 }}>
          <span className="jua" style={{ fontSize: 14, minWidth: 30, textAlign: 'center', flexShrink: 0 }}>아직</span>
          <span style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {waiting.map((p) => <Avatar key={p.id} seed={p.avatar} size={32} dim />)}
          </span>
        </div>
      )}
    </div>
  )
}
