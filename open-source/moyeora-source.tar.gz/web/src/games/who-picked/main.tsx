import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { WHO_PICKED_PACKS, type WhoPickedRoom, type ServerMessage, type WhoPickedReveal, type WhoPickedPack } from '@moyeora/shared'
import { PACK_LABEL } from './labels.ts'
import { errorText } from '../../ui/errors.ts'
import { Final } from '../../ui/Final.tsx'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { RoundProgress } from '../../ui/RoundProgress.tsx'
import { Shell } from '../../ui/Shell.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { useSocket } from '../../ws.ts'
import { Guess } from './Guess.tsx'
import { GuessReveal } from './GuessReveal.tsx'
import { Hero } from './Hero.tsx'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { Pick } from './Pick.tsx'
import { Review, type ReviewItem } from './Review.tsx'
import { PickReveal } from './PickReveal.tsx'
import { Tutorial } from './Tutorial.tsx'

const TUT_KEY = 'moyeora:who-picked:tutorial'
const tutorialSeen = () => {
  try { return localStorage.getItem(TUT_KEY) === '1' } catch { return false }
}

function App() {
  const [tutorial, setTutorial] = useState(false)
  const [tutSeen, setTutSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<WhoPickedRoom | null>(null)
  const [reveal, setReveal] = useState<WhoPickedReveal | null>(null)
  const [choice, setChoice] = useState<string | null>(null)
  const [error, setError] = useState<string>()
  const [showFinal, setShowFinal] = useState(false)
  const [history, setHistory] = useState<ReviewItem[]>([])
  const [review, setReview] = useState(false)
  const roomRef = useRef<WhoPickedRoom | null>(null)
  const finalTimer = useRef<ReturnType<typeof setTimeout>>(undefined)
  useEffect(() => () => clearTimeout(finalTimer.current), [])

  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room') {
      if (m.room.game !== 'who-picked') return
      const prev = roomRef.current
      if (!prev || prev.round !== m.room.round || (m.room.phase === 'choosing' && prev.phase !== 'choosing')) {
        setChoice(null)
        setReveal(null)
        setShowFinal(false)
        clearTimeout(finalTimer.current)
      }
      if (m.room.phase === 'lobby' || (m.room.phase === 'choosing' && m.room.round === 1)) {
        setHistory([])
        setReview(false)
      }
      roomRef.current = m.room
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'reveal') {
      const result = m.result as WhoPickedReveal
      setReveal(result)
      const cur = roomRef.current
      if (result.step === 'guess' && cur && cur.game === 'who-picked') {
        const item: ReviewItem = { round: m.round, text: cur.g.text ?? '', options: cur.g.options, answers: result.answers }
        setHistory((h) => [...h.filter((x) => x.round !== m.round), item])
      }
      if (roomRef.current?.phase === 'done') {
        clearTimeout(finalTimer.current)
        finalTimer.current = setTimeout(() => setShowFinal(true), 3000)
      }
    } else {
      setError(errorText(m.message))
    }
  }
  const onClose = () => {
    roomRef.current = null
    clearTimeout(finalTimer.current)
    setRoom(null)
    setReveal(null)
    setChoice(null)
    setShowFinal(false)
    setHistory([])
    setReview(false)
    setError((e) => e ?? '연결이 끊겼어요')
  }
  const send = useSocket(onMessage, onClose)

  const choose = (c: string) => {
    setChoice(c)
    send({ type: 'submit', choice: c })
  }
  const autoRound = useRef(-1)
  const needAuto = !!room && room.phase === 'choosing' && room.g.step === 'guess' && (!room.g.pickers.includes(room.you) || room.g.pickers.every((id) => id === room.you))
  const autoKey = room ? room.round : -1
  useEffect(() => {
    if (!needAuto || autoRound.current === autoKey) return
    autoRound.current = autoKey
    setChoice('')
    send({ type: 'submit', choice: '' })
  }, [needAuto, autoKey, send])

  let screen
  if (!profile || editing) {
    screen = <Profile initial={profile ?? undefined} onDone={(p) => { setProfile(p); setEditing(false) }} />
  } else if (!room) {
    screen = (
      <Join game="who-picked"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'who-picked', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  } else if (room.phase === 'lobby') {
    screen = <Lobby room={room} hero={<Hero width={room.players.length > 4 ? 110 : 150} />} onStart={() => send({ type: 'start' })} onKick={(playerId) => send({ type: 'kick', playerId })} onAddBot={() => send({ type: 'addBot' })}>
        <SegmentPicker label="질문 묶음" options={WHO_PICKED_PACKS.map((p) => ({ value: p, label: PACK_LABEL[p] }))} value={room.g.pack} host={room.host === room.you} onPick={(pack: WhoPickedPack) => send({ type: 'config', config: { pack } })} />
      </Lobby>
  } else if (room.phase === 'choosing' || !reveal) {
    screen = room.g.step === 'guess' ? <Guess key={room.round} room={room} onSubmit={choose} /> : <Pick room={room} choice={choice} onChoose={choose} />
  } else if (room.phase === 'done' && showFinal && review) {
    screen = <Review items={history} room={room} onClose={() => setReview(false)} />
  } else if (room.phase === 'done' && showFinal) {
    screen = (
      <Final room={room} title={`질문 ${room.g.questions}개 끝!`} onAgain={() => send({ type: 'start' })} onLobby={() => send({ type: 'lobby' })}>
        {history.length > 0 && <button type="button" className="btn-sticker" data-tone="cream" onClick={() => setReview(true)}>다시 보기</button>}
      </Final>
    )
  } else {
    screen = reveal.step === 'pick' ? <PickReveal room={room} reveal={reveal} /> : <GuessReveal room={room} reveal={reveal} onResult={() => setShowFinal(true)} />
  }

  let right
  if (room && room.phase !== 'lobby') {
    const chip = <RoundProgress round={room.g.question} rounds={room.g.questions} done={room.phase !== 'choosing' && !!reveal && reveal.step === 'guess'} />
    right =
      room.phase === 'choosing' || !reveal ? (
        <>{chip}<Timer remainingMs={room.remainingMs} totalMs={30000} /></>
      ) : room.phase === 'done' && showFinal ? undefined : (
        <>{chip}<span style={{ color: 'var(--lav-dim)' }}>{room.players.length}명</span></>
      )
  }

  const showTutorial = tutorial || (!!room && room.phase === 'lobby' && !tutSeen)
  const closeTutorial = () => {
    try { localStorage.setItem(TUT_KEY, '1') } catch { /* ignore */ }
    setTutSeen(true)
    setTutorial(false)
  }

  return (
    <Shell onLobby={room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done' ? () => send({ type: 'lobby' }) : undefined} safe={!room || room.phase === 'lobby' || room.phase === 'done'} right={right} onHelp={() => setTutorial(true)} confirmHome={!!room}>
      {screen}
      {showTutorial && <Tutorial onClose={closeTutorial} />}
    </Shell>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
