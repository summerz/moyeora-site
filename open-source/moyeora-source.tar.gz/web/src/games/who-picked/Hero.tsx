import { OPTION_LETTER } from './labels.ts'

export function Hero({ width = 150 }: { width?: number }) {
  return (
    <div aria-hidden="true" className="sticker tilt-c" style={{ width, margin: '0 auto', padding: '6px 8px 10px', boxSizing: 'border-box', textAlign: 'center' }}>
      <div className="jua hero-wiggle" style={{ fontSize: width < 150 ? 48 : 64, lineHeight: 1.1 }}>?</div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 4 }}>
        {OPTION_LETTER.map((l, i) => (
          <span key={l} className="chip hero-hop" style={{ animationDelay: `${i * 0.12}s`, fontSize: 12, padding: '0 7px', background: 'var(--cream)', boxShadow: '2px 2px 0 var(--ink)', borderWidth: 2 }}>{l}</span>
        ))}
      </div>
    </div>
  )
}
