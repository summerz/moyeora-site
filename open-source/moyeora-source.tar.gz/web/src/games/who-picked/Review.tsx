import { useState } from 'react'
import { WHO_PICKED_OPTIONS, type WhoPickedAnswer, type WhoPickedRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { OPTION_LETTER, letterOf, optionLabel } from './labels.ts'
import { OptionCard } from './OptionCard.tsx'
import { QuestionCard } from './QuestionCard.tsx'

export type ReviewItem = { round: number; text: string; options: string[]; answers: WhoPickedAnswer[] }
type Props = { items: ReviewItem[]; room: WhoPickedRoom; onClose: () => void }

export function Review({ items, room, onClose }: Props) {
  const [idx, setIdx] = useState(0)
  const item = items[Math.min(idx, items.length - 1)]
  if (!item) return null

  const chips = (list: WhoPickedAnswer[]) => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
      {list.map((a) => {
        const p = room.players.find((q) => q.id === a.id)
        const me = a.id === room.you
        return (
          <span key={a.id} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px 2px 2px', borderRadius: 999, border: '2px solid var(--ink)', background: me ? 'var(--lime)' : 'var(--cream)' }}>
            <Avatar seed={p?.avatar ?? a.id} size={24} />
            <span className="nick nick--sm nick--1l" style={{ maxWidth: 120 }}>{p?.name ?? '?'}</span>
            {p?.bot && <NpcTag />}
          </span>
        )
      })}
    </div>
  )
  const myPick = item.answers.find((a) => a.id === room.you)?.pick ?? null
  const resters = item.answers.filter((a) => !a.pick)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <QuestionCard question={idx + 1} total={items.length} text={item.text}
        myPick={myPick ? { letter: letterOf(myPick), text: optionLabel(item.options, myPick) } : null} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {WHO_PICKED_OPTIONS.map((o, i) => {
          const who = item.answers.filter((a) => a.pick === o)
          return (
            <OptionCard key={o} letter={OPTION_LETTER[i]!} text={item.options[i] ?? ''}
              below={who.length > 0 ? chips(who) : <span style={{ fontSize: 13, color: '#6b5f8a' }}>아무도 안 골랐어요</span>} />
          )
        })}
      </div>
      {resters.length > 0 && (
        <div style={{ border: '3px dashed var(--lav-dim)', borderRadius: 20, padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span className="jua" style={{ fontSize: 14, color: 'var(--lav)' }}>쉰 사람</span>
          {chips(resters)}
        </div>
      )}
      <div style={{ display: 'flex', gap: 10 }}>
        <button type="button" className="btn-sticker" data-tone="cream" disabled={idx <= 0} onClick={() => setIdx(idx - 1)}>← 이전</button>
        <button type="button" className="btn-sticker" data-tone="cream" disabled={idx >= items.length - 1} onClick={() => setIdx(idx + 1)}>다음 →</button>
      </div>
      <button type="button" className="btn-sticker" data-tone="cream" onClick={onClose}>결과로 돌아가기</button>
    </div>
  )
}
