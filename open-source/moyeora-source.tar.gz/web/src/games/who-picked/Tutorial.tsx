import type { ReactNode } from 'react'
import { Avatar } from '../../ui/Avatar.tsx'
import { Stamp } from '../../ui/ResultRow.tsx'
import { Tutorial as Frame, type TutorialPage } from '../../ui/Tutorial.tsx'
import { LetterBadge, OptionCard } from './OptionCard.tsx'

/** 실제 보기 카드를 줄여 놓은 그림 (누를 수 없음) */
const scaled = (children: ReactNode, width = 430, zoom = 0.62): ReactNode => (
  <div aria-hidden="true" style={{ zoom, width, pointerEvents: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>{children}</div>
)

const mine = <span className="chip jua" style={{ fontSize: 13, padding: '0 10px', borderWidth: 2, boxShadow: '2px 2px 0 var(--ink)' }}>내 선택</span>
const count = (n: number) => <span className="jua" style={{ fontSize: 18 }}>{n}명</span>

const PAGES: TutorialPage[] = [
  {
    title: '몰래 하나 골라요',
    art: scaled(
      <>
        <OptionCard letter="A" text="치킨" tone="dim" />
        <OptionCard letter="B" text="피자" tone="lime" right={mine} />
        <OptionCard letter="C" text="떡볶이" tone="dim" />
      </>,
    ),
    line: <>질문에 대한 내가 생각하는 답을 <b>몰래</b> 골라요. 다 고르면 몇 명이 뭘 선택했는지 공개!</>,
  },
  {
    title: '누가 뭘 골랐을까',
    art: (
      <div className="tut__col" aria-hidden="true" style={{ pointerEvents: 'none', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Avatar seed="who-a" size={48} />
          <span className="jua" style={{ fontSize: 18 }}>똑똑한 문어는?</span>
        </div>
        <div style={{ zoom: 0.62, width: 430, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <OptionCard letter="A" text="치킨" right={count(1)} />
          <OptionCard letter="B" text="피자" tone="lime" right={count(2)} />
        </div>
      </div>
    ),
    line: <>얘가 이걸 골랐을까?<br/>잘 고민해서 맞혀요! 맞히면 <b>+2점</b></>,
  },
  {
    title: '의외의 답은 보너스',
    art: (
      <div className="sticker" aria-hidden="true" style={{ pointerEvents: 'none', width: 190, padding: '10px 10px', display: 'flex', flexDirection: 'column', gap: 4, boxShadow: '3px 3px 0 var(--lime)', position: 'relative' }}>
        <Avatar seed="who-b" size={40} />
        <span style={{ position: 'absolute', top: 8, right: 8, transform: 'rotate(8deg)', display: 'inline-flex' }}><LetterBadge letter="C" /></span>
        <span className="nick nick--2l">엉뚱한 너구리</span>
        <span className="chip" style={{ fontSize: 12, padding: '0 8px', background: 'var(--amber)', borderWidth: 2, boxShadow: '2px 2px 0 var(--ink)' }}>아무도 못 맞힘 +3점</span>
      </div>
    ),
    line: <>내 답을 <b>아무도 못 맞히면</b> 내가 +3점!</>,
  },
  {
    title: '점수는 이렇게',
    art: (
      <div className="tut__col tut__col--list" aria-hidden="true" style={{ pointerEvents: 'none' }}>
        <Stamp text="한 명 맞힘 +2" bg="var(--lime)" />
        <Stamp text="아무도 못 맞힘 +3" bg="var(--amber)" />
        <Stamp text="시간 안에 못 냄 0" bg="var(--cream)" />
      </div>
    ),
    line: <>질문 5개, 한 번에 30초. 합산 <b>최고점</b>이 승리!</>,
  },
]

export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame pages={PAGES} onClose={onClose} />
}
