import { LetterBadge } from './OptionCard.tsx'

type Props = { question: number; total: number; text: string; myPick: { letter: string; text: string } | null }

export function QuestionCard({ question, total, text, myPick }: Props) {
  return (
    <div className="q-card">
      <div><span className="chip jua" style={{ background: 'var(--amber)', fontSize: 13, padding: '0 12px' }}>Q{question} / {total}</span></div>
      <div className="jua" style={{ fontSize: 20, lineHeight: 1.35, wordBreak: 'keep-all' }}>{text}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, minHeight: 22 }}>
        <span className="jua" style={{ color: 'var(--lav)', flexShrink: 0 }}>내 답</span>
        {myPick ? (
          <>
            <LetterBadge letter={myPick.letter} size="sm" />
            <span style={{ fontWeight: 700, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{myPick.text}</span>
          </>
        ) : (
          <span style={{ color: 'var(--lav-dim)' }}>아직 안 골랐어요</span>
        )}
      </div>
    </div>
  )
}
