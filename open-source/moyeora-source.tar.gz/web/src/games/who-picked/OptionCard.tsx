import type { ReactNode } from 'react'

export function LetterBadge({ letter, size = 'md' }: { letter: string; size?: 'sm' | 'md' }) {
  const px = size === 'sm' ? 22 : 30
  return (
    <span className="jua" aria-hidden="true" style={{ width: px, height: px, flex: 'none', borderRadius: '50%', border: '3px solid var(--ink)', boxSizing: 'border-box', display: 'grid', placeItems: 'center', fontSize: size === 'sm' ? 12 : 16, lineHeight: 1, background: 'var(--cream)', color: 'var(--ink)' }}>{letter}</span>
  )
}

type Props = {
  letter: string
  text: string
  tone?: 'cream' | 'lime' | 'dim'
  right?: ReactNode
  below?: ReactNode
  onClick?: () => void
  ariaLabel?: string
  pressed?: boolean
}

export function OptionCard({ letter, text, tone = 'cream', right, below, onClick, ariaLabel, pressed }: Props) {
  const style = {
    minHeight: 56, padding: '10px 14px', display: 'flex', flexDirection: 'column', alignItems: 'stretch', justifyContent: 'center', gap: 8,
    textAlign: 'left', boxSizing: 'border-box', width: '100%', fontFamily: '"Noto Sans KR", sans-serif', fontSize: 16, ...(tone === 'dim' ? { opacity: 0.6 } : null),
  } as const
  const body = (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <LetterBadge letter={letter} />
        <span style={{ flex: 1, minWidth: 0, fontSize: 16, fontWeight: 700, lineHeight: 1.3, wordBreak: 'keep-all' }}>{text}</span>
        {right != null && <span style={{ flexShrink: 0 }}>{right}</span>}
      </div>
      {below}
    </>
  )
  if (onClick) {
    return (
      <button type="button" className="btn-sticker" data-tone={tone === 'lime' ? 'lime' : 'cream'} aria-pressed={pressed} aria-label={ariaLabel} onClick={onClick} style={style}>{body}</button>
    )
  }
  return <div className="sticker" aria-label={ariaLabel} style={{ ...style, background: tone === 'lime' ? 'var(--lime)' : undefined, boxShadow: '4px 4px 0 var(--ink)', borderRadius: 18 }}>{body}</div>
}
