import { WHO_PICKED_OPTIONS, type WhoPickedReveal, type WhoPickedRoom } from '@moyeora/shared'
import { useCountdown } from '../../ui/useCountdown.ts'
import { OPTION_LETTER, letterOf, optionLabel } from './labels.ts'
import { OptionCard } from './OptionCard.tsx'
import { QuestionCard } from './QuestionCard.tsx'

type Props = { room: WhoPickedRoom; reveal: Extract<WhoPickedReveal, { step: 'pick' }> }

export function PickReveal({ room, reveal }: Props) {
  const left = useCountdown(room.remainingMs)
  const total = Math.max(1, reveal.pickers.length)
  const mine = room.g.myPick
  const sec = left !== null ? Math.ceil(left / 1000) : null
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <QuestionCard question={room.g.question} total={room.g.questions} text={room.g.text ?? ''}
        myPick={mine ? { letter: letterOf(mine), text: optionLabel(room.g.options, mine) } : null} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {WHO_PICKED_OPTIONS.map((o, i) => {
          const n = reveal.counts ? (reveal.counts[i] ?? 0) : null
          return (
            <OptionCard key={o} letter={OPTION_LETTER[i]!} text={room.g.options[i] ?? ''}
              right={n !== null ? <span className="jua" style={{ fontSize: 18 }}>{n}명</span> : undefined}
              below={n !== null ? (
                <div style={{ height: 10, borderRadius: 999, background: 'var(--card)', overflow: 'hidden' }}>
                  <div style={{ width: `${(n / total) * 100}%`, height: '100%', background: 'var(--amber)' }} />
                </div>
              ) : undefined} />
          )
        })}
      </div>
      {sec !== null && (
        <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>
          {reveal.counts ? `모두 골랐어요! 맞히기까지 ${sec}초` : `둘이서는 인원수가 비밀이에요. 맞히기까지 ${sec}초`}
        </div>
      )}
    </div>
  )
}
