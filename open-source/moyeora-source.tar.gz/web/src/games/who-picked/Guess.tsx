import { useState } from 'react'
import { WHO_PICKED_OPTIONS, type WhoPickedOption, type WhoPickedRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { OPTION_LETTER, letterOf, optionLabel } from './labels.ts'
import { LetterBadge, OptionCard } from './OptionCard.tsx'
import { QuestionCard } from './QuestionCard.tsx'

type Props = { room: WhoPickedRoom; onSubmit: (s: string) => void }

export function Guess({ room, onSubmit }: Props) {
  const [answers, setAnswers] = useState<Record<string, WhoPickedOption>>({})
  const [cursor, setCursor] = useState(0)
  const [editing, setEditing] = useState(false)
  const [sent, setSent] = useState(false)
  const targets = room.players.filter((p) => room.g.pickers.includes(p.id) && p.id !== room.you)
  const opts = room.g.options
  const mine = room.g.myPick
  const mineIdx = mine ? WHO_PICKED_OPTIONS.indexOf(mine) : -1

  if (targets.length === 0) {
    return (
      <div className="sticker tilt-b" style={{ padding: 16, textAlign: 'center' }}>
        <div className="jua" style={{ fontSize: 18 }}>이번엔 맞힐 사람이 없어요</div>
      </div>
    )
  }

  const all = targets.every((p) => answers[p.id])
  const summary = all && !editing
  const cur = targets[Math.min(cursor, targets.length - 1)]!
  const remaining = (i: number) => {
    const given = targets.filter((p) => p.id !== cur.id && answers[p.id] === WHO_PICKED_OPTIONS[i]).length
    return (room.g.counts?.[i] ?? 0) - (i === mineIdx ? 1 : 0) - given
  }
  const go = (idx: number) => { setCursor(idx); setEditing(true) }
  const choose = (o: WhoPickedOption) => {
    navigator.vibrate?.(20)
    const next = { ...answers, [cur.id]: o }
    setAnswers(next)
    setSent(false)
    setTimeout(() => {
      const nextIdx = targets.findIndex((p, i) => i !== targets.indexOf(cur) && !next[p.id] && i > targets.indexOf(cur))
      const any = nextIdx >= 0 ? nextIdx : targets.findIndex((p) => !next[p.id])
      if (any >= 0) setCursor(any)
      else setEditing(false)
    }, 250)
  }
  const submit = () => {
    navigator.vibrate?.(20)
    onSubmit(targets.map((p) => answers[p.id]).join(''))
    setSent(true)
  }
  const mineText = mine ? optionLabel(opts, mine) : ''

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <QuestionCard question={room.g.question} total={room.g.questions} text={room.g.text ?? ''}
        myPick={mine ? { letter: letterOf(mine), text: mineText } : null} />

      {summary ? (
        <>
          <div className="sticker" style={{ padding: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
            {targets.map((p, i) => {
              const o = answers[p.id]!
              return (
                <button key={p.id} type="button" onClick={() => go(i)} aria-label={`${p.name} ${letterOf(o)} 다시 고르기`}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 4px', background: 'transparent', border: 0, textAlign: 'left', cursor: 'pointer', font: 'inherit', color: 'inherit', minHeight: 40 }}>
                  <Avatar seed={p.avatar} size={32} />
                  <span className="nick nick--sm nick--1l" style={{ flex: 'none', maxWidth: '38%' }}>{p.name}{p.bot && <NpcTag />}</span>
                  <span style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-end' }}>
                    <LetterBadge letter={letterOf(o)} size="sm" />
                    <span style={{ fontSize: 14, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{optionLabel(opts, o)}</span>
                  </span>
                </button>
              )
            })}
          </div>
          <button type="button" className="btn-sticker" data-tone="lime" onClick={submit}>{sent ? '다시 내기' : '이걸로 확정!'}</button>
        </>
      ) : (
        <>
          <div className="sticker" style={{ padding: '8px 12px', display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Avatar seed={cur.avatar} size={44} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <span className="nick nick--2l" style={{ display: 'block', minHeight: 0 }}>{cur.name}{cur.bot && <NpcTag />}</span>
                <div className="jua" style={{ fontSize: 16 }}>이 사람은 뭘 골랐을까?</div>
              </div>
              <span className="chip" style={{ fontSize: 13, padding: '0 10px' }}>{targets.indexOf(cur) + 1}/{targets.length}</span>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {WHO_PICKED_OPTIONS.map((o, i) => {
              const on = answers[cur.id] === o
              const n = room.g.counts ? remaining(i) : null
              return (
                <OptionCard key={o} letter={OPTION_LETTER[i]!} text={opts[i] ?? ''} tone={on ? 'lime' : 'cream'} pressed={on}
                  onClick={() => choose(o)}
                  right={n !== null ? <span className="chip" style={{ fontSize: 12, padding: '0 8px', whiteSpace: 'nowrap', opacity: n <= 0 ? 0.5 : 1 }}>남은 {Math.max(0, n)}</span> : undefined} />
              )
            })}
          </div>
        </>
      )}

      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '4px 2px' }}>
        {targets.map((p, i) => {
          const a = answers[p.id]
          const here = !summary && p.id === cur.id
          return (
            <button key={p.id} type="button" onClick={() => go(i)} aria-label={`${p.name}${a ? ' ' + letterOf(a) : ''}`}
              style={{ position: 'relative', flex: 'none', padding: 2, borderRadius: '50%', background: 'transparent', cursor: 'pointer', border: `3px solid ${here ? 'var(--lime)' : 'transparent'}`, opacity: a || here ? 1 : 0.45 }}>
              <Avatar seed={p.avatar} size={28} />
              {a && <span className="jua" style={{ position: 'absolute', right: -4, bottom: -4, width: 16, height: 16, borderRadius: '50%', background: 'var(--lime)', border: '2px solid var(--ink)', boxSizing: 'border-box', display: 'grid', placeItems: 'center', fontSize: 9, color: 'var(--ink)' }}>{letterOf(a)}</span>}
            </button>
          )
        })}
      </div>
      <SubmitBanner room={room} label="찍었다!" compact />
      <AvatarStrip room={room} />
    </div>
  )
}
