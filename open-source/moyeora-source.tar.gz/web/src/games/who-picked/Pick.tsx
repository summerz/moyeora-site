import { WHO_PICKED_OPTIONS, type WhoPickedOption, type WhoPickedRoom } from '@moyeora/shared'
import { AvatarStrip } from '../../ui/AvatarStrip.tsx'
import { SubmitBanner } from '../../ui/SubmitBanner.tsx'
import { OPTION_LETTER, letterOf, optionLabel } from './labels.ts'
import { OptionCard } from './OptionCard.tsx'
import { QuestionCard } from './QuestionCard.tsx'

type Props = { room: WhoPickedRoom; choice: string | null; onChoose: (o: WhoPickedOption) => void }

export function Pick({ room, choice, onChoose }: Props) {
  const mineOpt = (choice || room.g.myPick || null) as WhoPickedOption | null
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <QuestionCard question={room.g.question} total={room.g.questions} text={room.g.text ?? ''}
        myPick={mineOpt ? { letter: letterOf(mineOpt), text: optionLabel(room.g.options, mineOpt) } : null} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {WHO_PICKED_OPTIONS.map((o, i) => {
          const mine = mineOpt === o
          return (
            <OptionCard key={o} letter={OPTION_LETTER[i]!} text={room.g.options[i] ?? ''} pressed={mine}
              tone={mine ? 'lime' : mineOpt ? 'dim' : 'cream'}
              right={mine ? <span className="jua" style={{ background: 'var(--ink)', color: 'var(--cream)', fontSize: 12, padding: '3px 10px', borderRadius: 999, whiteSpace: 'nowrap' }}>내 선택</span> : undefined}
              onClick={() => { navigator.vibrate?.(20); onChoose(o) }} />
          )
        })}
      </div>
      <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>모두 고르면 3초 뒤 인원수 공개</div>
      <SubmitBanner room={room} label="골랐다!" />
      <AvatarStrip room={room} />
    </div>
  )
}
