import { WHO_PICKED_OPTIONS, type WhoPickedOption, type WhoPickedPack } from '@moyeora/shared'

export const OPTION_LETTER = ['A', 'B', 'C', 'D']
export const letterOf = (o: WhoPickedOption) => OPTION_LETTER[WHO_PICKED_OPTIONS.indexOf(o)]!
export const PACK_LABEL: Record<WhoPickedPack, string> = { all: '전체', family: '가족', friends: '친구' }
export const fmtDelta = (d: number) => (d > 0 ? `+${d}점` : d < 0 ? `−${-d}점` : '0점')
export const optionLabel = (options: string[], o: WhoPickedOption) => options[WHO_PICKED_OPTIONS.indexOf(o)] ?? ''
