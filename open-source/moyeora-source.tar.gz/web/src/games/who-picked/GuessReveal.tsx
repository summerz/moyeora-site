import type { WhoPickedReveal, WhoPickedRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { fmtDelta, letterOf, optionLabel } from './labels.ts'
import { LetterBadge } from './OptionCard.tsx'
import { QuestionCard } from './QuestionCard.tsx'

type Props = { room: WhoPickedRoom; reveal: Extract<WhoPickedReveal, { step: 'guess' }>; onResult: () => void }

const deltaColor = (d: number) => (d > 0 ? 'var(--green)' : d < 0 ? '#c0392b' : '#6b5f8a')

export function GuessReveal({ room, reveal, onResult }: Props) {
  const left = useCountdown(room.remainingMs)
  const mine = reveal.answers.find((a) => a.id === room.you)?.pick ?? null
  const player = (id: string) => room.players.find((p) => p.id === id)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <QuestionCard question={room.g.question} total={room.g.questions} text={room.g.text ?? ''}
        myPick={mine ? { letter: letterOf(mine), text: optionLabel(room.g.options, mine) } : null} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 10 }}>
        {reveal.answers.map((a) => {
          const p = player(a.id)
          const me = a.id === room.you
          return (
            <div key={a.id} className="sticker"
              style={{ position: 'relative', padding: '10px 10px', display: 'flex', flexDirection: 'column', gap: 4, boxShadow: me ? '3px 3px 0 var(--lime)' : '3px 3px 0 var(--ink)', ...(a.pick ? null : { borderStyle: 'dashed' }) }}>
              <Avatar seed={p?.avatar ?? a.id} size={44} />
              {a.pick && <span aria-label={`답 ${letterOf(a.pick)}`} style={{ position: 'absolute', top: 8, right: 8, transform: 'rotate(8deg)', display: 'inline-flex' }}><LetterBadge letter={letterOf(a.pick)} /></span>}
              <span className="nick nick--2l">{(p?.name ?? '?') + (me ? ' · 나' : '')}{p?.bot && <NpcTag />}</span>
              <span className="opt-text" style={{ color: a.pick ? 'var(--ink)' : '#6b5f8a' }}>{a.pick ? optionLabel(room.g.options, a.pick) : '쉬었어요'}</span>
              <span className="jua" style={{ fontSize: 20 }}>
                <span style={{ color: deltaColor(a.delta) }}>{fmtDelta(a.delta)}</span> → {a.score < 0 ? `−${-a.score}` : a.score}점
              </span>
              <div style={{ minHeight: 24, display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap', fontSize: 11 }}>
                {a.guessedBy.length > 0 ? (
                  <>
                    <span style={{ color: '#6b5f8a' }}>맞힌 사람</span>
                    {a.guessedBy.map((id) => <Avatar key={id} seed={player(id)?.avatar ?? id} size={20} />)}
                  </>
                ) : a.hidden ? (
                  <span className="chip" style={{ fontSize: 11, padding: '0 8px', background: 'var(--amber)', borderWidth: 2, boxShadow: '2px 2px 0 var(--ink)' }}>아무도 못 맞힘 +3점</span>
                ) : null}
              </div>
            </div>
          )
        })}
      </div>
      {room.phase === 'done' ? (
        <button type="button" className="btn-sticker" data-tone="cream" onClick={onResult}>결과 보기</button>
      ) : (
        left !== null && <div style={{ fontSize: 13, color: 'var(--lav-dim)', textAlign: 'center' }}>다음 질문까지 {Math.ceil(left / 1000)}초</div>
      )}
    </div>
  )
}
