import { useEffect, useRef, useState } from 'react'
import { MARBLES, turnOf, type MarblesRoom } from '@moyeora/shared'
import { Avatar } from '../../ui/Avatar.tsx'
import { Final } from '../../ui/Final.tsx'
import { MePill } from '../../ui/MePill.tsx'
import { NpcTag } from '../../ui/NpcTag.tsx'
import { OrderIntro } from '../../ui/OrderIntro.tsx'
import { PlayerNotice } from '../../ui/SubmitBanner.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { useCountdown } from '../../ui/useCountdown.ts'
import { MarblesScene } from './MarblesScene.tsx'
export function Play({
  room,
  error,
  onPick,
  onLobby,
  onAgain,
}: {
  room: MarblesRoom
  error?: string
  onPick: (stick: number) => void
  onLobby: () => void
  onAgain: () => void
}) {
  const { g } = room,
    remaining = useCountdown(room.remainingMs),
    motionLeft = useCountdown(
      g.settling && g.event ? Math.max(0, MARBLES.motionMs - g.elapsedMs) : null,
    )
  const submitted = useRef<{ round: number; error?: string } | null>(null)
  const [sent, setSent] = useState<{ round: number; error?: string } | null>(null)
  const [settled, setSettled] = useState<number | null>(null)
  const [fallProgress, setFallProgress] = useState<{ event: number; count: number } | null>(null)
  useEffect(() => {
    document.body.classList.add('marbles-playing')
    return () => document.body.classList.remove('marbles-playing')
  }, [])
  const moving = g.settling && (motionLeft ?? 0) > 0
  const visibleBoard = moving && g.event ? g.event.before : g.board
  const liveFallen = moving && fallProgress?.event === g.event?.id ? fallProgress!.count : 0
  const resultReady = room.phase === 'done' && !moving
  if (room.phase === 'intro')
    return (
      <OrderIntro
        players={room.players}
        order={g.order}
        me={room.you}
        remainingMs={room.remainingMs}
      />
    )
  if (resultReady)
    return (
      <Final
        room={room}
        onAgain={onAgain}
        onLobby={onLobby}
        title="구슬을 모두 셌어요!"
        scoreUnit="개"
        scoreOrder="asc"
      >
        <p className="marbles-final-note">떨어뜨린 구슬이 가장 적은 사람이 1등!</p>
      </Final>
    )
  const choosing = room.phase === 'choosing' && !g.settling
  const cur = choosing
    ? turnOf(
        g.order,
        g.last,
        room.players.map((p) => p.id),
      )
    : g.event?.by
  const player = room.players.find((p) => p.id === cur)
  const mine = choosing && cur === room.you && !(sent?.round === room.round && sent.error === error)
  const pull = (stick: number) => {
    if (!mine || (submitted.current?.round === room.round && submitted.current.error === error))
      return
    submitted.current = { round: room.round, error }
    setSent({ round: room.round, error })
    onPick(stick)
  }
  const finished = !moving && g.event && (settled === g.event.id || (motionLeft ?? 0) === 0)
  const status =
    error ??
    (moving
      ? '구슬이 멈출 때까지 기다려요'
      : choosing
        ? mine
          ? '막대 끝을 누르면 빠져요 · 드래그로 회전'
          : '통을 돌려 보고 다음 차례를 준비해요'
        : finished
          ? `${g.event!.fallen.length}개 떨어졌어요`
          : '다음 차례를 준비해요')
  return (
    <div className="marbles-play">
      <TurnCard
        name={player?.name ?? null}
        avatar={player?.avatar}
        me={mine}
        meTitle="내 차례!"
        meHint="막대 끝을 터치해 빼요"
        other={choosing ? '님 차례' : '님이 뺐어요'}
        fixed
        right={
          choosing ? (
            <Timer key={room.round} remainingMs={remaining} totalMs={MARBLES.chooseMs} />
          ) : undefined
        }
      />
      <div className="marbles-stats">
        <span className="chip">막대 {g.board.sticks.length}개</span>
        <span className="chip">구슬 {visibleBoard.balls.length - liveFallen}개</span>
        <span className="marbles-round jua">{room.round}번째 차례</span>
      </div>
      <div className="marbles-stage">
        <MarblesScene
          view={g}
          canPick={mine}
          onPick={pull}
          onSettled={() => setSettled(g.event?.id ?? null)}
          onFallCount={(event, count) => setFallProgress({ event, count })}
        />
        <div className="marbles-notice" aria-live="polite">
          {moving && g.event?.auto ? (
            <PlayerNotice
              key={g.event.id}
              name={player?.name ?? '나간 친구'}
              avatar={player?.avatar ?? 'x'}
              bot={player?.bot ?? false}
              label="시간 초과! 자동으로 뺐어요"
              compact
              tone="plain"
              icon={false}
            />
          ) : g.settling && g.event ? (
            <span className="chip marbles-fallen" key={g.event.id}>
              이번에는{' '}
              <strong className="marbles-count" key={moving ? liveFallen : g.event.fallen.length}>
                {moving ? liveFallen : g.event.fallen.length}
              </strong>
              개!
            </span>
          ) : null}
        </div>
      </div>
      <div className="marbles-status" role={error ? 'alert' : 'status'}>
        {status}
      </div>
      <div className="marbles-scores" aria-label="떨어뜨린 구슬 개수">
        {room.players.map((p) => (
          <div
            key={p.id}
            className="marbles-score sticker"
            data-me={p.id === room.you ? '1' : undefined}
            data-turn={p.id === cur ? '1' : undefined}
          >
            <div className="marbles-score-top">
              <div className="marbles-score-avatar">
                <Avatar seed={p.avatar} size={24} />
                {p.id === room.you ? (
                  <MePill
                    style={{
                      position: 'absolute',
                      right: -3,
                      bottom: -3,
                      fontSize: 9,
                      padding: '0 4px',
                    }}
                  />
                ) : p.bot ? (
                  <NpcTag overlay />
                ) : null}
              </div>
              <span className="jua">
                <span
                  className="marbles-count"
                  key={p.id === g.event?.by ? `${g.event.id}:${liveFallen}` : p.id}
                >
                  {p.score -
                    (moving && room.phase !== 'choosing' && p.id === g.event?.by
                      ? g.event.fallen.length
                      : 0) +
                    (moving && p.id === g.event?.by ? liveFallen : 0)}
                </span>
                <small>개</small>
              </span>
            </div>
            <span className="nick nick--1l nick--sm">{p.name}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
