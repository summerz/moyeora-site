import { useEffect, useId, useRef } from 'react'
import { GLASS_COLORS, STICK_COLORS } from '@moyeora/shared'
import './hero.css'
export function Hero({
  size = 190,
  animate = true,
  mode = 'tube',
}: {
  size?: number
  animate?: boolean
  mode?: 'tube' | 'fall' | 'score'
}) {
  const id = useId().replace(/:/g, ''),
    el = useRef<SVGSVGElement>(null)
  useEffect(() => {
    const node = el.current!
    let visible = true
    const update = () =>
      node.style.setProperty('--marble-play', visible && !document.hidden ? 'running' : 'paused')
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry!.isIntersecting
      update()
    })
    observer.observe(node)
    document.addEventListener('visibilitychange', update)
    return () => {
      observer.disconnect()
      document.removeEventListener('visibilitychange', update)
    }
  }, [])
  return (
    <svg
      ref={el}
      className={`marbles-hero ${animate ? 'marbles-hero--animate' : ''}`}
      width={size}
      viewBox="0 0 220 220"
      role="img"
      aria-label="색색의 막대 위에 놓인 유리 구슬"
      style={{ display: 'block', margin: '0 auto' }}
    >
      <defs>
        <linearGradient id={`${id}-tube`}>
          <stop stopColor="#d0f5ff" stopOpacity=".22" />
          <stop offset=".3" stopColor="#91caff" stopOpacity=".04" />
          <stop offset="1" stopColor="#bfe7ff" stopOpacity=".2" />
        </linearGradient>
        {GLASS_COLORS.map((c, i) => (
          <radialGradient key={c} id={`${id}-ball${i}`} cx="30%" cy="24%">
            <stop stopColor="white" />
            <stop offset=".3" stopColor={c} />
            <stop offset="1" stopColor={c} stopOpacity=".55" />
          </radialGradient>
        ))}
      </defs>
      <ellipse cx="110" cy="199" rx="76" ry="10" fill="#090817" opacity=".4" />
      <path
        d="M55 46 V179 C55 202 165 202 165 179 V46"
        fill={`url(#${id}-tube)`}
        stroke="#b9defa"
        strokeWidth="2"
        strokeOpacity=".7"
      />
      <ellipse
        cx="110"
        cy="46"
        rx="55"
        ry="19"
        fill="#7ebdff"
        fillOpacity=".06"
        stroke="#d4efff"
        strokeWidth="3"
      />
      {[0, 1, 2].map((layer) => (
        <g key={layer}>
          {[0, 1, 2, 3].map((j) => (
            <path
              key={j}
              d={`M${32 + j * 9} ${135 + layer * 13 - j * 4} L${176 + j * 6} ${119 + layer * 13 + j * 4}`}
              stroke={STICK_COLORS[(j + layer * 2) % STICK_COLORS.length]}
              strokeWidth="5"
              strokeLinecap="round"
            />
          ))}
        </g>
      ))}
      <g className={mode === 'fall' ? 'marble-art-fall' : 'marble-art-balls'}>
        {Array.from({ length: 15 }, (_, i) => {
          const row = Math.floor(i / 5),
            x = 69 + (i % 5) * 20 + (row % 2) * 7,
            y = 82 + row * 19
          return (
            <g
              key={i}
              className={
                i === 10 || i === 12 || i === 14
                  ? `marble-art-drop marble-art-drop--${(i - 10) / 2}`
                  : undefined
              }
            >
              <circle
                cx={x}
                cy={y}
                r="11"
                fill={`url(#${id}-ball${i % 6})`}
                stroke={GLASS_COLORS[i % 6]}
                strokeWidth=".8"
              />
              <path
                d={`M${x - 5} ${y + 5} Q${x + 6} ${y} ${x - 2} ${y - 7}`}
                stroke={GLASS_COLORS[(i + 2) % 6]}
                strokeWidth="4"
                fill="none"
              />
              <ellipse cx={x - 4} cy={y - 5} rx="3" ry="2" fill="white" opacity=".9" />
            </g>
          )
        })}
      </g>
      <path
        className="marble-art-stick"
        d="M29 150 L191 131"
        stroke={STICK_COLORS[1]}
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path
        d="M55 46 C55 70 165 70 165 46 M55 179 C55 202 165 202 165 179"
        fill="none"
        stroke="#d4efff"
        strokeWidth="2"
        opacity=".75"
      />
      {mode === 'score' && (
        <g>
          <circle cx="167" cy="165" r="30" fill="#b7ee63" stroke="#120d24" strokeWidth="4" />
          <text x="167" y="173" textAnchor="middle" className="jua" fontSize="23" fill="#120d24">
            0개
          </text>
        </g>
      )}
    </svg>
  )
}
