import * as THREE from 'three'
import {
  GLASS_COLORS,
  MARBLES,
  STICK_COLORS,
  type MarbleBoard,
  type MarblesView,
} from '@moyeora/shared'
import type { MarbleMotion } from '@moyeora/shared/marble-physics'
import { preloadSamples, sampleAt } from '../../ui/sound.ts'
import pullUrl from '../../audio/marbles-pull.wav'
import fallUrl from '../../audio/marbles-fall.wav'
import clinkUrl from '../../audio/marbles-clink.wav'
export type SceneControl = {
  sync: (view: MarblesView, canPick: boolean) => void
  key: (key: string) => void
  zoomBy: (delta: number) => void
  dispose: () => void
}
export const MAX_ZOOM = 1.6
let physicsReady: Promise<typeof import('@moyeora/shared/marble-physics')> | undefined
export function prepareMarblePhysics() {
  return (physicsReady ??= import('@moyeora/shared/marble-physics')
    .then(async (physics) => {
      await physics.initMarblePhysics()
      return physics
    })
    .catch((error) => {
      physicsReady = undefined
      throw error
    }))
}
/** Owns the full viewport renderer and all geometry, input, audio and animation resources. */
export function createMarblesScene(
  el: HTMLDivElement,
  surface: HTMLCanvasElement,
  initial: { view: MarblesView; canPick: boolean },
  callbacks: {
    pick: (id: number) => void
    settled: () => void
    fallCount: (event: number, count: number) => void
    zoom: (value: number) => void
    failed: () => void
  },
): SceneControl | null {
  let renderer: THREE.WebGLRenderer
  try {
    renderer = new THREE.WebGLRenderer({ canvas: surface, antialias: true, alpha: true })
  } catch {
    callbacks.failed()
    return null
  }
  preloadSamples([pullUrl, fallUrl, clinkUrl])
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75))
  renderer.outputColorSpace = THREE.SRGBColorSpace
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  const scene = new THREE.Scene(),
    group = new THREE.Group()
  scene.add(group)
  scene.add(new THREE.AmbientLight('#e8dcff', 2.5))
  const keyLight = new THREE.DirectionalLight('#ffffff', 3.4)
  keyLight.position.set(-4, 7, 5)
  scene.add(keyLight)
  const fill = new THREE.DirectionalLight('#8ec8ff', 2)
  fill.position.set(4, 2, -4)
  scene.add(fill)
  const camera = new THREE.OrthographicCamera(-3, 3, 3, -3, 0.1, 80)
  let elevation = (50 * Math.PI) / 180
  function positionCamera() {
    camera.position.set(0, 1.45 + 10 * Math.sin(elevation), 10 * Math.cos(elevation))
    camera.lookAt(0, 1.45, 0)
    camera.updateMatrixWorld()
  }
  positionCamera()
  const wallMat = new THREE.MeshPhysicalMaterial({
    color: '#c7edff',
    transparent: true,
    opacity: 0.1,
    roughness: 0.12,
    metalness: 0.05,
    side: THREE.DoubleSide,
    depthWrite: false,
  })
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(1.17, 1.17, 3.55, 64, 1, true), wallMat)
  wall.position.y = 1.47
  wall.renderOrder = 2
  group.add(wall)
  const rimMat = new THREE.MeshStandardMaterial({
    color: '#d1edff',
    roughness: 0.28,
    metalness: 0.32,
  })
  for (const y of [-0.3, 3.25]) {
    const rim = new THREE.Mesh(new THREE.TorusGeometry(1.18, 0.047, 10, 64), rimMat)
    rim.rotation.x = Math.PI / 2
    rim.position.y = y
    group.add(rim)
  }
  // Sparse fine seams describe the tube without obscuring the glass marbles.
  const seamMat = new THREE.MeshBasicMaterial({
    color: '#d8f1ff',
    transparent: true,
    opacity: 0.18,
  })
  for (const a of [0.3, 2.8]) {
    const seam = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 3.5, 6), seamMat)
    seam.position.set(Math.sin(a) * 1.18, 1.47, Math.cos(a) * 1.18)
    group.add(seam)
  }
  const rods = new Map<number, THREE.Group>(),
    sockets = new Set<number>(),
    balls = new Map<number, THREE.Group>(),
    targets: THREE.Object3D[] = []
  const geometries = new Set<THREE.BufferGeometry>(),
    materials = new Set<THREE.Material>()
  const sphereGeometry = new THREE.SphereGeometry(MARBLES.radius, 20, 14)
  geometries.add(sphereGeometry)
  const coreGeometry = new THREE.SphereGeometry(1, 12, 8)
  geometries.add(coreGeometry)
  const tipGeometry = new THREE.SphereGeometry(0.092, 14, 10)
  geometries.add(tipGeometry)
  const pointGeometry = new THREE.ConeGeometry(0.052, 0.24, 10)
  geometries.add(pointGeometry)
  const hitGeometry = new THREE.SphereGeometry(0.15, 8, 6)
  geometries.add(hitGeometry)
  const hitMat = new THREE.MeshBasicMaterial({ visible: false })
  materials.add(hitMat)
  // Fixed eyelets at both wall intersections show how each rod is supported.
  // They belong to the tube, so they stay in place when the rod slides out.
  const socketGeometry = new THREE.TorusGeometry(0.076, 0.016, 8, 16)
  geometries.add(socketGeometry)
  const socketMat = new THREE.MeshStandardMaterial({
    color: '#b6c6df',
    roughness: 0.38,
    metalness: 0.35,
  })
  materials.add(socketMat)
  const counted = new Set<number>()
  let fallenIds = new Set<number>()
  let v = initial.view,
    enabled = initial.canPick,
    yaw = 0,
    frame = 0,
    disposed = false,
    motion: MarbleMotion | null = null,
    motionStart = 0,
    eventId: number | null = null,
    completeId: number | null = null
  let tour = 0
  let zoom = 1,
    pinchDistance = 0,
    pinchZoom = 1
  const pointers = new Map<number, { x: number; y: number }>()
  let hover: number | null = null,
    dragged = false,
    pointer: number | null = null,
    downX = 0,
    downY = 0,
    lastX = 0,
    lastY = 0,
    needsDraw = true
  let soundCancels: (() => void)[] = []
  void prepareMarblePhysics().catch(() => {})
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
  function makeBall(p: MarbleBoard['balls'][number]) {
    const node = new THREE.Group()
    const mat = new THREE.MeshPhysicalMaterial({
      color: GLASS_COLORS[p.color % 6],
      roughness: 0.1,
      metalness: 0.08,
      transparent: true,
      opacity: 0.64,
      clearcoat: 1,
      clearcoatRoughness: 0.04,
      depthWrite: false,
    })
    materials.add(mat)
    const glass = new THREE.Mesh(sphereGeometry, mat)
    glass.renderOrder = 1
    node.add(glass)
    const insideMat = new THREE.MeshStandardMaterial({
      color: GLASS_COLORS[(p.color + 2) % 6],
      roughness: 0.23,
      metalness: 0.12,
    })
    materials.add(insideMat)
    for (let k = 0; k < 3; k++) {
      const eye = new THREE.Mesh(coreGeometry, insideMat)
      eye.scale.set(0.035, 0.137, 0.067)
      eye.rotation.z = (k * Math.PI) / 3 + 0.3
      eye.rotation.y = (k * Math.PI) / 3
      node.add(eye)
    }
    const shineMat = new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: 0.8,
    })
    materials.add(shineMat)
    const shine = new THREE.Mesh(coreGeometry, shineMat)
    shine.scale.set(0.028, 0.041, 0.01)
    shine.position.set(-0.065, 0.075, 0.135)
    node.add(shine)
    group.add(node)
    balls.set(p.id, node)
  }
  function ensureBoard(board: MarbleBoard) {
    targets.length = 0
    for (const s of board.sticks) {
      if (!sockets.has(s.id)) {
        sockets.add(s.id)
        const along = s.x * s.dx + s.z * s.dz
        const reach = Math.sqrt(along ** 2 + 1.17 ** 2 - s.x ** 2 - s.z ** 2)
        for (const sign of [-1, 1]) {
          const t = -along + sign * reach
          const eyelet = new THREE.Mesh(socketGeometry, socketMat)
          eyelet.position.set(s.x + s.dx * t, s.y, s.z + s.dz * t)
          eyelet.quaternion.setFromUnitVectors(
            new THREE.Vector3(0, 0, 1),
            new THREE.Vector3(s.dx, 0, s.dz),
          )
          group.add(eyelet)
        }
      }
      let node = rods.get(s.id)
      if (!node) {
        node = new THREE.Group()
        const geometry = new THREE.CapsuleGeometry(0.052, s.half * 2, 4, 10)
        geometries.add(geometry)
        const mat = new THREE.MeshStandardMaterial({
          color: STICK_COLORS[s.color % STICK_COLORS.length],
          roughness: 0.85,
          metalness: 0,
        })
        materials.add(mat)
        const mesh = new THREE.Mesh(geometry, mat)
        mesh.quaternion.setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          new THREE.Vector3(s.dx, 0, s.dz),
        )
        node.add(mesh)
        for (const sign of [-1, 1]) {
          // Round grip on the pulling end, tapered insertion tip on the other.
          const end = new THREE.Mesh(sign > 0 ? tipGeometry : pointGeometry, mat)
          const endOffset = s.half + (sign > 0 ? 0.04 : 0.08)
          end.position.set(sign * s.dx * endOffset, 0, sign * s.dz * endOffset)
          if (sign < 0)
            end.quaternion.setFromUnitVectors(
              new THREE.Vector3(0, 1, 0),
              new THREE.Vector3(-s.dx, 0, -s.dz),
            )
          node.add(end)
          const hit = new THREE.Mesh(hitGeometry, hitMat)
          hit.position.copy(end.position)
          hit.userData.id = s.id
          node.add(hit)
          targets.push(hit)
        }
        group.add(node)
        rods.set(s.id, node)
      } else
        for (const child of node.children) if (child.userData.id !== undefined) targets.push(child)
      node.position.set(s.x, s.y, s.z)
      node.visible = true
    }
    for (const [id, node] of rods) if (!board.sticks.some((s) => s.id === id)) node.visible = false
    for (const p of board.balls) {
      if (!balls.has(p.id)) makeBall(p)
      const node = balls.get(p.id)!
      node.position.set(p.x, p.y, p.z)
      node.quaternion.set(p.qx, p.qy, p.qz, p.qw)
      node.visible = true
    }
    for (const [id, node] of balls) if (!board.balls.some((p) => p.id === id)) node.visible = false
    needsDraw = true
  }
  function fit() {
    const r = el.getBoundingClientRect(),
      w = innerWidth,
      h = innerHeight,
      units = Math.max(5.1 / Math.max(r.width, 1), 5.35 / Math.max(r.height, 1)) / zoom
    const cx = r.left + r.width / 2,
      cy = r.top + r.height / 2
    camera.left = -cx * units
    camera.right = (w - cx) * units
    camera.top = cy * units
    camera.bottom = -(h - cy) * units
    camera.updateProjectionMatrix()
    renderer.setSize(w, h, false)
    needsDraw = true
    requestDraw()
  }
  const ray = new THREE.Raycaster(),
    point = new THREE.Vector2()
  function hit(x: number, y: number) {
    point.set((x / innerWidth) * 2 - 1, (-y / innerHeight) * 2 + 1)
    ray.setFromCamera(point, camera)
    group.updateMatrixWorld(true)
    return ray.intersectObjects(targets, false).find((h) => h.object.parent?.visible)?.object
      .userData.id as number | undefined
  }
  function select(id: number | null) {
    hover = id
    for (const [id, node] of rods) {
      const mesh = node.children[0] as THREE.Mesh<THREE.BufferGeometry, THREE.MeshStandardMaterial>
      mesh.material.emissive.set(id === hover && enabled ? '#fff0bf' : '#000000')
      mesh.material.emissiveIntensity = 0.5
    }
    needsDraw = true
  }
  function sync(next: MarblesView, can: boolean) {
    v = next
    enabled = can
    select(null)
    if (next.event && next.settling && eventId !== next.event.id) {
      eventId = next.event.id
      counted.clear()
      fallenIds = new Set(next.event.fallen)
      callbacks.fallCount(eventId, 0)
      motion = null
      motionStart = performance.now() - next.elapsedMs
      completeId = null
      ensureBoard(next.event.before)
      soundCancels.forEach((f) => f())
      soundCancels = []
      if (next.elapsedMs < 200) soundCancels.push(sampleAt(performance.now(), pullUrl))
      void prepareMarblePhysics()
        .then((physics) => {
          if (disposed || eventId !== next.event!.id) return
          const m = physics.simulateMarblePull(next.event!.before, next.event!.stick)
          motion = m
          const now = performance.now()
          const elapsed = now - motionStart
          const firstFall = m.frames.find((f) =>
            f.balls.some((p) => fallenIds.has(p.id) && p.y < -0.3),
          )?.ms
          if (firstFall !== undefined && firstFall > elapsed - 100)
            soundCancels.push(sampleAt(now + Math.max(0, firstFall - elapsed), fallUrl))
          for (const at of m.hits
            .filter((at, i, all) => i === 0 || at - all[i - 1]! > 300)
            .slice(0, 6)) {
            if (at > elapsed && (firstFall === undefined || at < firstFall))
              soundCancels.push(sampleAt(now + at - elapsed, clinkUrl))
          }
          needsDraw = true
          requestDraw()
        })
        .catch(() => {
          ensureBoard(next.board)
          callbacks.settled()
        })
    } else if (!next.settling || !next.event) ensureBoard(next.board)
    needsDraw = true
    requestDraw()
  }
  function draw(now: number) {
    frame = 0
    if (disposed || document.hidden) return
    const elapsed = now - motionStart
    if (v.settling && v.event && motion && elapsed < MARBLES.motionMs) {
      const t = Math.min(elapsed, MARBLES.motionMs),
        index = Math.min(motion.frames.length - 2, Math.floor(Math.max(0, t) / (1000 / 30))),
        a = motion.frames[index]!,
        b = motion.frames[index + 1]!,
        u = Math.max(0, Math.min(1, (t - a.ms) / (b.ms - a.ms)))
      const previousCount = counted.size
      for (let i = 0; i < a.balls.length; i++) {
        const p = a.balls[i]!,
          q = b.balls[i]!,
          node = balls.get(p.id)!
        node.position.set(p.x + (q.x - p.x) * u, p.y + (q.y - p.y) * u, p.z + (q.z - p.z) * u)
        if (fallenIds.has(p.id) && node.position.y < MARBLES.fallY) counted.add(p.id)
        node.quaternion
          .set(p.qx, p.qy, p.qz, p.qw)
          .slerp(new THREE.Quaternion(q.qx, q.qy, q.qz, q.qw), u)
      }
      if (counted.size !== previousCount) callbacks.fallCount(v.event.id, counted.size)
      const rod = v.event.before.sticks.find((s) => s.id === v.event!.stick)!,
        node = rods.get(rod.id)!,
        distance = Math.min(1, t / MARBLES.pullMs) * 3.4
      node.position.set(rod.x + rod.dx * distance, rod.y, rod.z + rod.dz * distance)
      node.visible = t < MARBLES.pullMs
      needsDraw = true
    } else if (v.settling && v.event && elapsed >= MARBLES.motionMs && completeId !== v.event.id) {
      ensureBoard(v.board)
      callbacks.fallCount(v.event.id, v.event.fallen.length)
      completeId = v.event.id
      callbacks.settled()
    }
    group.rotation.y = yaw
    if (needsDraw) {
      renderer.render(scene, camera)
      needsDraw = false
    }
    if (v.settling && elapsed < MARBLES.motionMs && motion) requestDraw()
  }
  function requestDraw() {
    if (!frame && !document.hidden) frame = requestAnimationFrame(draw)
  }
  function setZoom(value: number) {
    cancelAnimationFrame(tour)
    const next = Math.max(1, Math.min(MAX_ZOOM, value))
    if (next === zoom) return
    // Scale the off-center frustum around the scene slot, rather than the viewport center.
    const ratio = zoom / next
    camera.left *= ratio
    camera.right *= ratio
    camera.top *= ratio
    camera.bottom *= ratio
    zoom = next
    camera.updateProjectionMatrix()
    callbacks.zoom(zoom)
    select(null)
    needsDraw = true
    requestDraw()
  }
  function touchDistance() {
    const [a, b] = [...pointers.values()]
    return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0
  }
  const down = (e: PointerEvent) => {
    if (e.button !== 0 || pointers.size >= 2) return
    cancelAnimationFrame(tour)
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
    el.setPointerCapture(e.pointerId)
    if (pointers.size === 2) {
      pinchDistance = touchDistance()
      pinchZoom = zoom
      dragged = true
      select(null)
      requestDraw()
      return
    }
    pointer = e.pointerId
    downX = lastX = e.clientX
    downY = lastY = e.clientY
    dragged = false
  }
  const move = (e: PointerEvent) => {
    if (pointers.has(e.pointerId)) {
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
      if (pointers.size === 2) {
        if (pinchDistance > 0) setZoom((pinchZoom * touchDistance()) / pinchDistance)
        return
      }
    }
    if (pointer !== e.pointerId) {
      if (pointers.size) return
      select(enabled ? (hit(e.clientX, e.clientY) ?? null) : null)
      requestDraw()
      return
    }
    if (Math.hypot(e.clientX - downX, e.clientY - downY) > 7) dragged = true
    if (dragged) {
      yaw += (e.clientX - lastX) * 0.012
      elevation = Math.max(
        (-45 * Math.PI) / 180,
        Math.min((80 * Math.PI) / 180, elevation + (e.clientY - lastY) * 0.008),
      )
      positionCamera()
      needsDraw = true
      select(null)
      requestDraw()
    }
    lastX = e.clientX
    lastY = e.clientY
  }
  function endPointer(e: PointerEvent, allowPick: boolean) {
    if (!pointers.has(e.pointerId)) return
    if (allowPick && pointers.size === 1 && !dragged && enabled) {
      const id = hit(e.clientX, e.clientY)
      if (id !== undefined) {
        enabled = false
        callbacks.pick(id)
      }
    }
    pointers.delete(e.pointerId)
    const remaining = [...pointers.entries()][0]
    pointer = remaining?.[0] ?? null
    if (remaining) {
      downX = lastX = remaining[1].x
      downY = lastY = remaining[1].y
      // The final finger release after a pinch must never pull a rod.
      dragged = true
    }
    select(null)
    requestDraw()
  }
  const up = (e: PointerEvent) => endPointer(e, true)
  const cancel = (e: PointerEvent) => endPointer(e, false)
  const leave = () => {
    if (pointers.size) return
    select(null)
    requestDraw()
  }
  const wheel = (e: WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? el.clientHeight : 1)
    setZoom(zoom * Math.exp(-delta * 0.0015))
  }
  const visibility = () => {
    if (!document.hidden) {
      needsDraw = true
      requestDraw()
    }
  }
  el.addEventListener('pointerdown', down)
  el.addEventListener('pointermove', move)
  el.addEventListener('pointerup', up)
  el.addEventListener('pointercancel', cancel)
  el.addEventListener('lostpointercapture', cancel)
  el.addEventListener('pointerleave', leave)
  el.addEventListener('wheel', wheel, { passive: false })
  window.addEventListener('resize', fit)
  window.addEventListener('scroll', fit)
  visualViewport?.addEventListener('resize', fit)
  document.addEventListener('visibilitychange', visibility)
  const observer = new ResizeObserver(() => {
    fit()
    requestDraw()
  })
  observer.observe(el)
  const controls = {
    sync,
    zoomBy: (delta: number) => setZoom(zoom + delta),
    key: (key: string) => {
      cancelAnimationFrame(tour)
      if (key === 'ArrowLeft' || key === 'ArrowRight') {
        yaw += key === 'ArrowLeft' ? -0.22 : 0.22
        needsDraw = true
        requestDraw()
      } else if (key === 'PageUp' || key === 'PageDown') {
        elevation = Math.max(
          (-45 * Math.PI) / 180,
          Math.min((80 * Math.PI) / 180, elevation + (key === 'PageUp' ? 0.15 : -0.15)),
        )
        positionCamera()
        needsDraw = true
        requestDraw()
      } else if (key === 'Enter' && enabled) {
        const available = v.board.sticks.filter((s) => rods.get(s.id)?.visible)
        const n = hover ?? available[0]?.id
        if (n !== undefined) {
          enabled = false
          callbacks.pick(n)
        }
      } else if ((key === 'ArrowDown' || key === 'ArrowUp') && enabled) {
        const ids = v.board.sticks.map((s) => s.id)
        select(
          ids[
            (ids.indexOf(hover ?? -1) + (key === 'ArrowUp' ? -1 : 1) + ids.length) % ids.length
          ] ?? null,
        )
        requestDraw()
      }
    },
  }
  ensureBoard(v.board)
  fit()
  sync(v, enabled)
  // Show both orbit axes, then return to the initial view. Any input cancels the tour.
  const start = performance.now()
  const intro = (now: number) => {
    if (disposed || reduced || pointer !== null) return
    const u = Math.min(1, (now - start) / 2800)
    const stops = [50, 80, -25, 50]
    const leg = Math.min(2, Math.floor(u * 3))
    const t = u * 3 - leg
    const eased = t * t * (3 - 2 * t)
    elevation = ((stops[leg]! + (stops[leg + 1]! - stops[leg]!) * eased) * Math.PI) / 180
    yaw = Math.sin(u * Math.PI * 2) * 0.45
    positionCamera()
    needsDraw = true
    requestDraw()
    if (u < 1) tour = requestAnimationFrame(intro)
  }
  if (!reduced) tour = requestAnimationFrame(intro)
  const contextLost = () => {
    disposed = true
    cancelAnimationFrame(frame)
    cancelAnimationFrame(tour)
    soundCancels.forEach((f) => f())
    callbacks.failed()
  }
  surface.addEventListener('webglcontextlost', contextLost)
  return {
    ...controls,
    dispose: () => {
      disposed = true
      cancelAnimationFrame(frame)
      cancelAnimationFrame(tour)
      soundCancels.forEach((f) => f())
      observer.disconnect()
      surface.removeEventListener('webglcontextlost', contextLost)
      window.removeEventListener('resize', fit)
      window.removeEventListener('scroll', fit)
      visualViewport?.removeEventListener('resize', fit)
      document.removeEventListener('visibilitychange', visibility)
      el.removeEventListener('pointerdown', down)
      el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerup', up)
      el.removeEventListener('pointercancel', cancel)
      el.removeEventListener('lostpointercapture', cancel)
      el.removeEventListener('pointerleave', leave)
      el.removeEventListener('wheel', wheel)
      pointers.clear()
      scene.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          geometries.add(o.geometry)
          const ms = Array.isArray(o.material) ? o.material : [o.material]
          ms.forEach((m) => materials.add(m))
        }
      })
      geometries.forEach((g) => g.dispose())
      materials.forEach((m) => m.dispose())
      renderer.dispose()
    },
  }
}
