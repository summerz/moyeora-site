import { Tutorial as SharedTutorial } from '../../ui/Tutorial.tsx'
import { Hero } from './Hero.tsx'
export function Tutorial({ onClose }: { onClose: () => void }) {
  return (
    <SharedTutorial
      onClose={onClose}
      pages={[
        {
          title: '돌려 보고, 막대는 쏙!',
          art: <Hero size={210} />,
          line: (
            <>
              드래그로 돌리고, 두 손가락으로 확대해요.
              <br />내 차례에 막대 끝을 누르면 빠져요.
            </>
          ),
        },
        {
          title: '구슬이 우르르!',
          art: <Hero size={210} mode="fall" animate={false} />,
          line: (
            <>
              막대를 빼서 떨어진 구슬은 내 몫!
              <br />
              구슬이 멈춘 뒤 다음 차례로 넘어가요.
            </>
          ),
        },
        {
          title: '가장 적게 떨어뜨리면 1등',
          art: <Hero size={210} mode="score" animate={false} />,
          line: (
            <>
              구슬이 모두 떨어지면 끝! 같은 개수는 공동 순위.
              <br />
              20초가 지나면 막대 하나가 자동으로 빠져요.
            </>
          ),
        },
      ]}
    />
  )
}
