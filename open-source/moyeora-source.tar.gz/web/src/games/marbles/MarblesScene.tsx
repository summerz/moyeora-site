import { useEffect, useEffectEvent, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { STICK_COLORS, type MarblesView } from '@moyeora/shared'
import { Icon } from '../../ui/icons.tsx'
import { createMarblesScene, MAX_ZOOM, type SceneControl } from './scene.ts'
import { Hero } from './Hero.tsx'

type Props = {
  view: MarblesView
  canPick: boolean
  onPick: (id: number) => void
  onSettled: () => void
  onFallCount: (event: number, count: number) => void
}
/** Full viewport canvas behind the UI. The transparent slot owns input and camera framing. */
export function MarblesScene({ view, canPick, onPick, onSettled, onFallCount }: Props) {
  const slot = useRef<HTMLDivElement>(null),
    canvas = useRef<HTMLCanvasElement>(null),
    control = useRef<SceneControl | null>(null)
  const initial = useEffectEvent(() => ({ view, canPick }))
  const pick = useEffectEvent((id: number) => onPick(id))
  const settled = useEffectEvent(() => onSettled())
  const fallCount = useEffectEvent((event: number, count: number) => onFallCount(event, count))
  const [failed, setFailed] = useState(false)
  const [zoom, setZoom] = useState(1)
  useEffect(() => {
    const engine = createMarblesScene(slot.current!, canvas.current!, initial(), {
      pick,
      settled,
      fallCount,
      zoom: setZoom,
      failed: () => setFailed(true),
    })
    control.current = engine
    return () => {
      engine?.dispose()
      control.current = null
    }
  }, [])
  useEffect(() => {
    control.current?.sync(view, canPick)
  }, [view, canPick])
  return (
    <>
      <div
        ref={slot}
        className="marbles-scene"
        tabIndex={0}
        role="group"
        aria-label="통을 상하좌우로 드래그해 둘러보고 막대 끝을 누르세요. 두 손가락이나 마우스 휠로 확대하세요. 키보드는 좌우 방향키로 회전, PageUp과 PageDown으로 시점 높이 조절, 상하 방향키로 막대 선택, 엔터로 빼기."
        onKeyDown={(e) => {
          if (
            [
              'ArrowLeft',
              'ArrowRight',
              'ArrowUp',
              'ArrowDown',
              'PageUp',
              'PageDown',
              'Enter',
            ].includes(e.key) &&
            !e.shiftKey
          ) {
            e.preventDefault()
            control.current?.key(e.key)
          }
        }}
      >
        {createPortal(
          <canvas ref={canvas} className="marbles-canvas" aria-hidden="true" />,
          document.body,
        )}
        {failed && (
          <div className="marbles-fallback">
            <Hero size={150} />
            <p>3D 화면을 사용할 수 없어요. 막대 번호로 골라주세요.</p>
            <div className="marbles-fallback-sticks">
              {view.board.sticks.map((s) => (
                <button
                  type="button"
                  key={s.id}
                  disabled={!canPick}
                  style={{
                    background: STICK_COLORS[s.color % STICK_COLORS.length],
                    color: 'var(--cream)',
                  }}
                  onClick={() => onPick(s.id)}
                >
                  {s.id + 1}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      {!failed && (
        <div
          className="marbles-zoom"
          role="group"
          aria-label={`화면 크기 ${Math.round(zoom * 100)}%`}
        >
          <button
            type="button"
            className="btn-sticker btn-sticker--sm"
            data-tone="cream"
            aria-label="축소"
            title="축소"
            disabled={zoom <= 1.001}
            onClick={() => control.current?.zoomBy(-0.2)}
          >
            <Icon name="minus" size={22} />
          </button>
          <button
            type="button"
            className="btn-sticker btn-sticker--sm"
            data-tone="cream"
            aria-label="확대"
            title="확대"
            disabled={zoom >= MAX_ZOOM - 0.001}
            onClick={() => control.current?.zoomBy(0.2)}
          >
            <Icon name="plus" size={22} />
          </button>
        </div>
      )}
    </>
  )
}
