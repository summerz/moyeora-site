import { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { MARBLES, type MarblesRoom, type ServerMessage } from '@moyeora/shared'
import { errorText } from '../../ui/errors.ts'
import { Join } from '../../ui/Join.tsx'
import { Lobby } from '../../ui/Lobby.tsx'
import { Profile } from '../../ui/Profile.tsx'
import { loadProfile } from '../../ui/profile.ts'
import { useCountdown } from '../../ui/useCountdown.ts'
import { Shell } from '../../ui/Shell.tsx'
import { useSocket } from '../../ws.ts'
import { prepareMarblePhysics } from './scene.ts'
import { Hero } from './Hero.tsx'
import { Play } from './Play.tsx'
import { Tutorial } from './Tutorial.tsx'
import './marbles.css'

const TUT_KEY = 'moyeora:marbles:tutorial'
const tutorialSeen = () => {
  try {
    return localStorage.getItem(TUT_KEY) === '1'
  } catch {
    return false
  }
}
function App() {
  useEffect(() => {
    void prepareMarblePhysics().catch(() => {})
  }, [])
  const [tutorial, setTutorial] = useState(false)
  const [seen, setSeen] = useState(tutorialSeen)
  const [profile, setProfile] = useState(loadProfile)
  const [editing, setEditing] = useState(false)
  const [room, setRoom] = useState<MarblesRoom | null>(null)
  const [error, setError] = useState<string>()
  const onMessage = (m: ServerMessage) => {
    if (m.type === 'room' && m.room.game === 'marbles') {
      setRoom(m.room)
      setError(undefined)
    } else if (m.type === 'error') setError(errorText(m.message))
  }
  const send = useSocket(onMessage, () => {
    setRoom(null)
    setError('연결이 끊겼어요')
  })
  const doneMotion = useCountdown(
    room?.phase === 'done' ? Math.max(0, MARBLES.motionMs - room.g.elapsedMs) : null,
  )
  let screen
  if (!profile || editing)
    screen = (
      <Profile
        initial={profile ?? undefined}
        onDone={(p) => {
          setProfile(p)
          setEditing(false)
        }}
      />
    )
  else if (!room)
    screen = (
      <Join
        game="marbles"
        profile={profile}
        error={error}
        onEdit={() => setEditing(true)}
        onCreate={() => send({ type: 'create', game: 'marbles', ...profile })}
        onJoin={(code) => send({ type: 'join', code, ...profile })}
      />
    )
  else if (room.phase === 'lobby')
    screen = (
      <Lobby
        room={room}
        hero={<Hero size={room.players.length > 4 ? 140 : 190} />}
        onStart={() => send({ type: 'start' })}
        onKick={(playerId) => send({ type: 'kick', playerId })}
        onAddBot={() => send({ type: 'addBot' })}
      >
        {error && <div role="alert">{error}</div>}
      </Lobby>
    )
  else
    screen = (
      <Play
        room={room}
        error={error}
        onPick={(stick) => send({ type: 'submit', choice: String(stick) })}
        onAgain={() => send({ type: 'start' })}
        onLobby={() => send({ type: 'lobby' })}
      />
    )
  const closeTutorial = () => {
    try {
      localStorage.setItem(TUT_KEY, '1')
    } catch {
      /* 저장 불가 */
    }
    setSeen(true)
    setTutorial(false)
  }
  return (
    <Shell
      fit={
        !!room &&
        room.phase !== 'lobby' &&
        room.phase !== 'intro' &&
        (room.phase !== 'done' || (doneMotion ?? 0) > 0)
      }
      safe={!room || room.phase === 'lobby' || room.phase === 'done'}
      confirmHome={!!room}
      onHelp={() => setTutorial(true)}
      onLobby={
        room && room.host === room.you && room.phase !== 'lobby' && room.phase !== 'done'
          ? () => send({ type: 'lobby' })
          : undefined
      }
    >
      {screen}
      {(tutorial || (!!room && room.phase === 'lobby' && !seen)) && (
        <Tutorial onClose={closeTutorial} />
      )}
    </Shell>
  )
}
createRoot(document.getElementById('root')!).render(<App />)
