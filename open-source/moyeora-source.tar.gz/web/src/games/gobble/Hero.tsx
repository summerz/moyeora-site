import { PieceG } from './Piece.tsx'
import './hero.css'

// 3×3 판 + 큰 말이 작은 말을 냠. 정사각형 viewBox, 홈 카드 88px · 대기실 145px.
export function Hero({ size = 145 }: { size?: number }) {
  const c = [28, 60, 92]
  const mini = (cx: number, cy: number, side: number, s: 1 | 2 | 3) => <PieceG key={`${cx}${cy}`} side={side} size={s} x={cx} y={cy} k={.3} />
  return <svg width={size} height={size} viewBox="0 0 120 120" aria-hidden="true" style={{ overflow: 'visible', display: 'block', margin: '0 auto' }}>
    <rect x="9" y="10" width="106" height="106" rx="17" fill="var(--ink)" />
    <rect x="6" y="6" width="106" height="106" rx="17" fill="#2a2147" stroke="var(--ink)" strokeWidth="4" />
    {c.map(y => c.map(x => <rect key={`${x}${y}`} x={x - 14} y={y - 14} width="28" height="28" rx="8" fill="#41346e" />))}
    {mini(c[0], c[0], 1, 2)}{mini(c[2], c[0], 0, 2)}{mini(c[0], c[2], 0, 1)}{mini(c[2], c[2], 1, 2)}
    <g className="gobble-hero-small"><PieceG side={1} size={1} x={64} y={95} k={.36} /></g>
    <g className="gobble-hero-hop"><g className="gobble-hero-chomp"><PieceG side={0} size={3} x={58} y={58} k={.68} /></g></g>
  </svg>
}
