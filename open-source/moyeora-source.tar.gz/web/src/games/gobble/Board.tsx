import type { GobblePiece } from '@moyeora/shared'
import { Piece, SIZE_NAMES } from './Piece.tsx'
type Props = { board: (GobblePiece | null)[]; order: string[]; selected?: string; targets?: number[]; line?: number[]; lastTo?: number; moveKey?: number; onCell?: (cell: number) => void; selectable?: string[] }
export function Board({ board, order, selected, targets = [], line = [], lastTo, moveKey = 0, onCell, selectable = [] }: Props) {
  return <div className="gobble-board" role="group" aria-label="세 줄 게임판">
    {board.map((piece, i) => {
      const legal = targets.includes(i)
      const isSelected = !!piece && piece.id === selected
      const cls = `gobble-cell${isSelected ? ' gobble-cell--selected' : ''}${legal ? ' gobble-cell--legal' : ''}${line.includes(i) ? ' gobble-cell--win' : i === lastTo && !line.length ? ' gobble-cell--last' : ''}`
      const art = <>{piece && <div key={`${piece.id}-${i === lastTo ? moveKey : 0}`} className={i === lastTo ? 'gobble-arrive' : undefined}><Piece side={order.indexOf(piece.owner)} size={piece.size} width="100%" /></div>}{legal && <span className="gobble-target" aria-hidden="true" />}</>
      const label = `${Math.floor(i / 3) + 1}행 ${i % 3 + 1}열, ${piece ? `${order.indexOf(piece.owner) === 0 ? '주황' : '파랑'} ${SIZE_NAMES[piece.size]}` : '빈칸'}${legal ? ', 놓을 수 있어요' : ''}`
      return onCell ? <button type="button" key={i} className={cls} aria-label={label} aria-pressed={isSelected} disabled={!legal && (!piece || !selectable.includes(piece.id))} onClick={() => onCell(i)}>{art}</button>
        : <div key={i} className={cls} role="img" aria-label={label}>{art}</div>
    })}
  </div>
}
