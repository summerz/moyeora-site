import { GOBBLE, gobbleWinsNeeded, type GobbleRoom } from '@moyeora/shared'
import { ResultRow, Stamp } from '../../ui/ResultRow.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { Board } from './Board.tsx'

export function RoundResult({ room }: { room: GobbleRoom }) {
  const g = room.g
  const winner = room.players.find((p) => p.id === g.winner)
  return <div className="gobble-round-result">
    <TurnCard fixed name={winner?.name ?? null} avatar={winner?.avatar} me={g.winner === room.you} meTitle="이번 판 승리!" meHint="다음 판도 이어서 해요" other="님 승리!" none="이번 판은 무승부!" />
    <div className="gobble-board-space"><Board board={g.board} order={g.order} line={g.line} /></div>
    <div className="gobble-wins">{room.players.map((p) => <ResultRow key={p.id} p={p} me={p.id === room.you}><Stamp text={`${p.score}승`} bg={p.id === g.winner ? 'var(--amber)' : 'var(--cream)'} /></ResultRow>)}</div>
    <div className="gobble-next"><p className="gobble-footnote">{g.draw ? '승수는 그대로 · ' : ''}먼저 {gobbleWinsNeeded(g.bestOf)}승 하면 최종 승리!<br />다음 판은 선공을 바꿔요</p><Timer remainingMs={room.remainingMs} totalMs={GOBBLE.resultMs} /></div>
  </div>
}
