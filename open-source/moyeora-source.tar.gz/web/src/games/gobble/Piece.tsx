import type { GobbleSize } from '@moyeora/shared'

// 위에서 내려다본 얼굴 원. 크기 = 지름(0.5 / 0.75 / 1.0) + 표정(작은=걱정·땀, 중간=작은 입, 큰=활짝 냠). 두 팀 동일.
//  팀 = 실루엣 + 색만: 팀0 주황 동그라미, 팀1 하늘색 둥근 네모.
// var(--ink) 만 쓴다 (sticker.css 토큰). 외부 CSS 없음.
export const SIZE_NAMES = { 1: '작은 말', 2: '중간 말', 3: '큰 말' } as const

const SCALE = { 1: .5, 2: .75, 3: 1 } as const
const STROKE = { 1: 5, 2: 4.5, 3: 4 } as const
const TEAM = [
  { rim: '#e3861a', face: '#ffb347' },
  { rim: '#3a86d9', face: '#6ec3ff' },
]

/** 100×100 좌표 안에서 (x,y) 중심, 배율 k 로 그리는 말. Hero 가 재사용한다. */
export function PieceG({ side, size, x = 50, y = 50, k = 1 }: { side: number; size: GobbleSize; x?: number; y?: number; k?: number }) {
  const t = TEAM[side === 0 ? 0 : 1]
  const sq = side !== 0
  const r = 42 * SCALE[size] * (sq ? .93 : 1)
  const sw = STROKE[size]
  const shape = (rr: number, props: object) => sq
    ? <rect x={50 - rr} y={50 - rr} width={rr * 2} height={rr * 2} rx={rr * .44} {...props} />
    : <circle cx="50" cy="50" r={rr} {...props} />
  const e = size === 1 ? 1.25 : 1
  const ex = .32 * r, ey = 50 - .12 * r
  const my = 50 + .4 * r
  return <g transform={`translate(${x} ${y}) scale(${k}) translate(-50 -50)`}>
    <g transform="translate(2.5 3.5)">{shape(r, { fill: 'var(--ink)' })}</g>
    {shape(r, { fill: t.rim, stroke: 'var(--ink)', strokeWidth: sw, strokeLinejoin: 'round' })}
    {shape(r * .8, { fill: t.face })}
    <ellipse cx={50 - r * .42} cy={50 - r * .52} rx={r * .14} ry={r * .07} fill="#fff" opacity=".6" transform={`rotate(-35 ${50 - r * .42} ${50 - r * .52})`} />
    {/* 눈 */}
    {[-1, 1].map(s => <g key={s}><ellipse cx={50 + s * ex} cy={ey} rx={.15 * r * e} ry={.18 * r * e} fill="#fff" stroke="var(--ink)" strokeWidth={sw * .4} /><circle cx={50 + s * ex + (size === 1 ? s * .03 * r : .02 * r)} cy={ey + .03 * r} r={.08 * r * e} fill="var(--ink)" /></g>)}
    {/* 볼 */}
    <ellipse cx={50 - r * .56} cy={50 + r * .2} rx={r * .12} ry={r * .07} fill="#ff8fa3" opacity=".8" />
    <ellipse cx={50 + r * .56} cy={50 + r * .2} rx={r * .12} ry={r * .07} fill="#ff8fa3" opacity=".8" />
    {/* 입: 클수록 크게 벌린 "냠" */}
    {size === 3 && <g><ellipse cx="50" cy={my} rx={r * .34} ry={r * .28} fill="var(--ink)" /><ellipse cx="50" cy={my + r * .15} rx={r * .2} ry={r * .1} fill="#ff7d8a" /></g>}
    {size === 2 && <path d={`M${50 - r * .2} ${my - r * .04}q${r * .2} ${r * .22} ${r * .4} 0`} stroke="var(--ink)" strokeWidth={sw * .8} strokeLinecap="round" fill="none" />}
    {size === 1 && <g><ellipse cx="50" cy={my + r * .02} rx={r * .11} ry={r * .13} fill="var(--ink)" />
      <path d={`M${50 + r * .62} ${50 - r * .72}q${r * .2} ${r * .3} 0 ${r * .38}q${-r * .2} ${-r * .08} 0 ${-r * .38}z`} fill="#bfeaff" stroke="var(--ink)" strokeWidth="1.6" strokeLinejoin="round" /></g>}
  </g>
}

export function Piece({ side, size, width = 80 }: { side: number; size: GobbleSize; width?: number | string }) {
  return <svg className="gobble-piece" width={width} viewBox="0 0 100 100" aria-hidden="true" style={{ overflow: 'visible' }}>
    <PieceG side={side} size={size} />
  </svg>
}
