import { gobblePieces } from '@moyeora/shared'
import { Tutorial as Frame } from '../../ui/Tutorial.tsx'
import { Board } from './Board.tsx'
import { Piece } from './Piece.tsx'
const order = ['blue', 'pink']
const pieces = gobblePieces(order)
const board = (ids: (string | null)[]) => ids.map((id) => pieces.find((p) => p.id === id) ?? null)
export function Tutorial({ onClose }: { onClose: () => void }) {
  return <Frame onClose={onClose} pages={[
    { title: '내 말 세 개를 한 줄로!', art: <div className="gobble-demo"><Board order={order} board={board(['0-1-0', '0-2-0', '0-3-0', null, '1-1-0', null, null, null, '1-2-0'])} line={[0, 1, 2]} /></div>, line: <>가로·세로·대각선, 먼저 세 개를 이으면 승리!</> },
    { title: '큰 말이 작은 말을 냠!', art: <div className="gobble-size-demo"><div><Piece side={0} size={1} width="100%" /><span>작은 말</span></div><div><Piece side={1} size={2} width="100%" /><span>중간 말</span></div><div className="gobble-chew"><Piece side={0} size={3} width="100%" /><span>큰 말</span></div></div>, line: <>작은 말 위에 더 큰 말을 놓아요.<br />내 말 위에도, 상대 말 위에도!</> },
    { title: '판 위의 말도 옮겨요', art: <div className="gobble-demo"><Board order={order} board={board(['1-1-0', null, null, null, '0-3-0', null, null, null, null])} lastTo={4} /></div>, line: <>맨 위의 내 말을 다른 칸으로 옮겨요.<br />밑에 숨은 말이 다시 나와요!</> },
    { title: '말을 톡, 놓을 칸을 톡!', art: <div className="gobble-demo"><Board order={order} board={board([null, '1-1-0', null, null, '0-2-0', null, null, null, null])} selected="0-2-0" targets={[0, 1, 2, 3, 5, 6, 7, 8]} /></div>, line: <>말을 고르고 점이 있는 칸을 톡!<br />혼자라면 NPC와, 90초 지나면 자동으로.</> },
  ]} />
}
