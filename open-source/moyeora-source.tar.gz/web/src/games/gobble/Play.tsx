import { useState } from 'react'
import { GOBBLE, gobbleTargets, type GobblePiece, type GobbleRoom, type GobbleSize } from '@moyeora/shared'
import { PlayerLabel } from '../../ui/PlayerLabel.tsx'
import { Timer } from '../../ui/Timer.tsx'
import { TurnCard } from '../../ui/TurnCard.tsx'
import { Board } from './Board.tsx'
import { Piece, SIZE_NAMES } from './Piece.tsx'

function Reserve({ room, owner, interactive, enabled, selected, onSelect }: { room: GobbleRoom; owner: string; interactive: boolean; enabled: boolean; selected: string | null; onSelect: (id: string) => void }) {
  return <div className={`gobble-tray${interactive ? ' gobble-tray--me' : ''}`}>
    {([1, 2, 3] as GobbleSize[]).map((size) => {
      const remaining = room.g.reserve.filter((p) => p.owner === owner && p.size === size)
      const piece = remaining.find((p) => p.id === selected) ?? remaining[0]
      const active = !!piece && selected === piece.id
      const cls = `gobble-reserve${active ? ' gobble-reserve--selected' : ''}${remaining.length === 0 ? ' gobble-reserve--used' : ''}`
      const label = `${SIZE_NAMES[size]}, ${remaining.length}개 남음`
      const content = <><Piece side={room.g.order.indexOf(owner)} size={size} width={48} /><span><span className="gobble-reserve-name">{SIZE_NAMES[size].replace(' 말', '')} · </span>{remaining.length}개</span></>
      return interactive ? <button key={size} type="button" className={cls} aria-label={label} aria-pressed={active} disabled={!piece || !enabled} onClick={() => onSelect(piece!.id)}>{content}</button>
        : <div key={size} className={cls} aria-label={label}>{content}</div>
    })}
  </div>
}

export function Play({ room, onMove }: { room: GobbleRoom; onMove: (piece: string, to: number) => void }) {
  const [selected, setSelected] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const g = room.g
  const [ply, setPly] = useState(g.ply)
  if (ply !== g.ply) { setPly(g.ply); setSelected(null); setSending(false) }
  const myTurn = room.phase === 'choosing' && !g.settling && g.turn === room.you && !sending
  const piece = [...g.reserve, ...g.board].find((p) => p?.id === selected) ?? null
  const targets = myTurn && piece ? gobbleTargets(g.board, piece) : []
  const cur = room.players.find((p) => p.id === g.turn)
  const mine = room.players.find((p) => p.id === room.you)!
  const other = room.players.find((p) => p.id !== room.you)!
  const label = (p: typeof mine) => <div className="gobble-player"><PlayerLabel player={p} me={p.id === room.you}><span className={`gobble-side gobble-side--${g.order.indexOf(p.id)}`}>{g.order.indexOf(p.id) === 0 ? '동글 주황' : '네모 파랑'}</span></PlayerLabel></div>
  const onCell = (i: number) => {
    if (!myTurn) return
    if (piece && targets.includes(i)) { setSending(true); onMove(piece.id, i); return }
    const top: GobblePiece | null = g.board[i] ?? null
    if (top?.owner === room.you) setSelected(top.id === selected ? null : top.id)
  }
  return <div className="gobble-play">
    <TurnCard fixed hintOneLine name={cur?.name ?? null} avatar={cur?.avatar} me={g.turn === room.you} meTitle={g.settling ? '냠! 놓았어요' : '내 차례!'} meHint={g.settling ? '잠시 기다려요' : piece ? '놓을 칸을 눌러요' : '말을 골라 주세요'} other={g.settling ? '님이 놓았어요' : '님 차례'} right={!g.settling && <Timer remainingMs={room.remainingMs} totalMs={GOBBLE.chooseMs} />} />
    <div>{label(mine)}<Reserve room={room} owner={mine.id} interactive enabled={myTurn} selected={selected} onSelect={(id) => setSelected(selected === id ? null : id)} /></div>
    <div className="gobble-board-space"><Board board={g.board} order={g.order} selected={piece?.id} targets={targets} line={g.line} lastTo={g.last?.to} moveKey={g.ply} onCell={onCell} selectable={myTurn ? g.board.filter((p) => p?.owner === room.you).map((p) => p!.id) : []} /></div>
    <p className="gobble-status" role="status">{g.last?.auto ? '시간이 지나 대신 놓았어요' : g.settling ? g.last?.covered ? '냠! 작은 말을 덮었어요' : '톡! 말을 놓았어요' : myTurn ? piece ? '같은 말을 다시 누르면 선택 취소' : '말을 고르고 → 놓을 칸을 톡!' : '상대가 어디에 놓을지 지켜봐요'}</p>
    <div>{label(other)}<Reserve room={room} owner={other.id} interactive={false} enabled={false} selected={null} onSelect={() => {}} /></div>
  </div>
}
