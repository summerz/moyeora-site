import { createRoot } from 'react-dom/client'
import { Shell } from '../../ui/Shell.tsx'
import { levelLabel, modeLabel, useSudoku } from './useSudoku.ts'
import { SudokuDialogs, SudokuHome, SudokuPlay } from './views.tsx'
import './sudoku.css'

function App() {
  const state = useSudoku()
  const puzzle = state.playing ? state.session?.puzzle : undefined
  return <Shell solo fit={state.playing} safe onHelp={() => state.setDialog('help')} right={puzzle && <span className="chip sudoku-mode" aria-label={`${modeLabel(puzzle.mode)}, 난이도 ${levelLabel(puzzle.difficulty)}`}>{modeLabel(puzzle.mode)} · {levelLabel(puzzle.difficulty)}</span>}>
    {state.playing && state.session ? <SudokuPlay state={state} /> : <SudokuHome state={state} />}
    <SudokuDialogs state={state} />
  </Shell>
}

createRoot(document.getElementById('root')!).render(<App />)
