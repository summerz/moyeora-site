import { completed, type Session } from './model.ts'

export const UNIT_FLASH_STEP_MS = 36
export const UNIT_FLASH_MS = 160
export const UNIT_CELEBRATION_MS = 8 * UNIT_FLASH_STEP_MS + UNIT_FLASH_MS

/** Only units completed by this edit celebrate; each list follows its reading order. */
export function newlyCompletedUnits(before: Session, after: Session, cell: number): number[][] {
  if (cell < 0 || cell >= 81 || before.entries[cell] === after.entries[cell]) return []
  const row = Math.floor(cell / 9), col = cell % 9
  const top = Math.floor(row / 3) * 3, left = Math.floor(col / 3) * 3
  const units = [
    Array.from({ length: 9 }, (_, i) => row * 9 + i),
    Array.from({ length: 9 }, (_, i) => i * 9 + col),
    Array.from({ length: 9 }, (_, i) => (top + Math.floor(i / 3)) * 9 + left + i % 3),
  ]
  const correct = (s: Session, unit: number[]) => unit.every((p) => s.entries[p] === s.puzzle.solution[p])
  return units.filter((unit) => !correct(before, unit) && correct(after, unit))
}

/** 한 입력에는 하나의 소리만 낸다. 마지막 칸은 숫자 완성보다 전체 완성을 우선한다. */
export function editFeedback(before: Session, after: Session, cell: number) {
  if (after.mistakes > before.mistakes) return 'mistake'
  if (completed(after) && !completed(before)) return 'complete'
  const value = after.entries[cell]
  if (value && value !== before.entries[cell] && value === after.puzzle.solution[cell]) {
    const count = (s: Session) => s.entries.filter((v, p) => v === value && v === s.puzzle.solution[p]).length
    if (count(before) < 9 && count(after) === 9) return 'digit-complete'
  }
  return 'input'
}
