import { completed, type Session } from './model.ts'

/** 한 입력에는 하나의 소리만 낸다. 마지막 칸은 숫자 완성보다 전체 완성을 우선한다. */
export function editFeedback(before: Session, after: Session, cell: number) {
  if (after.mistakes > before.mistakes) return 'mistake'
  if (completed(after) && !completed(before)) return 'complete'
  const value = after.entries[cell]
  if (value && value !== before.entries[cell] && value === after.puzzle.solution[cell]) {
    const count = (s: Session) => s.entries.filter((v, p) => v === value && v === s.puzzle.solution[p]).length
    if (count(before) < 9 && count(after) === 9) return 'digit-complete'
  }
  return 'input'
}
