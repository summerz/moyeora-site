import { generate, type Difficulty, type Mode } from './generator.ts'

self.onmessage = (e: MessageEvent<{ mode: Mode; difficulty: Difficulty }>) => {
  try {
    const puzzle = generate(e.data.mode, e.data.difficulty, (attempt) => {
      if (attempt % 5 === 0) self.postMessage({ type: 'progress', attempt })
    })
    self.postMessage({ type: 'ready', puzzle })
  } catch {
    self.postMessage({ type: 'error' })
  }
}
