import './hero.css'

export function Hero({ size = 120 }: { size?: number }) {
  const values = ['1', '', '3', '', '', '', '7', '', '5']
  return <svg className="sudoku-hero" width={size} height={size} viewBox="0 0 120 120" aria-hidden="true">
    <rect x="13" y="15" width="99" height="99" rx="16" fill="var(--ink)" />
    <rect x="8" y="8" width="99" height="99" rx="16" fill="var(--cream)" stroke="var(--ink)" strokeWidth="4" />
    <rect className="sudoku-hero__selection" x="42" y="42" width="32" height="32" fill="var(--lime)" />
    {[41, 74].map((n) => <path key={n} d={`M ${n} 10 V 105 M 10 ${n} H 105`} stroke="var(--ink)" strokeWidth="2" />)}
    {values.map((v, i) => <text key={i} x={25 + i % 3 * 33} y={34 + Math.floor(i / 3) * 33} textAnchor="middle" fill="var(--ink)" fontSize="24" fontFamily="Jua, sans-serif">{v}</text>)}
    <text className="sudoku-hero__digit sudoku-hero__digit--first" x="58" y="67" textAnchor="middle" fill="var(--ink)" fontSize="24" fontFamily="Jua, sans-serif">2</text>
    <text className="sudoku-hero__digit sudoku-hero__digit--second" x="91" y="67" textAnchor="middle" fill="var(--ink)" fontSize="24" fontFamily="Jua, sans-serif">8</text>
  </svg>
}
