import { useEffect, useEffectEvent, useRef, useState } from 'react'
import { tickAt, beepAt, preloadSamples, sampleAt } from '../../ui/sound.ts'
import failureUrl from '../juice/sfx/failure.wav'
import { logic, type Difficulty, type Mode, type Puzzle } from './generator.ts'
import { availableDigits, completed, edit, loadSession, saveSession, startSession, undo, type Session } from './model.ts'

type Hint = { cell: number; value: number; explanation: string }
type Dialog = 'help' | 'new' | 'hint' | 'pause' | null
export const modeLabel = (m: Mode) => m === 'sum' ? '합 단서' : '기본'
export const levelLabel = (d: Difficulty) => ({ 1: '하', 2: '중', 3: '상' } as const)[d]

type KeyActions = {
  input: (value: number) => void
  chooseDigit: (value: number) => void
  digitFirst: boolean
  undo: () => void
  hint: () => void
  toggleNotes: () => void
  move: (direction: number) => void
}
function handleKey(e: KeyboardEvent, actions: KeyActions) {
  if (e.altKey) return
  if (e.ctrlKey || e.metaKey) {
    if (e.key.toLowerCase() === 'z') { e.preventDefault(); actions.undo() }
    return
  }
  if (/^[1-9]$/.test(e.key) && !e.ctrlKey && !e.metaKey) {
    e.preventDefault()
    if (actions.digitFirst) actions.chooseDigit(Number(e.key)); else actions.input(Number(e.key))
  } else if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') { e.preventDefault(); actions.input(0) }
  else if (e.key.toLowerCase() === 'u') { e.preventDefault(); actions.undo() }
  else if (e.key.toLowerCase() === 'h') { e.preventDefault(); actions.hint() }
  else if (['m', 'n'].includes(e.key.toLowerCase()) && !e.repeat) { e.preventDefault(); actions.toggleNotes() }
  else if (e.key.startsWith('Arrow')) {
    const direction = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 }[e.key] ?? 0
    e.preventDefault(); actions.move(direction)
  }
}

function inputState(session: Session | null, selected: number, digit: number | null) {
  const errors = new Set<number>()
  const counts = Array<number>(10).fill(0)
  session?.entries.forEach((v, p) => {
    if (!v) return
    if (v !== session.puzzle.solution[p]) errors.add(p)
    else counts[v]++
  })
  const activeDigit = digit && counts[digit] < 9 ? digit : null
  const candidates = session && selected >= 0 && !activeDigit && !session.puzzle.givens[selected]
    ? availableDigits(session.entries, selected) : null
  // Point out the location of a naked single, without revealing its digit on the keypad.
  const hideSingle = session && !session.entries[selected] && candidates?.length === 1
  return { errors, counts, activeDigit, candidates: hideSingle ? null : candidates }
}

export function useSudoku() {
  const [session, setSession] = useState<Session | null>(loadSession)
  const [playing, setPlaying] = useState(false)
  const [mode, setMode] = useState<Mode>(session?.puzzle.mode ?? 'classic')
  const [difficulty, setDifficulty] = useState<Difficulty>(session?.puzzle.difficulty ?? 1)
  const [autoHint, setAutoHint] = useState(session?.autoHint ?? true)
  const [selected, setSelected] = useState(-1)
  const [digit, setDigit] = useState<number | null>(null)
  const [pencil, setPencil] = useState(false)
  const [dialog, setDialog] = useState<Dialog>(null)
  const [hint, setHint] = useState<Hint | null>(null)
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [generationError, setGenerationError] = useState(false)
  const [saved, setSaved] = useState(true)
  const [dismissedResult, setDismissedResult] = useState(false)
  const worker = useRef<Worker | null>(null)
  const done = !!session && completed(session)
  const resultOpen = playing && done && !dismissedResult
  const isPaused = dialog === 'pause'
  const paused = !playing || !!dialog || resultOpen || busy || done
  const { errors, counts, activeDigit, candidates } = inputState(session, selected, digit)
  const resume = () => { setSelected(-1); setDigit(null); setMessage(''); setPlaying(true) }
  const goHome = () => { setSelected(-1); setDigit(null); setMessage(''); setDialog(null); setPlaying(false) }

  useEffect(() => () => { worker.current?.terminate() }, [])
  useEffect(() => preloadSamples([failureUrl]), [])
  useEffect(() => { if (session) setSaved(saveSession(session)) }, [session])
  useEffect(() => {
    if (paused) return
    let previous = performance.now()
    const advance = () => {
      const now = performance.now()
      const elapsed = now - previous
      previous = now
      if (!document.hidden) setSession((s) => s ? { ...s, elapsedMs: s.elapsedMs + elapsed } : s)
    }
    const visibility = () => { previous = performance.now() }
    const timer = window.setInterval(advance, 1000)
    document.addEventListener('visibilitychange', visibility)
    return () => { clearInterval(timer); advance(); document.removeEventListener('visibilitychange', visibility) }
  }, [paused])

  const cancelGeneration = () => { worker.current?.terminate(); worker.current = null; setBusy(false) }
  const makePuzzle = () => {
    cancelGeneration()
    setDialog(null); setBusy(true); setGenerationError(false); setMessage('')
    try {
      const next = new Worker(new URL('./generator.worker.ts', import.meta.url), { type: 'module' })
      worker.current = next
      next.onmessage = (e: MessageEvent<{ type: string; puzzle?: Puzzle }>) => {
        if (worker.current !== next) return
        if (e.data.type === 'progress') return
        next.terminate(); worker.current = null; setBusy(false)
        if (e.data.type !== 'ready' || !e.data.puzzle) { setGenerationError(true); return }
        const s = startSession(e.data.puzzle, autoHint)
        setSession(s); setPlaying(true); setSelected(-1); setDigit(null)
        setPencil(false); setDismissedResult(false)
      }
      next.onerror = () => { if (worker.current === next) { cancelGeneration(); setGenerationError(true) } }
      next.postMessage({ mode, difficulty })
    } catch { setBusy(false); setGenerationError(true) }
  }
  const requestNew = () => { if (session && !done) setDialog('new'); else makePuzzle() }
  const inputAt = (cell: number, value: number) => {
    if (!session || done || (value > 0 && counts[value] === 9)) return
    if (cell < 0) return
    if (session.puzzle.givens[cell]) { setMessage('처음 주어진 숫자는 바꿀 수 없어요.'); return }
    const next = edit(session, cell, value, pencil)
    if (next === session) return
    if (next.mistakes > session.mistakes) sampleAt(performance.now(), failureUrl)
    else tickAt(0)
    setSession(next); setMessage('')
    if (value && next.entries.filter((v, p) => v === value && v === next.puzzle.solution[p]).length === 9) {
      setDigit(null)
    }
    if (completed(next)) { beepAt(0, 'go'); setDismissedResult(false) }
  }
  const input = (value: number) => {
    if (!value) setDigit(null)
    inputAt(selected, value)
  }
  const chooseDigit = (value: number) => {
    if (!session || done || counts[value] === 9) return
    setMessage('')
    if (activeDigit === value) { tickAt(0); setDigit(null); setSelected(-1); return }
    if (!activeDigit && selected >= 0 && !session.puzzle.givens[selected]) {
      inputAt(selected, value)
    } else { tickAt(0); setDigit(value); setSelected(-1) }
  }
  const selectCell = (cell: number) => {
    setMessage('')
    setSelected(!activeDigit && selected === cell ? -1 : cell)
    if (activeDigit && session && !session.puzzle.givens[cell] && (!session.entries[cell] || errors.has(cell))) inputAt(cell, activeDigit)
    else tickAt(0)
  }
  const showHint = () => {
    if (!session || done) return
    if (session.entries.some((v, i) => v && v !== session.puzzle.solution[i])) {
      setMessage('먼저 빨간색 숫자를 다시 확인해 주세요.'); return
    }
    const result = logic(session.entries, session.puzzle.clues, session.puzzle.difficulty)
    const step = result.steps.find((s) => s.type >= 1 && s.type <= 4 && s.value > 0 && !session.entries[s.position])
    if (!step) { setMessage('지금은 숫자를 채울 힌트를 찾지 못했어요.'); return }
    const advanced = result.steps.slice(0, result.steps.indexOf(step)).some((s) => s.type >= 7)
    const explanation = step.type === 1 ? `${advanced ? '후보 쌍과 같은 상자 안의 후보 위치까지 정리하면' : '행·열·3×3 상자와 합 단서를 살펴보면'} 이 칸에 남는 후보는 하나예요.` :
      '행·열 또는 3×3 상자 안에서 이 숫자가 들어갈 수 있는 칸은 여기뿐이에요.'
    setHint({ cell: step.position, value: step.value, explanation }); setDigit(null); setSelected(step.position); setDialog('hint')
  }
  const applyHint = () => {
    if (!session || !hint) return
    const next = { ...edit(session, hint.cell, hint.value), hints: session.hints + 1 }
    setSession(next); setDialog(null)
    tickAt(0)
    if (completed(next)) { beepAt(0, 'go'); setDismissedResult(false) }
  }
  const key = useEffectEvent((e: KeyboardEvent) => {
    if (dialog || resultOpen || busy || !session || !playing) return
    if (e.target instanceof Element && e.target.closest('input, textarea, select, [contenteditable]:not([contenteditable="false"]), [role="dialog"]')) return
    if (e.defaultPrevented) return
    if (e.key === 'Escape') {
      if (!done && !e.repeat) { e.preventDefault(); setDialog('pause') }
      return
    }
    if (done) return
    handleKey(e, {
      input: (value) => { setDigit(null); input(value) }, chooseDigit, digitFirst: selected < 0,
      undo: () => { setSession(undo(session)); setMessage('') },
      hint: showHint,
      toggleNotes: () => setPencil((p) => !p),
      move: (direction) => {
        const next = selected < 0 ? 0 : Math.max(0, Math.min(80, selected + direction))
        setDigit(null); setSelected(next)
        document.querySelectorAll<HTMLElement>('.sudoku-board [role="gridcell"]')[next]?.focus()
      },
    })
  })
  useEffect(() => {
    const listener = (e: KeyboardEvent) => key(e)
    window.addEventListener('keydown', listener)
    return () => window.removeEventListener('keydown', listener)
  }, [])
  return { session, setSession, playing, setPlaying, mode, setMode, difficulty, setDifficulty, autoHint, setAutoHint, selected, selectCell, activeDigit, candidates, chooseDigit, resume, goHome, pencil, setPencil, dialog, setDialog, hint, message, setMessage, busy, generationError, saved, dismissedResult, setDismissedResult, done, resultOpen, isPaused, cancelGeneration, makePuzzle, requestNew, input, showHint, applyHint, errors, counts }
}

export type SudokuState = ReturnType<typeof useSudoku>
