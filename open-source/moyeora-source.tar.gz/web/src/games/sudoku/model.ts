import type { Puzzle } from './generator.ts'

export type Snapshot = { entries: number[]; notes: number[] }
export type Session = Snapshot & { puzzle: Puzzle; elapsedMs: number; history: Snapshot[]; hints: number; mistakes: number; autoHint: boolean }
export const STORAGE_KEY = 'moyeora-sudoku-v1'
export function startSession(puzzle: Puzzle, autoHint = true): Session {
  return { puzzle, entries: [...puzzle.givens], notes: Array(81).fill(0), elapsedMs: 0, history: [], hints: 0, mistakes: 0, autoHint }
}
export function peers(a: number, b: number) {
  return Math.floor(a / 9) === Math.floor(b / 9) || a % 9 === b % 9 ||
    (Math.floor(a / 27) === Math.floor(b / 27) && Math.floor(a % 9 / 3) === Math.floor(b % 9 / 3))
}
/** Basic candidates use visible entries only; ignore the current cell when replacing its value. */
export function availableDigits(entries: number[], cell: number): number[] {
  const used = new Set(entries.filter((v, p) => p !== cell && peers(cell, p)))
  return Array.from({ length: 9 }, (_, n) => n + 1).filter((v) => !used.has(v))
}
export function edit(session: Session, cell: number, value: number, pencil = false): Session {
  if (!Number.isInteger(cell) || cell < 0 || cell >= 81 || !Number.isInteger(value) || value < 0 || value > 9 || session.puzzle.givens[cell]) return session
  const entries = [...session.entries], notes = [...session.notes]
  if (pencil && value) {
    if (entries[cell]) return session
    notes[cell] = notes[cell]! ^ (1 << (value - 1))
  } else {
    entries[cell] = value
    notes[cell] = 0
    if (value) notes.forEach((mask, p) => { if (peers(cell, p)) notes[p] = mask & ~(1 << (value - 1)) })
  }
  if (entries.every((v, i) => v === session.entries[i]) && notes.every((v, i) => v === session.notes[i])) return session
  const mistaken = !pencil && value > 0 && value !== session.puzzle.solution[cell] && value !== session.entries[cell]
  return { ...session, entries, notes, mistakes: session.mistakes + Number(mistaken), history: [...session.history.slice(-99), { entries: session.entries, notes: session.notes }] }
}
export function undo(session: Session): Session {
  const last = session.history.at(-1)
  return last ? { ...session, ...last, history: session.history.slice(0, -1) } : session
}
export function completed(session: Session) {
  return session.entries.every((v, i) => v === session.puzzle.solution[i])
}
export function conflicts(session: Session): Set<number> {
  const bad = new Set<number>()
  session.entries.forEach((v, a) => {
    if (!v) return
    session.entries.forEach((w, b) => { if (a !== b && v === w && peers(a, b)) { bad.add(a); bad.add(b) } })
  })
  for (const h of session.puzzle.clues) {
    const a = session.entries[h.a]!, b = session.entries[h.b]!
    if (a && b && a + b !== h.sum) { bad.add(h.a); bad.add(h.b) }
  }
  return bad
}
export function formatTime(ms: number) {
  const seconds = Math.floor(ms / 1000)
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
}
const digits = (v: unknown, max = 9): v is number[] => Array.isArray(v) && v.length === 81 && v.every((n) => Number.isInteger(n) && n >= 0 && n <= max)
export function validSolution(grid: number[]): boolean {
  if (!digits(grid) || grid.includes(0)) return false
  return !grid.some((v, a) => grid.some((w, b) => a !== b && v === w && peers(a, b)))
}
function validSnapshot(value: unknown, puzzle: Puzzle): value is Snapshot {
  if (!value || typeof value !== 'object') return false
  const v = value as Snapshot
  return digits(v.entries) && digits(v.notes, 511) && v.entries.every((n, p) => (!puzzle.givens[p] || n === puzzle.givens[p]) && (!n || v.notes[p] === 0))
}
/** Stored data is untrusted; reject corrupt grids rather than trapping someone in a broken puzzle. */
export function decodeSession(text: string | null): Session | null {
  try {
    if (!text || text.length > 250_000) return null
    const s: Session = JSON.parse(text)
    // Keep older saves' original behavior when newer settings are absent.
    if (s.mistakes === undefined) s.mistakes = 0
    if (s.autoHint === undefined) s.autoHint = true
    if (typeof s.autoHint !== 'boolean') return null
    const p = s.puzzle
    if (!p || typeof p.id !== 'string' || !['classic', 'sum'].includes(p.mode) || ![1, 2, 3].includes(p.difficulty) ||
      !digits(p.givens) || !validSolution(p.solution) || !p.givens.every((v, i) => !v || v === p.solution[i]) ||
      !Array.isArray(p.clues) || p.clues.length > 8 || (p.mode === 'classic' && p.clues.length) || (p.mode === 'sum' && !p.clues.length)) return null
    const used = new Set<number>()
    for (const h of p.clues) {
      if (!h || !Number.isInteger(h.a) || !Number.isInteger(h.b) || h.a < 0 || h.b >= 81 || h.b <= h.a ||
        !((h.b === h.a + 1 && Math.floor(h.a / 9) === Math.floor(h.b / 9)) || h.b === h.a + 9) ||
        used.has(h.a) || used.has(h.b) || h.sum !== p.solution[h.a]! + p.solution[h.b]!) return null
      used.add(h.a); used.add(h.b)
    }
    if (!validSnapshot(s, p) || !Number.isFinite(s.elapsedMs) || s.elapsedMs < 0 || s.elapsedMs > 1e12 ||
      !Number.isInteger(s.hints) || s.hints < 0 || !Number.isSafeInteger(s.mistakes) || s.mistakes < 0 || !Array.isArray(s.history) || s.history.length > 100 || !s.history.every((h) => validSnapshot(h, p))) return null
    return s
  } catch { return null }
}
export function loadSession(): Session | null {
  try { return decodeSession(localStorage.getItem(STORAGE_KEY)) } catch { return null }
}
export function saveSession(session: Session): boolean {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(session)); return true } catch { return false }
}
