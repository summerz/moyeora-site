import type { Session } from './model.ts'
import { availableDigits, peers } from './model.ts'

const MAX_SINGLE_MARKS = 1

export function Board({ session, selected, activeDigit, errors, onSelect }: {
  session: Session; selected: number; activeDigit: number | null; errors: Set<number>; onSelect: (cell: number) => void
}) {
  const { entries, notes, puzzle } = session
  const value = activeDigit ?? entries[selected]
  const singles = new Set(!session.autoHint || errors.size ? [] : entries.flatMap((v, cell) => !v && availableDigits(entries, cell).length === 1 ? [cell] : []).slice(0, MAX_SINGLE_MARKS))
  return <div className="sudoku-board" role="grid" aria-label="스도쿠 숫자판" aria-rowcount={9} aria-colcount={9}>
    {Array.from({ length: 9 }, (_, row) => <div role="row" className="sudoku-board__row" key={row}>
      {Array.from({ length: 9 }, (_, col) => {
        const cell = row * 9 + col
        const single = singles.has(cell)
        const clue = puzzle.clues.find((h) => h.a === cell || h.b === cell)
        const start = clue?.a === cell
        const vertical = clue && clue.b - clue.a === 9
        const label = `${row + 1}행 ${col + 1}열, ${entries[cell] || '빈칸'}${single ? ', 들어갈 숫자가 하나인 칸' : ''}${puzzle.givens[cell] ? ', 주어진 숫자' : ''}${clue ? `, 두 칸 합 ${clue.sum}` : ''}${errors.has(cell) ? ', 오류' : ''}`
        return <button type="button" role="gridcell" key={cell} aria-label={label} aria-selected={selected === cell}
          tabIndex={selected === cell || (selected < 0 && cell === 0) ? 0 : -1} onClick={() => onSelect(cell)}
          ref={(el) => { if (el && document.activeElement?.getAttribute('role') === 'gridcell' && selected === cell) el.focus() }}
          className="sudoku-cell" data-given={!!puzzle.givens[cell]} data-selected={selected === cell} data-single={single}
          data-peer={selected >= 0 && !activeDigit && peers(selected, cell)} data-match={!!value && entries[cell] === value} data-error={errors.has(cell)}
          data-right={(col + 1) % 3 === 0 && col !== 8} data-bottom={(row + 1) % 3 === 0 && row !== 8}>
          {clue && <span aria-hidden="true" className={`sudoku-cage ${vertical ? 'sudoku-cage--vertical' : 'sudoku-cage--horizontal'} ${start ? 'sudoku-cage--start' : 'sudoku-cage--end'}`} />}
          {start && <span aria-hidden="true" className="sudoku-sum">{clue.sum}</span>}
          {entries[cell] ? <span className="sudoku-value">{entries[cell]}</span> : <span className="sudoku-notes" aria-label={notes[cell] ? `메모 ${Array.from({ length: 9 }, (_, n) => notes[cell]! & 1 << n ? n + 1 : '').filter(Boolean).join(', ')}` : undefined}>
            {Array.from({ length: 9 }, (_, n) => <span key={n}>{notes[cell]! & 1 << n ? n + 1 : ''}</span>)}
          </span>}
        </button>
      })}
    </div>)}
  </div>
}
