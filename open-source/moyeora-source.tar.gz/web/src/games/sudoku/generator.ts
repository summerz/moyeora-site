import QQWing, { type LogicResult, type SumClue } from '../../vendor/qqwing/qqwing.js'

export type Mode = 'classic' | 'sum'
export type Difficulty = 1 | 2 | 3
export type Puzzle = {
  id: string; mode: Mode; difficulty: Difficulty; givens: number[]; solution: number[]; clues: SumClue[]
}
export const DIFFICULTIES = [{ value: 1, label: '하' }, { value: 2, label: '중' }, { value: 3, label: '상' }] as const
export const MODES = [{ value: 'classic', label: '기본' }, { value: 'sum', label: '합 단서' }] as const
const pairs: [number, number][] = []
for (let a = 0; a < 81; a++) {
  if (a % 9 < 8) pairs.push([a, a + 1])
  if (a < 72) pairs.push([a, a + 9])
}
const parse = (s: string) => [...s.trim()].map((c) => c === '.' ? 0 : Number(c))
export function solver(grid: number[]) {
  const q = new QQWing()
  q.setPrintStyle(QQWing.PrintStyle.ONE_LINE)
  q.setPuzzle(grid)
  return q
}
export function logic(grid: number[], clues: SumClue[], tier: Difficulty): LogicResult {
  return solver(grid).solveLogically(clues, tier)
}
export function rate(givens: number[], clues: SumClue[]): Difficulty | null {
  for (const tier of [1, 2, 3] as const) if (logic(givens, clues, tier).solved) return tier
  return null
}
const score = (s: LogicResult) => s.filled * 1000 - s.candidateCount

/** Test every eligible sum; keep the one that unlocks the most logical progress. */
export function addSumClues(givens: number[], solution: number[], tier: Difficulty): SumClue[] | null {
  const clues: SumClue[] = []
  const q = solver(givens)
  let state = q.solveLogically(clues, tier)
  while (!state.solved && clues.length < 8) {
    const used = new Set(clues.flatMap((h) => [h.a, h.b]))
    let best: { clue: SumClue; state: LogicResult } | null = null
    for (const [a, b] of pairs) {
      if (state.grid[a] || state.grid[b] || used.has(a) || used.has(b)) continue
      const clue = { a, b, sum: solution[a]! + solution[b]! }
      const trial = q.solveLogically([...clues, clue], tier)
      if (trial.valid && score(trial) > score(state) && (!best || score(trial) > score(best.state))) best = { clue, state: trial }
    }
    if (!best) return null
    clues.push(best.clue)
    state = best.state
  }
  if (!state.solved || state.grid.some((v, i) => v !== solution[i])) return null
  return clues
}

/** Runs inside a terminable worker. Every delivered puzzle is unique and logically rated. */
export function generate(mode: Mode, difficulty: Difficulty, progress?: (attempt: number) => void): Puzzle {
  for (let attempt = 1; attempt <= 350; attempt++) {
    progress?.(attempt)
    const q = solver(Array(81).fill(0))
    if (!q.generatePuzzle()) continue
    const givens = parse(q.getPuzzleString())
    q.setRecordHistory(true)
    if (!q.solve()) continue
    if (q.getDifficulty() !== (mode === 'sum' ? 4 : difficulty)) continue
    const solution = parse(q.getSolutionString())
    const clues = mode === 'sum' ? addSumClues(givens, solution, difficulty) : []
    if (!clues || rate(givens, clues) !== difficulty || solver(givens).countSolutions() !== 1) continue
    return { id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, mode, difficulty, givens, solution, clues }
  }
  throw new Error('난이도에 맞는 문제를 만들지 못했어요')
}
