import { VisuallyHidden } from '@mantine/core'
import { GameTitle } from '../../ui/GameTitle.tsx'
import { GameHero } from '../../ui/GameHero.tsx'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { ConfirmDialog } from '../../ui/ConfirmDialog.tsx'
import { StickerModal } from '../../ui/StickerModal.tsx'
import { Tutorial } from '../../ui/Tutorial.tsx'
import { OpenSourceLink } from '../../ui/OpenSource.tsx'
import { DIFFICULTIES, MODES } from './generator.ts'
import { formatTime, undo } from './model.ts'
import { Board } from './Board.tsx'
import { levelLabel, modeLabel, type SudokuState } from './useSudoku.ts'

export function SudokuPlay({ state }: { state: SudokuState }) {
  const { session, done, selected, errors, counts, key, goHome, selectCell, activeDigit, candidates, chooseDigit, saved, message, pencil, setPencil, setSession, setMessage, setDismissedResult, input, showHint } = state
  if (!session) return null
  return <div className="sudoku-play" onKeyDown={key}>
      <div className="sudoku-heading">
        <button type="button" className="chip sudoku-menu" onClick={goHome}>← 스도쿠</button>
        <VisuallyHidden role="status">{activeDigit ? `${activeDigit} 연속 입력 · 다시 눌러 해제` : '연속 입력 해제'}</VisuallyHidden>
        <div className="sudoku-stats"><span className="sudoku-mistakes" data-active={session.mistakes > 0}>틀린 횟수: {session.mistakes}회</span><time aria-label="풀이 시간">{formatTime(session.elapsedMs)}</time></div>
      </div>
      <div className="sudoku-stage">
        <div className="sudoku-board-wrap">
          <Board session={session} selected={selected} activeDigit={activeDigit} errors={errors} onSelect={selectCell} />
          {(!saved || message) && <div className="sudoku-notice" role="status">{!saved ? '저장 공간이 부족해요. 지금은 저장되지 않아요.' : message}</div>}
        </div>
        <div className="sudoku-controls">
          <div className="sudoku-tools">
            <button type="button" onClick={() => setPencil((p) => !p)} aria-pressed={pencil} disabled={done}>메모 <span>{pencil ? 'ON' : 'OFF'}</span></button>
            <button type="button" onClick={() => { setSession(undo(session)); setMessage(''); setDismissedResult(false) }} disabled={!session.history.length}>되돌리기</button>
            <button type="button" onClick={() => input(0)} disabled={done || selected < 0}>지우기</button>
            <button type="button" onClick={showHint} disabled={done}>힌트</button>
          </div>
          <div className="sudoku-keypad" role="group" aria-label={activeDigit ? `${activeDigit} 연속 입력, 같은 숫자를 다시 누르면 해제` : '숫자 입력'}>
            {Array.from({ length: 9 }, (_, n) => {
              const value = n + 1, count = counts[value]!, complete = count === 9
              const unavailable = !!candidates && !candidates.includes(value), picked = activeDigit === value
              return <button type="button" key={value} className="btn-sticker jua" data-complete={complete} data-unavailable={unavailable} data-picked={picked} aria-pressed={picked} disabled={done || complete}
                title={complete ? '이 숫자는 모두 채웠어요' : unavailable ? '같은 행·열·상자에 이미 있는 숫자예요' : picked ? '한 번 더 누르면 연속 입력을 해제해요' : '칸을 골랐다면 입력, 숫자를 먼저 고르면 연속 입력'}
                aria-label={complete ? `${value} 모두 채움` : `${value} 입력, ${9 - count}개 남음${unavailable ? ', 겹치는 숫자' : ''}`} onClick={() => chooseDigit(value)}>
                <span className="sudoku-keypad__fill" aria-hidden="true" style={{ transform: `scaleY(${(9 - count) / 9})` }} />
                <span className="sudoku-keypad__digit">{value}</span>
              </button>
            })}
          </div>
        </div>
      </div>
    </div>
}

export function SudokuHome({ state }: { state: SudokuState }) {
  const { session, done, busy, mode, setMode, difficulty, setDifficulty, autoHint, setAutoHint, resume, setDismissedResult, requestNew, cancelGeneration, generationError } = state
  return <div className="sudoku-home">
      <GameTitle id="sudoku" />
      <GameHero id="sudoku" size={140} />
      {session && <div className="sticker sudoku-resume">
        <div className="jua">{done ? '완성한 문제' : '풀고 있던 문제'}</div>
        <p>자동 힌트 {session.autoHint ? '켜짐' : '꺼짐'}</p>
        <p>{modeLabel(session.puzzle.mode)} · 난이도 {levelLabel(session.puzzle.difficulty)} · {formatTime(session.elapsedMs)} · {session.entries.filter(Boolean).length}/81</p>
        <button type="button" className="btn-sticker" data-tone="lime" disabled={busy} onClick={() => { resume(); setDismissedResult(done) }}>{done ? '숫자판 보기' : '이어서 풀기'}</button>
      </div>}
      <div className="sticker sticker--dark sudoku-settings">
        <SegmentPicker label="문제 종류" options={MODES} value={mode} host={!busy} onPick={setMode} />
        <p>{mode === 'sum' ? '기본 규칙에 두 칸의 합 단서가 더해져요.' : '행·열·3×3 상자에 1–9를 한 번씩 넣어요.'}</p>
        <SegmentPicker label="난이도" options={DIFFICULTIES} value={difficulty} host={!busy} onPick={setDifficulty} />
        <SegmentPicker label="자동 힌트" options={[{ value: 1, label: '켜기' }, { value: 0, label: '끄기' }]} value={autoHint ? 1 : 0} host={!busy} onPick={(value) => setAutoHint(value === 1)} />
        <p>켜면 들어갈 숫자가 하나인 칸을<br />최대 한 칸씩 자동으로 표시해줘요.</p>
        <button type="button" className="btn-sticker" data-tone="amber" disabled={busy} onClick={requestNew}>{busy ? '문제를 만들고 있어요…' : '새 문제 풀기'}</button>
        {busy && <button type="button" className="btn-sticker btn-sticker--sm" data-tone="cream" onClick={cancelGeneration}>취소</button>}
        {generationError && <p role="alert">문제를 만들지 못했어요. 다시 눌러 주세요.</p>}
      </div>
      <p className="sudoku-local-note">진행 상황은 이 브라우저에 저장돼요.<br />인터넷이 끊겨도 풀 수 있어요.</p>
      <OpenSourceLink />
    </div>
}

export function SudokuDialogs({ state }: { state: SudokuState }) {
  const { session, dialog, setDialog, makePuzzle, hint, applyHint, resultOpen, setPlaying, setDismissedResult } = state
  return <>
    {dialog === 'new' && <ConfirmDialog title="새 문제를 풀까요?" message="지금 풀던 문제의 진행 상황이 새 문제로 바뀌어요." confirmLabel="새 문제 만들기" onConfirm={makePuzzle} onCancel={() => setDialog(null)} />}
    {dialog === 'help' && <Tutorial onClose={() => setDialog(null)} pages={[
      { title: '1부터 9까지, 한 번씩', art: <GameHero id="sudoku" size={160} />, line: <>가로줄·세로줄·3×3 상자에<br />같은 숫자가 겹치지 않게 채워요.</> },
      { title: '칸 먼저, 숫자 먼저', art: <div className="sudoku-example"><span>3</span><span>3</span></div>, line: <>칸→숫자는 한 칸 입력. 숫자→칸은 연속 입력.<br />같은 숫자를 다시 누르면 해제돼요.</> },
      { title: '겹치는 숫자는 흐리게', art: <div className="sudoku-example"><span>3</span><span className="sudoku-example--dim">3</span></div>, line: <>칸을 고르면 행·열·상자에 이미 있는 숫자가 흐려져요.<br />틀린 입력은 빨갛게 표시하고 횟수를 세어요.</> },
      { title: '하나 남은 칸을 찾아요', art: <div className="sudoku-example sudoku-example--single"><span>?</span></div>, line: <>자동 힌트를 켜면 하나 남은 칸을 연보라로 표시해요.<br />새 문제를 만들 때 켜거나 끌 수 있어요.</> },
      { title: '두 칸의 합이 힌트!', art: <div className="sudoku-example"><small>10</small><span>3</span><span>7</span></div>, line: <>합 단서 모드에서는 점선 안의 두 숫자를<br />더하면 구석의 작은 숫자가 돼요.</> },
      { title: '천천히, 이어서 풀어요', art: <div className="sudoku-example sudoku-example--notes"><span>1 3<br />5 7</span><span>↶</span></div>, line: <>메모로 후보를 적고, 실수는 되돌려요.<br />나갔다 와도 풀던 문제를 이어서 풀어요.</> },
    ]} />}
    {dialog === 'hint' && hint && <StickerModal onClose={() => setDialog(null)} labelledBy="sudoku-hint-title" tone="plain">
      <h2 className="jua modal__title--sm" id="sudoku-hint-title">{Math.floor(hint.cell / 9) + 1}행 {hint.cell % 9 + 1}열에 {hint.value}</h2>
      <p className="modal__msg">{hint.explanation}</p>
      <div className="modal__btns"><button type="button" className="btn-sticker" data-tone="lime" onClick={() => setDialog(null)}>직접 넣을게요</button><button type="button" className="btn-sticker" data-tone="cream" onClick={applyHint}>이 숫자 넣기</button></div>
    </StickerModal>}
    {resultOpen && session && <StickerModal labelledBy="sudoku-done-title">
      <div className="sudoku-finish" aria-hidden="true">○</div>
      <h2 className="jua modal__title" id="sudoku-done-title">다 풀었어요!</h2>
      <p className="modal__msg">{modeLabel(session.puzzle.mode)} · 난이도 {levelLabel(session.puzzle.difficulty)}<br />{formatTime(session.elapsedMs)} · 넣은 힌트 {session.hints}개</p>
      <div className="modal__btns"><button type="button" className="btn-sticker" data-tone="lime" onClick={() => { setPlaying(false); setDismissedResult(true) }}>다음 문제 고르기</button><button type="button" className="btn-sticker" data-tone="cream" onClick={() => setDismissedResult(true)}>완성한 숫자판 보기</button></div>
    </StickerModal>}
  </>
}
