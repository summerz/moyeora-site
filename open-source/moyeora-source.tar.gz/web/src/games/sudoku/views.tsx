import { VisuallyHidden } from '@mantine/core'
import { GameTitle } from '../../ui/GameTitle.tsx'
import { GameHero } from '../../ui/GameHero.tsx'
import { SegmentPicker } from '../../ui/SegmentPicker.tsx'
import { ConfirmDialog } from '../../ui/ConfirmDialog.tsx'
import { StickerModal } from '../../ui/StickerModal.tsx'
import { StatSummary } from '../../ui/StatSummary.tsx'
import { ShortcutBadge } from '../../ui/ShortcutBadge.tsx'
import { Tutorial } from '../../ui/Tutorial.tsx'
import { OpenSourceLink } from '../../ui/OpenSource.tsx'
import { DIFFICULTIES, MODES } from './generator.ts'
import { formatTime } from './model.ts'
import { Board } from './Board.tsx'
import { levelLabel, modeLabel, type SudokuState } from './useSudoku.ts'

export function SudokuPlay({ state }: { state: SudokuState }) {
  const { session, done, selected, errors, counts, isPaused, setDialog, goHome, selectCell, activeDigit, candidates, chooseDigit, saved, message, pencil, setPencil, input, showHint, celebration, undoInput } = state
  if (!session) return null
  return <div className="sudoku-play" data-pencil={pencil} inert={isPaused}>
      <div className="sudoku-heading">
        <button type="button" className="chip sudoku-menu" onClick={goHome}>← 스도쿠</button>
        <VisuallyHidden role="status">{activeDigit ? `${activeDigit} 연속 입력 · 다시 눌러 해제` : '연속 입력 해제'}</VisuallyHidden>
        <div className="sudoku-stats"><span className="sudoku-mistakes" data-active={session.mistakes > 0}>틀린 횟수: {session.mistakes}회</span><button type="button" className="sudoku-clock" disabled={done} onClick={() => setDialog('pause')} aria-label="일시정지" aria-keyshortcuts="Escape" title="일시정지 (Esc)"><time aria-label="풀이 시간">{formatTime(session.elapsedMs)}</time></button></div>
      </div>
      <div className="sudoku-stage">
        <div className="sudoku-board-wrap" data-paused={isPaused}>
          <Board session={session} selected={selected} activeDigit={activeDigit} errors={errors} onSelect={selectCell} celebration={celebration} />
          {(!saved || message) && <div className="sudoku-notice" role="status">{!saved ? '저장 공간이 부족해요. 지금은 저장되지 않아요.' : message}</div>}
        </div>
        <div className="sudoku-controls">
          <div className="sudoku-tools">
            <button type="button" onClick={() => setPencil((p) => !p)} aria-pressed={pencil} aria-keyshortcuts="M" title="메모 (M)" disabled={done}><span className="sudoku-tool__label">메모</span><ShortcutBadge>M</ShortcutBadge></button>
            <button type="button" onClick={undoInput} aria-keyshortcuts="U Control+Z Meta+Z" title="되돌리기 (U)" disabled={!session.history.length}><span className="sudoku-tool__label">되돌리기</span><ShortcutBadge>U</ShortcutBadge></button>
            <button type="button" onClick={() => input(0)} aria-keyshortcuts="Backspace Delete" title="지우기 (Backspace)" disabled={done || selected < 0}><span className="sudoku-tool__label">지우기</span><ShortcutBadge>⌫</ShortcutBadge></button>
            <button type="button" onClick={showHint} aria-keyshortcuts="H" title="힌트 (H)" disabled={done}><span className="sudoku-tool__label">힌트</span><ShortcutBadge>H</ShortcutBadge></button>
          </div>
          <div className="sudoku-keypad" role="group" aria-label={activeDigit ? `${activeDigit} 연속 입력, 같은 숫자를 다시 누르면 해제` : '숫자 입력'}>
            {Array.from({ length: 9 }, (_, n) => {
              const value = n + 1, count = counts[value]!, complete = count === 9
              const unavailable = !!candidates && !candidates.includes(value), picked = activeDigit === value
              return <button type="button" key={value} className="btn-sticker jua" data-complete={complete} data-unavailable={unavailable} data-picked={picked} aria-pressed={picked} disabled={done || complete}
                title={complete ? '이 숫자는 모두 채웠어요' : unavailable ? '같은 행·열·상자에 이미 있는 숫자예요' : picked ? '한 번 더 누르면 연속 입력을 해제해요' : '칸을 골랐다면 입력, 숫자를 먼저 고르면 연속 입력'}
                aria-label={complete ? `${value} 모두 채움` : `${value} 입력, ${9 - count}개 남음${unavailable ? ', 겹치는 숫자' : ''}`} onClick={() => chooseDigit(value)}>
                <span className="sudoku-keypad__fill" aria-hidden="true" style={{ transform: `scaleY(${(9 - count) / 9})` }} />
                <span className="sudoku-keypad__digit">{value}</span>
              </button>
            })}
          </div>
        </div>
      </div>
    </div>
}

export function SudokuHome({ state }: { state: SudokuState }) {
  const { session, done, busy, mode, setMode, difficulty, setDifficulty, autoHint, setAutoHint, resume, requestNew, cancelGeneration, generationError } = state
  const filled = session?.entries.filter(Boolean).length ?? 0
  return <div className="sudoku-home">
      <GameTitle id="sudoku" />
      <GameHero id="sudoku" size={140} />
      {session && !done && <div className="sticker sudoku-resume">
        <h2 className="jua sudoku-resume__title">풀고 있던 문제</h2>
        <div><span className="chip sudoku-mode">{modeLabel(session.puzzle.mode)} 스도쿠 · 난이도 {levelLabel(session.puzzle.difficulty)}</span></div>
        <StatSummary items={[
          { label: '채운 칸', value: <>{filled}<span>/ 81</span></> },
          { label: '풀이 시간', value: <time>{formatTime(session.elapsedMs)}</time> },
        ]} />
        <progress className="sudoku-resume__progress" aria-label="채운 칸" value={filled} max={81} />
        <div className="sudoku-resume__hint">자동 힌트 <span data-enabled={session.autoHint}>{session.autoHint ? '켜짐' : '꺼짐'}</span></div>
        <button type="button" className="btn-sticker" data-tone="lime" disabled={busy} onClick={resume}>이어서 풀기</button>
      </div>}
      <div className="sticker sticker--dark sudoku-settings">
        <SegmentPicker label="문제 종류" options={MODES} value={mode} host={!busy} onPick={setMode} />
        <p>{mode === 'sum' ? '기본 규칙에 여러 칸의 더하기 힌트가 추가됩니다.' : '행·열·3×3 상자에 1–9를 한 번씩 넣어요.'}</p>
        <SegmentPicker label="난이도" options={DIFFICULTIES} value={difficulty} host={!busy} onPick={setDifficulty} />
        <SegmentPicker label="자동 힌트" options={[{ value: 1, label: '켜기' }, { value: 0, label: '끄기' }]} value={autoHint ? 1 : 0} host={!busy} onPick={(value) => setAutoHint(value === 1)} />
        <p>켜면 들어갈 숫자가 하나인 칸을<br />최대 한 칸씩 자동으로 표시해줘요.</p>
        <button type="button" className="btn-sticker" data-tone="amber" disabled={busy} onClick={requestNew}>{busy ? '문제를 만들고 있어요…' : '새 문제 풀기'}</button>
        {busy && <button type="button" className="btn-sticker btn-sticker--sm" data-tone="cream" onClick={cancelGeneration}>취소</button>}
        {generationError && <p role="alert">문제를 만들지 못했어요. 다시 눌러 주세요.</p>}
      </div>
      <p className="sudoku-local-note">진행 상황은 이 브라우저에 저장돼요.<br />인터넷이 끊겨도 풀 수 있어요.</p>
      <OpenSourceLink />
    </div>
}

export function SudokuDialogs({ state }: { state: SudokuState }) {
  const { session, dialog, setDialog, makePuzzle, hint, applyHint, resultOpen, setPlaying, setDismissedResult, goHome } = state
  return <>
    {dialog === 'pause' && <StickerModal onClose={() => setDialog(null)} labelledBy="sudoku-pause-title" tone="plain">
      <h2 className="jua modal__title" id="sudoku-pause-title">일시정지</h2>
      <p className="modal__msg">잠깐 쉬어 가요.<br />계속하기 또는 Esc로 이어서 풀어요.</p>
      <div className="modal__btns"><button type="button" className="btn-sticker" data-tone="lime" onClick={() => setDialog(null)}>계속하기</button><button type="button" className="btn-sticker" data-tone="cream" onClick={goHome}>스도쿠 홈</button></div>
    </StickerModal>}
    {dialog === 'new' && <ConfirmDialog title="새 문제를 풀까요?" message="지금 풀던 문제의 진행 상황이 새 문제로 바뀌어요." confirmLabel="새 문제 만들기" onConfirm={makePuzzle} onCancel={() => setDialog(null)} />}
    {dialog === 'help' && <Tutorial onClose={() => setDialog(null)} pages={[
      { title: '1부터 9까지, 한 번씩', art: <GameHero id="sudoku" size={160} />, line: <>가로줄·세로줄·3×3 상자에<br />같은 숫자가 겹치지 않게 채워요.</> },
      { title: '칸 먼저, 숫자 먼저', art: <div className="sudoku-example"><span>3</span><span>3</span></div>, line: <>칸→숫자는 한 칸 입력. 숫자→칸은 연속 입력.<br />같은 숫자를 다시 누르면 해제돼요.</> },
      { title: '겹치는 숫자는 흐리게', art: <div className="sudoku-example"><span>3</span><span className="sudoku-example--dim">3</span></div>, line: <>칸을 고르면 행·열·상자에 이미 있는 숫자가 흐려져요.<br />틀린 입력은 빨갛게 표시하고 횟수를 세어요.</> },
      { title: '하나 남은 칸을 찾아요', art: <div className="sudoku-example sudoku-example--single"><span>?</span></div>, line: <>자동 힌트를 켜면 하나 남은 칸을 연보라로 표시해요.<br />새 문제를 만들 때 켜거나 끌 수 있어요.</> },
      { title: '묶음의 합이 힌트!', art: <div className="sudoku-example"><small>15</small><span>3</span><span>7</span><span>5</span></div>, line: <>플러스에서는 점선 안의 숫자를 모두<br />더하면 구석의 작은 숫자가 돼요.</> },
      { title: '천천히, 이어서 풀어요', art: <div className="sudoku-example sudoku-example--notes"><span>1 3<br />5 7</span><span>↶</span></div>, line: <>메모로 후보를 적고, 실수는 되돌려요.<br />나갔다 와도 풀던 문제를 이어서 풀어요.</> },
      { title: '키보드로 편하게', art: <div className="sudoku-example sudoku-example--notes"><span>1–9</span><span>⌨</span></div>, line: <>화살표로 칸 이동, 숫자키로 입력, Backspace로 지워요.<br />M 메모 · H 힌트 · U 되돌리기 · Esc 일시정지.</> },
    ]} />}
    {dialog === 'hint' && hint && <StickerModal onClose={() => setDialog(null)} labelledBy="sudoku-hint-title" tone="plain">
      <h2 className="jua modal__title--sm" id="sudoku-hint-title">{Math.floor(hint.cell / 9) + 1}행 {hint.cell % 9 + 1}열에 {hint.value}</h2>
      <p className="modal__msg">{hint.explanation}</p>
      <div className="modal__btns"><button type="button" className="btn-sticker" data-tone="lime" onClick={() => setDialog(null)}>직접 넣을게요</button><button type="button" className="btn-sticker" data-tone="cream" onClick={applyHint}>이 숫자 넣기</button></div>
    </StickerModal>}
    {resultOpen && session && <StickerModal labelledBy="sudoku-done-title" className="sudoku-result">
      <h2 className="jua modal__title" id="sudoku-done-title">다 풀었어요!</h2>
      <div className="sudoku-result__summary">
        <dl className="sudoku-result__intro">
          <div className="sudoku-result__game"><VisuallyHidden component="dt">게임 종류</VisuallyHidden><dd><span className="chip sudoku-mode">{modeLabel(session.puzzle.mode)} 스도쿠 · 난이도 {levelLabel(session.puzzle.difficulty)}</span></dd></div>
          <div className="sudoku-result__time"><dt>풀이 시간</dt><dd className="jua"><time>{formatTime(session.elapsedMs)}</time></dd></div>
        </dl>
        <StatSummary items={[
          { label: '사용한 힌트', value: <>{session.hints}<span>개</span></> },
          { label: '틀린 횟수', value: <>{session.mistakes}<span>회</span></> },
        ]} />
      </div>
      <div className="modal__btns"><button type="button" className="btn-sticker" data-tone="lime" onClick={() => { setPlaying(false); setDismissedResult(true) }}>다음 문제 고르기</button><button type="button" className="btn-sticker" data-tone="cream" onClick={() => setDismissedResult(true)}>완성한 숫자판 보기</button></div>
    </StickerModal>}
  </>
}
