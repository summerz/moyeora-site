# 스도쿠 전체 완성음

`complete.wav`는 Agent Audio의 Stable Audio 3 Medium으로 생성했다. 숫자 하나의
완성에는 기존 공용 `ui/sfx/success.wav`를 사용하고, 전체 완성에는 이 음원을 사용한다.

생성 프롬프트:

> A single short cheerful puzzle-complete celebration jingle for a cozy casual mobile game. Bright warm marimba and crystal bell tones play an ascending five-note major melody, finishing with a fuller sparkling harmonious chord and a gentle short decay. A clear satisfying higher level reward than a simple two-note success chime. One isolated event starts immediately, about two seconds of sound, clean studio recording.

3초 생성본의 끝 무음을 줄여 2.2초로 편집하고, 마지막 0.2초에 페이드아웃을 적용했다.
배포 파일은 44.1 kHz, 모노, 16-bit PCM WAV다. 공용 sampleAt으로 재생하므로
기존 음소거·볼륨·사용자 입력에 따른 잠금 해제를 따른다.
