import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const web = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const root = resolve(web, '..')
const out = join(web, 'public/open-source')
mkdirSync(join(out, 'licenses'), { recursive: true })
const notices = []
const visited = new Set()
function visit(name, parent) {
  if (name.startsWith('@moyeora/')) return
  const req = createRequire(join(parent, 'package.json'))
  const location = req.resolve.paths(name)?.map((p) => join(p, name, 'package.json')).find(existsSync)
  if (!location) throw new Error(`Missing dependency source: ${name}`)
  const folder = dirname(realpathSync(location)), pkg = JSON.parse(readFileSync(join(folder, 'package.json'), 'utf8'))
  const id = `${pkg.name}@${pkg.version}`
  if (visited.has(id)) return
  visited.add(id)
  const files = readdirSync(folder).filter((p) => /^(licen[sc]e|copying|notice)/i.test(p))
  const licenses = files.filter((f) => !f.endsWith('.json')).map((f, i) => {
    const filename = `${pkg.name.replaceAll('/', '_').replaceAll('@', '')}-${pkg.version}-${i}.txt`
    writeFileSync(join(out, 'licenses', filename), readFileSync(join(folder, f)))
    return `open-source/licenses/${filename}`
  })
  const repo = typeof pkg.repository === 'string' ? pkg.repository : pkg.repository?.url
  const source = repo?.replace(/^git\+/, '').replace(/^git:\/\//, 'https://').replace(/\.git$/, '')
  notices.push({ name: pkg.name, version: pkg.version, license: pkg.license ?? 'See notice', source: source?.startsWith('https://') ? source : `https://www.npmjs.com/package/${pkg.name}/v/${pkg.version}`, licenses })
  for (const dependency of Object.keys(pkg.dependencies ?? {})) visit(dependency, folder)
}
const pkg = JSON.parse(readFileSync(join(web, 'package.json'), 'utf8'))
for (const name of Object.keys(pkg.dependencies)) visit(name, web)
const shared = join(root, 'shared')
for (const name of Object.keys(JSON.parse(readFileSync(join(shared, 'package.json'), 'utf8')).dependencies ?? {})) visit(name, shared)
notices.unshift({ name: 'QQWing', version: '1.3.4', license: 'GPL-2.0-or-later', source: 'https://qqwing.com/download.html', licenses: ['open-source/qqwing-license.txt'], modified: '모여라: ES 모듈 변환, 추측 없는 난이도별 풀이와 두 칸 합 단서 처리 추가 (2026-10-12).' })
writeFileSync(join(out, 'notices.json'), JSON.stringify(notices, null, 2) + '\n')
// Whitelisted build inputs only: never include .env, Git history, or server credentials.
const inputs = ['package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json', 'web/package.json', 'web/tsconfig.json', 'web/vite.config.ts', 'web/src', 'web/public', 'web/scripts', 'shared/package.json', 'shared/tsconfig.json', 'shared/src', 'docs/sudoku']
for (const name of readdirSync(web)) if (existsSync(join(web, name, 'index.html'))) inputs.push(`web/${name}/index.html`)
inputs.push('web/index.html')
inputs.push('web/ladder/replay/index.html')
execFileSync('tar', ['-czf', join(out, 'moyeora-source.tar.gz'), '--exclude=moyeora-source.tar.gz', '--exclude=.DS_Store', '-C', root, ...inputs])
console.log(`Open source: ${notices.length} notices + buildable web/shared source archive`)
