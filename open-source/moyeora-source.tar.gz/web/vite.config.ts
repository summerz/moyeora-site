import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { join, resolve } from 'node:path'
import { defineConfig, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'

const root = fileURLToPath(new URL('.', import.meta.url))
// 버전의 단일 출처: 루트 package.json
const version: string = JSON.parse(readFileSync(resolve(root, '../package.json'), 'utf8')).version
const base = process.env.VITE_BASE || '/'
const sha = (b: Buffer | string) => createHash('sha256').update(b).digest('hex')

/** 앱 셸 서비스 워커: 빌드 때 dist 전체를 해시해 dist/sw.js 로 쓴다. 개발에는 스스로 사라지는 워커를 준다. */
function appShell(): Plugin {
  let outDir = ''
  let build = false
  return {
    name: 'moyeora-app-shell',
    // 모든 진입 페이지에 같은 iOS 설치형 앱 설정을 적용한다.
    transformIndexHtml() {
      return [
        { tag: 'meta', attrs: { name: 'apple-mobile-web-app-capable', content: 'yes' }, injectTo: 'head' },
        { tag: 'meta', attrs: { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' }, injectTo: 'head' },
      ]
    },
    configResolved(c) {
      build = c.command === 'build'
      outDir = resolve(c.root, c.build.outDir)
    },
    configureServer(server) {
      // 예전에 이 오리진에 깔린 운영 워커가 낡은 셸로 dev 를 덮지 않도록, 스스로 지우는 워커로 바꿔 준다
      server.middlewares.use('/sw.js', (_req, res) => {
        res.setHeader('Content-Type', 'text/javascript')
        res.setHeader('Cache-Control', 'no-store')
        res.end(`self.addEventListener('install', () => self.skipWaiting())
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  for (const k of await caches.keys()) await caches.delete(k)
  await self.registration.unregister()
  for (const c of await self.clients.matchAll({ type: 'window' })) c.navigate(c.url)
})()))`)
      })
    },
    closeBundle() {
      if (!build) return
      const walk = (dir: string, prefix = ''): string[] =>
        readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(join(dir, e.name), prefix + e.name + '/') : [prefix + e.name]))
      const files = walk(outDir).filter((n) => n !== 'sw.js' && n !== 'CNAME').sort()
      const hashes = files.map((n) => [n, sha(readFileSync(join(outDir, n)))])
      // 페이지 index.html 은 폴더 주소('/nunchi/')로도 요청되므로 둘 다 담는다
      // Source downloads remain available on demand; do not download the source archive on every installation.
      const assets = files.filter((n) => !n.endsWith('.tar.gz')).flatMap((n) => (n === 'index.html' || n.endsWith('/index.html') ? [base + n.slice(0, -'index.html'.length), base + n] : [base + n]))
      const shell = { version, generation: sha(JSON.stringify(hashes)).slice(0, 20), base, assets }
      const source = readFileSync(resolve(root, 'scripts/service-worker.js'), 'utf8')
      writeFileSync(join(outDir, 'sw.js'), `const SHELL = ${JSON.stringify(shell)};\n${source}`)
    },
  }
}

export default defineConfig({
  base,
  define: { 'import.meta.env.VITE_APP_VERSION': JSON.stringify(version) },
  plugins: [react(), appShell()],
  build: {
    rollupOptions: {
      input: {
        index: resolve(root, 'index.html'),
        sudoku: resolve(root, 'sudoku/index.html'),
        'sus-jar': resolve(root, 'sus-jar/index.html'),
        'who-picked': resolve(root, 'who-picked/index.html'),
        nunchi: resolve(root, 'nunchi/index.html'),
        stopwatch: resolve(root, 'stopwatch/index.html'),
        burger: resolve(root, 'burger/index.html'),
        pirate: resolve(root, 'pirate/index.html'),
        plate: resolve(root, 'plate/index.html'),
        marbles: resolve(root, 'marbles/index.html'),
        juice: resolve(root, 'juice/index.html'),
        gobble: resolve(root, 'gobble/index.html'),
        othello: resolve(root, 'othello/index.html'),
        ladder: resolve(root, 'ladder/index.html'),
        liar: resolve(root, 'liar/index.html'),
        'ladder/replay': resolve(root, 'ladder/replay/index.html'),
      },
    },
  },
})
